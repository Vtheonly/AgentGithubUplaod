"use client";

/**
 * Portal data hooks — TanStack Query wrappers around Supabase queries.
 *
 * All queries inherit Row-Level Security automatically. The parent signing in
 * via Google OAuth will only ever see rows where:
 *   - tenant_id matches their user_profiles.tenant_id, AND
 *   - they are the linked parent (parents.auth_user_id = auth.uid())
 *
 * These hooks MUST NOT introduce new business logic — they are thin readers
 * on top of the already-implemented backend. Aggregates (balance, GPA,
 * attendance rate) are computed exclusively in src/lib/canonical/ so every
 * platform derives identical values from identical rows.
 */

import { useQuery, type UseQueryResult } from "@tanstack/react-query";
import type { SupabaseClient } from "@supabase/supabase-js";
import { supabase } from "@/lib/supabase/client";
import {
  PaymentRow,
  InstallmentRow,
  InvoiceRow,
  ServiceEnrollmentRow,
  AttendanceRecordRow,
  HomeworkRow,
  GradeRow,
  AssessmentRow,
  ClassSubjectRow,
  SubjectRow,
  ClassRow,
  AcademicLevelRow,
  AcademicYearRow,
  TransportDestinationRow,
  NotificationRow,
  CalendarEventRow,
  ChatChannelRow,
  ChatMessageRow,
  ChatMessageReadEntry,
  AccountAdjustmentRow,
  NotificationPreferenceRow,
  NotificationCategory,
  StudentDocumentRow,
  StudentDocumentKind,
  LedgerEntryRow,
  PaymentAllocationRow,
  StudentAcademicHistoryRow,
  PricingConfigRow,
  GradeLevelTuitionRow,
  DiscountRow,
  AdditionalServiceRow,
  ComplementaryServiceRow,
  TimetablePublishedRow,
} from "@/lib/types/database";

/* -------------------------------------------------------------------------- */
/* Parent + children                                                          */
/* -------------------------------------------------------------------------- */
/* Note: useParent() and useStudents() are intentionally NOT exposed.
 * The parent + children data is loaded once by the AuthProvider (which
 * subscribes to Supabase onAuthStateChange) and shared via React context.
 * Exposing per-component TanStack Query hooks would duplicate the cache
 * and risk drift between the auth state and the query cache. If a future
 * feature needs to re-fetch the parent/children outside of the auth flow,
 * call `refresh()` from useAuth() instead. */

/* -------------------------------------------------------------------------- */
/* Academic context                                                           */
/* -------------------------------------------------------------------------- */

export function useAcademicLevels(): UseQueryResult<AcademicLevelRow[]> {
  return useQuery({
    queryKey: ["academic-levels"],
    queryFn: async () => {
      if (!supabase) return [];
      const { data, error } = await supabase
        .from("academic_levels")
        .select("*")
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return (data ?? []) as AcademicLevelRow[];
    },
  });
}

export function useClass(
  classId: string | null | undefined,
): UseQueryResult<ClassRow | null> {
  return useQuery({
    queryKey: ["class", classId],
    queryFn: async () => {
      if (!classId || !supabase) return null;
      const { data, error } = await supabase
        .from("classes")
        .select("*")
        .eq("id", classId)
        .maybeSingle();
      if (error) throw error;
      return (data as ClassRow) ?? null;
    },
    enabled: Boolean(classId),
  });
}

/* -------------------------------------------------------------------------- */
/* Grades                                                                     */
/* -------------------------------------------------------------------------- */

/**
 * Canonical grade data — reads the `assessments` table (migration 0029
 * shape: one row per student × subject × term × year with devoir1/devoir2/
 * examen + subject_average + coefficient). This is the table the DESKTOP
 * grade-entry flow and the ANDROID sync dispatcher write to, so the portal
 * sees exactly what staff entered. (The legacy `grades` table from 0004 is
 * no longer written by any platform — reading it left the portal's Academic
 * Hub permanently empty.)
 */
export type PortalAssessmentRow = AssessmentRow & {
  subject?: Pick<
    SubjectRow,
    | "id"
    | "name_fr"
    | "name_en"
    | "default_coefficient"
    | "is_extracurricular"
    | "passing_grade"
  > | null;
};

export function useGradesForStudent(
  studentId: string | null | undefined,
): UseQueryResult<PortalAssessmentRow[]> {
  return useQuery({
    queryKey: ["grades", studentId],
    queryFn: async () => {
      if (!studentId || !supabase) return [];
      const { data, error } = await supabase
        .from("assessments")
        .select(
          `*,
            subject:subjects(
              id, name_fr, name_en, default_coefficient, is_extracurricular, passing_grade
            )`,
        )
        .eq("student_id", studentId)
        .order("entered_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as PortalAssessmentRow[];
    },
    enabled: Boolean(studentId),
  });
}

/* -------------------------------------------------------------------------- */
/* Attendance                                                                 */
/* -------------------------------------------------------------------------- */

export function useAttendanceForStudent(
  studentId: string | null | undefined,
  options: { limit?: number } = {},
): UseQueryResult<AttendanceRecordRow[]> {
  return useQuery({
    queryKey: ["attendance", studentId, options.limit],
    queryFn: async () => {
      if (!studentId || !supabase) return [];
      let q = supabase
        .from("attendance_records")
        .select("*")
        .eq("student_id", studentId)
        .order("date", { ascending: false });
      if (options.limit) q = q.limit(options.limit);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as AttendanceRecordRow[];
    },
    enabled: Boolean(studentId),
  });
}

/* -------------------------------------------------------------------------- */
/* Homework                                                                   */
/* -------------------------------------------------------------------------- */

export function useHomeworkForClass(
  classId: string | null | undefined,
  options: { limit?: number } = {},
): UseQueryResult<HomeworkRow[]> {
  return useQuery({
    queryKey: ["homework", classId, options.limit],
    queryFn: async () => {
      if (!classId || !supabase) return [];
      // Canonical `homework` table (migration 0029) — written by the desktop
      // homework-push flow and the Android sync dispatcher.
      let q = supabase
        .from("homework")
        .select("*")
        .eq("class_id", classId)
        .order("due_date", { ascending: true });
      if (options.limit) q = q.limit(options.limit);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as unknown as HomeworkRow[];
    },
    enabled: Boolean(classId),
  });
}

/* -------------------------------------------------------------------------- */
/* Financial                                                                  */
/* -------------------------------------------------------------------------- */

export function useInstallments(
  parentId: string | null | undefined,
  options: { studentId?: string | null; limit?: number } = {},
): UseQueryResult<InstallmentRow[]> {
  return useQuery({
    queryKey: ["installments", parentId, options.studentId, options.limit],
    queryFn: async () => {
      if (!parentId || !supabase) return [];
      let q = supabase
        .from("installments")
        .select("*")
        .eq("parent_id", parentId)
        .order("due_date", { ascending: true });
      if (options.studentId) q = q.eq("student_id", options.studentId);
      if (options.limit) q = q.limit(options.limit);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as InstallmentRow[];
    },
    enabled: Boolean(parentId),
  });
}

export function usePayments(
  parentId: string | null | undefined,
  options: { studentId?: string | null; limit?: number } = {},
): UseQueryResult<PaymentRow[]> {
  return useQuery({
    queryKey: ["payments", parentId, options.studentId, options.limit],
    queryFn: async () => {
      if (!parentId || !supabase) return [];
      let q = supabase
        .from("payments")
        .select("*")
        .eq("parent_id", parentId)
        .order("collected_at", { ascending: false });
      if (options.studentId) q = q.eq("student_id", options.studentId);
      if (options.limit) q = q.limit(options.limit);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as PaymentRow[];
    },
    enabled: Boolean(parentId),
  });
}

export function useInvoices(
  parentId: string | null | undefined,
  options: { limit?: number } = {},
): UseQueryResult<InvoiceRow[]> {
  return useQuery({
    queryKey: ["invoices", parentId, options.limit],
    queryFn: async () => {
      if (!parentId || !supabase) return [];
      let q = supabase
        .from("invoices")
        .select("*")
        .eq("parent_id", parentId)
        .order("invoice_date", { ascending: false });
      if (options.limit) q = q.limit(options.limit);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as InvoiceRow[];
    },
    enabled: Boolean(parentId),
  });
}

/**
 * REMOVED (T-195, 30th session — CROSS-101 resolution): the per-payment and
 * per-parent receipt hooks that queried the orphaned `receipts` table (no
 * writer since migration 0034; 0 live rows) with ZERO consumers. Receipt
 * downloads are now real and client-side (ADR-014):
 * src/lib/pdf/payment-receipt.ts (per payment) + account-statement.ts (per
 * family). The `receipts` table itself is dropped by hub migration 0079 —
 * guarded by src/test/t-194-receipt-pdf.test.ts (S2 scan: the `receipts`
 * consumer class cannot return).
 */

export function useServiceEnrollments(
  studentId: string | null | undefined,
): UseQueryResult<ServiceEnrollmentRow[]> {
  return useQuery({
    queryKey: ["service-enrollments", studentId],
    queryFn: async () => {
      if (!studentId || !supabase) return [];
      const { data, error } = await supabase
        .from("service_enrollments")
        .select("*")
        .eq("student_id", studentId)
        .eq("is_active", true)
        .order("service_kind", { ascending: true });
      if (error) throw error;
      return (data ?? []) as ServiceEnrollmentRow[];
    },
    enabled: Boolean(studentId),
  });
}

export function useAccountAdjustments(
  parentId: string | null | undefined,
  options: { limit?: number } = {},
): UseQueryResult<AccountAdjustmentRow[]> {
  return useQuery({
    queryKey: ["adjustments", parentId, options.limit],
    queryFn: async () => {
      if (!parentId || !supabase) return [];
      // `performed_at` is the real column (migration 0007) — the previous
      // `applied_at` ordering caused a PostgREST 400 on every load.
      let q = supabase
        .from("account_adjustments")
        .select("*")
        .eq("parent_id", parentId)
        .order("performed_at", { ascending: false });
      if (options.limit) q = q.limit(options.limit);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as AccountAdjustmentRow[];
    },
    enabled: Boolean(parentId),
  });
}

/**
 * Ledger entries for a parent — the canonical source the portal replays to
 * compute balances (INV-1: balances are NEVER stored, always replayed).
 * RLS allows parents to SELECT their own entries (migration 0019).
 */
/**
 * WEAK-022 (T-035): fetch ALL ledger entries for a parent by paging with
 * `.range()` until a short page — balance replay (INV-1: balances are
 * NEVER stored, always replayed) is only correct over the ENTIRE ledger.
 * The old hook hard-capped at 500 rows, so a parent with more entries had
 * a wrong balance on the portal (oldest 500 kept, newest dropped — recent
 * payments missed, outstanding balance inflated) while the desktop's
 * `compute_parent_summary` SQL RPC replays everything.
 *
 * Extracted from the hook so it is unit-testable without React.
 *
 * @param limit optional hard cap (kept for explicit overrides; call sites
 *   that need a correct balance MUST NOT pass one).
 */
export async function fetchAllLedgerEntries(
  client: SupabaseClient,
  parentId: string,
  limit?: number,
): Promise<LedgerEntryRow[]> {
  const PAGE_SIZE = 1000;
  const all: LedgerEntryRow[] = [];
  let from = 0;
  for (;;) {
    let q = client
      .from("ledger_entries")
      .select("*")
      .eq("parent_id", parentId)
      .order("at", { ascending: true })
      .range(from, from + PAGE_SIZE - 1);
    if (limit !== undefined && limit > 0) {
      q = q.limit(limit);
    }
    const { data, error } = await q;
    if (error) throw error;
    const page = (data ?? []) as unknown as LedgerEntryRow[];
    all.push(...page);
    if (page.length < PAGE_SIZE) return all; // short page = last page
    if (limit !== undefined && all.length >= limit) return all;
    from += PAGE_SIZE;
  }
}

export function useLedgerEntries(
  parentId: string | null | undefined,
  options: { limit?: number } = {},
): UseQueryResult<LedgerEntryRow[]> {
  return useQuery({
    queryKey: ["ledger-entries", parentId, options.limit],
    queryFn: async () => {
      if (!parentId || !supabase) return [];
      return fetchAllLedgerEntries(supabase, parentId, options.limit);
    },
    enabled: Boolean(parentId),
  });
}

/* -------------------------------------------------------------------------- */
/* Notifications + Calendar                                                   */
/* -------------------------------------------------------------------------- */

export function useNotifications(
  targetUserId: string | null | undefined,
  options: { limit?: number; unreadOnly?: boolean } = {},
): UseQueryResult<NotificationRow[]> {
  return useQuery({
    queryKey: [
      "notifications",
      targetUserId,
      options.limit,
      options.unreadOnly,
    ],
    queryFn: async () => {
      if (!targetUserId || !supabase) return [];
      // Two delivery paths exist in the backend schema:
      //   1. direct targeting — notifications.target_user_id = the user
      //   2. role broadcasts — target_user_id IS NULL + target_role = the
      //      user's role ('parent' for portal accounts)
      // The old query matched ANY null-target row and missed neither
      // half correctly: parents saw no role broadcasts at all (the
      // query-side half of REALTIME-102). RLS still filters what this
      // session is allowed to read.
      let q = supabase
        .from("notifications")
        .select("*")
        .or(
          `target_user_id.eq.${targetUserId},and(target_user_id.is.null,target_role.eq.parent)`,
        )
        .order("triggered_at", { ascending: false });
      if (options.unreadOnly) q = q.eq("is_read", false);
      if (options.limit) q = q.limit(options.limit);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as NotificationRow[];
    },
    enabled: Boolean(targetUserId),
  });
}

/**
 * T-052 (NOTIF-103): the TRUE unread count via a COUNT-only query
 * (head: true — zero rows transferred). Replaces the top-app-bar's
 * `limit: 50 + .length` pattern which capped the bell badge at 50.
 * Same delivery paths as useNotifications (direct + parent role broadcast).
 */
export function useUnreadNotificationCount(
  targetUserId: string | null | undefined,
): UseQueryResult<number> {
  return useQuery({
    queryKey: ["notifications-unread-count", targetUserId],
    queryFn: async () => {
      if (!targetUserId || !supabase) return 0;
      const { count, error } = await supabase
        .from("notifications")
        .select("id", { count: "exact", head: true })
        .or(
          `target_user_id.eq.${targetUserId},and(target_user_id.is.null,target_role.eq.parent)`,
        )
        .eq("is_read", false);
      if (error) throw error;
      return count ?? 0;
    },
    enabled: Boolean(targetUserId),
  });
}

export function useUpcomingEvents(
  options: { limit?: number; from?: string } = {},
): UseQueryResult<CalendarEventRow[]> {
  return useQuery({
    queryKey: ["calendar-events", options.limit, options.from],
    queryFn: async () => {
      if (!supabase) return [];
      const from = options.from ?? new Date().toISOString();
      let q = supabase
        .from("calendar_events")
        .select("*")
        .is("is_deleted", false)
        .gte("start_at", from)
        .order("start_at", { ascending: true });
      if (options.limit) q = q.limit(options.limit);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as CalendarEventRow[];
    },
  });
}

/** Fetch calendar events in a specific month range (for the month grid view). */
export function useEventsInRange(
  rangeStart: string | null,
  rangeEnd: string | null,
): UseQueryResult<CalendarEventRow[]> {
  return useQuery({
    queryKey: ["calendar-events-range", rangeStart, rangeEnd],
    queryFn: async () => {
      if (!rangeStart || !rangeEnd || !supabase) return [];
      const { data, error } = await supabase
        .from("calendar_events")
        .select("*")
        .is("is_deleted", false)
        .gte("start_at", rangeStart)
        .lte("start_at", rangeEnd)
        .order("start_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as CalendarEventRow[];
    },
    enabled: Boolean(rangeStart && rangeEnd),
  });
}

/* -------------------------------------------------------------------------- */
/* Messages                                                                   */
/* -------------------------------------------------------------------------- */

/**
 * Fetch all chat channels where the current user is a member.
 * The `member_ids` column is a uuid[] — we filter with `.contains()`.
 * RLS also enforces this server-side, so even a buggy filter can't leak data.
 */
export function useChatChannels(
  userProfileId: string | null | undefined,
): UseQueryResult<ChatChannelRow[]> {
  return useQuery({
    queryKey: ["chat-channels", userProfileId],
    queryFn: async () => {
      if (!userProfileId || !supabase) return [];
      const { data, error } = await supabase
        .from("chat_channels")
        .select("*")
        .contains("member_ids", [userProfileId])
        // T-101 (CHAT-104, migration 0061): archived channels are hidden;
        // ordering is by LAST ACTIVITY (the 0061 trigger maintains
        // last_message_at on every insert), not by any-column updated_at.
        .is("archived_at", null)
        .order("last_message_at", { ascending: false, nullsFirst: false });
      if (error) throw error;
      return (data ?? []) as ChatChannelRow[];
    },
    enabled: Boolean(userProfileId),
  });
}

export function useChatMessages(
  channelId: string | null | undefined,
  options: { limit?: number } = {},
): UseQueryResult<ChatMessageRow[]> {
  return useQuery({
    queryKey: ["chat-messages", channelId, options.limit],
    queryFn: async () => {
      if (!channelId || !supabase) return [];
      let q = supabase
        .from("chat_messages")
        .select("*")
        .eq("channel_id", channelId)
        .is("deleted_at", null)
        .order("sent_at", { ascending: true });
      if (options.limit) q = q.limit(options.limit);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as ChatMessageRow[];
    },
    enabled: Boolean(channelId),
  });
}

/**
 * Count of unread chat messages across all of the user's channels.
 * A message is unread when its `read_by` jsonb array does NOT contain an
 * entry with `user_id = current_user`.
 *
 * Accuracy note (WEAK-023, T-065): the query fetches the latest 500
 * `chat_messages` rows TOTAL (ordered by `sent_at` desc — NOT "200 per
 * channel" as a stale comment once claimed), relying on RLS to expose only
 * channels the user is a member of. The returned count is therefore a
 * LOWER BOUND: if unread + read volume across all channels exceeds the
 * 500-row window, older unread messages are not counted. An exact count
 * would need a channel-scoped fetch or a server-side counter. (Since
 * migration 0061 / T-099, chat HAS production writers — the old
 * justification "no production writers (CHAT-103 / UNKNOWN-005)" no
 * longer applies; the lower-bound caveat itself remains true and the
 * exact counter stays a follow-up.)
 *
 * The bottom-nav badge uses this instead of the previous (incorrect) count
 * from the `notifications` table.
 */
export function useUnreadChatCount(
  userProfileId: string | null | undefined,
): UseQueryResult<number> {
  return useQuery({
    queryKey: ["chat-unread-count", userProfileId],
    queryFn: async () => {
      if (!userProfileId || !supabase) return 0;
      // Latest 500 chat_messages TOTAL (RLS limits this to channels the
      // user is a member of — there is no per-channel split; see the
      // hook's accuracy note). Counted client-side: unread = authored by
      // someone else AND no read_by entry for this user.
      const { data, error } = await supabase
        .from("chat_messages")
        .select("id, author_id, read_by, channel_id")
        .is("deleted_at", null)
        .order("sent_at", { ascending: false })
        .limit(500);
      if (error) throw error;
      const rows = (data ?? []) as unknown as Array<{
        id: string;
        author_id: string;
        read_by: ChatMessageReadEntry[] | null;
      }>;
      // Only count messages authored by someone OTHER than this user.
      const unread = rows.filter((r) => {
        if (r.author_id === userProfileId) return false;
        const reads = Array.isArray(r.read_by) ? r.read_by : [];
        return !reads.some((entry) => entry.user_id === userProfileId);
      });
      return unread.length;
    },
    enabled: Boolean(userProfileId),
    // Refetch on window focus so the badge updates when the user returns.
    refetchOnWindowFocus: true,
  });
}

/* -------------------------------------------------------------------------- */
/* Notification preferences                                                    */
/* -------------------------------------------------------------------------- */

export const NOTIFICATION_CATEGORIES: NotificationCategory[] = [
  "payment",
  "absence",
  "message",
  "announcement",
  "grade",
  "homework",
  "calendar",
  "account",
  "system",
];

/**
 * Fetch the user's per-category notification preferences.
 * Missing rows are treated as "both push and in-app enabled" (default opt-in).
 * The hook returns a complete map keyed by category so callers don't need
 * to handle missing rows themselves.
 */
export function useNotificationPreferences(
  userProfileId: string | null | undefined,
): UseQueryResult<Map<NotificationCategory, NotificationPreferenceRow>> {
  return useQuery({
    queryKey: ["notification-preferences", userProfileId],
    queryFn: async () => {
      const map = new Map<NotificationCategory, NotificationPreferenceRow>();
      if (!userProfileId || !supabase) return map;
      const { data, error } = await supabase
        .from("notification_preferences")
        .select("*")
        .eq("user_profile_id", userProfileId);
      if (error) throw error;
      for (const row of (data ?? []) as NotificationPreferenceRow[]) {
        map.set(row.category, row);
      }
      return map;
    },
    enabled: Boolean(userProfileId),
  });
}

/* -------------------------------------------------------------------------- */
/* Student documents                                                          */
/* -------------------------------------------------------------------------- */

/**
 * Fetch all documents uploaded for a given student.
 * RLS limits this to the parent's own children (migration 0027).
 */
export function useStudentDocuments(
  studentId: string | null | undefined,
): UseQueryResult<StudentDocumentRow[]> {
  return useQuery({
    queryKey: ["student-documents", studentId],
    queryFn: async () => {
      if (!studentId || !supabase) return [];
      const { data, error } = await supabase
        .from("student_documents")
        .select("*")
        .eq("student_id", studentId)
        .order("uploaded_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as StudentDocumentRow[];
    },
    enabled: Boolean(studentId),
  });
}

/**
 * Fetch all documents for all of the parent's children, merged.
 * Useful for a "family documents" overview.
 */
export function useAllStudentDocuments(
  studentIds: string[],
): UseQueryResult<StudentDocumentRow[]> {
  return useQuery({
    queryKey: ["student-documents-all", studentIds],
    queryFn: async () => {
      if (studentIds.length === 0 || !supabase) return [];
      const { data, error } = await supabase
        .from("student_documents")
        .select("*")
        .in("student_id", studentIds)
        .order("uploaded_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as StudentDocumentRow[];
    },
    enabled: studentIds.length > 0,
  });
}

/* -------------------------------------------------------------------------- */
/* Receipts — see the REMOVED note above (T-195/CROSS-101/ADR-014)          */
/* -------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------- */
/* Children enrollments (T-211 — the owner's "children's enrollments"        */
/* mandate: per-child service enrollments + the REAL per-student fee        */
/* schedule + the academic-year context)                                     */
/* -------------------------------------------------------------------------- */

/**
 * The child's installment schedule — every tranche the school issued for
 * THIS student (fees + transport), straight from the canonical
 * `installments` table (0007 + 0032). This is the REAL enrollment billing
 * data on the live DB (1 276 rows, 100% student-attributed) — unlike
 * `service_enrollments` which is currently empty (32nd-session probe).
 *
 * The financial view filters installments by PARENT; this per-student view
 * is what the enrollment card shows (amount_due / amount_paid per tranche).
 */
export function useInstallmentsForStudent(
  studentId: string | null | undefined,
  options: { activeOnly?: boolean } = {},
): UseQueryResult<InstallmentRow[]> {
  return useQuery({
    queryKey: [
      "installments-for-student",
      studentId,
      options.activeOnly ?? false,
    ],
    queryFn: async () => {
      if (!studentId || !supabase) return [];
      // The full installment schedule for the child — every tranche the
      // school issued (fees + transport), including paid history. The
      // financial view filters by parent; this per-student view is what
      // the enrollment card shows (amount_due/paid per tranche).
      let q = supabase
        .from("installments")
        .select("*")
        .eq("student_id", studentId)
        .order("tranche_number", { ascending: true });
      if (options.activeOnly) q = q.neq("status", "paid");
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as InstallmentRow[];
    },
    enabled: Boolean(studentId),
  });
}

/**
 * The CURRENT academic year row (exactly one per the seed: is_current=true).
 * Gives the enrollment card its "Année scolaire 2026-2027" context line.
 */
export function useCurrentAcademicYear(): UseQueryResult<AcademicYearRow | null> {
  return useQuery({
    queryKey: ["academic-year-current"],
    queryFn: async () => {
      if (!supabase) return null;
      const { data, error } = await supabase
        .from("academic_years")
        .select("*")
        .eq("is_current", true)
        .maybeSingle();
      if (error) throw error;
      return (data as AcademicYearRow) ?? null;
    },
  });
}

/**
 * A single transport destination (label_fr / label_ar + tranche months) —
 * the `destination_id` join target for transport service_enrollments.
 * RLS: tenant-scoped via pricing_configs (0019).
 */
export function useTransportDestination(
  destinationId: string | null | undefined,
): UseQueryResult<TransportDestinationRow | null> {
  return useQuery({
    queryKey: ["transport-destination", destinationId],
    queryFn: async () => {
      if (!destinationId || !supabase) return null;
      const { data, error } = await supabase
        .from("transport_destinations")
        .select(
          "id, code, label_fr, label_ar, annual_amount, tranche_1_amount, tranche_2_amount, tranche_3_amount, tranche_1_month, tranche_2_month, tranche_3_month",
        )
        .eq("id", destinationId)
        .maybeSingle();
      if (error) throw error;
      return (data as TransportDestinationRow) ?? null;
    },
    enabled: Boolean(destinationId),
  });


  

}



/* -------------------------------------------------------------------------- */
/* Payment Coverage Allocations                                               */
/* -------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------- */
/* Pricing catalog (T-333 / DATA-016 — the exhaustive per-service profile)    */
/* -------------------------------------------------------------------------- */

/**
 * The full pricing catalog snapshot behind the per-service pricing profile:
 * the active pricing_configs row + the per-grade tuition grid (with the
 * academic_levels join for grade codes/cycles) + transport destinations +
 * discounts + additional/complementary services + the year label.
 *
 * RLS: every table is tenant-scoped SELECT for authenticated (0019), so a
 * signed-in parent reads the same catalog the staff clients render.
 */
export interface PricingCatalogData {
  config: PricingConfigRow | null;
  tuitionRows: GradeLevelTuitionRow[];
  /** academic_level_id → grade code + cycle (the join carried on tuition rows). */
  gradeInfoByLevelId: Map<string, { code: string; cycle: string | null }>;
  transportRows: TransportDestinationRow[];
  discountRows: DiscountRow[];
  additionalRows: AdditionalServiceRow[];
  complementaryRows: ComplementaryServiceRow[];
  academicYearLabel: string | null;
}

type TuitionWithLevel = GradeLevelTuitionRow & {
  academic_levels: { grade_code: string; cycle: string | null } | null;
};

export function usePricingCatalog(): UseQueryResult<PricingCatalogData | null> {
  return useQuery({
    queryKey: ["pricing-catalog"],
    queryFn: async () => {
      if (!supabase) return null;
      const [configRes, tuitionRes, transportRes, discountRes, additionalRes, complementaryRes, yearRes] =
        await Promise.all([
          supabase
            .from("pricing_configs")
            .select("*")
            .eq("is_active", true)
            .order("created_at", { ascending: false })
            .limit(1)
            .maybeSingle(),
          supabase
            .from("grade_level_tuition")
            .select("*, academic_levels(grade_code, cycle)")
            .order("id"),
          supabase.from("transport_destinations").select("*").order("code"),
          supabase.from("discounts").select("*").order("code"),
          supabase.from("additional_services").select("*").order("code"),
          supabase.from("complementary_services").select("*").order("code"),
          supabase
            .from("academic_years")
            .select("id, label")
            .eq("is_current", true)
            .maybeSingle(),
        ]);
      // The catalog tables are reference data: partial failure degrades the
      // profile's catalog legs (rendered as "—") rather than throwing the
      // whole financial tab — every leg is independently optional.
      const config = (configRes.data as PricingConfigRow | null) ?? null;
      const tuitionRows = (tuitionRes.data ?? []) as unknown as TuitionWithLevel[];
      const gradeInfoByLevelId = new Map<string, { code: string; cycle: string | null }>();
      for (const t of tuitionRows) {
        if (t.academic_levels) {
          gradeInfoByLevelId.set(t.academic_level_id, {
            code: t.academic_levels.grade_code,
            cycle: t.academic_levels.cycle,
          });
        }
      }
      return {
        config,
        tuitionRows: tuitionRows.map(({ academic_levels: _levels, ...rest }) => rest),
        gradeInfoByLevelId,
        transportRows: (transportRes.data ?? []) as TransportDestinationRow[],
        discountRows: (discountRes.data ?? []) as DiscountRow[],
        additionalRows: (additionalRes.data ?? []) as AdditionalServiceRow[],
        complementaryRows: (complementaryRes.data ?? []) as ComplementaryServiceRow[],
        academicYearLabel: (yearRes.data as { label: string } | null)?.label ?? null,
      } satisfies PricingCatalogData;
    },
  });
}

/**
 * The classes lookup for a set of class ids (the child-coverage class labels
 * inside the per-service profile). RLS: tenant-scoped SELECT (0019).
 */
export function useClassesByIds(
  classIds: readonly string[],
): UseQueryResult<Map<string, string>> {
  const ids = [...new Set(classIds.filter(Boolean))];
  return useQuery({
    queryKey: ["classes-by-ids", ids],
    queryFn: async () => {
      if (ids.length === 0 || !supabase) return new Map<string, string>();
      const { data, error } = await supabase
        .from("classes")
        .select("id, name, code, room")
        .in("id", ids);
      if (error) throw error;
      const map = new Map<string, string>();
      for (const c of (data ?? []) as { id: string; name: string | null; code: string | null; room: string | null }[]) {
        map.set(c.id, [c.name ?? c.code, c.room].filter(Boolean).join(" · ") || c.code || c.id);
      }
      return map;
    },
    enabled: ids.length > 0,
  });
}

export function usePaymentAllocations(
  paymentId: string | null | undefined
): UseQueryResult<PaymentAllocationRow[]> {
  return useQuery({
    queryKey: ["payment-allocations", paymentId],
    queryFn: async () => {
      if (!paymentId || !supabase) return [];
      const { data, error } = await supabase
        .from("payment_allocations")
        .select("*")
        .eq("payment_id", paymentId)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as PaymentAllocationRow[];
    },
    enabled: Boolean(paymentId),
  });
}

/* -------------------------------------------------------------------------- */
/* Student Academic History                                                   */
/* -------------------------------------------------------------------------- */

export function useStudentAcademicHistories(
  studentId: string | null | undefined
): UseQueryResult<StudentAcademicHistoryRow[]> {
  return useQuery({
    queryKey: ["student-academic-histories", studentId],
    queryFn: async () => {
      if (!studentId || !supabase) return [];
      const { data, error } = await supabase
        .from("student_academic_histories")
        .select("*")
        .eq("student_id", studentId)
        .order("academic_year", { ascending: false });
      if (error) throw error;
      return (data ?? []) as StudentAcademicHistoryRow[];
    },
    enabled: Boolean(studentId),
  });
}
/* -------------------------------------------------------------------------- */
/* Timetable (Emploi du temps) — T-408 (SCHED-106)                            */
/* -------------------------------------------------------------------------- */

/*
 * The parent-portal projection of the ONE canonical published timetable:
 * v_timetable_published (migration 0113 §4) exposes the entries of the
 * PUBLISHED version for the child's class with denormalized subject /
 * teacher / room names. Drafts and trials are never visible to parents
 * (0109/0110 RLS + the view's published-only join).
 */
export function usePublishedTimetable(
  classId: string | null | undefined,
): UseQueryResult<TimetablePublishedRow[]> {
  return useQuery({
    queryKey: ["timetable-published", classId],
    queryFn: async () => {
      if (!classId || !supabase) return [];
      const { data, error } = await supabase
        .from("v_timetable_published")
        .select("*")
        .eq("class_id", classId)
        .order("period_index", { ascending: true });
      if (error) throw error;
      return (data ?? []) as TimetablePublishedRow[];
    },
    enabled: Boolean(classId),
  });
}
