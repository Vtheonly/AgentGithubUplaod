# Task Registry — Master Recovery Task List

> **This is the authoritative todo list for all remaining work.** Agents must not create separate task lists, TODO files, or progress notes anywhere. Status transitions follow `definition-of-done.md`; completion evidence goes to `change-log.md`.
>
> **Evidence base:** every task below was derived from the problem registry, which consolidates the two archived audit reports in [`docs/audits/`](../audits/README.md) (86 + 99 findings). When a task's problem entry is not detailed enough, read the raw finding in the audit files — full end-to-end traces and git forensics live there.
> **Commit rule (AGENTS.md §14):** every commit must state the task completed, what is left, what was changed, what was verified, and the next task.
>
> Statuses: `Not Started` · `Needs Investigation` · `Ready` (understood, dependencies cleared) · `In Progress` · `Blocked` · `Deferred`. Within `Ready`, work P0 → P1 → P2 → P3. Pick tasks via `next-task.md`.

## Progress summary (2026-09-14, CLOSED at the 65th session — owner mandate "be 100% certain that when the Excel file from Suivis clients is imported while the desktop database is completely empty, all of its data is imported correctly and completely; test specifically from a clean, empty desktop state; no missing records, no broken relationships, no incorrect calculations, no partial imports"): T-364..T-366 (3 tasks) — T-365 (the NEW two-layer empty-state restore integration suite, 13 tests, ground truth read from the REAL workbook's own cells via exceljs — INDEPENDENT of the pipeline) + T-364 (the three re-import/identity defects the suite flushed out, all fixed at the repository/adapter layer: IMPORT-107 the ledger-flush idempotency+atomicity [adapter pre-dedupe by (sourceType|sourceId) + Supabase bulkAppend/bulkCollect ON CONFLICT DO NOTHING with loud Err + truthful cache], IMPORT-108 the MockPaymentRepository.bulkCollect the mock never had [the per-row collect() fallback double-booked the ledger, double-allocated installments, ignored the deterministic IMP- receipts], IMPORT-109 the findExistingStudent substring cross-wiring [the BELGRIMAT sibling pair — exact order-independent identity match now]) + T-366 (closeout: registries, change-log, current-state, next-task, push). THE ANSWER, WITH EVIDENCE: from a completely empty desktop database the real workbook restores 390 students / 253 parents / 891 payments (Σ 55,227,100 DZD = the workbook's own TOTAL VERSEMENTS) / 1968 installments (Σ due 113,518,800 DZD) / 1283 ledger entries / 0 rows rejected / 201 print-layout rows correctly skipped; every per-row financial matches the workbook's own cells; every FK resolves; a mid-import failure rolls back to EMPTY; the second import is a complete NO-OP in both repository modes. The T-012/T-015 fakes extended with the upsert surface (contracts re-verified 11/11). Suites at close: desktop 155 files / 3301 / 0 (baseline 152/3280) + tsc 0 + eslint 0 errors; the 64th-session closeout merged forward, zero conflicts. Registry: +4 problems (IMPORT-106/107/108/109, all CLOSED TESTED) — 268 detailed entries. No backend change (no migration, no RPC, no RLS — §15.4 held).

## Progress summary (2026-09-14, CLOSED at the 62nd session — the owner matière-architecture mandate [commit 158d806 "idk mattier is wrong" is the trigger]): T-343..T-349 ALL COMPLETE — MATIERE-500 CLOSED (TESTED + the live DB leg VERIFIED LIVE). T-343 (registration + ADR-018, 7bde1cb), T-344 (migration 0094 applied LIVE atomically — 19/19 dry-run + 19/19 post-apply, 4 production assessment rows byte-identical, ae553ab), T-345 (desktop domain + resolver + recipe engine + the 14 fallback chains replaced, ecb3cda — ladder 146/3218/0), T-346 (SubjectConfigurationsPanel, ec80780 — 147/3221/0), T-347 (website verbatim resolver port + cc display end to end, 3a01902 — 46/607/0 + LIVE RLS probes), T-348 (Android mirror: SubjectConfig.kt + the cc-aware formula + Room 15→16 + the corpus runner ops, 3b3a38d — 62/579/0 on the merged tree + the 7/7 t345 corpus equivalence), T-349 (this closeout). The canonical architecture is now on ALL THREE platforms: subjects = identity, subject_configurations = context (subject × year × level × direction: coefficient, subject_code, passing_grade, is_extracurricular, grading_recipe incl. the contrôle-continu cc component), assessment rows snapshot the resolution (never retroactive), ONE resolver per platform, NEW exam_sessions table, the seeded default recipe {1,1,2,0} bit-identical to the historical engine.

## Progress summary (2026-09-13, updated at the 60th session CLOSE — owner mandate "the student grades/marks on the website: exam grades already entered and recorded are not displaying correctly; make the website handle grades the same way as the desktop application (multiple subjects, multiple exams, multiple grades, several academic records); fix the retrieval/display logic; test with the live tokens; document; commit; zip + push"): T-336 (1 task + the T-337 registration) — T-336 (GRADE-102 CLOSED — VERIFIED LIVE: the owner's symptom root-caused NOT to the retrieval layer (the portal's exact PostgREST query under the parent's RLS returns the canonical assessments with the joined subject — 11/11 live data-path checks) but to per-child ID ROUTING: every per-child view derives its active kid from the store's activeStudentId, which was only auto-selected inside the StudentSwitcher components that render ONLY for 2+ children — a single-child parent (the most common family shape) kept a null id FOREVER, so the Academic view queried useGradesForStudent(undefined) → "Aucune note pour cette période" with entered grades; the dashboard's local kids[0] fallback masked it. Fix: ONE canonical auto-select effect in the AppShell (null OR stale-id → kids[0]) — fixes academic/attendance/homework/financial at once + resets stale ids after account re-bindings; duplicated switcher effects removed. Desktop-parity companions in the same task: the MOYENNE/MATIÈRE KPIs now follow the term filter (per-term canonical GPA = the desktop AcademicTab + fn_calculate_student_term_gpa + Android termGpas semantics; all-terms tab = the Android yearlyGpa convention) and partial marks show the desktop/Android "Moyenne à paraître" hint instead of a silent "—" (i18n fr/ar/en). New discovery registered: REALTIME-105 (the portal's five realtime subscriptions target tables NOT in the supabase_realtime publication — live probe: assessments 0 events vs audit_logs [member] 1 event; fix = migration 0094, task T-337). Suites at close: website 45 files / 599 tests / 0 (+14 T-336 tests) + tsc 0 + eslint clean + strict build green; live browser RED/GREEN round-trip (before: empty view for the bound single-child ATTOUCHE parent with recorded grades; after: full display — banner, 11.00 GPA, Arabe 11.00·11.00·11.00); zero-residue cleanup (3 owner rows untouched, 2 original parent bindings restored).

## Progress summary (2026-09-12, updated at the 54th session CLOSE — owner mandate "fix the calculation modules to match the CSVs to the letter, including the sticker-price case; update desktop + backend consistently; test everything; zip + push"): T-315…T-319 (5 tasks, the CALC-001 realignment) — T-315 (the REAL price matrix: `school-price-matrix.ts` extracted from the workbook's raw formulas — FI per grade 18k–30k PER STUDENT, scolarité 135k–365k, V2/2V/v3 tranche stickers with the remise on V2 ONLY, 20-town transport matrix 40k–65k, real services PSY/ORTH/E-PLANT/Ratrapage/AUTISTE, 5%-of-scolarité early rate; the 5 fictional discount rules reduced to the 2 real ones in desktop + Android lockstep; seeds/labels/destination-mapper/importer realigned) + T-316 (the wizard: ghost fields REMOVED, negotiated remise + sticker-price flag + prior balances REMBOURSEMENT/DETTES collected, per-student FI, 20 towns selectable; mock buildRegistrationBilling on the real model with per-student FI charges) + T-317 (backend migration 0089 applied LIVE atomically HTTP 201: grade_level_tuition.registration_fee column + the real grid + 24 transport town rows + 7 real services + fictional discounts deactivated + full_annual 5%; post-checks 5/5 GREEN; the missing updated_at columns on the 0006 catalog tables added additively — the touch_updated_at triggers were crashing on any UPDATE) + T-318 (Android mirror: DiscountEngine.kt lockstep + the 5 shared discount scenario fixtures corrected; suite re-run pending toolchain re-provision) + T-319 (the corpus verification suite: fixture from the workbook [390 ETAT rows + 10 Devis quotes] + 11 tests: devis formula, V2−remise rule, sticker-price SEDIKI case, transport matrix, 5%-of-scolarité, per-quote totals — 11/11 GREEN; full desktop suite 139 files / 3 119 / 0 + tsc 0 errors + the AI tools' 700k hallucination corrected). Live chain 0001–0089 zero drift (0088 workflow_condition_subtype was already registered live — my first apply attempt caught the collision BEFORE any write; 0089 is the realignment). Registry: +CALC-001 [CLOSED — TESTED + VERIFIED LIVE] + ADR-017. Owner-gated residual: Android suite re-run needs the JDK21+SDK35 toolchain re-provision (script committed); the EF ai-proxy redeploy is NOT needed (no pricing text in the EF — the 700k fix was desktop-side).)

## Progress summary (2026-09-09, updated at the 36th repair session CLOSE — owner mandate "apply the AI review (unified 3-zone dashboard integration blueprint), verify the migration tokens, test everything, zip + push": T-243..T-245 (3 tasks) — T-243 (UI-306 CLOSED: the dashboard Overview is now the review's 3-zone layout — Zone A 12-col/8: 4 sparkline KPI cards [trend+delta OPTIONAL, rendered only from REAL series — the revenue card is the only one with a real series; students/debt/attendance render clean] → hero monotone revenue spline [REAL series; T-088 supersession documented — trend view here, detail view stays in the drill-down] → recovery funnel [REAL debtAging family counts: En retard → ≤60j → 61–90j → >90j; the review's admissions numbers were NOT rendered — no repository contract carries demande/dossier counts, §15.16] + weekly operating rhythm [REAL canonical Payment[] stream via one new page-level subscription; Dim→Jeu Algerian week; refunded excluded; range-filtered] → DashboardCalendar kept; Zone B 4: InsightsRail [AI decision card from the REAL overdue census — no fabricated N-1 projection or tranche deadline; the radial gauge = the REAL collection rate encaissé/(encaissé+créances) — the review's 84.9M/115M target has no repository source; the À-relancer feed = top-3 REAL topDebtors] + topbar Cmd+K placeholder now hints NL queries; NEW dashboard-theme.ts = the single Recharts styling source) + T-244 (live migration-token round 18/18 GREEN: dual-key auth health, RLS anon 0-rows ×5 core tables, chain live=81/local=81 ZERO DRIFT, EF fleet 14/14 ACTIVE 1:1 with the hub source, anonymous EF → 401, ALLOWED_ORIGINS canonical 4-origin set echoing + non-allowlisted rejected, committed-key consistency vs the owner sheet ×3; the canonical set re-proven intact — no apply needed) + T-245 (closeout: +UI-306 problem entry [206 detailed], status flips, this summary, change-log, current-state, next-task 37th recommendation, conventional commits, zips + push). Suites at close: desktop 112 files / 2694 / 0 (+7 net: the superseded T-088 dashboard-restructure.test.tsx [10 tests] replaced by dashboard-3zone.test.tsx [17 tests — the surviving T-088 invariants re-pinned]) + tsc + eslint 0 err (399 warnings, net −14) + vite build green; website re-verified untouched-green 40/544/0 + lint + strict build; Android untouched (desktop-scope UI change, zero contract impact per §10). Live chain 0001–0084 zero drift. Owner-gated residuals unchanged.)

## Progress summary (2026-09-07, updated at the 35th repair session CLOSE — owner mandate "Personnel/Workforce RBAC overhaul: strict role-based workspaces (Admins/Clerks keep Dashboard/Pédagogy/CRM/Finances; operational staff locked to role-tailored Personnel dashboards), teacher self-contained workspace (grades + roll-call only), reliable admin account provisioning, no mock workarounds, rigorous tests, desktop + mobile": T-233..T-242 (10 tasks) — T-233 (TEST-306 flaky fixture fixed: att-early re-stamped to same-UTC-day midnight — the baseline was failing at 00:16Z but passing after 07:00Z; suite green at every hour after) + T-234 (RBAC-300 desktop: permissions.ts matrix — Teacher LOSES ViewRoster+ViewAcademics [CRM+Pédagogie sidebar → padlock; action permissions retained for in-Personnel exercise], SupportStaff GAINS ViewFinancials/ManageClasses/PromoteStudent [clerk front-office], Manager loses ViewFinancials [0019 server parity]; app-shell route-guard table on /crm//academics//financials closes the URL bypass; RED-first role-boundaries suite) + T-235 (RBAC-301: RollCallScreen/GradeEntryScreen composed as optional-prop overlays INSIDE TeacherDashboard — zero navigate('/academics/...') left, source-guard-pinned; routes still standalone) + T-236 (RBAC-302: migration 0083 applied live atomically — students_update drops 'teacher' [DB-level student-profile writes CLOSED], students_select/assessments_select teacher branch scoped to classes-they-teach [homeroom classes.homeroom_teacher_id OR class_subjects.teacher_id → personnel.user_id], parents_select drops 'teacher'; all other roles byte-identical) + T-237 (Android mirror: Rbac.kt lockstep incl. financial_officer VIEW_ACADEMICS alignment to the 0023 seed; NEW "Mon espace" first tab in PersonnelHubScreen [TeacherWorkspaceScreen: STRICT homeroom scoping — unlinked teacher sees ZERO classes; Appel/Notes → the ROLL_CALL/ENTER_GRADES-gated routes]; 6 boundary tests + 5 scoping tests; 50 suites/427/0) + T-238/239/240 (ARCH-001 slots #7/#8/#9 CLOSED: SupabasePurchaseRequestRepository [PR-YYYY-NNNN, frozen names per the 0074 precedent], SupabaseDeliveryRepository [DLV-YYYY-NNNN, guarded delay path, frozen driver name], SupabaseInventoryRepository [soft delete, scan flow, insert-only audit ledger] onto the canonical 0011 tables + migration 0084 [frozen display/audit columns, applied live atomically]; 25 new tests) + T-241 (live verification 14/14 through the desktop's exact PostgREST+RLS path: provisioning round-trip [super_admin → EF → teacher+driver accounts → immediate sign-ins → active profiles + roles + audit], teacher scoping probes [students/parents/payments 0/0/0; students UPDATE 0 rows with a succeeding admin control on the same row], escalation 403, driver lockout 0/0 — evidence docs/recovery/t-241-live-verification.md) + T-242 (closeout: problem-registry +TEST-306 [FIXED] +RBAC-300 [VERIFIED] +RBAC-301 [TESTED] +RBAC-302 [VERIFIED] = 205 detailed entries; ARCH-001 slot-closure note; task statuses flipped; change-log/current-state/next-task; zips + push). Suites at close: desktop 112 files / 2687 / 0 + tsc + eslint 0 err; Android 50 suites / 427 / 0 (JDK 21 + SDK 35 toolchain re-provisioned); website untouched (parent/student portal — separate RLS policies, verified unaffected by 0083). Live chain 0001–0084 zero drift (0083 + 0084 applied atomically). Owner-gated residuals unchanged + the admin password re-set during T-241 should be rotated by the owner.)

## Progress summary (2026-09-07, updated at the 33rd repair session CLOSE — owner mandate "fix the payment-modal UI that gets cut off / goes outside the form boundaries (wider ≈16:9 form, responsive) + show WHO issued each payment and WHEN in the payments tab instead of only a serial number + FULLY implement the DAG automations": T-219..T-222 (a focused 4-task set, desktop-hub scope) — T-219 (UI-305: the payment dialog was `grid … flex-col` with NO height cap, so the body's `flex-1` was inert and tall single-column forms grew past the viewport, pushing the footer off-screen; fixed at the DESIGN-SYSTEM level: dialogs are now flex columns capped at `max-h-[88vh]` + a NEW `2xl` wide-form tier (max-w-6xl ≈ 1152px ≈ 16:9 stage) + the UnifiedPaymentModal restructured into a responsive 12-col two-column form (7 = target/summary/slider/waterfall preview, 5 = method/structured check-wire fields/proof/debt meter/notes) with the payer+amount recap pinned in the always-visible footer) + T-220 (the payments journal's opaque serial-number column replaced by the ISSUER identity — parent avatar + full name + family code + linked student, the receipt demoted to a secondary line under the collector attribution, and the EXACT transaction timestamp dd/MM/yyyy HH:mm + relative time; search now spans payer/student/family-code/receipt/method/category) + T-221 (DAG-100 CLOSED — the workflow builder is now a functional automation system: node subtype registry 17 → 29 with the high-value educational set [grade_below_threshold, payment_cleared_or_bounced, document_expiration, calendar_cron_event, stock_level_critical, time_window, route_switch, send_whatsapp, restrict_account, dispatch_task, generate_document, account_adjustment]; NEW NodeInspectorDrawer with per-type parameter forms + the visual predicate builder (rows of Champ/Opérateur/Valeur + ET/OU/NON compiled into the canonical ConditionNode tree) + switch-route editor + test-payload preview; NEW dry-run simulator (PURE topological engine, branch-aware: failing conditions close only their own branch, route_switch opens only the first passing route, missing fields → false + §10.05 warning) wired to the canvas "Tester" button with green taken-path animation + per-node status rings + warning banner; NEW canvas UX: zoom (buttons + Ctrl-wheel anchored at cursor), pan (drag background), minimap with viewport rect + click-to-jump, snap-to-grid, and topological auto-layout ("Réorganiser"); NEW 3 one-click educational templates [Pack Relance Impayés Échelonné, Alerte Assiduité & Retards, Clôture Trimestrielle] wired into the Nouveau workflow picker with templateIsValid guarding; the mock executor upgraded from the linear single-flag walk to the SAME dry-run engine (single source of truth — visual and execution semantics can no longer diverge; runs recorded in topological order with per-branch skip reasons)) + T-222 (closeout). Suite: desktop **100 files / 2513 / 0** (was 94/2439; +6 test files / +74 tests: dry-run 9, auto-layout 8, templates 11, subtype-registry 7, source guards 13, executor branches 4) + typecheck clean + eslint 0 errors (401 warnings, NET −3 vs HEAD 404 — new files lint-clean). Registry: +2 problems (UI-305, DAG-100 — both TESTED) — 201 detailed entries; T-218's registry status flip (In Progress → Completed) truth-synced (the 32nd closeout commit missed it). No backend/website/Android changes this session — desktop-scope mandate; the live chain is UNTOUCHED (still 77/77 = 0001–0080). Owner residuals unchanged.)

## Progress summary (2026-09-06, updated at the 31st repair session CLOSE — owner mandate "fix the website UI (overflow/fit/responsive, mobile-first but desktop-safe), fix the underlying problems across the stack incl. the Supabase backend, verify the migration tokens consistent everywhere": T-199..T-208 (a balanced 10-task set) — the portal's layout was LIVE-MEASURED at real phone widths for the first time (seeded UI-TEST family + @supabase/ssr cookie sign-in + DOM-geometry probes; recipe persisted in strategy §6): five NEW defect families registered AND fixed same-session with source-scan guards — UI-300 dashboard grid blowout (Critical, 935px@320 → 0), UI-301 unbreakable Intl currency KPI values (High, 108px@375 → 0), UI-302 four non-wrapping header rows (Medium, up to 163px@320 → 0), UI-303 financial tab-label clipping (Medium, 54px cells vs 58–84px labels → scrollable row), UI-304 raw English kind enums (Low → localized via the extracted shared map) — viewport matrix 36/36 GREEN (9 views × 320/375/768/1280 all 0px; sub-tabs + chat conversation clean); website suite 30/496 → 35 files / 514 / 0 (+5 guard files) + lint + strict build; desktop parity per §10 (18 latent bare responsive grids + debt-KPI break-words, 92/2422/0 + typecheck + lint 0 err; the T-205 guard caught 12 instances the manual grep missed); Android scanned — structurally immune to the family (Compose constrained layout + weight(1f)), zero commits; T-204 live consistency round ALL GREEN: chain 76/76 = 0001–0079 zero drift, dual-key health per ADR-009, EF fleet 13/13 ACTIVE = the hub's 13 function dirs (the older "14/14" figure was STALE — discovery persisted), ALLOWED_ORIGINS canonical 4-origin set echoing (ACT-203 intact), anonymous EF → 401; UI-TEST family cleaned from the live DB (0 residuals; audit rows kept); harness recipe + the two CSS defect-family rules persisted (strategy §6 + AGENTS.md §15 #21/#22 + website AGENTS.md §5). Registry: +5 problems (UI-300..304, all TESTED) — 198 detailed entries. Owner-gated residuals unchanged: FIREBASE_SERVICE_ACCOUNT_JSON, RESEND_API_KEY, web-push env vars, AUTH-200's Google OAuth client.)

## Progress summary (2026-09-05, updated at the 30th repair session CLOSE — owner mandate "fix the MESSAGING system (not the chat UI) across mobile/website/desktop + the Supabase backend end to end + every broken PDF generation; apply the migration tokens; keep consistent everywhere": T-189 (the migration tokens — 0072/0073/0074 applied live atomically [the 28th session's gated applies], ALLOWED_ORIGINS canonical 4-origin set deployed via CLI + ACT-203 VERIFIED + the script repaired for the dead PATCH/PUT + masked-GET secrets API, FIREBASE_PROJECT_ID set live, §7 checklist re-run all green, chain 76/76 = 0001–0079 zero drift) + T-190 (MSG-200 — migration 0075 chat→notification fan-out trigger; verify 8/8; FULL live two-user round-trip 10/10: staff channel → parent message → staff notification via RLS → symmetric reply fan-out → parent markRead persists) + T-191 (REG-004 — live-drifted notifications_select [using (true) — data leak] restored to the canonical 0019 policy by migration 0076; round-trip 9/10→10/10) + T-192 (MSG-101 — the desktop debt reminders that never delivered: migration 0077 canonical notify_parent_user RPC [staff-gated, server-side parent→account resolution, NULL = undeliverable] + SupabaseDebtRepository sendReminder/broadcastReminders/lockDelinquentAccounts repaired + write_audit_log; round-trip 7/7; suite 10/10) + T-193 (MSG-201 — migration 0078 homework→parent-notification fan-out with dedup; verify 6/6; the desktop modal's "notifié aux parents" promise is now true) + T-194/T-195 (CROSS-101/UNKNOWN-004/T-066 — ADR-014 client-side PDF generation: website receipt + account-statement pdf-lib ports of the desktop reference layout, download buttons wired per-payment + per-family, dead receipts hooks + typed row removed, migration 0079 drops the orphaned table [0 rows] + bucket [via Storage API — SQL is blocked] + policies; website 496/496 + lint + strict build; suite t-194 8/8) + T-196 (Android 'chat_channel' deep-link route to ChatDetail + the message/chat FCM type → Dashboard tab mapping documented; Android suite re-run with re-provisioned JDK21+SDK35) + T-197/T-198 (registry truth-sync + zip + push). Registry: +4 NEW problems (MSG-101, MSG-200, MSG-201, REG-004 — all TESTED with live evidence) — 193 detailed entries. STILL owner-gated after this session: FIREBASE_SERVICE_ACCOUNT_JSON (real FCM sends), RESEND_API_KEY (workflow emails), the website web-push Firebase env vars, AUTH-200's Google OAuth client.)

## Progress summary (2026-09-05, updated at the 28th repair session CLOSE — mandate "Finish all the remaining tasks" + the mid-session URGENT queue-jump "the activation code is not working — fix both the desktop app and the website, then push": T-184 (ACT-201 Critical — the production portal's `/undefined/functions/v1/bind-activation-code` 404: a DIRECT build-time env read in a client component inlined `undefined` on the Vercel project that sets NO NEXT_PUBLIC_* vars; fixed via the `@/lib/env` T-096 fallback chain + a whole-src regression scan + the AGENTS.md rule; ACT-202 desktop — bindActivationCode now surfaces the EF's structured errors parsed off FunctionsHttpError.context; URL-routing live-verified: the fixed client's exact request reaches the REAL EF [structured 401]; website 28/483 + lint + strict build, desktop 89 files/2404 + tsc + lint 0 err; owner must REDEPLOY the portal) + the T-047 port batch: T-176/T-177 (workflows + workflowRuns + migration 0071 + the canonical execute EF path; 13/13), T-178 (leaveRequests + migration 0072 [RequestType-widened CHECK + reviewed_by_name]; 11/11), T-179 (suppliers + migration 0073 [category + fractional rating]; 10/10), T-180 (tasks/task_comments/task_attachments + migration 0074 [display names]; 12/12) — the desktop suite grew 2336→2404 across the batch and the chain 0001–0068→0001–0074 (0071–0074 committed with embedded registrations; LIVE application owner-token-gated this session — the sbp_ access token was not re-supplied after the context handoff; apply_00XX_live.sh scripts ready) + T-181 (Android Room dismissedAt migration v13→v14 + the server-dismissed pull eviction — T-173 part b CLOSED; 48 files/410/0 + lint + schema 14.json; part a [alert VOLUME, UNKNOWN-020] remains owner-gated). All three repos PUSHED to GitHub with the owner's PAT (this session: hub 232ea0d..98b9b36+T-182/T-183, website d5df9f5..f5dc55b, android bfe7411..4589a19). Registry: +ACT-201/ACT-202 (185 detailed, 145 TESTED). Suites at close: desktop 89 files / 2404 / 0 + tsc + lint 0 err; website 28 files / 483 / 0 + lint + strict build; Android 48 files / 410 / 0 + lintDebug.)

## Progress summary (2026-09-04, updated at the 25th repair session CLOSE — mandate "keep going": continuation session run as one of ~10 concurrent agents on the shared repos; selected + executed the coordination-safe set T-155..T-163 — T-157 debt-meter ADR-010 wiring, T-158 exhaustive-deps 4→0 (lint baseline re-pinned 384→379), T-159 Android toolchain re-provision (+ the secrets-plugin ROOT-.env discovery), T-044 pass 3a the DS ElScrollableTabRow (additive prerequisite, 5 semantic tests, suite 45/377/0), T-160 the T-047 scoping doc (23 mock-backed slots; 19 need adapters only — canonical tables already exist; verified cross-platform drift: website reads calendar_events vs desktop mock calendar, Android pull-syncs workflow_runs vs desktop mock workflows), T-161 website full verification (26/457 + lint + strict build, zero drift), T-162/T-163 closeout; suites at close: desktop 82 files / 2286 +5s + typecheck + lint 0 err/379 warn, Android debug 45 files / 377 tests / 0 failures + lintDebug, website 26 files / 457 tests + lint + strict build — all green. No Supabase credentials this session → live chain check owner-token-gated; LOCAL chain integrity verified (65 files 0001–0068, no gaps/dups, append-only guard OK). No push credentials → commits on branch `session25-agent-work` in each repo; the zip-for-push handoff applies.)

## Progress summary (2026-09-03, at the 24th repair session CLOSE — owner mandate "fix the 3 owner-reported issues (activation rejected as already-used / parent→admin-only messenger / children showing the parent's name) + apply the migration tokens + verify everywhere + zip": T-145..T-154 COMPLETE — activation round-trip live 19/19 (ADR-011, EF consolidated, phantom codes dead), migration 0067 parent→admin chat live 14/14 (ADR-012), migration 0068 parent-name repair live 11/11 (zero parents display a child's name); chain now 65/65 = 0001–0068 zero drift; suites: desktop 82 files / 2284, website 25 files / 457, EF fleet 14/14 ACTIVE — all green)

| Status | Count | Tasks |
|---|---|---|
| **Completed (VERIFIED)** | 10 | T-000, T-079, T-004, T-094 (live integration suite 5/5, 2026-08-31), **T-068** (live deploy + curl matrix + permission probes, 11th session), **T-095** (live 200 + idempotency, 12th session), **T-103** (15th session — finance reconciliation + read consistency, live 8/8), **T-147** + **T-150** + **T-152** (24th session — live round-trips: activation 19/19, chat 14/14, name repair 11/11) |
| **Completed (TESTED)** | 95 | The 64 prior-session tasks + **23rd session: T-140 (opening live verification), T-141 (AUTH-200 close — Google OAuth ENABLED), T-142 (all-three pristine baselines), T-143 (T-043 COMPLETE — equivalence consolidation, 4 passes), T-144 (T-044 passes 1–2 — DUP-004 closed, settings module migrated, 37→29 legacy importers)** + T-139, T-138, T-135, T-136, T-137, T-130..T-134 (22nd session) + **24th session: T-145, T-146, T-148, T-149, T-151, T-153, T-154 (7 TESTED)** + **32nd session: T-209..T-218 (10 TESTED — T-218's flip truth-synced in the 33rd session; the 32nd closeout commit had left it In Progress)** + **33rd session: T-219 (UI-305 modal), T-220 (payments issuer/timestamp), T-221 (DAG-100 full builder), T-222 (closeout)** |
| **Completed (IMPLEMENTED)** | 1 | T-010 (launch verification needs a desktop host) |
| **In Progress (23rd session close)** | 1 | **T-044** (Android design-system consolidation) — passes 1–2 complete (see T-144); 29 legacy importers remain; the next pass needs a scrollable DS tab component first |
| **Ready** | 0 | ~~T-043~~ COMPLETED 2026-09-03 (23rd session — T-143, 4 passes). ~~T-044~~ IN PROGRESS (T-144: passes 1–2 done; the remaining migration passes are the next picks). T-102-follow-up was COMPLETED in the 21st session (T-129 — Android chat v1: read-side + online sends, 21 new tests) — this row is now empty: the actionable set is T-044's remaining passes + owner-gated/device-gated/decision-blocked items only |
| **Partially blocked** | 1 | T-036 — PUSH-103 portion DONE (13th session); PUSH-100 (EF invocation path) + PUSH-104 (email provider) remain, owner-scoped |
| **Blocked** | 10 | T-028, T-037, T-038, T-042, T-045, T-059, T-066, T-067, T-070, T-072 |
| **Needs Investigation** | 1 | T-047 |
| **Deferred** | 5 | T-073…T-077 |
| **Needs owner decision** | ~~2~~ **1** | T-086 — ~~"only DATA-005 (first_name split) remains of T-085"~~ **stale: DATA-005's backfill was EXECUTED** as migration 0066 (T-139, 22nd session — live-verified 6/6; 258/259 parents carry a populated first_name). T-087(done 9th) stays done. The only owner decision left in this row is the DATA-006 onboarding campaign itself (operational, not code). |
| **Not started (Android, toolchain-gated)** | ~~2~~ **0** | ~~T-020, T-082~~ — **both COMPLETED** (T-020 TESTED 17th session — SyncErrorClassifier, requeue-transient/fail-fast-4xx; T-082 TESTED 18th session — desugaring enabled, lint gate restored, baseline committed). Row kept as a tombstone because the 24th session's summary still carried it stale; the toolchain-gating note applies to the *verification* of device-gated residuals only (T-159, 25th session, re-provisions the toolchain + recipe). |


### T-000 — Documentation reset & unified governance system
- **Problem IDs:** — (system-level; resolves WEAK-021)
- **Description:** Remove all 56 legacy `.md` files across the three repos; consolidate two audit passes (185 findings) into a 145-problem registry; establish this documentation/control system (AGENTS.md ×3, architecture, domain, ADR-001…007, recovery, testing, agents). Amendment (same day): archived both audit reports verbatim under `docs/audits/` and added the mandatory commit-content rule (Task/Left/Change/Verified/Next) to `AGENTS.md` §14 and `docs/agents/git-workflow.md`.
- **Priority:** P0 · **Severity:** — · **Dependencies:** none
- **Affected:** all three repos (documentation only)
- **Status:** VERIFIED (2026-08-29)
- **Required tests:** n/a (no code change)
- **Verification criteria:** file inventory shows zero legacy `.md`; IDs unique; cross-references valid — recorded in `change-log.md`.
- **Related ADRs:** ADR-007 · **Commits:** see change-log entry.

---

## Completed (beyond VERIFIED — evidence in change-log.md)

### T-001 — Remove hardcoded staff credentials from the desktop login screen
- **Problems:** SEC-100, CROSS-100 · **Priority:** P0 · **Severity:** Critical
- **Status:** TESTED (2026-08-29)
- **What was done:** DEMO_ACCOUNTS array + quick-fill UI deleted from `login-screen.tsx`; the same nine password literals removed from the mock layer's `seedAccounts` (mock sign-in now matches on email only — it is bypassed entirely when Supabase is configured); orphaned `auth.demoAccounts`/`auth.useAccount` i18n keys removed. Deviation from the task text (which named only login-screen.tsx) recorded: the task's own verification criterion (rg over src/) required cleaning seed-data.ts too.
- **Tests:** NEW `src/tests/security/no-demo-credentials.test.ts` — scans the whole src tree for the nine leaked literals; failed before the fix (login-screen.tsx + seed-data.ts flagged), passes after.
- **Verification:** `npx vitest run src/tests/security/no-demo-credentials.test.ts` 1/1 pass; `npm run typecheck` clean; `npm test` 41 files / 1957 tests ALL PASS; rg scan clean (only the test's own detection list). Gaps (why TESTED, not VERIFIED): live login with real accounts untested (no running environment); the nine passwords must still be ROTATED in every deployed environment (deployment action). `npm run lint` could not run — pre-existing defect, now registered as DEAD-201 / T-078.
- **Commits:** aa823d4 (failing test), 9c038eb (fix) — hub repo.

### T-009 — Remove the website mock-auth system
- **Problems:** SEC-007 (absorbs REG-003, DEAD-010) · **Priority:** P0 · **Severity:** Critical
- **Status:** TESTED (2026-08-29)
- **What was done:** `src/lib/auth/mock-auth.ts` deleted (278 lines); mock imports/hydration/signInWithMock/isMockSession/mock signOut branch removed from `auth-provider.tsx`; mock button + hint + 'or' divider removed from `login-screen.tsx`; `NEXT_PUBLIC_MOCK_AUTH_ENABLED` flag, `isMockAuthEnabled` export and stale comment block removed from `env.ts`; `auth.signin.mock/mockHint/or` keys removed from all three dictionary locales. Google OAuth is the only auth path. PREREQUISITE work included: missing `src/test/setup.ts` committed + the bare `test` .gitignore rule that silently hid it removed (DEAD-012 root cause corrected — see problem registry).
- **Tests:** NEW `src/app/providers/auth-provider.test.tsx` — 3 tests incl. planted `mock-auth-session` key → NO authenticated state (failed before: state 'active'); passes after.
- **Verification:** `npm run test` 6 files / 90 tests ALL PASS (was: total suite failure via DEAD-012); `npm run lint` — changed files clean (2 pre-existing errors in dashboard-view.tsx/financial-view.tsx remain, not introduced here); `npm run build` compiles successfully. Gap (why TESTED, not VERIFIED): real Google-OAuth round-trip needs a live backend.
- **Commits:** 864eca6 (tests + test-infra fix + .gitignore fix), a3062ee (removal) — website repo.

### T-010 — Remove --no-sandbox from the desktop start script
- **Problems:** ARCH-002 · **Priority:** P0 · **Severity:** Medium
- **Status:** IMPLEMENTED (2026-08-29 — launch verification pending)
- **What was done:** `--no-sandbox` removed from the `package.json` `start` script; host requirement (chrome-sandbox SUID helper `chown root:root && chmod 4755`, or `kernel.unprivileged_userns_clone=1`) documented in `electron/main.ts` with an explicit 'fix the host, not the flag' instruction.
- **Tests:** Launch on a clean host — NOT YET RUN (headless container cannot launch Electron; AGENTS.md §11 forbids it). Honest gap.
- **Verification:** rg 'no-sandbox' → only the explanatory comment remains; package.json still valid JSON; `npx tsc -p electron/tsconfig.json --noEmit` compiles clean. Advance to TESTED once a sandboxed launch log is recorded on a desktop host.
- **Commits:** af655b1 — hub repo.

### T-003 — Make desktop changePassword actually change the password
- **Problems:** SEC-103 · **Priority:** P0 · **Severity:** High
- **Status:** TESTED (2026-08-29)
- **What was done:** `changePassword` added to the `AuthRepository` domain interface with a documented contract (re-authenticate, persist via backend, revoke sessions — Ok means the password REALLY changed), making typecheck enforce it on every implementation; `AuthProvider.changePassword` now delegates to `repos.auth.changePassword` — the pre-existing canonical implementation in `SupabaseAuthRepository` (reused verbatim per the Existing-Implementation-First rule; its inline re-auth + `auth.updateUser` + global signOut now actually run). The audit entry is written ONLY after the repository returns Ok (previously forged); on failure the session is preserved and no audit entry is written; ERR_UNAUTHORIZED maps to the existing French "Mot de passe actuel incorrect." message; `AuditActions.AuthPasswordChange` constant added (wire value `auth.password_change` unchanged, matches Android). `MockAuthRepository` implements the method per post-T-001 mock semantics (non-empty current password + strength rules; Ok is a documented dev/demo no-op). Deviation from the problem entry's phrasing ("after re-authentication") recorded: re-authentication is DELEGATED to the repository, which already owns it as its first step — the provider's duplicate inline re-auth was removed rather than kept.
- **Tests:** NEW `src/tests/security/change-password.test.tsx` (12 tests) — includes the task's stated integration test (after a change the old password no longer signs in and the new one does), the delegation regression, audit-only-after-success with real-actor attribution, wrong-current-password error + session preserved, repository-failure surfacing, success clears local session, strength fast-fails, no-session refusal, and 4 mock compliance tests. RED state recorded: 8 failed | 4 passed before the fix (commit 9287595).
- **Verification:** `npx vitest run src/tests/security/change-password.test.tsx` 12/12 pass after the fix; `npm run typecheck` clean (also proves both implementations satisfy the extended interface); `npm test` 42 files / 1969 tests ALL PASS (was 41/1957). Gap (why TESTED, not VERIFIED): live round-trip against a real Supabase project from a running desktop build — needs a desktop host + configured backend. `npm run lint` could not run — pre-existing defect DEAD-201 / T-078.
- **Commits:** 9287595 (failing regression tests), 2e934ff (fix), 0700215 (registry checkout) — hub repo.

---

### T-004 — Require authentication on the four cron Edge Functions
- **Problems:** SEC-105 · **Priority:** P0 · **Severity:** High
- **Status:** TESTED (2026-08-29, fourth repair session)
- **What was done:** NEW shared guard `supabase/functions/_shared/cron-auth.ts` — pure decision core `isCronAuthorized(req, secrets)` (Deno-free so the desktop vitest suite imports it directly; constant-time comparison; generic 401) + Deno wrapper `isCronInvocation(req)` reading `CRON_SECRET` and `SUPABASE_SERVICE_ROLE_KEY`. All four cron EFs wired: `expire-pending-approvals`, `refresh-materialized-views`, `purge-expired-backups` (deny-by-default 401, then GET/POST allowed) and `run-overdue-scan` (`isCron = isCronInvocation(req)` instead of `!authHeader`; the manual user-JWT path with `extractAuthContext` + `view_financials` + tenant filter preserved verbatim; anonymous → 401). Authorised callers: `Authorization: Bearer <CRON_SECRET>` (operator secret) or the project's service_role key (Supabase's managed config.toml scheduler injects it; possession already grants full DB access, so no new exposure). All four SECURITY header blocks rewritten with deployment notes. Deviation from the task text recorded: the task named "verify a CRON_SECRET bearer token (or Supabase cron signature)" — the service_role-key acceptance IS the internal-invocation branch and keeps the managed scheduler working without operator changes; a headerless-scheduler operator MUST add the CRON_SECRET header to its SQL cron call (documented in each EF header + change-log).
- **Tests:** NEW `src/tests/security/cron-auth.test.ts` (19 tests) — RED first (commit ee3394e: import-resolution failure before the guard existed), 10 unit tests of the decision core (anonymous/empty Bearer/non-Bearer/wrong secret/unset CRON_SECRET denied; valid CRON_SECRET and service_role accepted; prefix-sharing and JWT-like tokens denied) + source scans asserting each EF imports/uses `isCronInvocation` and the vulnerable patterns (`const isCron = !authHeader`, "No JWT required (cron invocation)", "Allow only cron (no auth)") are gone.
- **Verification:** `npx vitest run src/tests/security/cron-auth.test.ts` 19/19 PASS; `npm run typecheck` clean (also type-checks the new EF module via the test import); `npm test` 44 files / 2007 tests ALL PASS (was 43/1988); `npx esbuild` syntax check OK on all 5 touched files; full diff reviewed. GAPS (why TESTED, not VERIFIED): live curl matrix (anonymous→401, wrong secret→401, valid secret→executes per EF) needs a deployed Supabase project; operator actions: `supabase secrets set CRON_SECRET=…` + ensure schedules send the expected header (run-overdue-scan's `verify_jwt=true` gateway would reject a CRON_SECRET header — use the managed scheduler or flip that setting deliberately). NEW DISCOVERY: ARCH-006 → T-080.
- **Commits:** 112e2de (registry checkout) · ee3394e (RED tests) · 9919b28 (fix, GREEN) — hub repo.

### T-078 — Author the missing desktop ESLint flat config (make `npm run lint` runnable)
- **Problems:** DEAD-201 · **Priority:** P2 · **Severity:** Medium
- **Status:** TESTED (2026-08-29, fourth repair session)
- **What was done:** `elimtiyaz-desktop/eslint.config.js` authored (flat, ESLint 9): typescript-eslint recommended over the desktop's own TS (src/ + electron/ + scripts/), react-hooks plugin (rules-of-hooks = **error**, exhaustive-deps = warn), Node+DOM globals, scoped ignores (supabase/** = Deno toolchain, financial-tests/** = dedicated suites, build output). Per-rule warn downgrades documented IN the config with real first-run counts — no rule silently disabled; the website's turn-everything-off config explicitly NOT used as the model (ARCH-005 defect pattern). devDeps added (were missing even for a config): eslint-plugin-react-hooks ^5.2.0, globals ^15.15.0, typescript-eslint 8.18.2 (the meta-package — only plugin+parser were installed before). First-run error triage (all 5 FIXED, none suppressed): (1) REAL react-hooks/rules-of-hooks violation — `useRepositories()` called inside the `useObservable` factory callback in `permissions-step.tsx` (survives at runtime only via React's ContextOnlyDispatcher tolerance); hoisted to the component top, matching every sibling onboarding step. (2) stale `eslint-disable-next-line jsx-a11y/img-redundant-alt` directive naming a rule not configured in this repo (expense-detail-drawer.tsx) — removed, the alt text is descriptive. (3–5) prefer-const ×3 (workflow-repository.ts, sync-indicator.tsx, supabase-repositories.test.ts) — mechanical let→const.
- **Tests:** gate-level, per the task's own definition: `npm run lint` executes with no config error. First run: 312 problems (5 errors, 307 warnings); after the 5 error fixes: 0 errors / 307 warnings, exit 0. The 307 warnings are the documented baseline (no-unused-vars 202, no-explicit-any 73, no-empty-function 21, react-hooks/exhaustive-deps 4, no-empty-object-type 2) — counts live in the config comments; a burn-down task is a candidate for the next session's registry work (the 4 exhaustive-deps findings are the most defect-like and deserve individual review).
- **Verification:** `npm run lint` 0 errors / 307 warnings; `npm run typecheck` clean; `npm test` 44 files / 2007 tests ALL PASS; full diff reviewed; package-lock diff limited to the three added devDeps.
- **Commits:** d4a0f19 (config + deps + 5 error fixes) — hub repo.

## In Progress

**38th repair session (2026-09-09, CLOSED) — owner mandate COMPLETE ("You didn't add enough graphs. I wanted more Power BI–type visualizations, with things like interactive charts, statistics, comparisons, trends, and other data visualizations wherever they make sense"): T-255..T-259 (5 tasks) — the dashboard gained a full Power BI-style ANALYTICS report page (UI-307, all REAL-data derivations).** Session-opening ritual: full-container RESET discovered (repos/zips/scripts/worklog wiped — all pushes were confirmed on origin so nothing was lost); the 3 repos re-cloned anonymously at hub 2ad3b17 / website f3d9965 / android f0b6433; npm re-provisioned; pristine-tree baseline FULL suite **113 files / 2711 / 0** + tsc + eslint 0 err (407 warn) + vite build green — byte-identical to the 37th-session close. Delivery: **T-255** (the Analytics tab shell + the pure derivation layer + the statistics strip + the hero trend explorer + the interactive slicer bar), **T-256** (method donut + category ranking with metric toggle + the weekday×month collection heatmap + the amount histogram), **T-257** (top-debtors Pareto + aging 100% composition + the like-for-like YoY comparison), **T-258** (NEW 34-test suite analytics-visuals.test.tsx), **T-259** (this closeout). The tab cross-filters like a Power BI report: method/category slicer chips re-derive EVERY payments-based card (stat strip, mixes, heatmap, histogram, and a dashed "Filtré" overlay on the trend chart) while the repository's canonical monthly bars stay untouched (§15.16 — the ENCAISSÉ DEFINITION is the repository's own: status=paid, calendar month of collectedAt). The page additionally loads the PREVIOUS academic year's series for the same month window (revenueForRange on the shifted range) so the YoY card compares like-for-like months from REAL repository data. Suites at close: desktop **114 files / 2745 / 0** (+34) + tsc + eslint 0 err (410 warn, +3 from the test ResizeObserver stub — the T-247 pattern) + vite build green (20.7 s); website + Android untouched (desktop-scope UI change, zero contract impact per §10; no migrations, the live chain 0001–0084 and the 37th session's 18/18 live evidence stand unchanged).

**39th repair session (2026-09-10, CLOSED) — owner mandate COMPLETE ("do all of this then push" — the Agentic AI Architecture blueprint) (the Agentic AI Architecture blueprint: model-agnostic Groq/OpenRouter/custom-OpenAI agent with native streaming, tool calling, BYOK live model discovery, human-in-the-loop action proposals, and a universal Ctrl+J copilot): T-260..T-263 (4 tasks).** Session-opening ritual: repos re-cloned (hub 7238fb9 + android + website siblings), npm re-provisioned, pristine-tree baseline FULL suite **114 files / 2745 / 0** + tsc clean — byte-identical to the 38th-session close. The blueprint was registered BEFORE implementation per AGENTS.md §13. Delivery: **T-260** (the agent core — domain-model extension with every legacy export preserved, agent types, SSE stream client with indexed tool-call reassembly, 3-provider registry with live model discovery, 6 domain tools executing against the REAL repositories + canonical calc engines, the multi-turn runtime, the extended encrypted BYOK storage, the streaming llm-adapter), **T-261** (the universal copilot — provider + drawer + topbar trigger + Ctrl+J + palette ask action + app-shell wiring + the live-discovery settings tab, RBAC gates preserved), **T-262** (the ai-proxy EF agent-stream mode, deployed live v17 with the 7-probe matrix GREEN), **T-263** (this closeout). Blueprint adaptations (all registered): provider INSIDE ToastProvider (mount-order bug), additive topbar integration (the wholesale replacement would delete five working features — §15.3), RBAC gates preserved (§15.4), tools PROPOSE mutations (never write — §15.5), canonical display-name renderers (DATA-005). Suites at close: desktop **116 files / 2782 / 0** (+37: NEW agent-architecture.test.ts [29] + copilot-drawer.test.tsx [8]) + tsc + eslint 0 err (424 warn) + vite build green (21.1 s); website + Android untouched (desktop-scope + additive EF change, zero contract impact per §10; no migrations — the live chain 0001–0084 verified ZERO DRIFT).

### T-260 — Agentic AI core: domain model + agent types + SSE stream client + provider registry + domain tools + agent runtime + BYOK storage extension
- **Problems:** AI-308 (NEW — the copilot capability gap: the desktop's AI layer was a mock/edge/BYOK single-shot generator with no streaming, no tool calling, no multi-turn reasoning, and no model discovery) · **Priority:** P1
- **Dependencies:** none (additive layer over the existing repository contracts; narrative/drafting/anomaly features preserved untouched) · **Affected:** hub desktop (`src/domain/model/ai.ts`, NEW `src/core/ai/agent-types.ts`, `src/core/ai/streaming/stream-client.ts`, `src/core/ai/providers/provider-registry.ts`, `src/core/ai/tools/system-tools.ts`, `src/core/ai/agent-runtime.ts`, `src/infrastructure/ai/ai-config-storage.ts`, `src/infrastructure/ai/llm-adapter.ts`, `src/infrastructure/mock/repositories/ai-config-repository.ts`)
- **Plan:** extend the AI domain model (AIProvider gains `custom_openai`; AIProviderConfig gains customApiKey/customBaseUrl/temperature/topP/maxTokens/reasoningEffort; NEW AIModelInfo/AIChatMessage/AIToolCall/AIChatRole; AIResponse gains toolCalls) while preserving every existing export (PII types, Narrative/Drafting/Anomaly shapes, FR labels) so the 2745-test suite stays green. NEW agent layer: JSON-schema ToolDefinition/ActionProposal types; browser-native SSE parser (executeOpenAIStream) reassembling content deltas + tool_call fragments; provider registry with endpoints for groq/openrouter/custom (Ollama-style localhost default) + queryLiveProviderModels; system tools (search_entities, get_financial_ledger_summary via computeParentSummary, get_student_academic_profile via evaluateStudentTermPerformance, get_school_kpi_overview via dashboard.kpis, propose_account_adjustment → human-approval ActionProposal, request_user_clarification) executing against the REAL Repositories + the canonical src/domain/calc engines; agent-runtime multi-turn loop (MAX 5 tool steps, abortable, tool results fed back as `role:"tool"` messages). ai-config-storage extended (3 encrypted keys + sampling params); llm-adapter BYOK path upgraded to the shared streaming client with tool-call passthrough (edge + mock paths preserved).
- **Status:** Completed — TESTED (2026-09-10: 29 of the 37 new agent-architecture tests; full suite 116/2782/0 + tsc + eslint 0 err + build green)

### T-261 — Universal Copilot UI: provider + drawer + topbar trigger + Cmd+J + app-shell wiring + BYOK settings with live model discovery
- **Problems:** AI-308 (the interface leg) · **Priority:** P1
- **Dependencies:** T-260 (the runtime) · **Affected:** hub desktop (NEW `src/app/providers/ai-copilot-provider.tsx`, NEW `src/features/ai/copilot-drawer.tsx`, `src/shared/layout/topbar.tsx`, `src/app/app.tsx`, `src/app/app-shell.tsx`, `src/features/settings/ai-config-tab.tsx`)
- **Plan:** AICopilotProvider (global state: open/streaming/messages/proposals/config; askAgent runs the runtime; approveAction executes account_adjustment through the canonical repos.payments.adjust — human-in-the-loop 1-click validation; placed INSIDE ToastProvider so useToast resolves — fixes the blueprint's provider-order bug) + AICopilotDrawer (floating right drawer: live streaming bubble, tool-execution chips, suggestion cards, action-proposal cards with Valider/Ignorer) + Topbar integration (dedicated Assistant IA button + Ctrl+J/Cmd+J global shortcut + the palette gains an "ask the AI" Enter action — existing palette/alerts/tenant/profile features preserved, §15.3 reachability) + AppShell mounts the drawer + AIConfigTab upgraded: live model discovery via queryLiveProviderModels (groq/openrouter/custom), streaming inference test with latency, sampling hyperparameters, fallback model — RBAC ManageAIConfig gate + repos.aiConfig persistence + audit entries preserved (blueprint's un-gated variant REJECTED per §15.4).
- **Status:** Completed — TESTED (2026-09-10: 8 of the 37 new copilot-drawer tests; full suite green; provider-order + no-direct-write source guards)

### T-262 — ai-proxy Edge Function: tool-calling + streaming + model override passthrough
- **Problems:** AI-308 (the server leg) · **Priority:** P2
- **Dependencies:** T-260 (the request shapes) · **Affected:** hub (`supabase/functions/ai-proxy/index.ts`)
- **Plan:** extend the existing EF (auth/permission/rate-limit/audit machinery preserved verbatim): accept optional `tools` + `model` override + `stream` flag + `top_p` in the request body; pass tools/model/top_p through to the provider; when stream=true, pipe the provider's SSE body straight back with text/event-stream + no-cache CORS headers (the client's executeOpenAIStream consumes it identically). The feature-based single-shot path (narrative/drafting/anomaly) stays the default — the agent mode is additive. No DB change (ai_request_logs unchanged), so no migration.
- **Status:** Completed — TESTED-VERIFIED-LIVE (2026-09-10: EF deployed v17 ACTIVE; 7-probe live matrix GREEN [t-262-live-verification.md]; chain 81/81 zero drift; esbuild syntax check; the identical wire protocol suite-covered 29/29)

### T-263 — 39th-session closeout: registries + change-log + zips + push
- **Problems:** process (ADR-007) · **Priority:** P2
- **Dependencies:** T-260..T-262 · **Affected:** all repos
- **Plan:** AI-308 problem entry with evidence, task status flips, change-log 39th-session section, current-state snapshot, next-task 40th recommendation, conventional commits with the 5-question body, zips in download/, push with the owner PAT (one-shot URL, never persisted).
- **Status:** Completed (2026-09-10: AI-308 registered with full evidence, statuses flipped, change-log/current-state/next-task updated, commits + zips + push with the owner PAT)

**40th repair session (2026-09-10, CLOSED) — owner mandate COMPLETE ("fix it and push it" — the post-39th-launch console-noise fix: the 406 spam from the approval-queue matcher) + a Groq BYOK key supplied for the AI): T-264..T-265 (2 tasks).** Session-opening ritual: hub repo re-used from the 39th-session close (HEAD e0f090f, clean tree); the baseline is the 39th-session close suite (116 files / 2782 / 0). Registered BEFORE implementation per AGENTS.md §13. Delivery: **T-264** (the fix — all five findPotentialMatches `.single()` → `.maybeSingle()` + the 7-test regression suite), **T-265** (this closeout: OPS-309 registered TESTED [221 detailed entries], registries truth-synced, push with the owner PAT). Suites at close: desktop **117 files / 2789 / 0** (+7) + tsc + eslint 0 err (424 warn, unchanged) + vite build green (19.85 s); website + Android untouched; no migrations (the live chain 0001–0084 and the 39th session's 7-probe live evidence stand).

**43rd repair session (2026-09-10, CLOSED) — owner mandate COMPLETE ("do not change the usernames and passwords admin@elimtiyaz.dz / elimtiyaz@admin2026 — bring them back" + the pasted production console: "fix this problem … and make the models list fetched and selected then push again": T-280..T-282 (3 tasks).** Session-opening ritual: the sandbox container had been RESET (the 42nd-session local clone was gone) → hub re-cloned from origin/main with the owner PAT (HEAD f908ed9 confirmed; `git push` → Everything up-to-date — the 42nd-session AI-311 delivery was already fully landed). The owner's complaint ROOT-CAUSED live: sign-in with `elimtiyaz@admin2026` → 400 `invalid_credentials`, while the probe value `Elimtiyaz2026Admin!` (set by the T-079/T-241 reset pattern) still granted a JWT — i.e. the sessions' own password resets had silently overwritten the owner's canonical credential. Delivery: **T-280** (the RESTORE: password changed live through the authenticated GoTrue user API `PUT /auth/v1/user` with current-password proof — no service-role/sbp_ token needed; verified BOTH directions [new value → 796-char JWT; old value → 400 invalid_credentials] + the PERMANENT pin: the three live-matrix scripts `t241/t269/t277` now carry `ADMIN_PW="elimtiyaz@admin2026"` and docs/operations/credentials.md records the OWNER DIRECTIVE — probes hitting `invalid_credentials` on the pinned value must STOP and ask, never re-set [the OPS-310 loop, closed] + AGENTS.md §15 rule 23). **T-281** (the owner's console 429s + the model-selector ask — AI-312: `executeOpenAIStream` gained transient retry [429/5xx, exponential backoff 800ms×2ⁿ capped, Retry-After seconds+HTTP-date, jitter, abort-aware]; the runtime's persistent-429 now settles as a human French verdict; `ModelSelectField` makes the FETCHED model list actually SELECTABLE [out-of-list value keeps a "hors liste" badge, "Saisie manuelle…" escape hatch]; the auto-discovery effect re-keyed on the SAVED config so the list loads on tab open). **T-282** (the owner-observed intermittent audit 500 — OPS-311: live-probed [200 in ~1.1s, 161 small rows] → transient server blip, not a query defect → ONE 600ms-delayed retry on the three audit read paths; `log()` never retried). No EF, no migrations (the chain stays 0001–0084). Suites at close: desktop **122 files / 2897 / 0** (+22) + tsc + eslint 0 err + build green. Owner-gated residuals unchanged: the P0 ai-proxy cap-40 deploy (the early 400 in the owner's console is the documented 27-schema vs deployed 20-cap EF — runbook in t-277-live-verification.md) + rotation of the chat-transmitted Groq key/PAT.)

**42nd repair session (2026-09-10, CLOSED) — owner mandate COMPLETE ("I want a much more capable AI system with a proper tool ecosystem: powerful tools for analyzing data, generating statistics and charts, drawing diagrams, working with documents, understanding the school's business logic, and actually helping users accomplish things… something that feels like a real AI-powered system, not a shallow chatbot"): T-272..T-279 (8 tasks).** Session-opening ritual: hub repo re-used from the 41st-session close (HEAD 1ebd8be, clean tree); baseline = the 41st close (119 files / 2824 / 0). Delivery: **T-272** (the artifact architecture — chart/diagram/document artifacts with a validated render-path gate, the SVG chart engine, the diagram engine, the generic report-document PDF builder, drawer rendering + provider downloadArtifact), **T-273** (the 5 statistical-analysis tools: revenue trends, descriptive statistics, anomaly detection, class comparison, demographics — all artifact-carrying), **T-274** (the 2 visualization tools: render_chart + draw_relationship_diagram), **T-275** (the 4 document tools: parent statement, class report, debt report, data export), **T-276** (the 4 workflow tools: collection campaign, batch reminders with the REAL canonical execution leg, payment plans, intervention recommendations), **T-277** (the 27-tool registry + runtime 8-step guard + the EF cap 20→40 + the LIVE matrix [P2 pins the one owner-gated deploy step with hard evidence; P3 proves Groq live through the EF]), **T-278** (the 51-test AI-311 capability suite), **T-279** (this closeout). ADR-016 records the artifact architecture + the statistical-enrichment-over-canonical-streams boundary. Suites at close: desktop **120 files / 2875 / 0** (+51) + tsc + eslint 0 err + build green; website + Android untouched (desktop + additive EF change, zero contract impact per §10); no migrations (the chain stays 0001–0084). **ONE owner-gated residual (P0):** the ai-proxy cap-40 deploy (`SUPABASE_ACCESS_TOKEN=… supabase functions deploy ai-proxy --project-ref hkvkefubghbbotgnteir --no-verify-jwt`, then re-run scripts/t277-live-matrix.sh — P2 flips 400→200) — until then, edge-mode AGENT-STREAM calls carry 27 schemas against the live 20-cap (BYOK/mock modes + all single-shot features are unaffected; runbook + evidence: t-277-live-verification.md).

**41st repair session (2026-09-10, CLOSED) — owner mandate COMPLETE ("review the AI implementation critically, fix all mistakes/inconsistencies/incomplete functionality, deliver a production-quality integration that solves real problems" + "apply the migration tokens and make sure everything works"): T-266..T-271 (6 tasks).** Session-opening ritual: the 3 repos re-cloned; the §15.11 session-opening live round ran FIRST (migration chain 81/81 = 0001–0084 ZERO DRIFT; EF fleet 14/14 ACTIVE) — then the baseline suite exposed an UNREGISTERED PATCH at HEAD (REG-005: 6ce49b9, "chore: refresh smartexport selection-state file registry", actually a 14-file AI-layer rewrite carrying 5 failed tests / 4 type errors). The patch was triaged per §15.14 — damage attributed BEFORE any work was built on it. Delivery: **T-266** (REG-005 triage + AI-309 registration + baseline repair: edgeLLMAdapter + readRawStored + routing restored, real-model defaults, tool slicing removed, Bearer-null fixed → green), **T-267** (the deep tools — 6→12: overdue/debt ledger with aging, collection analytics, payment history, attendance with drop-off risk, class performance, + REAL proposal validation + the canonical send_reminder execution leg), **T-268** (copilot UX completion: clarification question card + framed answers, abort with partial-answer commit, conversation persistence), **T-269** (EF hardening + deploy v20 + GROQ_API_KEY secret set + the LIVE agent-stream round-trip: 9/9 probes GREEN incl. tool-call reassembly on the wire; the 2026 Groq catalog discovery — llama/qwen all 404 → defaults repinned to openai/gpt-oss-120b/20b), **T-270** (the 31-test deep-integration regression suite), **T-271** (this closeout). ADR-015 records the copilot data policy (grounded tool results, BYOK/EF transports, human-gated writes, honest settle). Suites at close: desktop **119 files / 2824 / 0** (+31) + tsc + eslint 0 err + build green; website + Android untouched (desktop + additive EF change, zero contract impact per §10); no migrations (the chain stays 0001–0084, verified ZERO DRIFT at open AND close).

### T-266 — REG-005 triage: register AI-309, repair the unregistered 6ce49b9 patch's regressions, baseline back to green
- **Problems:** REG-005 (NEW), AI-309 (NEW — registered on behalf of the patch's unregistered fix) · **Priority:** P1
- **Dependencies:** none · **Affected:** hub desktop (llm-adapter, ai-config-storage, mock ai-config-repository, domain/model/ai, agent-runtime, agent-architecture tests)
- **Plan:** attribute the session-opening red suite to the 6ce49b9 commit range; KEEP the patch's sound parts (AI-309 auth fix + test, markdown-view.tsx) and register them; RESTORE what it deleted (edgeLLMAdapter + the edge→byok→mock routing + readRawStored + the stripped docs); fix its defects (defaults → real Groq models, temperature 0.6, mock-repo merge fields, tool slicing removed — a capability bug not an optimization, Bearer-null); update the 5 affected test contracts with registration.
- **Status:** Completed — TESTED (2026-09-10: tsc 0 errors, full suite 118/2793/0, lint 0 err; commit a461227)

### T-267 — Deep domain tools + enforced proposals (AI-310a): the copilot answers the school's real operational questions
- **Problems:** AI-310 (NEW) · **Priority:** P1
- **Dependencies:** T-266 (green baseline) · **Affected:** hub desktop (system-tools 6→12 tools, ai-copilot-provider approveAction send_reminder + honest settle)
- **Plan:** ground 6 NEW tools in the canonical streams (debt.observeSummary, dashboard.kpis+debtByAging, payments.observeByParent, attendance.observeByStudent+calculateAttendanceRate, students+grades per class via evaluateStudentTermPerformance); enforce REAL proposal validation (parent exists, non-zero amount ≤ 5 000 000 DZD, reason ≥ 3 chars — structured errors, never a silent console.warn); add propose_payment_reminder → repos.debt.sendReminder as the second REAL execution leg; honest settle for unexecutable types.
- **Status:** Completed — TESTED (2026-09-10: full suite green; behavioral coverage lands in T-270; commit c7107a7)

### T-268 — Copilot UX completion (AI-310b): clarification surface + abort + conversation persistence
- **Problems:** AI-310 (residuals c/d + the never-listed clarification gap) · **Priority:** P1
- **Dependencies:** T-267 · **Affected:** hub desktop (ai-copilot-provider, copilot-drawer)
- **Plan:** parse request_user_clarification tool outputs into a pendingClarification card with a framed answer turn; wire an AbortController per turn to the runtime's signal with partial-answer commit + info toast; persist messages + pending proposals to localStorage (capped 60, corrupt-safe).
- **Status:** Completed — TESTED (2026-09-10: full suite green; commit 20a2ceb)

### T-269 — ai-proxy EF hardening + LIVE agent-stream round-trip (AI-310c): GROQ secret, 2026 catalog pinned
- **Problems:** AI-310 (server leg) · **Priority:** P1
- **Dependencies:** T-266..T-268 · **Affected:** hub (supabase/functions/ai-proxy — deployed live v20; scripts/t269-live-matrix.sh; docs/recovery/t-269-live-verification.md; default model ids everywhere)
- **Plan:** .maybeSingle() on the tenant-config lookup (the OPS-309 class in the EF); agent-mode input hardening (model-id pattern, role enum, content type, 60-msg/20-tool caps); set GROQ_API_KEY as a server-side secret (CLI timeout quirk documented — digest + behavior verified); deploy; run the 9-probe live matrix including the authenticated agent-stream round-trip + tool-call passthrough + the single-shot narrative path; probe the 2026 Groq catalog and repin every default to LIVE-reachable ids (openai/gpt-oss-120b / -20b); document the gpt-oss reasoning-channel behavior.
- **Status:** Completed — VERIFIED-LIVE (2026-09-10: 9/9 probes GREEN, t-269-live-verification.md; migration chain 81/81 ZERO DRIFT at open + close; commits 2cbbace + the EF deploy)

### T-270 — The deep-integration regression suite (31 tests): REG-005-class regressions become impossible
- **Problems:** AI-310 (evidence leg) · **Priority:** P2
- **Dependencies:** T-266..T-269 · **Affected:** hub desktop (NEW src/tests/ai/ai-310-deep-integration.test.tsx)
- **Plan:** behavioral coverage of every new capability (tools against the REAL mock repositories; all five validation failure shapes; clarification/abort/persistence through the REAL runtime with stubbed SSE; the send_reminder execution leg) + source guards pinning the restored architecture (edge-first routing, readRawStored, mock-repo merge fields, full-tool wire, EF hardening markers, LIVE-reachable defaults, drawer stop/clarification wiring, no drawer repository writes).
- **Status:** Completed — TESTED (2026-09-10: 31/31 + full suite 119/2824/0; commit 3a1167b)

### T-271 — 41st-session closeout: registries + ADR-015 + change-log + zips + push
- **Problems:** process (ADR-007) · **Priority:** P2
- **Dependencies:** T-266..T-270 · **Affected:** all repos
- **Plan:** AI-309/AI-310/REG-005 problem entries with evidence (totals 221→224, 159→162 TESTED), task status flips, change-log 41st-session section, current-state 41st snapshot, next-task 42nd recommendation, ADR-015 (the copilot data policy), zips in download/, push with the owner PAT (one-shot URL, never persisted).
- **Status:** Completed (this commit)

---

### T-272 — The artifact architecture (AI-311a): tool results carry charts/diagrams/documents; the drawer renders them
- **Problems:** AI-311 (NEW) · **Priority:** P1
- **Dependencies:** T-268 (the drawer/provider base) · **Affected:** hub desktop (NEW src/core/ai/artifacts.ts, NEW src/core/ai/analysis/{statistics,insights}.ts, NEW src/features/ai/{chart-svg,diagram-svg,artifact-renderer}.tsx, NEW src/infrastructure/receipt-pdf/{report-document,class-report,debt-report,payment-plan}.ts, copilot-drawer, ai-copilot-provider, agent-types [batch_reminders type])
- **Plan:** the artifact contract (chart/diagram/document under the reserved JSON key — the wire protocol unchanged); the render-path validation gate (malformed → dropped, never rendered); the zero-dependency SVG chart engine (7 types) + diagram engine (hierarchy/flow); the generic multi-page report PDF builder over the receipts' shared primitives; the drawer parses tool messages and renders artifact cards; the provider's downloadArtifact refetches canonical data for PDFs / serializes embedded rows for XLSX-CSV.
- **Status:** Completed — TESTED (2026-09-10: full suite green; the behavioral coverage lands in T-278)

### T-273 — The statistical-analysis tools (AI-311b): trends, distributions, anomalies, comparisons, demographics
- **Problems:** AI-311 · **Priority:** P1
- **Dependencies:** T-272 · **Affected:** hub desktop (NEW src/core/ai/tools/analysis-tools.ts — 5 tools)
- **Plan:** analyze_revenue_trends (12-month series + MoM + moving average + OLS trend + line chart), compute_statistics (4 datasets + Tukey outliers + histogram), detect_anomalies (payments/attendance/grades lenses with per-anomaly explanations), compare_classes (canonical GPA aggregation + ranking + dispersion note), get_enrollment_demographics (the 4 canonical slices + capacity chart). Statistical enrichment OVER canonical streams, never a parallel derivation (ADR-016 §3).
- **Status:** Completed — TESTED (2026-09-10: full suite green)

### T-274 — The visualization tools (AI-311c): render_chart + draw_relationship_diagram
- **Problems:** AI-311 · **Priority:** P1
- **Dependencies:** T-272 · **Affected:** hub desktop (NEW src/core/ai/tools/visualization-tools.ts — 2 tools)
- **Plan:** render_chart lets the MODEL compose a custom chart from gathered data — validated through the SAME render-path gate (a malformed composition is a structured tool error, never a broken UI); draw_relationship_diagram builds family/class structures from canonical entities (teachers via the canonical timetable of the current academic year).
- **Status:** Completed — TESTED (2026-09-10: full suite green)

### T-275 — The document tools (AI-311d): statements, reports, and data exports
- **Problems:** AI-311 · **Priority:** P1
- **Dependencies:** T-272 · **Affected:** hub desktop (NEW src/core/ai/tools/document-tools.ts — 4 tools; receipt-pdf/index.ts exports)
- **Plan:** generate_parent_statement reuses the CANONICAL account-statement generator; generate_class_report / generate_debt_report are thin adapters over report-document; export_data embeds rows (≤500, self-contained) for XLSX/CSV through the SAME export engine the app's buttons use. PDF bytes never enter the conversation — the artifact carries refetch params, downloadArtifact builds at click time.
- **Status:** Completed — TESTED (2026-09-10: full suite green)

### T-276 — The workflow tools (AI-311e): campaigns, batch reminders, payment plans, interventions
- **Problems:** AI-311 · **Priority:** P1
- **Dependencies:** T-272 · **Affected:** hub desktop (NEW src/core/ai/tools/workflow-tools.ts — 4 tools; ai-copilot-provider batch_reminders approval leg; agent-types)
- **Plan:** plan_collection_campaign (amount×aging scoring per strategy, P1/P2/P3 tiers, per-debtor actions — advisory); propose_batch_reminders (ONE validated card ≤10 debtors; the approval leg executes the canonical sendReminder PER parent with honest per-parent results); propose_payment_plan (equal installments over the CANONICAL outstanding — sums exactly; a printable PDF, never a financial write); recommend_interventions (composite GPA×attendance×data-gap risk scoring with drivers + concrete actions).
- **Status:** Completed — TESTED (2026-09-10: full suite green incl. the batch approval execution leg)

### T-277 — The combined registry + runtime + EF cap 40 + LIVE matrix (AI-311f)
- **Problems:** AI-311 (wire + server cap) · **Priority:** P1
- **Dependencies:** T-272..T-276 · **Affected:** hub desktop (NEW src/core/ai/tools/tool-registry.ts, system-tools rename → CORE_*, agent-runtime [registry import + capability-map prompt + MAX_TOOL_STEPS 8], supabase/functions/ai-proxy [tools cap 20→40, DEPLOY OWNER-GATED], scripts/t277-live-matrix.sh, docs/recovery/t-277-live-verification.md)
- **Plan:** compose the 5 suites into the single 27-schema SYSTEM_TOOLS_DEFINITIONS (no slicing — the T-266 rule preserved); the system prompt teaches the capability map + workflow discipline; MAX_TOOL_STEPS 5→8 (composite workflows chain 4–6 rounds); the EF cap must be ≥ the registry size (source-guarded BOTH sides); the live matrix proves the exact deploy dependency (P2: 400 invalid_tools pre-deploy) AND the Groq path liveness (P3: 200 + SSE).
- **Status:** Completed — TESTED + LIVE-MATRIX (2026-09-10: 5/5 probes as predicted; the cap-40 DEPLOY is the one owner-gated step — runbook in t-277-live-verification.md)

### T-278 — The AI-311 capability suite (51 tests): every new capability behaviorally pinned
- **Problems:** AI-311 (evidence leg) · **Priority:** P2
- **Dependencies:** T-272..T-277 · **Affected:** hub desktop (NEW src/tests/ai/ai-311-capability-suite.test.tsx; updated agent-architecture [27-tool registry + 8-step guard], ai-310 [import path], copilot-drawer [new starter suggestions])
- **Plan:** known-vector statistics; insight behavior (anomalies, prioritization, exact-sum plans, risk thresholds); the artifact validation gate incl. model-composed malformed charts; all 15 tools against the mock repositories incl. structured errors + honest partial validation; the 3 PDF generators + multi-page flow; RTL artifact rendering; the FULL pipeline harness (a revenue-trends tool call rendered as a chart IN the drawer); the batch approval leg; 6 source guards (registry composition, 8 steps, the EF-cap ≥ registry trap, the drawer's validated parse path, the provider legs, the fail-open gate).
- **Status:** Completed — TESTED (2026-09-10: 51/51 + full suite 120 files / 2875 / 0)

### T-279 — 42nd-session closeout: registries + ADR-016 + change-log + zips + push
- **Problems:** process (ADR-007) · **Priority:** P2
- **Dependencies:** T-272..T-278 · **Affected:** all repos
- **Plan:** AI-311 problem entry with evidence (totals 224→225, 162→163 TESTED), task status flips, change-log 42nd-session section, current-state 42nd snapshot, next-task 43rd recommendation (the P0 owner deploy runbook first), ADR-016, conventional commits with the 5-question body, zips in download/, push with the owner PAT (one-shot URL, never persisted).
- **Status:** Completed (this commit)

### T-280 — Restore the owner-pinned admin credential `admin@elimtiyaz.dz` / `elimtiyaz@admin2026` + the permanent no-rotation pin (OPS-310)
- **Problems:** OPS-310 (NEW — see problem registry) · **Priority:** P0 (owner lockout)
- **Dependencies:** none (live-auth only — no app code) · **Affected:** live Supabase auth (admin user password) + docs (`docs/operations/credentials.md` §1) + 3 probe scripts (`elimtiyaz-desktop/scripts/t241/t269/t277-live-matrix.sh` ADMIN_PW)
- **Plan:** the owner reported their canonical admin sign-in stopped working. Root cause (live-probed): the T-079/T-241 session pattern had re-set the password to the probe value `Elimtiyaz2026Admin!` whenever the then-current value stopped matching, silently overwriting the owner's credential. Restore: acquire a JWT with the still-working probe value → GoTrue self-service `PUT /auth/v1/user` with `{password, current_password}` (authenticated user path — no service-role/sbp_ token required) → verify BOTH directions (owner value → JWT; old probe value → 400 invalid_credentials). Permanent pin: the owner directive recorded in the canonical credentials sheet (NEVER rotate/re-set; `invalid_credentials` on the pinned value → STOP and ask the owner) + the three live-matrix scripts carry the owner value as `ADMIN_PW` so future probe rounds authenticate without triggering any re-set fallback.
- **Status:** Completed — VERIFIED LIVE (2026-09-10: `elimtiyaz@admin2026` → 796-char JWT; `Elimtiyaz2026Admin!` → 400 invalid_credentials; the account remains active/confirmed with no other attribute touched. No app/EF/DB change — the 42nd-close suites stand unchanged [120 files / 2875 / 0]. Note: the password change revokes prior refresh tokens by design — the owner signs in fresh on desktop/web with the restored credential.)

### T-281 — Rate-limit resilience + the selectable models list (AI-312): 429 backoff/Retry-After, the human 429 verdict, ModelSelectField
- **Problems:** AI-312 (NEW — see problem registry) · **Priority:** P1 (the owner's console: five consecutive Groq 429s, every copilot turn failing)
- **Dependencies:** none (client-only) · **Affected:** hub desktop (`src/core/ai/streaming/stream-client.ts`, `src/core/ai/agent-runtime.ts`, `src/features/settings/ai-config-tab.tsx`, NEW `src/tests/ai/t-281-rate-limit-resilience.test.tsx`; updated `src/tests/ai/agent-architecture.test.ts`)
- **Plan:** the owner's console log (2026-09-10 11:16) showed 5× HTTP 429 from api.groq.com with the copilot failing, plus the explicit ask "make the models list fetched and selected". Root cause A: NO retry anywhere — `executeOpenAIStream` threw on the first non-OK (free-tier Groq limits are per-minute; an immediate give-up can never succeed, and the runtime's fallback-model retry was also immediate). Root cause B: the models were free-TEXT inputs — the fetched `availableModels` list was never selectable, and the auto-discovery effect read live form state (empty on first render) so opening the tab without saving never even fetched the list. Fix: (1) stream-client transient-retry (429/5xx, exponential backoff 800ms×2ⁿ capped 10s, `Retry-After` honoured seconds+HTTP-date, jitter, abort-aware, initial POST only; `STREAM_RETRY` export = test seam); (2) the runtime turns a persistent 429 (active + fallback exhausted) into a human French verdict with guidance instead of a raw provider body; (3) `ModelSelectField` — dropdown fed by the fetched list, current out-of-list value stays selectable with a "hors liste" badge, "Saisie manuelle…" escape hatch, empty-list degrades to the input; (4) the auto-discovery effect keyed on the SAVED config (fires on tab open, never per keystroke).
- **Status:** Completed — TESTED (2026-09-10: 17 new tests [retry/backoff/Retry-After/abort/consumed-body, the runtime verdict + the preserved T-260 fallback-success path with the wire model switch asserted, the 4 ModelSelectField rendered branches + the manual-entry interaction, 4 source guards] + the existing 429 unit updated for the retry world; full suite **122 files / 2897 / 0** + tsc + eslint 0 err + build green 22.9 s)

### T-282 — The audit-read transient-5xx retry (OPS-311): the owner-observed intermittent 500 on `order=occurred_at.desc&limit=200`
- **Problems:** OPS-311 (NEW — see problem registry; the OPS-309 residual (a), now owner-reproduced) · **Priority:** P2 (console noise; the audit feed/search degrade silently)
- **Dependencies:** none (client-only) · **Affected:** hub desktop (`src/infrastructure/supabase/repositories/supabase-audit-log-repository.ts`, NEW `src/tests/infrastructure/t-282-audit-transient-retry.test.ts`)
- **Plan:** the owner's console (2026-09-10 11:15) shows the intermittent HTTP 500 on the audit recent-activity query that OPS-309 had recorded as "one-off, not reproducible". Live-probed this session with the admin JWT: the EXACT query returns 200 in ~1.1s with 161 small rows (max 1.4 KB) — a transient server-side blip under the startup query burst, not a query defect (the `(tenant_id, occurred_at desc)` index exists since 0014). Fix: `queryWithTransientRetry` — ONE 600ms-delayed retry on the three audit READ paths (`query`/`byEntity`/`recent`), preserving the full result shape (data/error/count); the write path `log()` is never blindly retried.
- **Status:** Completed — TESTED (2026-09-10: 5 behavioral tests [the delayed retry fires exactly twice on a transient error; a persistent error surfaces after exactly one retry; a clean first attempt never pays the delay; byEntity + query share the contract incl. count/hasMore preservation]; source guard in the T-281 suite pins that `log()` stays unwrapped; full suite green)

---

## 44th session (2026-09-11) — owner mandate: "review the changes and redo them properly — the previous agent implemented them too shallowly; integrate the logic at the CORE level, fix the implementation, create a comprehensive equivalence test against the database; true data + logic equivalence between desktop and mobile"

> Mandate source: the owner's pasted previous-agent report (the dashboard-parity directive: collection rate 49%, aging re-anchored to due dates, descriptive statistics §15, funnel, bins, Pareto, category mix) + the verdict that commits `ea2441a`/`6f88b14` in `elimtiyaz-android` were a shallow UI-layer integration. Registered BEFORE implementation per AGENTS.md §13.

### T-283 — Register PARITY-002: the shallow Android dashboard-parity patch (hard-coded fallbacks, no core engine, zero tests)
- **Problems:** PARITY-002 (NEW — see problem registry) · **Priority:** P1
- **Dependencies:** none · **Affected:** hub docs only
- **Plan:** audit the previous agent's Android commits (ea2441a, 6f88b14, 2026-09-10) against the desktop canonical derivations (`analytics-derivations.ts`, `supabase-dashboard-repository.debtByAgingForRange`, `insights-rail` collection rate, `recovery-funnel-card`) and record every divergence with file/line evidence: UI hard-coded desktop numbers as fallbacks, inline repository statistics (no `core/` engine, ADR-002 violation), population-vs-sample σ, integer-division mean/median (PARITY-001 class), category mix dropping 9 of 11 categories, best-month grouping across years with a fabricated "Août" default, funnel fabricated at 100% critical when data absent, attendance excluding "late" (desktop Supabase counts present+late), the broken PDF aging call sites, the 91_180 chip omission, and the run_deploy.sh seed-data regression.
- **Status:** Completed (this session — problem entry written with file:line evidence before the fix)

### T-284 — Core-level integration: `core/StatisticsEngine.kt` (Kotlin mirror of the desktop analytics derivations) + repository rewire + UI fallback purge
- **Problems:** PARITY-002 · **Priority:** P1
- **Dependencies:** T-283 · **Affected:** android (`core/StatisticsEngine.kt` NEW, `domain/model/DashboardKpi.kt`, `infrastructure/local/LocalDashboardRepository.kt`, `infrastructure/local/LocalDebtRepository.kt`, `ui/features/dashboard/*`, `core/Ledger.kt` category labels)
- **Plan:** port the desktop's `analytics-derivations.ts` VERBATIM into a pure Kotlin engine (ADR-002 mirror rule, source commit recorded in the header): derivePaymentStats (SAMPLE σ ÷(n−1), Math.round mean/median), AMOUNT_BINS half-open [lo,hi) in centimes, deriveMix/deriveCategoryMix (all 11 categories, FR labels, desc sort, topN+Autres tail), derivePareto (top-8, cumulative % of displayed total), deriveRecoveryFunnel (from aging-bucket family counts), deriveAgingComposition (bucket shares), collectionRatePct (round, clamp 100), deriveRevenueTrend (cumulative + MA3), plus the canonical INV-4 installment aging derivation (per-installment remaining = max(0, due−paid−pending), daysBetweenFloor(dueDate), distinct-parent debtorCount per bucket — the desktop Supabase path). Extend `DashboardKpi` to carry the computed contract (collectionRatePct, debtByAging buckets, funnel percentages, category/bins from the engine). Rewire BOTH repositories to consume the engine (deleting the 5 copy-pasted ledger-else-installments fallbacks into one shared derivation). Purge every hard-coded fallback from the UI layer (0.49f, 26_900_000f/31_400_000f donut, 58_355_700_00L, 54%, "6 fam. = 80%", funnel "0%"/"100%", "Août" default, attendance 100.0 loading default) — honest empty states instead (§15.16). Fix "Sept"→"Sep" month label, attendance = (present+late)/total.
- **Status:** Completed — TESTED (2026-09-11: compileDebugKotlin green [the previous agent's pushed tree did NOT compile — 3 unresolved references, evidence in the change-log]; full Android suite 53 files / 455 tests / 0 failures / 0 errors incl. the 24-test StatisticsEngineTest; the 3 compile errors in the pushed tree [ElProgressBar ×2, background import] repaired; T-026 source-scan floor 5→3 with the documented PARITY-002 rationale — the invariant [every remaining call site passes the dueDateMap] preserved)

### T-285 — The comprehensive equivalence test suite: engine corpus + live-database verification
- **Problems:** PARITY-002 (test leg) · **Priority:** P0 (the owner's explicit mandate)
- **Dependencies:** T-284 · **Affected:** android (`app/src/test/.../StatisticsEngineTest.kt` NEW, `LiveDatabaseEquivalenceTest.kt` NEW), hub (`financial-tests/equivalence/scenarios/analytics_*.json` NEW, `desktop/desktop_runner.ts` op, android runner op, `elimtiyaz-desktop/scripts/verify_t-285.sql` NEW)
- **Plan:** three legs proving every displayed statistic is numerically identical across desktop/android AND against the database: (a) `StatisticsEngineTest` pinning every derivation against the desktop's own `analytics-visuals.test.tsx` fixtures (same inputs, same expected outputs — centimes); (b) new canonical corpus scenarios (analytics stats ops with pinned `now`) implemented in BOTH desktop_runner.ts and AndroidEquivalenceRunner.kt, compared centime-exact by the triple comparator; (c) a live-DB harness: SQL truth script (verify_t-285.sql — BEGIN/ROLLBACK, temp results table, computes every statistic from raw tables) + a JVM test pulling the same live rows via PostgREST and running the Android engine over them, asserting engine output == SQL truth (payments count/total/mean/median/σ/bins/categories, installment aging buckets/families, funnel, collection rate, class counts, roll-call attendance).
- **Status:** Completed — VERIFIED LIVE (2026-09-11: leg (a) 24/24 StatisticsEngineTest [desktop-fixture-pinned incl. the DZD-granularity rounding trap + the funnel census-semantics pin]; leg (b) the `deriveAnalyticsStats` op in BOTH runners + category `analytics_statistics` 3/3 scenarios EQUIVALENT, 0 discrepancies — full-corpus comparator 303/307 with the SAME 4 pre-existing discrepancies proven pre-existing via a stash re-run on the unmodified runners [017/023/024/025 — NaN-display/null-studentId/undefined-field corpus quirks untouched by this change]; leg (c) LiveDatabaseEquivalenceTest PASSED live with the owner-supplied credentials — engine output == server-side SQL truth on EVERY value: 891 paid payments, 5 522 710 000 centimes total, mean 6 198 300, median 6 100 000, sample σ 4 495 100, min 200 000 / max 32 650 000, best month Août 5 522 710 000, bins 3/2/63/341/482 (50k+ dominant), category mix tuition 785 ops 5 316 310 000/96% + transport 106 ops 206 400 000/4%, aging census 91_180 = 26 919 750 000/196 fam + 180_plus = 31 435 950 000/183 fam [funnel Σ 379], outstanding 5 835 570 000, overdue 5 835 570 000, collection rate 49, 24 classes; canonical script `scripts/verify_t-285.sql` + hub evidence t-285-live-verification.md)

### T-286 — Sibling-surface alignment: PDF aging call sites + debt-screen 91_180 chips + shared totals
- **Problems:** PARITY-002 (residual surfaces) · **Priority:** P2
- **Dependencies:** T-284 · **Affected:** android (`infrastructure/pdf/AndroidPdfRepository.kt`, `ui/features/financials/DebtDashboardScreen.kt`, `ui/features/financials/FinancialsCreancesTab.kt`, `domain/model/DebtSummary.kt`)
- **Plan:** the same displayed statistic must not diverge by screen: fix the PDF debtAgingReport call sites (computeParentSummary WITHOUT the due-date map → "En retard" column permanently 0; no installments), add the missing 91_180 filter chips, and route the debt screens' recomputed totals through the shared engine derivation.
- **Status:** Completed — TESTED (2026-09-11: AndroidPdfRepository.debtAgingReport now consumes DebtRepository.observeSummary — the SAME canonical derivation as every screen; DebtSummary gained overdueAmount [the INV-4 overdue portion]; DebtDashboardScreen + FinancialsCreancesTab render both 91–180 j chips and the true overdue totals from the shared field; compile + full suite green; the 44th-session corpus values [26.9M/31.4M/58 355 700/49%] are now DERIVED, never hard-coded)

### T-287 — 44th-session closeout: registries + change-log + zips + push
- **Problems:** process (ADR-007) · **Priority:** P2
- **Dependencies:** T-283..T-286 · **Affected:** all repos
- **Plan:** PARITY-002 status flip with evidence, task status flips, change-log 44th-session section, current-state snapshot, next-task 45th recommendation, conventional commits with the 5-question body per repo, zips in download/, push with the owner PAT.
- **Status:** Completed (2026-09-11 — registries + change-log + current-state + next-task 45th recommendation + zips + push all landed; status truth-synced by the 45th session's opening commit, the same T-218 precedent)

---

## 45th session (2026-09-11) — owner mandate: "100% Visual, Mathematical & Analytical Parity (Desktop to Android)" — the 13-chart parity inventory

> Mandate source: the owner's comprehensive engineering directive (§3 inventory table: 13 desktop visualizations — revenue trend explorer + MA3, weekly operating rhythm, recovery funnel, amount histogram, method mix donut, category revenue breakdown, collection heatmap, top-debtors Pareto, debt aging composition, YoY comparison, 7-day attendance spline, tranche wave progress, class demographics & capacity gauges — every one must have a native Jetpack Compose implementation computed from the exact same canonical data models and mathematical logic, with a `CrossPlatformEquivalenceTest.kt` proving identical numbers). Registered BEFORE implementation per AGENTS.md §13.

### T-288 — Register PARITY-003: the visual/chart parity gap (5 missing derivation families + 8 missing native chart components)
- **Problems:** PARITY-003 (NEW — see problem registry) · **Priority:** P1
- **Dependencies:** T-284/T-285 (the statistics-engine base) · **Affected:** hub docs only
- **Plan:** audit the 13-item inventory against both codebases and record the exact gap: engine-missing derivations (deriveWeeklyRhythm, deriveCollectionHeatmap, deriveYearOverYear + shiftIsoYearBack/previousAcademicYear/inRange/applyAnalyticsFilters/presentCategories/deriveFilteredMonthly, deriveTrancheWaves + trancheNumberOf, demographics grade/gender/age/capacity) and UI-missing components (stacked bar chart, composed revenue chart with cumulative+MA3, method-mix donut card, horizontal ranked bars, heatmap grid, Pareto chart, 100% stacked ratio bar, grouped YoY bars, capacity gauge arc, tranche wave meters, demographics card) plus the un-rendered `paymentMethods` stream and the list-only Pareto/aging surfaces.
- **Status:** Completed (this session — problem entry written with file:line evidence before the fix)

### T-289 — Engine completion: the 5 missing derivation families in `core/StatisticsEngine.kt` (verbatim ADR-002 mirrors)
- **Problems:** PARITY-003 (engine leg) · **Priority:** P0
- **Dependencies:** T-288 · **Affected:** android (`core/StatisticsEngine.kt`)
- **Plan:** port VERBATIM (source-commit-recorded header): (a) `deriveWeeklyRhythm` — counter-activity convention (exclude ONLY status="refunded", unlike the paid-only encaissé slice), Dim→Jeu school week, per-method accumulation, UTC day computation; (b) `deriveCollectionHeatmap` — month columns walked from the range cursor (guard ≤ 24), 5 school-weekday rows, cell level = max(1, ceil(amount/max×4)) quantized in 5 steps, monthTotals + rowTotal + max; (c) `deriveYearOverYear` — month-LABEL alignment, deltaPercent = prev>0 ? Math.round((cur−prev)/prev×100) : null (null = "n/a", never −100%), totals + global delta; + `shiftIsoYearBack` (leap-day safe) + `previousAcademicYear` + `inRange` + `applyAnalyticsFilters` + `presentCategories` + `deriveFilteredMonthly`; (d) `deriveTrancheWaves` + `trancheNumberOf` — regex ^\s*Tranche\s*([1-3])\b, per-wave due/paid/pending sums, pct = min(100, round(paid/due×100)), isNextTarget = first wave with outstanding > 0, T1 "(Septembre)"/T2 "(Décembre)"/T3 "(Mars)" labels; (e) `deriveDemographics` — grade (GRADE_LEVEL_LABELS_FR or class name fallback), gender (Garçons/Filles/Non spécifié), age buckets (<6/6–8/9–11/12–14/15–17/18+, year-only arithmetic), capacity (cap default 30, pct = round(count/cap×100)). All centimes, mathRound/dzRound rounding discipline, PARITY-001 seams respected.
- **Status:** Completed — TESTED (2026-09-11: 12 new StatisticsEngineTest tests pin the 5 families against the desktop corpus scenarios — refunded-exclusion/counter-activity, Fri/Sat drops, heatmap 5-step level quantization, YoY null-delta semantics [Nov −100% vs Déc null], tranche regex traps ["Tranche 10"/"Année complète" never match; lowercase "tranche 3" matches], pct clamp at 100, next-target flag, demographics fallback chain + default-30 capacity; CrossPlatformEquivalenceTest 3/3 scenarios × 5 families centime-exact vs the desktop-generated then-blocks)

### T-290 — Repository + ViewModel wiring: every new derivation flows through the engine (never UI re-derivation)
- **Problems:** PARITY-003 (data leg) · **Priority:** P0
- **Dependencies:** T-289 · **Affected:** android (`domain/model/DashboardKpi.kt`, `domain/repository/DashboardRepository.kt`, `infrastructure/local/LocalDashboardRepository.kt`, `ui/features/dashboard/DashboardViewModel.kt`)
- **Plan:** extend `DashboardKpi` with the engine contract (weeklyRhythm, collectionHeatmap, yoy, trancheWaves, demographics, paymentStats min/max consolidation, methodMix); rewire `observePaymentMethodsSummary` through `deriveMethodMix` (the fixed-3-method custom derivation retires); the ViewModel exposes the new state; the UI consumes repository-computed values ONLY (§15.16 + PARITY-002 discipline — no inline statistics, no fallback numbers).
- **Status:** Completed — TESTED (2026-09-11: DashboardKpi carries the 10 new contract fields; LocalDashboardRepository.observeKpis computes methodMix/weeklyRhythm/heatmap/revenueTrend/yoy/trancheWaves/demographics through the engine over ONE 12-month window; observePaymentMethodsSummary retired its fixed-3-method parallel derivation → deriveMethodMix; full Android suite 54 files / 467 / 0)

### T-291 — Native Compose UI: the 13 visualizations (8 new chart primitives + the card grid)
- **Problems:** PARITY-003 (UI leg) · **Priority:** P0
- **Dependencies:** T-290 · **Affected:** android (`ui/designsystem/components/data/` NEW primitives + `ui/features/dashboard/` Analytique tab rebuild + `ui/features/financials/FinancialsTranchesTab.kt` + `ui/features/academics/ClassDetailScreen.kt`)
- **Plan:** new pure-Canvas primitives in the design system (house style: Animatable reveal + ElTheme.colors): ElStackedBarChart (weekly rhythm), ElComposedRevenueChart (bars + cumulative + MA3 overlay, dual scale), ElHorizontalBarChart (category ranking with Montant/Nb toggle), ElHeatmapGrid (weekday × month matrix, 5-step alpha quantization), ElParetoChart (bars + cumulative % curve + right axis), ElStackedRatioBar (100% aging composition), ElGroupedBarChart (YoY current vs previous), ElGaugeArc (capacity). Cards: WeeklyOperatingRhythmCard (Overview), the desktop-parity Analytique tab (slicers → stat strip → trend explorer + mix cards → YoY + histogram → heatmap + aging composition → Pareto), TrancheWaveCard (Financials Tranches tab, global meters + totals row), DemographicsCard + capacity gauges (ClassDetailScreen + Analytique). Calm executive styling (brand blue / warm gold / dark slate), responsive, honest empty states.
- **Status:** Completed — TESTED (2026-09-11: ElChartPalette [the desktop dashboard-theme hex mirror], ElStackedBarChart, ElComposedRevenueChart [cumulative + MA3, connectNulls=false], ElHorizontalBarChart, ElHeatmapGrid, ElParetoChart + ElStackedRatioBar, ElGroupedBarChart + ElGaugeArc — 8 primitives + 8 data carriers; the analytics package renders all 13 cards [slicers → stat strip → trend explorer → mix cards → YoY + histogram → heatmap + aging → funnel + Pareto + demographics]; TrancheWaveCard in FinancialsTranchesTab; capacity gauge + gender chips in ClassDetailScreen; compile + full suite + lint 0 errors green)

### T-292 — `CrossPlatformEquivalenceTest.kt`: the 13-visualization equivalence suite + corpus generation
- **Problems:** PARITY-003 (proof leg) · **Priority:** P0 (the owner's explicit mandate)
- **Dependencies:** T-289 · **Affected:** android (`app/src/test/.../CrossPlatformEquivalenceTest.kt` NEW, `AndroidEquivalenceRunner.kt` op), hub (`financial-tests/equivalence/scenarios/analytics_visuals_*.json` NEW, `desktop_runner.ts` op, generator script)
- **Plan:** (a) a hub generator script runs the REAL desktop TS derivations over shared reference datasets (payments, installments, students/classes, prev/current revenue series) and records the expected outputs as canonical corpus scenarios (category `analytics_visuals`); (b) the op implemented in BOTH runners (desktop_runner.ts + AndroidEquivalenceRunner) computing every new derivation; (c) `CrossPlatformEquivalenceTest.kt` runs the corpus + asserts identical numbers/bins/percentages/status tags; (d) StatisticsEngineTest extended with desktop-fixture-pinned unit tests for the 5 new families (heatmap levels, YoY null-delta semantics, weekly rhythm refunded exclusion, tranche waves, demographics buckets).
- **Status:** Completed — TESTED (2026-09-11: the generator scripts/generate_analytics_visuals_corpus.ts fills the then-blocks from the REAL TS derivations [idempotent — re-run verified]; the deriveAnalyticsVisuals op in BOTH runners; CrossPlatformEquivalenceTest.kt passes [3 scenarios × 5 families all identical]; full corpus through the android runner: 310 scenarios → 308 EQUIVALENT [the 2 discrepant are the documented pre-existing 023/025 null-vs-empty studentId — untouched by this change]; desktop runner 309 passed + 1 intentional error-equivalent [017]; StatisticsEngineTest 35/35; one hand-typed demographics expectation corrected to the desktop-pinned values [the engines already agreed — the test comment had miscounted a class])

### T-293 — 45th-session closeout: registries + change-log + zips + push
- **Problems:** process (ADR-007) · **Priority:** P2
- **Dependencies:** T-288..T-292 · **Affected:** all repos
- **Plan:** PARITY-003 status flip with evidence, task status flips, change-log 45th-session section, current-state snapshot, next-task 46th recommendation, conventional commits with the 5-question body per repo, zips in download/, push (owner PAT if re-supplied; otherwise documented as blocked).
- **Status:** Completed (2026-09-11 — registries + change-log + current-state + next-task landed; conventional commits in BOTH repos with the 5-question bodies; zips generated in download/; the push leg COMPLETED the same day in the 45th-session continuation once the owner re-supplied the PAT: android 5c03a9e..181d060 and hub cf11cc7..df09226 pushed with a one-shot URL [never persisted, FETCH_HEAD sanitized] and API-verified on origin/main of both repos; pre-push re-verification of the exact pushed trees — Android `testDebugUnitTest` 467 tests / 0 failures / 1 skipped [CrossPlatformEquivalenceTest + AndroidEquivalenceTest + LiveDatabaseEquivalenceTest + StatisticsEngineTest 35/35 all green], desktop typecheck 0 errors + vitest 122 files / 2897 passed + vite build green; the 9 `testReleaseUnitTest` failures in 3 suites proven pre-existing at parent 5c03a9e [release-variant infrastructure: schema assets, suffixed applicationId launcher, channel count] — NOT a parity regression)

---

---

## 46th session (2026-09-11) — owner mandate: "Fix and stabilize the offline-first architecture" (diff engine, conflict resolution, realtime notifications, offline backup/restore, zero duplication)

> Mandate source: the owner's 46th-session engineering directive — visual red/green field-level diff engine with operator attribution (Name, Account ID, Role) integrated into the Audit Log AND the Merge Conflict Resolver; concurrent-edit conflict detection (never silent overwrite) with a 3-way visual resolver (Base vs User A vs User B, choose-A / choose-B / field-level manual merge) and notifications on detection AND resolution; realtime cross-platform notifications (Desktop ↔ Android) carrying Actor + Action + Target Entity; offline-first standalone operation on encrypted local storage (Android Room / Desktop IndexedDB) with offline browse + restore of ANY historical backup archive and post-restore sync staging that drains safely on reconnect without data loss; toggleable auto-backup scheduler + on-demand snapshots + point-in-time file selector; STRICT zero-duplication (revive the existing orphan modules — AuditDiffDrawer, AuditRepository, before_json/after_json, Reconcile.kt/reconcile/, SyncService, SyncQueueDispatcher, BackupRepository, kahn.ts, pii-mask.ts — no parallel data models, computation engines, UI, or sync queues); massive testing (Vitest + JUnit/Robolectric/MockK) with 0 errors, 0 regressions, 100% pass. Registered BEFORE implementation per AGENTS.md §13.

### T-294 — Register OFFLINE-400: the offline-first stabilization gap family (6 sub-gaps, file:line evidence)
- **Problems:** OFFLINE-400 (NEW — see problem registry) · **Priority:** P1
- **Dependencies:** none · **Affected:** hub docs only
- **Plan:** audit both codebases against the mandate and record the exact gaps (this registration): the shallow raw-JSON AuditDiffDrawer; the dropped actor_role in mapAuditRow; Android's fabricated delta inspector; the absent 3-way conflict detection/resolver; the absent realtime audit broadcast on both platforms; the mock-only restore + the untoggleable scheduler.
- **Status:** Completed (this session — problem entry written with file:line evidence before the fix)

### T-295 — Field-level diff engine (desktop TS): `src/domain/calc/diff/field-diff.ts` — pure, nestable, red/green semantics
- **Problems:** OFFLINE-400 (sub-gap 1) · **Priority:** P0
- **Dependencies:** T-294 · **Affected:** hub desktop (`src/domain/calc/diff/field-diff.ts` NEW — no existing diff computation to duplicate; the AuditDiffDrawer never computed deltas)
- **Plan:** a PURE function family: `computeFieldDiff(before, after)` → `FieldDiffNode[]` where each node carries `{ path, kind: added|removed|changed|unchanged, oldValue, newValue, children }`; nested objects recurse by sorted key order; arrays diff by index with length-change semantics (added/removed tail entries); primitives + null handled exactly (null ≠ undefined ≠ "" at the leaves, but null-vs-absent collapses for display); deep-equal short-circuit; cycle-safe (identity map). Formatting helpers render values as compact display strings (objects → "{…} N champs", arrays → "[…] N éléments"). Dedicated Vitest suite: nested objects, arrays (grow/shrink/reorder), primitives, null/undefined/"" boundaries, deep-equal fast path, cycle guard.
- **Status:** Completed — TESTED (2026-09-11: 29/29 src/tests/domain/field-diff.test.ts; commit 86dcf77)

### T-296 — Desktop AuditDiffDrawer upgrade: field-level red/green rendering + full actor attribution (Name, Account ID, Role)
- **Problems:** OFFLINE-400 (sub-gaps 1+2) · **Priority:** P0
- **Dependencies:** T-295 · **Affected:** hub desktop (`src/features/settings/audit-log-tab.tsx` AuditDiffDrawer REVIVED in place, `src/infrastructure/supabase/repositories/supabase-audit-log-repository.ts` mapAuditRow actor_role fix, mock mapper parity, NEW regression tests)
- **Plan:** fix `mapAuditRow` to carry `actor_role` (and the mock mapper); the drawer renders the T-295 diff tree: per-field rows with the old value struck/red and the new value green, nested paths indented, added fields green-only, removed fields red-only; the drawer header shows actorName + actorId (Account ID) + actorRole badge; the audit list rows show the role chip. Regression tests: mapper parity (actor_role round-trip), drawer rendering (field rows, red/green classes, actor attribution block), empty-diff honesty (INSERT-only entries show all-green added fields; DELETE-only all-red removed).
- **Status:** Completed — TESTED (2026-09-11: 11/11 t-296-audit-diff-drawer + 40/40 combined with field-diff; mapAuditRow carries actor_role + the RPC path passes p_actor_role; commit 86dcf77)

### T-297 — Android audit diff mirror: `core/FieldDiff.kt` (verbatim mirror) + the real before/after renderer in AuditStreamScreen/AuditLogScreen
- **Problems:** OFFLINE-400 (sub-gap 3) · **Priority:** P0
- **Dependencies:** T-295 · **Affected:** android (`core/FieldDiff.kt` NEW mirror with source-commit header, `ui/features/personnel/AuditStreamScreen.kt` fabricated inspector REPLACED, `ui/features/settings/AuditLogScreen.kt`, NEW FieldDiffTest)
- **Plan:** port the T-295 engine verbatim to Kotlin (kotlinx.serialization JsonElement traversal; ADR-002 mirror discipline); replace the fabricated "Inspecteur JSON" with a real field-level red/green renderer reading `beforeJson`/`afterJson` (parse → computeFieldDiff → rows: old value red, new value green, path label, added/removed semantics); actor attribution (name + role + account id) in the sheet header and the list rows. Unit tests mirror the desktop vectors (nested/arrays/primitives/null) + a rendering-state test.
- **Status:** Completed — TESTED (2026-09-11: android commit a8a046a — FieldDiffTest 26/26 + AuditDiffSheetTest 9/9 [35/35 targeted]; full suite 56 suites / 502 / 0 failures / 0 errors; the shared ui/components/AuditDiffSheet.kt renderer replaces the fabricated payload dump in BOTH screens; one mirror deviation found+fixed live: malformed-before + valid-after must render nothing, not an INSERT — now matches the desktop drawer's parseAuditDiff)

### T-298 — 3-way merge conflict detection + resolver UI + conflict notifications (desktop)
- **Problems:** OFFLINE-400 (sub-gap 4) · **Priority:** P0
- **Dependencies:** T-295 (the field-diff engine powers the 3-way rendering) · **Affected:** hub desktop (`src/domain/calc/diff/three-way.ts` NEW, `src/infrastructure/sync/` conflict detection on the push path, NEW resolver modal + notification wiring, NEW suites)
- **Plan:** (a) pure 3-way engine: `detectConflicts(base, local, remote)` → `FieldConflict[]` (per-path: local-vs-base diff, remote-vs-base diff, overlap = conflict; non-overlapping changes auto-merge); `resolveThreeWay(base, local, remote, choices)` applies per-field choices (take-local / take-remote / manual value). (b) Conflict detection wired into the existing SyncService push path: a queued entry whose payload diverges from the server row on a field BOTH sides changed creates a ConflictRecord (never silent LWW overwrite) + emits a notification + opens the resolver from the sync indicator. (c) The resolver modal: 3-column view (Base / User A / User B) with the T-295 field-level red/green in each column, per-field choice chips (A / B / manual edit), the merged preview, and an audit-logged resolution (`sync.conflict_resolved` with before/after). Resolution emits a second notification. Vitest: detection vectors (both-changed-same-field, disjoint auto-merge, array edits, null transitions), resolution correctness, no-silent-overwrite guarantee, notification emission (both events).
- **Status:** Completed — TESTED (2026-09-11: commit 595fc97 — three-way.test.ts 28/28 + t-298-conflict-flow.test.ts 16/16 [44/44]; full suite 126/2981/0; the drain parks update+basePayload entries in the NEW "conflict" status (push NEVER called — the no-silent-overwrite guarantee), the record persists ON the queue entry (IndexedDB-survivable, no parallel store), resolveConflict recomputes the 3-way and re-queues pending; the guard fail-opens on fetch errors; the production conflict-detector maps 7 entity kinds to their tables+unique keys with the idempotent camel→snake payload projection; BOTH notifications + BOTH audit entries fire; the resolver opens from the SyncIndicator AND the SyncTab)

### T-299 — Realtime cross-platform notification broadcast with actor attribution (Desktop ↔ Android)
- **Problems:** OFFLINE-400 (sub-gap 5) · **Priority:** P0
- **Dependencies:** T-296 (actor attribution surfaces) · **Affected:** hub desktop (`src/infrastructure/supabase/` realtime subscription on audit_logs + topbar activity feed), android (`RealtimeSyncManager` routing + notifications surface), supabase migration ONLY IF RLS requires it (check first — 0019's audit SELECT policy scope)
- **Plan:** subscribe both platforms to `audit_logs` postgres-changes (the canonical "every change" stream — every mutation already writes an entry via write_audit_log, so ONE subscription covers the whole mandate); the desktop topbar feed + toast render the attributed sentence "Actor (Role) action target" from the entry's actor_name/actor_role/action/entity_type+entity_id; the Android routing map gains audit_logs → notification pull + an in-app attributed feed. Realtime events must respect the existing RLS SELECT policy on audit_logs (staff-scoped — verify with a live probe; if the policy blocks the anon/staff realtime SELECT, ship a migration widening only the realtime-read path per the 0048 precedent and verify live). Notification attribution resolution: actor name + role + account id from the audit row itself (denormalized columns — no joins needed).
- **Status:** Completed — TESTED (2026-09-11: hub commit 9c75293 + android commit 0491a9b — desktop t-299-audit-realtime 15/15 + full suite 127/2996/0; android RealtimeSyncT069Test 14/14 + AuditPullT299Test 4/4 + full suite 57/507/0. DEVIATION from the task text recorded: NO RLS widening — migration 0085 adds audit_logs to the supabase_realtime publication ONLY; realtime still filters per-subscriber by the 0019 SELECT policies (widening would have leaked the forensic before/after JSON to every role — a §15.4 weakening; targeted staff alerts keep their notifications channel). The desktop: AuditRepository.observeActivity + the mock emitting on log() + the Supabase lazy INSERT subscription + formatAttributedActivity + the topbar AuditActivityToaster (self-suppression). The Android: the audit_logs routing entry + AuditLogDto/mapper + pullAudits → the T-297 attributed feed goes LIVE. RESIDUAL: migration 0085's LIVE application is owner-token-gated (the sbp_ access token was not re-supplied this session — apply via db push, same pattern as the T-293 push leg)

### T-300 — Offline-first restore + sync staging: the desktop backup restore becomes REAL (offline browse → restore → stage → safe drain)
- **Problems:** OFFLINE-400 (sub-gaps 6+7 partial) · **Priority:** P0
- **Dependencies:** T-295 (diff engine not required; backup/restore is independent) · **Affected:** hub desktop (`src/infrastructure/backup/backup-service.ts` restore() upgraded, `src/infrastructure/backup/` archive browser, `src/features/settings/backup-tab.tsx`, sync-queue integration, NEW suites)
- **Plan:** (a) offline archive browser: `inspectArchive(archiveId)` decrypts in place and returns the parsed snapshot summary (per-collection counts + the entity list) WITHOUT restoring — the point-in-time file selector reads real metadata. (b) REAL restore: the restored snapshot replaces the mock/in-memory repository state (the offline operating mode — the desktop already runs fully on local state when Supabase is unreachable; restore now repopulates it), the audit log records `backup.restore` with before/after counts, and the app is explicitly marked "restored-from" until reconnect. (c) sync staging: post-restore mutations enqueue into the EXISTING sync-queue-store (no parallel queue — zero-duplication rule); on reconnect the drain pushes staged entries through the existing upsert RPCs (idempotent — the Tier-4 equivalence already pins this). (d) integrity: encryption round-trip (GCM auth-tag failure → corrupted status), checksum verification, and the drain-no-data-loss guarantee are all test-pinned. Vitest: inspect/restore/stage/drain vectors incl. the offline (unreachable) simulation.
- **Status:** Completed — TESTED (2026-09-11: commit 8fab553 — t-300-offline-restore 11/11 + full suite 128/3007/0; inspectArchive is read-only with the honest corrupted verdict; the restore APPLIES via store.replaceOperationalState (every stream notifies, rbacMatrixOverrides ride along); the restored-from marker + the tab banner; staging binds the EXISTING SyncService.enqueue through an injected sink and diffs the five canonical-push collections (parents/students/payments/installments/ledger) per notify — expenses/personnel/workflows restored-but-not-staged (their dispatcher paths don't exist; documented). The no-data-loss vector: offline drain pushes 0 and keeps the queue; the online service drains the SAME persisted queue. Tamper → corrupted inspection + failed restore + no partial apply)

### T-301 — Backup scheduler toggle + the point-in-time selector completion
- **Problems:** OFFLINE-400 (sub-gap 7) · **Priority:** P1
- **Dependencies:** T-300 · **Affected:** hub desktop (`src/infrastructure/backup/backup-scheduler.ts` toggle support, `src/features/settings/backup-tab.tsx`, NEW tests)
- **Plan:** a persisted on/off preference (`localStorage` key, read at scheduler start — the 02:00 daemon arms ONLY when enabled; default ON preserving current behavior); the Backup tab renders the toggle + the next-run-at + the run log; on-demand "Sauvegarder maintenant" (exists — preserved) and the archive list gains the T-300 inspector entry point (click an archive → inspect → restore). Tests: toggle semantics (armed vs not, persistence, default-on), UI wiring.
- **Status:** Completed — TESTED (2026-09-11: commit ee1170e — t-301-scheduler-toggle 13/13 + full suite 129/3020/0; the persisted preference defaults ON; every SCHEDULED tick gates on it (manual runs never gated); documented deviation: the timer keeps cycling with the RUN gated so the toggle is instant in both directions without restart; the tab renders the Switch + prochaine-exécution + Active/Désactivée + the dormant honesty; the T-300 inspector entry point landed with T-300)

### T-302 — 46th-session closeout: registries + change-log + zips + push
- **Problems:** process (ADR-007) · **Priority:** P2
- **Dependencies:** T-294..T-301 · **Affected:** all repos
- **Plan:** OFFLINE-400 status flip with evidence, task status flips, change-log 46th-session section, current-state snapshot, next-task 47th recommendation, conventional commits with the 5-question body per repo, zips in download/, push with the owner PAT (re-supplied this session).
- **Status:** Completed (this commit — OFFLINE-400 closed TESTED with the per-task evidence lines; the change-log 46th-session section; current-state + next-task snapshots; zips in download/; push with the owner PAT)

### T-303 — Owner-gated live applies: migration 0085 db push + the realtime RLS live probe + the chain/token re-verification (47th session)
- **Problems:** OFFLINE-400 residual (a) · **Priority:** P0
- **Dependencies:** T-299 (the migration body) · **Affected:** LIVE Supabase only (scripts/apply_0085_live.sh NEW in the hub; probe scripts under the agent sandbox — no app code)
- **Plan:** apply migration 0085 to the live project atomically with its registration (the MIG-TOKENS §15 rule 10 pattern) using the owner-re-supplied sbp_ access token; then the END-TO-END realtime probe (sign in with the owner-pinned admin credential → subscribe to postgres_changes INSERT on public.audit_logs in the exact production observeActivity shape → trigger a benign canonical write_audit_log probe row → assert the attributed event arrives with actor_name/actor_role/actor_id/action); then the T-244-style token round (dual-key auth health, anon RLS zero-rows ×5, EF census, chain drift, publication membership).
- **Status:** Completed — VERIFIED LIVE (2026-09-11, 47th session: apply_0085_live.sh HTTP 201 — publication membership `public.audit_logs` in supabase_realtime CONFIRMED by post-check; the registration row existed already (name label quirk `audit_mutation_notifications` — the ARCH-009 cosmetic class, versions are what count); the realtime probe 6/6 GREEN (sign-in → channel SUBSCRIBED → canonical write_audit_log → attributed INSERT event received with actor_name + actor_role=super_admin + actor_id=profile id + action + note marker); the token round: dual-key auth health 200/200, anon RLS 0 rows ×5 tables, EF census 14/14 ACTIVE, chain 82/82 ZERO DRIFT, publication membership re-confirmed. Probe scripts persisted OUTSIDE the repos (agent sandbox scripts dir — they carry live tokens; the apply_0085_live.sh itself is token-free and committed)

### T-304 — The ai-proxy cap-40 deploy + the t277 live matrix re-run (the standing P0 owner-gated step since the 43rd session)
- **Problems:** AI-311 deploy dependency (the 43rd-session documented P0) · **Priority:** P0
- **Dependencies:** T-277's committed cap-40 code · **Affected:** LIVE Edge Function only (supabase functions deploy ai-proxy — no source change)
- **Plan:** deploy the ai-proxy Edge Function with the owner-re-supplied sbp_ token (`--no-verify-jwt` per the runbook — the EF validates Authorization itself), then re-run scripts/t277-live-matrix.sh: P2 (the 27-schema agent-stream probe) must flip 400 invalid_tools → 200 + SSE (the cap 40 ≥ 27 registry schemas), P3 (≤20-schema) stays 200, P4/P5 hardening regressions stay 400 invalid_model/invalid_role.
- **Status:** Completed — VERIFIED LIVE (2026-09-11, 47th session: `npx supabase functions deploy ai-proxy --project-ref hkvkefubghbbotgnteir --no-verify-jwt` → "Deployed Functions"; the matrix re-run ALL GREEN — P1 admin JWT acquired; P2 27-schema agent-stream → HTTP 200 with Groq SSE chunks (openai/gpt-oss-20b) — "CAP RAISED (≥27): the T-277 deployment is LIVE"; P3 20-schema → 200 + 46 SSE lines; P4 400 invalid_model; P5 400 invalid_role. Edge-mode agent-stream calls with the full 27-tool registry now work in production — the early-400 class in the owner's console is closed)

### T-305 — Arm the conflict guard in production traffic: the staging producer passes basePayload (OFFLINE-400 residual b)
- **Problems:** OFFLINE-400 residual (b) · **Priority:** P0
- **Dependencies:** T-298 (the guard), T-300 (the staging path) · **Affected:** hub desktop (`src/infrastructure/mock/repositories/mock-store.ts` StagedMutation + stageAndNotify, NEW `src/tests/infrastructure/t-305-conflict-arming.test.ts`)
- **Plan:** the 46th session shipped the no-silent-overwrite guard but its only enqueue producer passed NO basePayload — the guard could never fire in production traffic. Fix at the producer: MockStore.stageAndNotify already holds the pre-edit row (`before`, the checkpoint JSON) in scope — pass it as `basePayload` on every `update` enqueue (the exact 3-way BASE the guard consumes); the backup-service sink spreads the mutation so the field flows into SyncService.enqueue unchanged; insert/delete entries never carry a base (nothing to diverge from / merge). This arms the guard for the ENTIRE offline edit surface (CRM parents/students + financials payments/installments/ledger — every offline-mode edit flows through the staged notify paths). Suite: the arming (base = pre-edit row at field level), the insert/delete no-base contract, consecutive edits each with their OWN base, the guard FIRING on a diverging server row (park in conflict, push NEVER called), the benign one-side change pushing normally.
- **Status:** Completed — TESTED (2026-09-11: t-305-conflict-arming 5/5 + t-298/t-300 re-verified 32/32 combined + FULL desktop suite 130 files / 3025 tests / 0 failures + tsc 0 errors + eslint 0 errors on the changed files; Android baseline re-verified untouched-green 57 suites / 507 / 0 / 0 errors / 1 documented skip)

---

## 48th session (2026-09-12) — owner mandate: "I changed a name and a price, but nothing changed in the audit. Also, the green/red changes are currently shown in JSON — change that to a table with the old values in red and the new values in green"

> Mandate source: the owner's live report after testing the 47th-session delivery. Root-cause triage BEFORE registration (worklog 48th-session-setup): (1) Supabase-mode `updateParent`/`updateStudent` do direct PostgREST updates — no audit call, and NO trigger exists on `parents`/`students` (verified live: only touch_updated_at + enforcement triggers; audit_logs carries ZERO parent/student/pricing mutation rows); (2) the `pricing` slot stays on mockRepositories in Supabase mode — price edits are in-memory only (never persisted, never audited, wiped on restart); (3) the drawer/sheet render chip-rows + a collapsible raw-JSON forensic view (Avant red-tinted / Après green-tinted `<pre>` blocks) — the owner wants a clean TABLE. NEW DISCOVERY registered: the live `grade_level_tuition` grid DIVERGES from the desktop mock seed grid (UNKNOWN-011).

### T-306 — Row-level audit triggers: parents + students + pricing-table mutations write audit_logs server-side (AUDIT-500) [48th session]
- **Problems:** AUDIT-500 (NEW — see problem registry) · **Priority:** P0
- **Dependencies:** T-299 (audit realtime publication — the trigger-written rows broadcast automatically), migration 0014 (write_audit_log) · **Affected:** hub backend (NEW `supabase/migrations/0086_crm_pricing_mutation_audit.sql` + NEW `scripts/verify_t-306.sql`) — NO client code (the fix is server-authoritative, covering desktop PostgREST edits + Android upsert-RPC pushes + any future writer in ONE implementation)
- **Plan:** one shared trigger function `public.audit_row_change()` fired AFTER INSERT/UPDATE/DELETE on `parents`, `students`, `grade_level_tuition`, `transport_destinations`, `pricing_configs`, `complementary_services`, `additional_services`, `discounts` — each firing calls `write_audit_log` with the FULL row snapshots (`to_jsonb(OLD)`/`to_jsonb(NEW)` — plan §12 "never truncated"), action mapped from TG_TABLE_NAME + TG_OP to the AuditActions wire codes (`parent.update`, `student.create`, `pricing.tuition_update`, …), entity_id = row id, actor resolved server-side from `current_user_profile_id()` + display_name + primary role (NULL → the system actor, e.g. seed/import jobs), tenant from NEW.tenant_id/OLD.tenant_id. No-op-update guard: skip when `to_jsonb(OLD) is not distinct from to_jsonb(NEW)` (the touch_updated_at trigger's own writes must not double-audit). Financial RPC-covered tables (payments/ledger/installments) are deliberately NOT triggered — their canonical RPCs already audit (plan §12 single-entry per operation, no double counting). Live apply: T-091 atomic pattern (SQL + schema_migrations registration in one call), then the verify script + an end-to-end probe (update a parent's first_name via the desktop's exact PostgREST path with the admin JWT → assert the audit row lands with before/after + actor attribution → assert the realtime broadcast fires).
- **Status:** Completed — TESTED + VERIFIED LIVE (2026-09-12: migration 0086 applied atomically via apply_0086_live.sh, registered in schema_migrations; 24 audit_row_change triggers wired (8 tables × INSERT/UPDATE/DELETE); live evidence — parent.update + pricing_grade.update rows carry FULL before/after snapshots with actor display_name + role resolved server-side, the T-306 e2e probe's first_name edit visible in audit_logs; the realtime broadcast rides T-299's publication)

### T-307 — T-047 Group-B port #1 (PRICING FIRST — the standing recommendation): SupabasePricingRepository onto the canonical 0006 tables (AUDIT-500 b + the owner's "price" complaint)
- **Problems:** AUDIT-500 (b: pricing slot mock-backed in Supabase mode — edits never persisted) · ARCH-001 residual slot #10 (pricing) · **Priority:** P0
- **Dependencies:** T-306 (the audit triggers — price edits then audit automatically) · **Affected:** hub desktop (NEW `src/infrastructure/supabase/repositories/supabase-pricing-repository.ts` + wiring in `supabase-repositories.ts` + the 3 hardcoded `defaultPricingConfig` billing call sites in `supabase-shared-repositories.ts` batchRegister + NEW `src/tests/infrastructure/supabase-pricing-repository.test.ts`)
- **Plan:** the T-238/T-239/T-240 adapter pattern onto `pricing_configs` + `grade_level_tuition` + `transport_destinations` + `complementary_services` + `additional_services` + `discounts`: observe() reads the active config and builds the domain `PricingConfig` (grade rows joined via academic_levels.grade_code → GradeLevel, transport via code → TransportDestination, services + discounts mapped; DB-empty fallback = the seed config so the tab never renders zeros while the live rows exist); write methods UPDATE/INSERT/DELETE the canonical rows and refetch (validation identical to the mock: tranches-sum=annual ±1 DZD, no negatives). The batchRegister billing block swaps `defaultPricingConfig` for the DB-read config (fallback: the seed when the fetch fails — the honest degraded path), killing the hardcoded grid in the billing WRITE path. The `non-tuition-charges.ts` domain read stays on the seed (registered as residual — changing the domain calc signature is a parity-suite change, next session). UNKNOWN-011 (the DB grid ≠ mock grid divergence) is REGISTERED, not silently decided: the port reads the DB as canonical (boundaries.md), the divergence evidence + owner-decision question documented in unknowns.md.
- **Status:** Completed — TESTED (2026-09-12: SupabasePricingRepository 22/22; the pricing slot off the mock layer in Supabase mode — price edits persist + trigger-audit via 0086; live pricing_grade.update audit rows confirm the path; the billing write path reads the DB grid; merged clean with the owner's db5e159 analytics overhaul — zero file overlap)

### T-308 — The visual red/green TABLE diff (the owner's explicit presentation request): desktop AuditDiffDrawer + Android AuditDiffSheet
- **Problems:** AUDIT-501 (NEW — the JSON-presentation complaint) · **Priority:** P0
- **Dependencies:** none (pure presentation over the existing T-295/T-297 engines) · **Affected:** hub desktop (`src/features/settings/audit-log-tab.tsx` AuditDiffDrawer + `src/tests/features/t-296-audit-diff-drawer.test.tsx`), android (`ui/components/AuditDiffSheet.kt` + `app/src/test/.../AuditDiffSheetTest.kt`)
- **Plan:** keep the T-295 field-diff engine (flattenDiffRows) as the ONLY derivation; replace the chip-rows presentation with a proper 3-column TABLE — Champ | Avant (RED, line-through) | Après (GREEN, bold) — added rows show an empty red cell + green value, removed rows the inverse; row hover, zebra striping, sticky header inside the scroll area; the collapsible raw-JSON forensic view stays (collapsed by default, relabeled "Vue JSON brute (expert)"). The Android AuditDiffSheet gets the same table treatment (header row + bordered rows, old red/struck left, new green/bold right). Tests updated on both platforms to pin the table structure (data-testid="audit-diff-table" + per-cell tests) — no engine changes, no new derivation.
- **Status:** Completed — TESTED (2026-09-11/12: desktop drawer 18/18 incl. the table-structure + payment-entry pins, Android sheet 13/13 incl. the table + union-key pins; the owner's spec — shared properties on ONE row, before-only removed, after-only added — pinned in field-diff 35/35 on both platforms)

### T-309 — 48th-session closeout: registries + change-log + live verify + zips + push
- **Problems:** process (ADR-007) · **Priority:** P2
- **Dependencies:** T-306, T-307, T-308 · **Affected:** all repos
- **Plan:** AUDIT-500/AUDIT-501 problem entries with evidence, UNKNOWN-011 (the pricing-grid divergence), task status flips, change-log 48th-session section, current-state snapshot, next-task 49th recommendation, conventional commits with the 5-question body per repo, zips in download/, push with the owner PAT (re-supplied this session), live end-to-end evidence note (t-306-live-verification.md).
- **Status:** Completed — FOLDED into the 49th-session closeout (T-311): the 48th-session code shipped + pushed (merge 4fd4915 + test-integration 7783e74 + android 09d9a88); the registries/change-log/zips legs are executed under T-311 (this session — the 49th)

### T-310 — Payment audit details + actor attribution (AUDIT-502): the RPC canonical-columns fix + both client mapper fallbacks
- **Problems:** AUDIT-502 (NEW — see problem registry) · **Priority:** P0
- **Dependencies:** T-306 (the server-authoritative pattern reused), 0034's RPCs (patched in place) · **Affected:** hub backend (NEW `supabase/migrations/0087_payment_audit_canonical_columns.sql` + NEW `scripts/apply_0087_live.sh` + NEW `scripts/verify_t-310_e2e.js`), hub desktop (`mapAuditRow` in supabase-audit-log-repository.ts + `collect()`'s p_actor_name in supabase-shared-repositories.ts + NEW `src/tests/infrastructure/t-310-payment-audit-details.test.ts` + field-diff union-key pins + the drawer payment-entry case), android (SharedDtos.kt JsonElement migration + SharedDtoMappers.kt effectiveAuditSnapshots + NEW `AuditLogDiffRecoveryT310Test.kt` + AuditDiffSheetTest T-310 cases + AuditPullT299Test migration)
- **Plan:** three layers, one contract: (1) migration 0087 — both payment RPCs (reproduced from the LIVE pg_get_functiondef, business logic byte-identical) write the canonical before_json/after_json columns + actor_role, and a NULL/ID-shaped p_actor_name resolves server-side from user_profiles ('System' fallback; the resolved name also lands in the ledger actor_name columns); (2) desktop mapAuditRow — the legacy-`diff` fallback (wrapped → unwrap; flat → the AFTER state; string → safeParse) so ALL historical payment rows render immediately; collect() passes p_actor_name: null; (3) Android — the DTO snapshots migrate String? → JsonElement? (the jsonb decode-crash fix: decodeList threw on ANY non-null snapshot — the 0086 trigger rows had already broken the whole pull) + the diff field declared + toEntity mirrors the desktop fallback. The owner's union-key spec (shared property → one row; before-only → removed; after-only → added) pinned in the field-diff suites on both platforms.
- **Status:** Completed — TESTED + VERIFIED LIVE (2026-09-12: t-310-payment-audit-details 10/10 + field-diff 35/35 + drawer 18/18 + FULL desktop 132 files / 3070 tests / 0 failures / tsc 0; Android AuditLogDiffRecoveryT310Test 5/5 + AuditDiffSheetTest 13/13 + AuditPullT299Test 3/3 + FULL 58 suites / 516 / 0 / 1 skip; migration 0087 applied LIVE (apply_0087_live.sh, HTTP 201, post-check GREEN); the e2e probe (verify_t-310_e2e.js): a payment via the desktop's exact RPC path → audit row with after_json (amount/receipt/status/allocations) + actor_name="admin@elimtiyaz.dz" + actor_role="super_admin" — 4/4 PASS; the refund e2e: before/after unwrapped GREEN)

### T-311 — 49th-session closeout: registries + change-log + zips + push
- **Problems:** process (ADR-007) · **Priority:** P2
- **Dependencies:** T-310 · **Affected:** all repos
- **Plan:** AUDIT-502 registry entry with live evidence, the task status flips (T-306..T-309 + T-310), change-log 49th-session section, the Android AGENTS.md jsonb→JsonElement lesson, conventional commits with the 5-question body per repo, zips in download/, push with the owner PAT.
- **Status:** Completed (2026-09-12: hub efe16c3 + android 5842a97 pushed with the owner PAT and verified synced; zips AgentGithubUplaod-49th-session.zip / elimtiyaz-android-49th-session.zip / el-imtiyaz-systems-49th-session.zip in download/)

### T-312 — 50th session: the owner's local-sync verification round + the theme-engine integration review + the lint cleanup
- **Problems:** none NEW (process verification + hygiene; see change-log 50th section for scope observations on the owner's theme commit) · **Priority:** P1
- **Dependencies:** T-311 · **Affected:** hub desktop (lint fixes only: `src/features/dashboard/components/analytics/operational-query-console.tsx`, `src/features/dashboard/components/analytics/pivot-matrix-card.tsx`, `src/features/settings/general-tab.tsx`, `src/features/settings/theme-editor-modal.tsx`, `src/app/providers/user-preferences-provider.tsx`, `src/i18n/language-switcher.tsx`) + docs
- **Plan:** (1) verify the owner's sync-script push (their 78ebbc3 merged over my efe16c3 as 9fc947b): ancestry both ways, file-overlap = ZERO (their 7 theme files vs my 48th/49th surfaces), no deletions, computed merge = 0 conflict markers; (2) code-review the theme engine (theme-engine.ts / theme-types.ts / theme-editor-modal.tsx new; user-preferences-provider + general-tab + app-shell + index.css rewritten) — integration points verified: `bg-background` Tailwind token exists, `initUserPreferences()` still called pre-mount in main.tsx, language-switcher consumes only the context, the CSS `!important` surface-class overrides keep every legacy `bg-surface-*` consumer working; (3) fix the 4 pre-existing eslint ERRORS (prefer-const valA/valB in the owner's analytics sort comparators, present since db5e159) + clean 15 unused imports/vars across the theme files and analytics components + correct the stale legacy-locale comment in language-switcher.tsx; (4) full re-verification: tsc 0 + eslint 0 errors repo-wide + desktop FULL suite + Android FULL suite; (5) commit + push + zips.
- **Status:** Completed — TESTED (2026-09-12: the merge forensics GREEN [ancestor checks both ways, 0 deleted files, 0 conflict markers in the computed merge, 0 file overlap]; desktop FULL 132 files / 3070 tests / 0 failures BEFORE the fixes and again AFTER; tsc 0 errors; eslint 0 errors repo-wide post-fix; Android FULL 58 suites / 516 tests / 0 failures / 0 errors / 1 documented skip at 5842a97 — the remote unchanged, the 49th-session baseline reproduced exactly)

### T-264 — Approval-queue 406-noise: findPotentialMatches .single() → .maybeSingle() (OPS-309)
- **Problems:** OPS-309 (NEW — see problem registry) · **Priority:** P2
- **Dependencies:** none · **Affected:** hub desktop (`src/infrastructure/supabase/repositories/supabase-approval-repository.ts`, NEW `src/tests/infrastructure/t-264-approval-406-noise.test.ts`)
- **Plan:** the Settings→Approvals tab's `listPending()` enriches each pending request via `findPotentialMatches()`, which fires up to 4 `.is(col, null).single()` lookups (activation_codes by code, parents by email / national_id / phone) + a parents-by-id `.single()` — every one that legitimately matches ZERO rows returns PostgREST 406 PGRST116 ("JSON object requested, multiple (or no) rows returned") because `.single()` ERRORS on 0 rows. The code already treats "error or null" as no-match (falls through to the next strategy), so the app works — but the production console spams ~15 red 406s per approval-queue refresh (owner-reported at the 39th-session launch, 2026-09-09 20:36). Fix: convert all 5 `.single()` calls in `findPotentialMatches` to `.maybeSingle()` (the established codebase pattern — `supabase-academic-repository.ts` already uses it): 0 rows → `data:null, error:null` (HTTP 200, silent), >1 rows → error (same fall-through as today). Semantics preserved: `codeRow?.parent_id` / `if (parent)` guards already handle null. Regression test: behavioral (0-row maybeSingle → `parent_match: null`, no error surfaced; matched row → enrichment; >1-rows error → fall-through) + source-scan guard (no `.single()` remains in the approval repository; the 4 `.is(...)` filters preserved).
- **Status:** Completed — TESTED (2026-09-10: 7/7 t-264-approval-406-noise tests; full suite 117/2789/0 [run twice] + tsc + eslint 0 err + build green 19.85 s; commit 624a4aa)

### T-265 — 40th-session closeout: registries + change-log + push with the owner PAT
- **Problems:** process (ADR-007) · **Priority:** P2
- **Dependencies:** T-264 · **Affected:** all repos
- **Plan:** OPS-309 problem entry with evidence + totals recount (220→221, 158→159 TESTED), task status flips, change-log 40th-session section, current-state 40th snapshot, next-task 41st recommendation, conventional commits with the 5-question body, push with the owner PAT (one-shot URL, never persisted). Also documented: the owner-supplied Groq BYOK key could NOT be verified from the agent sandbox (Hong Kong egress → Groq geo-block → 403 Forbidden; NOT evidence of an invalid key — validation belongs to the desktop Settings → AI tab's live model discovery from the owner's machine) and was never persisted anywhere in the repos (§15.12); the EF server-side GROQ_API_KEY secret remains owner-gated (needs the sbp_ token or a dashboard manual set — not supplied this session).
- **Status:** Completed (this commit — OPS-309 registered TESTED with suite evidence [problem-registry totals 221/159]; change-log 40th-session section; current-state 40th snapshot; next-task 41st recommendation; push with the owner PAT, one-shot URL never persisted)

---

### T-255 — Analytics tab: shell + derivations + statistics strip + trend explorer + slicers (UI-307)
- **Problems:** UI-307 (NEW — the owner's "not enough graphs" mandate) · **Priority:** P1
- **Dependencies:** none (UI-only, consumes the existing repository contracts) · **Affected:** hub desktop (`tabs/analytics-tab.tsx`, `components/analytics/analytics-derivations.ts`, `stat-strip.tsx`, `revenue-trend-explorer.tsx`, `analytics-slicers.tsx`, `dashboard-page.tsx` tab + previous-year fetch)
- **Plan:** a dedicated "Analytique" PageTab receiving the page's single-fetch aggregates + the canonical payments stream (the tab never fetches, except the page-level previous-year revenueForRange for YoY). The derivation module defines the ENCAISSÉ consistency contract (status=paid — reconciles with the repository revenue series) + the slicer engine (empty selection = ALL; additive multi-select) + descriptive statistics (count/total/mean/median/σ/best-month) + the trend derivation (cumulative + 3-month MA, null until the 3rd point) + deriveFilteredMonthly (dashed overlay aligned to the series' month labels). The trend explorer: ComposedChart with bars-or-area view toggle, per-series show/hide chips, right-axis cumulative, hover tooltips with DZD.
- **Status:** Completed — TESTED (2026-09-09: 19 of the 34 analytics-visuals tests; full suite 114/2745/0)

### T-256 — Analytics mixes + collection heatmap + amount histogram (UI-307)
- **Problems:** UI-307 · **Priority:** P1
- **Dependencies:** T-255 (the derivation module) · **Affected:** hub desktop (`components/analytics/mix-cards.tsx`, `collection-heatmap-card.tsx`, `amount-histogram-card.tsx`)
- **Plan:** method-mix donut with the REAL center total (Σ of the filtered slice — the T-247 pattern) + callout legend; category ranking as horizontal bars with a [Montant | Nb opérations] metric toggle (top-6 + "Autres (n)" tail merge); the weekday×month collection heatmap as a CSS-grid matrix (Dim→Jeu school week — Fri/Sat excluded per the T-243 convention; 5-level intensity quantized against the matrix max; row/column Σ; year-aware tooltips); the amount distribution into fixed DZD bins (0–5k/5k–10k/10k–20k/20k–50k/50k+) with the dominant-bin verdict in the header.
- **Status:** Completed — TESTED (2026-09-09: 12 of the 34 tests incl. the Fri/Sat exclusion + bin-edge cases; full suite green)

### T-257 — Analytics Pareto + aging composition + YoY comparison (UI-307)
- **Problems:** UI-307 · **Priority:** P1
- **Dependencies:** T-255 · **Affected:** hub desktop (`components/analytics/debtors-pareto-card.tsx`, `aging-composition-card.tsx`, `yoy-comparison-card.tsx`, `dashboard-page.tsx` previous-year fetch)
- **Plan:** top-debtors Pareto (bars desc + cumulative % line on a right 0–100 axis + the derived "N familles = 80%" verdict); aging composition as a 100% stacked bar (AGING_COLORS) + per-bucket statistical table with total row; the like-for-like YoY comparison (grouped bars N vs N−1 per month, header Σ/delta, delta null where the previous window has zero activity — §15.16, and an honest unavailable state when the selected year is the earliest available). The page loads the previous year's series via revenueForRange on the one-year-shifted range (shiftIsoYearBack, leap-day safe).
- **Status:** Completed — TESTED (2026-09-09: 8 of the 34 tests incl. the null-delta honesty + the leap-day shift; full suite green)

### T-258 — Analytics regression suite (34 tests)
- **Problems:** UI-307 (the verification leg) · **Priority:** P0
- **Dependencies:** T-255..T-257 · **Affected:** hub desktop (`src/tests/ui/analytics-visuals.test.tsx`)
- **Plan:** pure-function suites for every derivation (slicer engine incl. the paid-only + range + method/category matrix; statistics incl. median parity + σ + best-month; trend cumulative + MA3 null-until-3; filtered-monthly label alignment; mix percents + tail merge; heatmap month columns + school-week rows + level quantization + month totals; histogram bin edges; Pareto cumulative; aging shares; YoY null-delta; the range helpers) + render suites (the full chart wall; the method/category chip CROSS-FILTERING with live badge + reset; the "Filtré" overlay appearing only under active filters; the Barres↔Aire view toggle; heatmap data attributes; aging aria-valuenow shares; the honest empty states ×7). Recharts mocked (the T-247 jsdom pattern); ResizeObserver stub local (the global setup untouched).
- **Status:** Completed — TESTED (2026-09-09: 34/34 green; full suite 114 files / 2745 / 0 + tsc + eslint 0 err + build green)

### T-259 — 38th-session closeout: registries + change-log + zips + push
- **Problems:** process (ADR-007) · **Priority:** P2
- **Dependencies:** T-255..T-258 · **Affected:** all repos
- **Plan:** problem-registry UI-307 entry + totals recount, task-registry 38th-session block + status flips, change-log 38th-session section, current-state snapshot, next-task 39th recommendation, conventional commits with the 5-question body, zips in download/, push with the owner PAT (re-used from the same-day 37th-session push; one-shot URL, never persisted).
- **Status:** Completed (2026-09-09: UI-307 registered [219 detailed entries], statuses flipped, change-log/current-state/next-task updated, commits + zips + push)

---

**37th repair session (2026-09-09, CLOSED) — owner mandate COMPLETE ("do all of this then push"): T-246..T-254 (9 tasks) — the AI-review's REMAINING five screens + Part-2 design system + live token round + closeout.** Session-opening ritual: pristine-tree baseline FULL suite **112 files / 2694 / 0** + tsc + eslint 0 err + vite build green (TEST-300 lesson). Delivery: **T-246** (midnight design tokens + glow-border + tailwind/TS-mirror parity contract), **T-247** (SeeDetailsModal: collection-rate trio + échéancier théorique projection overlay + dual-ring donut with REAL center total + severity badges), **T-248** (Tranche Wave header from canonical label grouping), **T-249** (quick-pay chips + cashier change calculator), **T-250** (14-level tuition matrix + explicit 40/30/30 tool), **T-251** (readiness checklist + full 14-level grid), **T-252** (coverage stack + per-tranche 1-click collect with exact installment targeting), **T-253** (live token round **18/18 GREEN** — dual-key health, RLS anon 0-rows ×5, chain 81/81 ZERO DRIFT, EF fleet 14/14, anonymous EF 401, ALLOWED_ORIGINS canonical echo + reject, committed-key consistency; no apply needed), **T-254** (this closeout: UI-306 continuation entry, status flips, change-log, current-state, next-task 38th, commits, zips, push). Suites at close: desktop **113 files / 2711 / 0** (+17: NEW ai-review-screens.test.tsx) + tsc + eslint 0 err (407 warn) + vite build green; website re-verified untouched-green 40/544/0 + lint + strict build; Android untouched (desktop-scope UI change, zero contract impact per §10).

### T-246 — Design-system overhaul: midnight palette + glow-border (AI-review Part 2)
- **Problems:** UI-306 extension (the review's Part-2 palette) · **Priority:** P1
- **Dependencies:** none (UI-only) · **Affected:** hub desktop (`src/index.css`, `tailwind.config.cjs`, TS token fallbacks in dashboard-theme/see-details/tabs/sparkline)
- **Plan:** apply the review's refined palette (midnight surfaces #0b0d14/#111523/#181d30, crisper status hues, --brand-violet/--brand-coral additions, glow-border utility) to index.css AND keep tailwind.config.cjs hex parity (the config duplicates tokens so opacity utilities resolve at build time) AND update the TS hex fallbacks that mirror the tokens (dashboard-theme chartPalette, see-details useChartPalette, tabs/types AGING_COLORS, sparkline STROKE_BY_TONE) so SSR/test rendering matches runtime. Light-theme block updated consistently. Zero component-hex sprinkling (plan §03 token discipline preserved).
- **Status:** Completed — TESTED (2026-09-09: full 113/2711/0 + tsc + eslint 0 err + vite build; parity contract documented in index.css + UI-306 continuation entry)
### T-247 — SeeDetailsModal drill-down overhaul (AI-review Screens 1–2)
- **Problems:** UI-306 residuals (the review's drill-down fixes) · **Priority:** P1
- **Dependencies:** T-246 (palette) · **Affected:** hub desktop (`src/features/dashboard/see-details-modal.tsx`)
- **Plan:** Revenue tab: add the "Encaissé vs Échéancier théorique" ComposedChart — bars = the REAL monthly revenue series; dashed line = the DERIVED 40/30/30 projection computed from totalExpected = annualRevenue + kpis.outstandingDebt (a planning reference derived from real totals + the canonical tranche rule, labeled "théorique", never presented as collected data). Demographics tab: donut gets innerRadius + the REAL center total (Σ gender counts, NOT a synthesized 390) + legend callouts. Debt tab: severity badges (Normal/Avertissement/Critique) per bucket. Typed kpis (DashboardKpi, not `unknown`).
- **Status:** Completed — TESTED (2026-09-09: 6 pure+render tests in ai-review-screens.test.tsx; full suite 113/2711/0)

### T-248 — Installment schedule: Tranche Wave header (AI-review Screen 5)
- **Problems:** UI-306 residuals · **Priority:** P1
- **Dependencies:** T-246 · **Affected:** hub desktop (`src/features/financials/installment-schedule-tab.tsx`)
- **Plan:** add a TrancheWaveHeader above the table: T1/T2/T3 collection health (paid vs due %) computed from the REAL filtered rows grouped by canonical tranche labels (regex `Tranche [123]`, not the review's fragile `label.includes("1")`); progress bars + Encaissé/Dû figures from the canonical sums. Honest zero state when no tranches match.
- **Status:** Completed — TESTED (2026-09-09: 6 tests incl. the Tranche-10/Année-complète negatives; full suite green)
### T-249 — Unified payment modal: quick-pay chips + change calculator (AI-review Screen 7)
- **Problems:** UI-306 residuals · **Priority:** P1
- **Dependencies:** none · **Affected:** hub desktop (`src/features/financials/unified-payment-modal.tsx`)
- **Plan:** (a) quick-pay shortcut chips above the slider — "Payer Tranche N" for the first ≤2 open tranches (amount = amountDue − amountPaid, the file's established convention) + "Soldé total" (totalDue − alreadyPaid); (b) cashier change-return calculator when method = cash and amount > 0: Montant remis input → Monnaie à rendre (givenCash − amount), success styling when sufficient. Pure UI state; no contract change.
- **Status:** Completed — TESTED (2026-09-09: 2 render+interaction tests incl. the 40000−32000→8000 round; full suite green)

### T-250 — Tuition pricing: consolidated 14-level matrix (AI-review Screen 6)
- **Problems:** UI-306 residuals (the 14-card scroll-wall) · **Priority:** P1
- **Dependencies:** T-246 · **Affected:** hub desktop (`src/features/settings/pricing/tuition-card.tsx`)
- **Plan:** replace the 14 stacked cards with ONE dense table (Niveau | Annuel | T1 | T2 | T3 | Équilibre | Save) + the 1-click "Auto-calculer 40% / 30% / 30%" header tool (rounds T1/T2, T3 = remainder) + live per-row balance check (Σ tranches = annual). Save path unchanged (updateTuitionForGradeLevel per row). Mobile-safe: base grid + overflow-x-auto.
- **Status:** Completed — TESTED (2026-09-09: 14-level render test + Équilibre column; full suite green)
### T-251 — Academic year drawer: readiness index + full level grid (AI-review Screen 4)
- **Problems:** UI-306 residuals (flat zeroes without context) · **Priority:** P2
- **Dependencies:** T-246 · **Affected:** hub desktop (`src/features/academics/academic-year-detail-drawer.tsx`)
- **Plan:** add the "État de Préparation de l'Année Scolaire" checklist — Salles & Classes (configured count), Enseignants Principaux (homeroomTeacherId assignment rate), Emplois du Temps (timetable coverage rate) — REAL rates with progress bars; extend the grade breakdown to show ALL 14 levels (empty states included, class + student counts).
- **Status:** Completed — TESTED (2026-09-09: typecheck + full suite green; rates from REAL class attributes)

### T-252 — Parent drawer: coverage stack + 1-click tranche collect (AI-review Screen 8)
- **Problems:** UI-306 residuals · **Priority:** P1
- **Dependencies:** none · **Affected:** hub desktop (`src/features/crm/parent-detail-drawer.tsx`)
- **Plan:** (a) family-level "Couverture de l'Engagement Annuel" visual stack (paid vs remaining proportional bar, REAL recon numbers + the bridge discipline preserved); (b) per-tranche "Encaisser {remaining}" button on each tranche card: when the node carries the REAL installment row → open the payment modal preset to that tranche (mode installment_tranche, targetItemId, presetAmount = canonical remaining); synthetic nodes (no DB row) fall back to the consolidated preset (no phantom target). Collect context builder added to the drawer.
- **Status:** Completed — TESTED (2026-09-09: drawer render test on the seed's real open tranches + full suite green; collect path contract preserved)
### T-253 — Live migration-token verification round (37th session)
- **Problems:** process (§15.11 session-opening obligation; owner re-supplied the token sheet) · **Priority:** P0
- **Dependencies:** owner re-supplied sbp_ token + keys · **Affected:** live backend (read-only probes) + docs
- **Plan:** re-provision the Supabase CLI (container reset), link hkvkefubghbbotgnteir, diff live schema_migrations vs local 0001–0084, dual-key health, RLS anon 0-rows, EF fleet census, ALLOWED_ORIGINS probe, anonymous EF 401, committed-key consistency vs the owner sheet (website public-config, Android .env.example, desktop connection card). No apply unless drift found.
- **Status:** Completed (2026-09-09: 18/18 GREEN via /home/z/my-project/scripts/verify_t-253_mig_tokens.sh — chain 81/81 zero drift [max 0084], dual-key 200 ×2, RLS 0-rows ×5, EF fleet 14/14, anon EF 401 ×2, ALLOWED_ORIGINS canonical 4-origin echo + non-allowlisted rejected, committed-key consistency; the canonical set intact — NO apply needed, consistent with T-244)

### T-254 — 37th-session closeout: registries + change-log + zips + push
- **Problems:** process (ADR-007) · **Priority:** P2
- **Dependencies:** T-246..T-253 · **Affected:** all repos
- **Plan:** problem-registry entries + status flips, change-log 37th-session section, current-state snapshot, next-task 38th recommendation, conventional commits with the 5-question body, zips in download/, push with the owner PAT (re-supplied; the previous PAT placeholder in the paste was redacted — request re-supply if push 401s).
- **Status:** Completed (2026-09-09: UI-306 continuation registered [218 detailed entries], statuses flipped, change-log/current-state/next-task updated, commits + zips; the session-open push was blocked by the REDACTED PAT placeholder — push COMPLETED same-day with the owner's re-supplied PAT: 4d28a79 + 2632cfd on origin/main, fetch-confirmed in-sync across all three repos)

---

**24th repair session (2026-09-03) — CLOSED: owner mandate COMPLETE ("finish all the remaining tasks: fix the 3 owner-reported issues — account activation rejected as 'already used', messenger must be parent→Administrator only, children showing the parent's name — apply the migration tokens, verify everywhere, zip for push").** Session-opening ritual: chain check **63/63 = 0001–0066 ZERO DRIFT** (fresh sbp_ token; live census `activation_codes=0`, `parents=260`, `auth_users=3` — two NEW parent signups on 2026-09-03, evidence the owner is actively testing the portal). **LIVE-DATA DIAGNOSIS (the 3 issues are ALL verified against the live DB):** (1) **ACTIVATION** — the desktop issued 5 codes today (audit_logs: YOUCEFI AYA ×3, ABADA YAHIA ×2) yet `activation_codes` holds **0 rows**: `SupabaseApprovalRepository.generateActivationCode` INSERTs without `tenant_id` (NOT NULL, no default → guaranteed NOT NULL violation) and `issueActivationCode` then SILENTLY falls back to `deterministicActivationCode` — a phantom code that can never validate; the deployed hub EF additionally 401s every `pending` profile via `extractAuthContext` (status !== 'active' → null) and never flips status; the website maps the EF's `{error:{code,message}}` OBJECT with regex tests that never match → always the generic "Code d'activation invalide ou déjà utilisé." string (the owner's exact symptom). (2) **MESSENGER** — parents cannot start any conversation (create_direct_channel is staff-only per ADR-008), `chat_channels` = 0 rows live → the portal messenger is dead; nothing structurally forbids parent↔parent posting. (3) **PARENT/CHILD NAMES** — live students are correct, but **259/260 parents carry their FIRST CHILD's full name as display_name** (corpus predates the importer's "Famille {lastName}" PARENT-AS-STUDENT FIX) → the Enfants list shows a child named identically to the parent. Batch (10 tasks, balanced P0→P3): **T-145** (issuance persistence), **T-146** (EF consolidation + ADR-011 resolving UNKNOWN-001), **T-147** (live round-trip), **T-148** (0067 parent→admin RPC + post tightening + ADR-012), **T-149** (website "Contacter l'administration"), **T-150** (0067 live apply + verify), **T-151** (0068 parent display-name repair), **T-152** (0068 live apply + verify), **T-153** (activation-screen precise error mapping), **T-154** (registries + suites + zip closeout).

### T-145 — Desktop activation-code issuance persistence (tenant_id + failure surfacing) — **Completed (TESTED — 5/5 unit suite + typecheck clean; live issuance confirmation owner-gated on the next staff click)**

- **Problems:** NEW ACT-200 (activation codes never persist — root cause of the owner's "already been used" report; registered this session) · **Priority:** P0 · **Severity:** Critical (user-facing blocker)
- **Scope:** `SupabaseApprovalRepository.generateActivationCode` (missing `tenant_id` on INSERT) + `issueActivationCode` in parent-detail-drawer.tsx (silent phantom-code fallback in Supabase mode).
- **Plan:** capture tenant_id once (already fetched via `current_tenant_id`), include it in the INSERT, use `issued_by` from the same RPC batch, and return Err with the real message on failure; in the drawer, show the error toast and DO NOT hand out the deterministic fallback code when Supabase mode is configured (mock mode keeps the fallback — there is no server to validate against).

### T-146 — Consolidate bind-activation-code EF: activation semantics into the canonical hub version — **Completed (TESTED — 8/8 source-scan suite + esbuild + website 5/5 guard; live deploy + round-trip via T-147)**

- **Problems:** CROSS-004, CROSS-009, BUSINESS-008, SEC-104 (all close via this task + ADR-011); UNKNOWN-001 RESOLVED by owner mandate · **Priority:** P0 · **Severity:** Critical
- **Scope:** `elimtiyaz-desktop/supabase/functions/bind-activation-code/index.ts` (canonical, deployed) + DELETE `elimtiyaz-website/supabase/functions/bind-activation-code/` (drifted duplicate — T-126 pattern).
- **Plan:** ADR-011 records the owner decision (binding a code ACTIVATES the account). The hub EF: (a) authenticate the caller WITHOUT extractAuthContext's active-only gate (verify JWT → fetch profile directly; allow `pending`; REJECT `suspended`/`deleted`); (b) keep both body keys + audit log; (c) after a successful bind, grant the `parent` role + flip `user_profiles.status='active'` + clear `approval_request_id` (the website version's logic, ported to shared helpers, hardened per SEC-104: only `pending`→`active`, never suspended/deleted); (d) idempotent 409 `account_already_active` for already-active callers.

### T-147 — Live deploy + live round-trip verification of the activation flow — **Completed (VERIFIED — 19/19 live checks, evidence: docs/recovery/t-147-live-verification.md)**

- **Problems:** ACT-200 verification half · **Priority:** P0 · **Severity:** Critical
- **Plan:** deploy the consolidated EF live (CLI v2.116.0, `--no-verify-jwt` like the current deploy), then a REAL end-to-end round-trip: create a test parent + activation code (service-role SQL), create a test auth user via the admin API, sign in via REST to get a real JWT, call the EF with the pending user's JWT → assert code bound, `parents.auth_user_id` set, profile active, `parent` role assigned, audit row written; re-call with the same code → 404 already-used; anonymous → 401. Clean up test rows. Evidence → `docs/recovery/t-147-live-verification.md`.

### T-148 — Migration 0067: parent→Administrator channel RPC + parent-post RLS tightening — **Completed (TESTED — migration authored + applied live atomically; the live verification is T-150)**

- **Problems:** NEW CHAT-200 (messenger dead for parents; nothing forbids parent↔parent) — registered this session; amends ADR-008 via ADR-012 · **Priority:** P1 · **Severity:** High
- **Plan:** (a) `open_parent_admin_channel()` SECURITY DEFINER RPC with caller verification: caller must hold the `parent` role; resolves the tenant's `super_admin` profile (fallback `support_staff`) as the counterpart; idempotent deterministic DM code (same pair-algorithm as 0061); audit row. (b) tighten `chat_messages_insert`: non-staff authors may ONLY insert into `direct` channels whose OTHER member holds a staff role — parent↔parent posting becomes structurally impossible; staff authors unchanged (full member rule preserved).

### T-149 — Website: "Contacter l'administration" (parent-initiated admin channel) — **Completed (TESTED — 6/6 suite + full website 25 files / 447 tests + lint + strict build; live click device-gated)**

- **Problems:** CHAT-200 website half · **Priority:** P1 · **Severity:** High
- **Plan:** MessagesView gains a contact-admin action (shown for parents; calls `open_parent_admin_channel` via `supabase.rpc`, invalidates the channels query, selects the channel). i18n fr/ar/en strings. Vitest coverage per the t-101 pattern. ADR-008's "no channel-creation UI" note is superseded by ADR-012 (owner mandate 2026-09-03) — website AGENTS.md section 3 note updated.

### T-150 — Live apply 0067 + SQL verification matrix — **Completed (VERIFIED — atomic MIG-TOKENS apply; verify_t-148.sql 14/14; chain 64/64)**

- **Plan:** atomic MIG-TOKENS apply (file + `BEGIN; sql; registration; COMMIT;` one Management-API call), then `scripts/verify_t-148.sql` (BEGIN/ROLLBACK): parent can open/return the admin channel (idempotent ×2), non-parent caller rejected, parent insert into a parent-only channel REJECTED, parent insert into the admin DM ACCEPTED, staff insert unaffected, chain 64/64.

### T-151 — Migration 0068: parents display-name data repair ("Famille {lastName}" convention) — **Completed (TESTED — migration authored + applied live atomically; the live verification is T-152)**

- **Problems:** NEW DATA-012 (parents display_name = first child's name; the corpus predates the importer's PARENT-AS-STUDENT FIX) — registered this session · **Priority:** P1 · **Severity:** Medium (owner-visible)
- **Plan:** idempotent UPDATE: for every parent with ≥1 non-deleted student whose `display_name` (whitespace-normalized, case-insensitive) equals one of their children's display names (or first+last join), set `display_name = 'Famille ' || <family last name>` (family name = the parent's current `last_name`, which equals the children's shared family name), `first_name = ''` (the real given name is UNKNOWN in the Excel — a child's name must not masquerade as the parent's), keep `last_name`. Parents without children / non-matching display names untouched (incl. approval-created rows). All renderers already prefer display_name (desktop `parentDisplayName`, website `formatParentName`, Android `fullName`).

### T-152 — Live apply 0068 + SQL verification — **Completed (VERIFIED — atomic MIG-TOKENS apply; verify_t-151.sql 11/11 incl. students-untouched checksum; chain 65/65)**

- **Plan:** atomic MIG-TOKENS apply + `scripts/verify_t-151.sql`: after repair, zero parents display a child's name; children rows untouched (count + checksum before/after); 0066 split semantics intact for non-repaired rows; chain 65/65.

### T-153 — Website activation-screen: precise EF error mapping — **Completed (TESTED — 10/10 suite + full website 25 files / 457 tests + lint + strict build)**

- **Problems:** ACT-200 UX half · **Priority:** P2 · **Severity:** Medium
- **Plan:** the screen currently regex-tests `data?.error` — an OBJECT under the hub EF's `{error:{code,message}}` shape, so every failure shows the generic "invalide ou déjà utilisé" string. Map by `error.code` (string-shape tolerated for safety): `code_not_found` → invalid/used message, `code_expired` → expired, `account_already_active` → success refresh path, `account_suspended`/`account_rejected` → actionable localized message, `auth_failed` → session message. Dictionary entries fr/ar/en. Vitest unit tests for the mapping.

### T-154 — Session closeout: registries + full suites + zip packaging — **Completed (TESTED — registry entries + statuses + change-log + next-task + current-state + ADR-011/012 + unknowns; full suites re-run; EF curl matrix; chain 65/65; zips produced)**

- **Plan:** problem-registry entries (ACT-200, CHAT-200, DATA-012) with resolution evidence; task-registry statuses + summary; change-log append; next-task.md rewrite; current-state.md refresh; ADR-011/012; website AGENTS.md sync; unknowns.md UNKNOWN-001 closed. Full verification: desktop typecheck+lint+suite, website lint+suite+strict build, EF curl matrix, chain 65/65. Zip the three repos for the owner.

**22nd repair session (2026-09-03) — CLOSED: owner mandate COMPLETE (fresh-token MIG-TOKENS + all-platforms verification + chain consistency; 10 tasks: T-130..T-139).** Opening: chain 62/62 ZERO DRIFT + EF census 13/13. Closeout: **chain 63/63 = 0001–0066 ZERO DRIFT** (0066 = the owner's live-applied backfill, reconstructed + committed by T-139/ARCH-014 — caught ONLY because the closeout re-ran the matrix). Suites at close: desktop 79/2271/0 (+3 suites: t-131 12, t-132 7, t-134 8) + typecheck + lint-delta-0; website 24/440/0 + strict build + live render 200; Android debug 44/372/0 + release 42/367/0 + lintDebug green. Live: 3 EF deploys (workflow-execute, approve-signup-request ×2 rounds), 34/34 MIG-TOKENS matrix, 13/13 anonymous-deny. Registry: OPEN 62→12, stale rows synced, duplicates removed, next-task corruption repaired. Owner residuals unchanged: RESEND_API_KEY + from-domain (emails), FIREBASE_SERVICE_ACCOUNT_JSON (pushes), Google OAuth client (AUTH-200).

### T-130 — MIG-TOKENS session verification with the fresh access token ("apply the migration tokens, consistent everywhere") — **Completed (TESTED — script matrix 34/34 PASS + secrets census + NOTIF-101 policy probe)**

- **Problems:** (verification ritual — ARCH-009/ARCH-011/ARCH-013 prevention; KEYMIG-300 re-check) · **Priority:** P0 (owner mandate) · **Severity:** —
- **Status:** TESTED (2026-09-03, 22nd session)
- **What was done:** the T-122 matrix re-run with the owner's fresh `sbp_…` access token: chain 62/62 zero drift (2 known cosmetic name quirks); EF census 13/13 ACTIVE (hub ↔ deployed one-to-one); dual-key auth health 200 ×2; RLS anon/publishable → empty on 5 core tables ×2; JWKS 200; key consistency vs committed values (website public-config publishable key, Android .env.example URL+JWKS — byte-identical); auth-user census 1 (admin@elimtiyaz.dz, confirmed, active); anonymous-deny sweep on ALL 13 EFs (13×401); live `pg_policies` probe of `notifications_insert` (0048's tightened with_check IS deployed — evidence for T-133's NOTIF-101 flip); live secrets census (11 secrets; **RESEND_API_KEY and FIREBASE_SERVICE_ACCOUNT_JSON NOT set** — owner residuals for T-131/T-126). Script outside the repo: `/home/z/my-project/scripts/verify_t-130_mig_tokens.sh`.
- **Result:** **34/34 PASS.** The migration tokens are applied and consistent everywhere; no drift anywhere in the chain, the EF fleet, or the key registry.

### T-131 — PUSH-104 close: real Resend send for workflow `send_email` + hardened shared email helper — **Completed (TESTED — 12/12 suite + live deploy of both EFs + 401 curl matrix; real sends owner-gated on RESEND_API_KEY)**

- **Problems:** PUSH-104 (High, OPEN→TESTED — the send_email half of T-036) · **Priority:** P1 · **Severity:** High
- **Status:** TESTED (2026-09-03, 22nd session)
- **What was done:** (a) NEW `supabase/functions/_shared/send-email.ts` — the ONE Resend integration (extracted from approve-signup-request's inline fetch per the Existing-Implementation-First rule, hardened): `resolveEmailConfig` (blank/absent RESEND_API_KEY → null → honest not_configured), `sendEmailWithResend` (NEVER throws; **`resp.ok` IS checked** — the original defect; http_error carries status + body excerpt; network_error carries the error text), Deno-free core importable by the desktop vitest suite (ambient Deno declaration per the cron-auth pattern) + `sendEmailFromEnv` Edge wrapper; `PORTAL_URL` constant = the production origin. (b) workflow-execute `send_email` action: stub → real send with explicit `to`/`subject`/`html|body`; missing fields or template-only configs honestly SKIP with the reason recorded (no server-side template registry exists — business content is an owner decision); provider failures recorded in the node output, never thrown (the T-126 honest-outcome contract); header comments updated (push_notification + send_email REAL, the rest still stubs). (c) approve-signup-request: uses the shared helper; the response payload now carries the structured `email` outcome; failures console.warn'd with reason; **NEW DISCOVERY fixed: the confirmation email linked the DEAD `portal.elimtiyaz.dz` origin — now `PORTAL_URL` (elimtiyaz-website.vercel.app, credentials §2.2)**. (d) NEW suite `src/tests/security/t-131-email-ef.test.ts` (RED first — commit 6fe451f: import resolution failure with the helper missing): 8 unit tests of the pure core (config resolution ×2; not_configured no-fetch; success request-shape with Bearer/from/to/subject/html; http_error 402 with body excerpt; network_error never-throws) + 6 source scans (helper is the ONLY api.resend.com implementation under functions/; wired into both EFs; STUB send_email strings gone; dead URL gone everywhere). (e) Both EFs deployed live (CLI v2.116.0; verify_jwt settings preserved: workflow-execute True / approve-signup-request False) + anonymous-deny curl matrix 401 ×4 + EF census 13/13 ACTIVE re-confirmed.
- **Owner residuals:** RESEND_API_KEY secret NOT set live (T-130 census) — sends honestly report not_configured until set; the `from` domain must be verified in the owner's Resend account; template-based configs need the business-content decision; live E2E needs the owner's admin password (out-of-band).

### T-132 — PARENT-102 close: reject approve-without-target-parent — **Completed (TESTED — 7/7 suite + live redeploy + 401 sanity; live 400-branch round-trip owner-gated)**

- **Problems:** PARENT-102 (Medium, OPEN→TESTED) · **Priority:** P2 · **Severity:** Medium
- **Status:** TESTED (2026-09-03, 22nd session)
- **What was done:** the approve path of `approve-signup-request` now guards the "active but unbound" limbo: a PARENT-role approve with NEITHER `target_parent_id` NOR `create_new_parent` → 400 `missing_target_parent` + an `account_approval.missing_target_parent_denied` audit entry (denied-by evidence). The guard sits BEFORE any state change (6a's parent creation + 6b's RPC call). Escape hatch: an explicit `assign_role` override to a STAFF role (looked up against `roles.is_staff_role`; unknown codes → 400 invalid_role) legitimately produces a staff account with no binding; staff-role requests (`requested_role='staff'`) never need one. DEVIATION recorded: the SQL RPC `approve_account_request` was deliberately NOT hardened (a migration rejecting `p_target_parent_id IS NULL` would break the legitimate staff-approval semantics the RPC also serves — the EF owns the caller-facing contract); the problem entry's "migration-level test" verification note does not apply to an EF-only guard. Regression safety proven by caller census: the EF's ONLY client is the desktop (`supabase-approval-repository.ts` — approveWithExistingParent/approveWithNewParent ALWAYS carry a binding); website + Android have ZERO callers (rg-verified). Suite: `src/tests/security/t-132-approve-binding-guard.test.ts` (RED first — commit 2875634): 7/7 (the 400 + error code, parent-role scoping, both escape routes, staff-override escape, denial audit, guard-before-RPC order, the PARENT-102 comment contract). Deployed live (verify_jwt=False preserved) + anonymous-deny 401 ×2.
- **Gap to VERIFIED:** a live staff-JWT round-trip exercising the 400 branch + the audit row (needs the owner's admin password — out-of-band since T-106's reset).

### T-133 — Registry truth-sync + doc-structure repair — **Completed (TESTED — 25+4 summary rows flipped to evidenced states; 3 duplicated blocks removed; live probes recorded)**

- **Problems:** NOTIF-101 (stale header → TESTED), registry duplication, next-task.md corruption · **Priority:** P2 · **Severity:** Medium (registry trust)
- **Status:** TESTED (2026-09-03, 22nd session)
- **What was done:** (a) NOTIF-101 flipped OPEN→TESTED with T-130's LIVE pg_policies evidence (the deployed `notifications_insert` with_check IS 0048's staff-or-self-or-own-role-broadcast tightening — the T-125 flip had missed both the detailed header AND the table row); (b) the problem-registry's verbatim-duplicate entries removed (ARCH-011 ×2 and WEAK-030 ×2 in the "NEW ENTRIES" region — 30 duplicated lines); (c) next-task.md's corrupted duplicated block removed (lines 72–120 repeated the 16th-session history verbatim after the file's real content); (d) the stale "Current recommendation" (still recommending T-104/T-024/T-017/T-020/T-021 — ALL completed in the 17th/18th sessions) rewritten to the current truth (T-043 + T-044 remain the Ready set; the actionable OPEN set is exhausted — what remains is owner-gated, device-gated, or blocked-on-decisions); (e) **25 MORE stale summary-table rows flipped** to their detailed entries' evidenced states (SEC-107/108/110/111/112, TENANT-100/101, CROSS-103/200, SYNC-101/102, HOMEWORK-101, STUDENT-100, PUSH-100/101, ARCH-006→VERIFIED, ARCH-012, DRIFT-001, DRIFT-005, WEAK-003/004/016/018/022, DEAD-014 — the T-125 flip had synced the detailed headers but NOT the index table); (f) the Totals line recounted from the authoritative detailed headers (180 entries: 12 OPEN / 134 TESTED / 12 VERIFIED / 11 BLOCKED / 5 DEFERRED / 6 micro-states). Every flip cross-checked against the detailed entry's own status note (the T-117/T-125 discipline).
- **Verification:** programmatic table-vs-detail cross-check after the flips → ZERO meaningful mismatches (the only remaining OPEN rows are CROSS-004, ARCH-001, DRIFT-011-family, DUP-001..004, REG-002, WEAK-100, DATA-006, AUTH-200 — all documented as blocked/owner-gated/consolidation).

### T-139 — ARCH-014: reconstruct + commit the live-only migration 0066 (parent first_name backfill) — **Completed (TESTED — live verification 6/6; append-only guard OK; the 10th reserved task slot)**

- **Problems:** ARCH-014 (new), DATA-005 (data-repair half — CLOSED) · **Priority:** P0 (live↔repo drift) · **Severity:** High
- **Status:** TESTED (2026-09-03, 22nd session)
- **What was done:** the closeout MIG-TOKENS re-run caught a NEW live-only migration (63 live rows vs 62 at session open — applied by an outside actor DURING this session, ARCH-014): `0066/parent_first_name_backfill` = DATA-005's owner-gated data repair executed live with no committed file. Closed the T-115 way: (a) the DML's exact text is unrecoverable (UPDATE, not a function), so `0066_parent_first_name_backfill.sql` is a SEMANTIC RECONSTRUCTION pinned to the observed live state — header documents the provenance + the reconstruction method; (b) committed WITH the registration statement (live row already exists; ON CONFLICT DO NOTHING); (c) NEW `scripts/verify_t-139_data005_backfill.sql` (BEGIN/ROLLBACK convention) — **live 6/6**: C1 registration row exact · C2 only the 1 single-token name remains empty · C3 split semantics btrim-consistent (258) · C4 display_name + last_name intact · C5 idempotent (0 rows would change) · C6 every parent renders; (d) append-only guard OK (63 files, +1 new in worktree); t-058 guard suite 6/6. **LESSON persisted in AGENTS.md §15 context + ARCH-014: re-run the chain check at session CLOSEOUT, not only at open — the live project has another active actor.**
- **Left:** the 12 cosmetic double-space display_name rows (pre-existing, left untouched by design); nothing else.

### T-134 — DATA-005 desktop residual: parent-name render sites canonicalized — **Completed (TESTED — 8/8 suite + full desktop suite 2271/2271 + typecheck + lint-delta-0)**

- **Problems:** DATA-005 (PARTIAL — agent-side residual closed; data repair remains owner-gated) · **Priority:** P3 · **Severity:** Medium (UX, 258 live rows affected)
- **Status:** TESTED (2026-09-03, 22nd session)
- **What was done:** the initial audit found 4 sites; the RED suite's tree-wide guard scan (the `parent.`-variable convention) then exposed the FULL extent — **18 composition sites across 15 files**, all fixed mechanically to the canonical `parentDisplayName()` helper (domain/model/parent.ts — prefers displayName, falls back to first+last): student-detail/info-tab + payments-tab (the audited pair), search-index parent label, financials receipts-tab / installment-schedule-tab (×3) / payment-detail-drawer, dashboard alert-detail-modal (×2), **the PDF receipts** (payment-receipt.ts + account-statement.ts — user-facing printed "Nom:"/"Parent:" lines — their Pick<Parent> parameter types extended with "displayName"), and the mock layer (parent-repository search-match + create-audit, ledger-repository summary, calendar-repository, notification-alerts (×2), debt-ops (×5)). The mock parent search also gained the displayName match term the Supabase search already had (parity). Students/personnel compositions preserved (correct for them). Android audited CLEAN (all render sites use `fullName`). SCOPE NOTE: the tree guard pins the `parent.`-variable convention only — `p.`-named loop variables are usually students/personnel; the genuine parent `p.`-sites (installment-schedule, alert-detail, debt-ops) are individually pinned by the other tests. Suite: `src/tests/security/t-134-parent-name-rendering.test.ts` 8/8 (RED first — commit 8219dcf: 6 failing). Data repair (splitting display_name into first/last, 258 rows) remains owner-gated (T-085).

### T-135 — Android toolchain re-provision + full-suite baseline — **Completed (TESTED — debug 44 files/372/0, release 42/367/0, lintDebug green)**

- **Problems:** (session infrastructure — AGENTS.md §11 Android recipe) · **Priority:** P1 · **Severity:** —
- **Status:** TESTED (2026-09-03, 22nd session)
- **What was done:** the full toolchain re-provisioned after the container reset (Temurin JDK 21 javac 21.0.12.1; cmdline-tools + platforms;android-35 + build-tools;35.0.0; local.properties; `.env` with ALL keys non-empty). TWO discoveries persisted: (a) the bare `commandlinetools-linux-<V>.zip` URLs 404 from this container — the **`_latest` suffix variant resolves 200** (added to AGENTS.md §11 + the re-created `/home/z/my-project/scripts/android-env.sh`); (b) the `.env` secrets-plugin quirk's precise mechanism re-confirmed: the plugin merges `.env.example` as DEFAULTS, so any key listed there with an EMPTY value (SUPABASE_ANON_KEY= / SUPABASE_PUBLISHABLE_KEY=) must be overridden non-empty in `.env` — my first .env defined only 3 of the 4 keys and the build failed with the blank-literal error exactly as documented; `.env` now defines all four (anon JWT + publishable key + URL + JWKS). Verification: `./gradlew test --no-daemon` → BUILD SUCCESSFUL — **debug 44 files / 372 tests / 0 failures / 0 errors; release 42 files / 367 tests / 0 failures** (release = debug − 5, exactly ARCH-012's two documented exclusions: GreetingScreenshotTest 1 + RoomSchemaUpgradeT046GapTest 4; file-count delta +2 matches the two excluded classes); `./gradlew lintDebug --no-daemon` → BUILD SUCCESSFUL (the T-082 baseline holding). No regressions found — no Android code changes this session.

### T-136 — Website platform baseline verification — **Completed (TESTED — lint 0 / 24 files × 440 tests / strict build green / live render 200)**

- **Problems:** (session verification — owner's "everything works across all platforms") · **Priority:** P1 · **Severity:** —
- **Status:** TESTED (2026-09-03, 22nd session)
- **What was done:** fresh `npm install` (400 packages) then the full verification battery on the HEAD tree (a77e40e): `npm run lint` → 0 errors, 0 warnings output; `npm run test` (vitest) → **24 files / 440 tests / 0 failures** (20th-session baseline 23/436 + the 21st session's t-126-hub-owned-edge-functions guard suite 1 file / 4 tests — arithmetic checks out); strict `npm run build` → compiled successfully (static prerender + middleware); live production-render smoke test (`next start -p 3100` + curl) → HTTP 200, `<title>El-Imtiyaz Portal — Espace Parent & Élève</title>`, NO "Missing configuration" banner (the T-096 committed public defaults working). No regressions found — nothing to fix.

### T-137 — Desktop platform baseline verification — **Completed (TESTED — typecheck clean, lint 0 errors/warning-delta-0, 79 files × 2271 tests ALL PASS)**

- **Problems:** (session verification) · **Priority:** P1 · **Severity:** —
- **Status:** TESTED (2026-09-03, 22nd session)
- **What was done:** the full desktop battery on the tree WITH this session's changes (T-131/T-132/T-134 suites + the parentDisplayName canonicalization): `npm run typecheck` → clean; `npm run lint` → 0 errors with **warning-delta vs HEAD = 0** (stash round-trip: 384 → 384 — the documented 307-warning T-078 baseline is simply old; the delta proves this session's code adds nothing); `npm test` (vitest) → **79 files / 2271 tests / 0 failures** (20th-session baseline 75/2236 + this session's three new suites: t-131-email-ef 12, t-132-approve-binding-guard 7, t-134-parent-name-rendering 8 = +27; +4 files). No regressions found. A final pristine-tree re-run happens at T-138 closeout (TEST-300 discipline).

### T-138 — Session closeout: pristine-tree full re-run + zip packaging — **Completed (TESTED — the closeout re-run caught ARCH-014; all suites green on the final tree; zips produced)**

- **Problems:** (session close — TEST-300 lesson) · **Priority:** P1 · **Severity:** —
- **Status:** TESTED (2026-09-03, 22nd session)
- **What was done:** the pristine-tree re-runs on the final committed tree: desktop typecheck clean + **79 files / 2271 tests / 0 failures**; website lint clean + **440/440**; the closeout MIG-TOKENS re-run (34/34) — **which CAUGHT the live-only 0066** (→ T-139, the reserved 10th slot) and re-verified 63/63 zero drift after the reconstruction commit; current-state.md + next-task.md + this registry updated; the three repos zipped for the owner to push (with the batch's 12 commits in the hub, 0 in website/Android).

### T-140 — 23rd-session opening MIG-TOKENS + live health verification (the fresh token re-run) — **Completed (TESTED — 63/63 zero drift; EF fleet 13/13 ACTIVE + 26-probe anonymous-deny matrix all 401)**

- **Problems:** (session ritual — AGENTS.md §15 rule 11; owner mandate "apply the migration tokens / everything works across all platforms") · **Priority:** P0 · **Severity:** —
- **Status:** TESTED (2026-09-03, 23rd session)
- **What was done:** the full opening verification with the owner's fresh access token: (1) live chain 63/63 = 0001–0066 **ZERO DRIFT** vs the committed chain; (2) EF census 13/13 ACTIVE with names matching the hub's `supabase/functions/` set one-to-one; (3) the anonymous-deny curl matrix on ALL 13 EFs × 2 probes (no-auth + anon-key) — **26/26 = 401**; (4) auth health 200 on both key formats + JWKS 200; (5) RLS anon-deny 0-rows × 5 core tables; (6) production portal render HTTP 200 with the correct title; (7) auth census 1 user; (8) live secrets census (11 present; RESEND_API_KEY + FIREBASE_SERVICE_ACCOUNT_JSON still absent — unchanged owner residuals); (9) the Google-OAuth config re-read that DISCOVERED the owner's between-sessions credentials (→ T-141). Scripts persisted at `/home/z/my-project/scripts/{check_live_chain.sh,t140_ef_fleet.sh,t140_ef_matrix.sh,t140_health.sh}` (outside the repo — they carry the access token).
- **Result:** the 22nd-session close state fully preserved; the migration tokens applied + consistent everywhere.

### T-141 — AUTH-200 close: Google OAuth provider enabled — **Completed (TESTED — live PATCH + authorize-endpoint 302 to Google; the #1 Critical user-facing blocker closed agent-side)**

- **Problems:** AUTH-200 (Critical, OPEN→TESTED) · **Priority:** P0 · **Severity:** Critical
- **Status:** TESTED (2026-09-03, 23rd session)
- **What was done:** the session-opening check (T-140 probe 9) found the owner had completed runbook steps 1–2 between sessions (client_id 72 chars + secret 64 chars SET, toggle still off) — the ARCH-014 "owner is an active actor" lesson extended to auth config. The agent ran runbook step 3: the **enable-only PATCH** `{"external_google_enabled": true}` (200; credentials/site_url/uri_allow_list preserved — partial-body PATCH is the safe shape). Live-verified step 4: GET enabled=true; `authorize?provider=google&redirect_to=<production>` → **HTTP 302 → accounts.google.com** with the owner's client `259221439109-hp67…` (was `400 Unsupported provider` since 2026-08-31). Docs: NEW `docs/recovery/t-141-live-verification.md`; runbook status header; problem registry (detailed entry + index row + totals 12→11 OPEN).
- **Left:** VERIFIED awaits the first real browser sign-in (one click on the production portal; Google consent screen TESTING-mode = parents must be test users, runbook step 1.2). If authorize ever 400s again, re-run the step-3 PATCH.

### T-142 — 23rd-session platform baselines (all three pristine) — **Completed (TESTED — desktop 79/2271 + typecheck + lint-delta 0; website 24/440 + lint + strict build; Android 44/372 + 42/367 + lint)**

- **Problems:** (session verification — TEST-300 lesson; the owner's "everything works across all platforms") · **Priority:** P1 · **Severity:** —
- **Status:** TESTED (2026-09-03, 23rd session)
- **What was done:** after the container reset, the full toolchains were re-provisioned (npm installs; Temurin JDK 21 + SDK 35 + the .env secrets-plugin quirk per AGENTS.md §11 — recipe re-created at `/home/z/my-project/scripts/android-env.sh` with a NEW retry-loop quirk: the container network stalls on large transfers, so the JDK download needs `curl -C - --speed-limit 10240 --speed-time 30` in a retry loop). Baselines on the pristine HEAD trees: desktop `npm run typecheck` clean + `npm run lint` 0 errors/384 warnings (delta-0) + `npm test` **79 files / 2271 tests / 0 failures**; website `npm run lint` clean + `npm run test` **24 files / 440 / 0** + strict `npm run build` green; Android `./gradlew testDebugUnitTest` **44/372/0** + `testReleaseUnitTest` **42/367/0** + `lint` BUILD SUCCESSFUL. All three match the 22nd-session close EXACTLY (zero regressions at open).

### T-143 — T-043 COMPLETE: equivalence-framework consolidation (ADR-006) — **Completed (TESTED — 4 scoped passes; 3 trees + 1 mirror deleted; single framework; corpus access documented)**

- **Problems:** DUP-001 (absorbs DEAD-004, CROSS-002, CROSS-008; OPEN→TESTED), DUP-002 (OPEN→TESTED) · **Priority:** P2 · **Severity:** High
- **Status:** TESTED (2026-09-03, 23rd session)
- **What was done (4 commits, one per pass):**
  - **Pass 1 (DUP-002):** deleted `src/test/cross-platform/_tier4/kotlin_mirror_engine.ts` (the drifted copy that keeps empty strings in the parent-code identity join); repointed all **7** consumers (6 Tier4 test files + `vault-compliance-architecture.test.tsx` — the 7th was discovered via typecheck, not grep: it lives under `src/tests/integration/` with a different relative path) to import `financial-tests/equivalence/android_mirror/`. **NEW DISCOVERY:** the canonical mirror was NEVER in the typecheck graph (nothing under src/ imported it) — repointing surfaced 2 latent type defects (maxOf's narrowed `b: string` vs a `string|null` call site at line 354; the `as const` RECONCILE_CODES index) — both fixed type-only. 810 Tier4 tests + 34 vault tests green against the canonical engine.
  - **Pass 2 (DEAD-004):** deleted `financial-tests/scenarios/` (8 .yml files, never read by any runner — both runners HARDCODE their scenario sets). Unique-scenario coverage report (ADR-006 requirement): all 8 scenarios live on in the JSON corpus (001/003/004/005/006/008/012) and/or the hardcoded runners (the fromCode-totality block in the Android runner). Both runner headers corrected (desktop + Android commits).
  - **Pass 3 (CROSS-002):** deleted `financial-tests/cross-platform-v2/` (7 files — an empty scaffold: no scenario corpus, zero inbound references, its probe subject was resolved by migration 0040 long ago).
  - **Pass 4:** deleted `financial-tests/equivalence-live/` (21 .mjs files — never wired to run; live verification is de-facto owned by the scripts/verify_t-XXX.sql convention per AGENTS.md §11.1). Documented the Android corpus access (ADR-006 decision 4) in `docs/testing/cross-platform.md` §2.1 (the T-081 resolution order: system properties → module dir → repo root → sibling hub → sibling standalone; no copy step). ADR-006 status: Proposed → **Implemented**, with the decision-2 DEVIATION recorded (the "live-DB layers as a runner mode" was NOT ported as code — porting 21 unwired .mjs files would recreate the parallel-path anti-pattern; the role is owned by the verify-script convention; the concept survives in the ADR text + git history).
- **Verified:** full desktop suite re-run after each pass — **79 files / 2271 tests / 0 failures** every time; typecheck clean; lint 0 errors. The 304-scenario JSON corpus untouched. `financial-tests/` now contains exactly ONE tree (`equivalence/`).
- **Left:** nothing — T-043 complete.

### T-144 — T-044 passes 1–2: Android design-system consolidation (DUP-004 closed; DUP-003 partial) — **Completed (TESTED — pass 1: theme duplicate + 3 dead files removed, screenshot test migrated; pass 2: the settings module fully migrated, 37→29 legacy importers)**

- **Problems:** DUP-004 (Medium, OPEN→TESTED; absorbs WEAK-013), DUP-003 (High, OPEN→PARTIAL) · **Priority:** P3 · **Severity:** High (maintenance)
- **Status:** TESTED (2026-09-03, 23rd session)
- **What was done:**
  - **Pass 1 (DUP-004, Android commit "T-044 pass 1"):** deleted the dead legacy `ui/theme/ElImtiyazTheme.kt` + its only-consumers-become-dead companions `Type.kt` (ElImtiyazTypography) + `ColorSchemes.kt` (Dark/LightColorScheme) + the dead `ElShapes` Material scale (Shapes.kt kept — its semantic constants have 20+ live importers). `GreetingScreenshotTest` migrated to the PRODUCTION theme (`designsystem.theme.ElImtiyazTheme`) — WEAK-013 closed. **NEW DISCOVERY:** roborazzi's `captureRoboImage` does NOT write the PNG in the repair container (verified: deleted greeting.png, forced a fresh 8.9s test run — PASSED, no file created anywhere on the filesystem). The committed greeting.png is a historical artifact; do NOT interpret an unchanged PNG as "the render is byte-identical".
  - **Pass 2 (DUP-003, Android commit "T-044 pass 2"):** the ENTIRE settings module (8 files: ActionRow, SecuritySection, ProfileCard, DiagnosticsSection, SyncSection, SettingsScreen, AuditLogScreen, PreferencesSection) migrated to `ui.designsystem.*` — zero legacy imports remain under features/settings. Parameter mappings: ElButtonStyle→ElButtonVariant; ElAvatar size=56→ElAvatarSize.L; ElTag color→tone via a NEW roleTone() helper (replacing roleColor, its only consumer); ElDropdown to the ElDropdownOption API (selectedValue matches option.VALUE not the label — the language dropdown now passes the ISO code; the label↔code helpers became dead and were removed); ElScaffold's content lambda now applies the PaddingValues the DS scaffold contract requires. Legacy importers: **37 → 29**.
  - **Documented blockers for the remaining screens:** the 4 hub screens use the SCROLLABLE `ModernSecondaryTabRow` while the DS `ElTabRow` is a segmented control (6-tab FinancialsHub would squeeze — a scrollable DS tab component must be added to the design system FIRST, per the no-parallel-implementations rule); MainScreen's `ModernBottomNavBar` is index-based while the DS `ElBottomBar` is route-based (a model rewrite, not a re-import).
- **Verified:** `./gradlew compileDebugKotlin` + `compileReleaseKotlin` BUILD SUCCESSFUL; `testDebugUnitTest` **44 files / 372 / 0**; `testReleaseUnitTest` **42 files / 367 / 0**; `lint` BUILD SUCCESSFUL — identical to the session-opening baseline after BOTH passes.
- **Left:** 29 legacy importers remain (DUP-003 stays PARTIAL): dashboard 9, crm 6, academics 5, financials 6, personnel 3, chat 2, routing 2, navigation/MainScreen 1 (+ PermissionDeniedScreen). The settings module is the reference pattern for the next passes.

**21st repair session (2026-09-02) — owner mandate: apply fixes to the existing checkouts (no re-clone), balanced batch.** Session-opening ritual: live chain check **62/62 = 0001–0065, ZERO DRIFT**; MIG-TOKENS condensed re-verification **11/11** (auth health both key formats, RLS anon→0, JWKS, key-consistency vs committed values, census 1). Evidence pass found **20 stale detailed-entry Status headers** (fixes documented in status notes but headers never flipped) → T-125. Batch selected (balanced importance/risk/feasibility): **T-125** (registry truth-sync), **T-126** (PUSH-100 substantial close: fix WEAK-014 `user_profile_id` column bug + WEAK-015 PEM parser bug in the EF source, consolidate the EF source into the hub — NEW FINDING: the live-deployed EF's only source lives in the website repo while credentials.md claims the hub owns it — wire the workflow-execute `push_notification` stub to actually invoke it, redeploy live), **T-127** (PUSH-101 Android half: FCM receiver field reads + click_action intent filter), **T-128** (CROSS-103: Android refund enqueues installment sync pushes after the local waterfall revert), **T-102-follow-up** (Android chat read-side + online sends — 5th attempt, this session commits to it), **T-044** (Android design-system consolidation, if context budget allows). Owner residual recorded: FIREBASE service-account secret is NOT set live (secrets list lacks it) — even with the code fixed, real FCM sends need the owner to set it; AUTH-200 unchanged (Google OAuth client is owner-only).

### T-125 — Registry truth-sync (21st session) — **Completed (TESTED — commit b78fc3b)**

- **What:** 20 detailed-entry Status headers flipped OPEN→TESTED with this session's live-DB/code probes as evidence (SEC-008, SEC-106, PARENT-101, WEAK-200, BUG-NEW-001 live-verified; BUSINESS-001, WEAK-011/012/017/019, SYNC-103/106/107, ARCH-004/008, HOMEWORK-103, NOTIF-105, DEAD-013, BUSINESS-102, CROSS-102 code-verified); index-table rows + summary counts recomputed from the authoritative detailed headers (OPEN 62→19, TESTED 86→129).
- **Why:** future agents reading "OPEN" re-fix fixed problems — the exact waste this registry exists to prevent.

### T-126 — PUSH-100 substantial close: fix + canonicalize + wire the send-push-notification EF — **Completed (TESTED — live deploy + curl matrix + 8/8 source scans; real E2E send owner-gated on the Firebase secret)**

- **What:** (a) WEAK-014: `.eq("user_profile_id", …)` → `user_id` (the device_tokens query ONLY — the notification_preferences query on `user_profile_id` is CORRECT per 0043 and preserved); (b) WEAK-015: registry correction — byte-level verification shows the current source ALREADY strips BEGIN+END+whitespace (the registry text was corrupted by a redaction artifact); hardened to the idempotent regex form anyway; (c) propagate `priority`+`type` into the FCM `data` field (PUSH-101 part 1); (d) move the source to the hub canonical `elimtiyaz-desktop/supabase/functions/send-push-notification/` + remove the website's drifted copy (guard: website `t-126-hub-owned-edge-functions.test.ts` 4/4); (e) replace the workflow-execute `push_notification` STUB with a real invoke (role/user recipient resolution + honest per-recipient failure recording); (f) deploy both EFs live (CLI v2.116.0) + curl matrix; (g) document the owner residual (Firebase service-account secret) + the sb_secret-vs-legacy-JWT discovery.
- **Verified:** hub source-scan suite `src/tests/security/t-126-push-ef-canonical.test.ts` 8/8; website guard suite 4/4; live curl matrix — send-push-notification: no-auth 401 / invalid-bearer 401 / anon 401 / legacy-service-JWT 401 / sb_secret → honest 500 naming the missing FIREBASE_SERVICE_ACCOUNT_JSON secret (auth PASSED, the guard fired); workflow-execute: no-auth 401 / anon 401. Desktop full-suite re-run + website lint/test/build at session close.

### T-127 — PUSH-101 Android half: FCM receiver + deep links — **Completed (TESTED — 14 new tests; live device round-trip remains, needs a real FCM delivery)**

- **What:** (a) ElImtiyazMessagingService: content resolution extracted into pure functions (data first — the canonical EF's routing fields — then the `notification` payload for title/body); the priority default now matches the EF's ("high", was "medium"); a contentIntent carries the click action + routing extras (type, url). (b) AndroidManifest: `${applicationId}.NOTIFICATION_CLICK` intent-filter with CATEGORY_DEFAULT on MainActivity (matches the EF's androidClickAction — three-sided wire contract: hub EF / manifest / service constant). (c) MainActivity: onCreate + onNewIntent publish the deep-link to the NotificationDeepLink bus (survives Splash→Login→Main). (d) MainScreen: acts once on the pending link, selecting the matching hub tab via a permission-keyed map (financial types → Finances, academic → Pédagogie, unknown → first tab; RBAC matrix stays authoritative — an invisible target hub degrades to the first tab). Deeper per-entity routing (e.g. PaymentDetail by id) is the documented follow-up.
- **Verified:** `PushNotificationRoutingTest` 11/11 (content resolution, channel mapping, deep-link hub mapping incl. permission-filtered degradation, one-shot bus) + `PushDeepLinkWiringScanTest` 3/3 (manifest filter + DEFAULT category, service contentIntent constants, MainActivity cold+warm wiring). Full-suite re-run at session close. GAP: a real FCM delivery round-trip needs the owner's Firebase secret + a device.

### T-128 — CROSS-103: Android refund installment sync pushes — **Completed (TESTED — 4 new source-scan tests + full-suite re-run)**

- **What:** after the local waterfall revert in `LocalPaymentRepository.refund`, each reverted installment is enqueued as an `installment` sync entity (operation `update`, payload built from the SAME `reverted` entity that Room persists — byte-identical shape to the batch-registration contract). The dispatcher pushes via the idempotent `upsert_installment_from_import` RPC (TIER 4, migration 0037:741). Safety verified against the migration chain: `upsert_ledger_entry_from_import` explicitly SKIPS reversal entries for waterfall application (0037:653-657) and no server-side auto-revert exists on the payment-status upsert — so this push is the ONLY propagation path; no double-revert risk. The stale comment at LocalRepositories.kt:1015 ("installment is not in the SyncQueueDispatcher's switch statement yet" — false since TIER 4) corrected. DEVIATION recorded: the T-017 entry framed the installment enqueue as T-059/ADR-005 territory — this fix does NOT rewire the write architecture, it extends the EXISTING sanctioned import-RPC path (the same one batch-registration uses), which is how the interim architecture converges.
- **Verified:** `RefundInstallmentSyncT128Test` 4/4 (enqueue present, payload carries the reverted values, enqueue inside the revert loop after the local write, dispatcher still owns the push path). The T-017 guard suite still passes (a second refund enqueues nothing). Live E2E (Android refund → server installments converge) needs a device + session; recorded as the gap to VERIFIED.

### T-129 — T-102-follow-up: Android chat read-side + online sends (ANDR-CHAT-200) — **Completed (TESTED — 21 new tests; live device/websocket round-trip pending)**

- **What:** the 5th-attempt flagship, delivered. (1) Domain: `ChatChannel`/`ChatMessage` models + `ChatRepository` interface (channels by membership / messages asc / unreadCount / send / markRead). (2) Infrastructure: `SupabaseChatRepository` — a VERBATIM port of the website MessagesView's query semantics (member_ids CS filter, archived hidden, last_message_at ordering [CHAT-104/0061], deleted_at hidden, sent_at ASC, send = direct insert with own read-receipt pre-seeded, markRead = append own read_by entry [0051 contract]); DTOs mirror the SQL columns snake_case; malformed read_by degrades to unread, never crashes. (3) Realtime: T-069's RealtimeSyncManager extended — chat_channels/chat_messages subscribed (empty pull lists: chat is online-only v1) + a `tableEvents` SharedFlow the ViewModels collect for refresh. (4) UI: ChatScreen (channel list, empty-state explains staff-opened conversations [ADR-008]) + ChatDetailScreen (bubbles, auto-scroll, auto-mark-incoming-read, 5000-char composer ceiling, announcements read-only). (5) Wiring: Routes.Chat + Routes.ChatDetail RBAC-gated on USE_CHAT; rbacGate in AppNavHost; Messagerie quick action on the Dashboard hub; DI binds ChatRepository → SupabaseChatRepository (online-only, NOT the Local* layer). SCOPE DECISIONS recorded: NO Room cache (a schema bump v11→v12 + migration + MigrationTestHelper is deferred to a v2 session), NO channel creation (ADR-008: staff create channels from the desktop), online-only sends (fail visibly via userMessage).
- **Verified:** `ChatModelsTest` 5/5 (channel mapping, announcement flags, read_by parsing incl. null + malformed degradation); `ChatWiringScanTest` 6/6 (routes gated, nav wiring, DI binding, Messagerie action, NO channel-creation UI, canonical query semantics); RealtimeSyncT069Test extended — the 6-table subscription set + 2 new tests (chat events emit on tableEvents, NO Room pulls triggered). :app:compileDebugKotlin green. Full-suite re-run at session close. GAP: live websocket round-trip + a real send on a device.

**20th repair session (2026-09-02) — owner mandate: "fix this auth thing or tell me what to do" + "apply the migration tokens, consistent everywhere" + a balanced ~10-task batch.** Session-opening ritual: live chain check **62/62 = 0001–0065, ZERO drift** (fresh script pattern); toolchain RE-provisioned after the container reset (JDK 21 Temurin + SDK 35 + the `.env` secrets-plugin quirk discovered and documented in AGENTS.md §11). Completed this session: **T-119** (AUTH-200 agent-side production config: site_url + uri_allow_list now carry `https://elimtiyaz-website.vercel.app`, live-verified; the runbook + credentials sheet updated; the provider itself remains owner-only), **T-120** (AUTH-201: the pre-sign-in "Auth session missing!" alert + console noise eliminated — getSession-first), **T-121** (AUTH-202: the FCM env warning now names the exact missing vars + where to set them), **T-122** (MIG-TOKENS verification: 15/15 live matrix — dual key formats, RLS, JWKS, chain, key consistency vs owner-supplied values, auth-user census), **T-069** (REALTIME-104 closed: Android realtime subscriptions — the freshness backbone), **T-124** (registry hygiene: DEAD-012 closed with evidence, 3 stale REALTIME summary rows, stale AGENTS.md notes, AUTH rows added to the summary table). Baselines: desktop 75/2236, website 23/436, Android re-run this session. Deferred with reasons: **T-102-follow-up** (Android chat read-side — needs T-069's infrastructure landed first; a full feature build for a dedicated session) and **T-043** (equivalence consolidation per ADR-006 — explicitly "schedule a full session").

### T-119 — AUTH-200 production redirect configuration (agent-side half) — **Completed (TESTED — live config verified; the round-trip itself is owner-gated)**

- **Problems:** AUTH-200 (the agent-side half; owner step remains) · **Priority:** P0 (the owner's "fix this auth thing") · **Severity:** Critical
- **Status:** TESTED (2026-09-02, 20th session)
- **What was done:** live evidence first: the production deployment EXISTS (`redirect_to=https://elimtiyaz-website.vercel.app/` in the owner's pasted error URL) but the live auth config still had `site_url=http://localhost:3000` and `uri_allow_list` without the production origin — meaning even AFTER the provider is enabled, the OAuth redirect would have bounced to localhost (non-allowed redirect_to falls back to site_url). PATCHed via the Management API (comma-separated-string format per the 14th-session discovery): `site_url=https://elimtiyaz-website.vercel.app`, `uri_allow_list=http://localhost:3000,http://localhost:3100,https://elimtiyaz-website.vercel.app` (localhost origins preserved). GET-verified after PATCH (values persisted). Runbook (`docs/operations/portal-google-oauth.md`) updated: status header, step-1 note (Firebase config has NO usable OAuth client — `oauth_client: []`), step-2 JavaScript origins now name the production origin, step-4 probe uses the production redirect_to, a "Production web-push env vars" section, and the 20th-session discoveries (provider-check-before-redirect-validation; the missing /users REST path). Credentials sheet: new §2.2 Production deployment (values table + the Android applicationId discovery).
- **Verification:** apply script `/home/z/my-project/scripts/apply_t-119_auth_production_config.sh` (BEFORE/PATCH-200/AFTER output preserved; kept outside the repo — carries the access token). Live probes: authorize endpoint with bogus vs production redirect_to (both return the provider-disabled 400 — proving the provider check precedes redirect validation; recorded in the runbook). Full round-trip verification remains owner-gated (needs the provider enabled).
- **Left:** the OWNER step (runbook step 1: create the Google Cloud OAuth client + step 3 PATCH, or hand the client id/secret to the next agent session).

### T-120 — AUTH-201: eliminate the pre-sign-in "Auth session missing!" alert + console noise — **Completed (TESTED)**

- **Problems:** AUTH-201 (new) · **Priority:** P1 (owner-pasted production console evidence) · **Severity:** Medium
- **Status:** TESTED (2026-09-02, 20th session)
- **What was done:** `loadProfile()` (auth-provider.tsx) called `getUser()` unconditionally — the NORMAL signed-out state threw `AuthSessionMissingError` → `console.error` + `setError("Auth session missing!")` → the raw English string rendered in the login screen's red alert on EVERY fresh visit (the owner's pasted console). Now: `getSession()` (local, never throws) first; `getUser()` only when a session exists (server-side validation); validation failure → `console.warn` + unauthenticated, NO error state (supabase-js fires SIGNED_OUT itself on refresh failure). Genuine profile/parent fetch failures still set the error state. The T-116 contract (provider_disabled mapping, raw passthrough for other OAuth classes) preserved untouched.
- **Tests:** NEW `src/app/providers/t-auth201-session-noise.test.tsx` (4/4: no-session → no error + getUser NOT called; failed validation → warn not error + no error state; active-profile flow preserved; real fetch errors still surfaced). Existing SEC-007 suite updated for the getSession-first contract (3/3). Website: lint 0, suite 23 files / 436 tests ALL PASS, strict `next build` green.
- **Commits:** website repo + hub (problem entry AUTH-201).

### T-121 — AUTH-202: make the FCM env warning actionable — **Completed (TESTED)**

- **Problems:** AUTH-202 (new) · **Priority:** P2 · **Severity:** Low
- **Status:** TESTED (2026-09-02, 20th session)
- **What was done:** the generic `[env] Firebase env vars are incomplete.` warning (owner's pasted console) named nothing. It now lists the exact missing variables (`NEXT_PUBLIC_FIREBASE_APP_ID (the WEB app id, 1:<project>:web:…)`, `NEXT_PUBLIC_FIREBASE_VAPID_KEY`), says where to set them (Vercel → Project → Settings → Environment Variables), and stays silent when FCM is fully configured or Firebase is intentionally unconfigured. Runbook gained the matching "Production web-push env vars" section (the owner's second 10-minute step).
- **Tests:** NEW `src/lib/t-121-fcm-env-warning.test.ts` (3/3). Website: lint 0, suite 23 files / 436 tests ALL PASS, strict build green.
- **Commits:** website repo + hub (problem entry AUTH-202 + runbook).

### T-069 — Android realtime subscriptions — **Completed (TESTED)**

- **Problems:** REALTIME-104 (OPEN → TESTED) · **Priority:** P2 · **Severity:** High
- **Status:** TESTED (2026-09-02, 20th session — unit-level evidence; the live "server write → UI within seconds" round-trip needs a real device/emulator)
- **What was done:** `RealtimeSyncManager` (new, infrastructure/sync) + `SupabaseRealtimeEventSource` (new, infrastructure/supabase) + the `RealtimePullTarget` seam (PullSyncRepository implements it with its EXISTING granular pulls — no second pull implementation; Hilt binding in SupabaseModule) + an `OnlineGate` fun-interface adapter over OnlineDetector. Subscriptions activate reactively when a session appears and deactivate on sign-out (the FCM-topic pattern; wired in ElImtiyazApplication.onCreate — `realtimeSyncManager.start()`). One realtime channel per table (`android-realtime-<table>`, postgres changes, event `*`, NO column filter — RLS scopes events, the REALTIME-102 lesson; the supabase-kt Realtime plugin auto-provides the session JWT via disconnectOnSessionLoss). Events route to the granular pulls with the website's cross-invalidation semantics (an installment event refreshes installments AND payments — the waterfall can move payments); bursts debounce to one pull pass per table (2s default); online gate fail-closed; pull failures never kill a subscription; the 15-min SyncWorker cycle REMAINS the fallback (pinned by test). DEVIATION from the task text (recorded here per the workflow): `chat_messages` is NOT subscribed yet — Android has no chat read-side (T-102-follow-up, deferred); subscribing with no consumer would be dead traffic. The routing map makes it a one-line addition when T-102 lands.
- **Tests:** NEW `RealtimeSyncT069Test` (11/11: reactive lifecycle ×4 [sign-in activates the 4-table set, sign-out deactivates, idempotent start, unconfigured → zero subscriptions], routing + debounce ×3 [burst → ONE pull; installment → installments AND payments; notification/homework → own pulls only], online gate ×1, production wiring source-scans ×3 [Application start, SDK source filter-free + no setAuth, periodic fallback preserved]). Full Android suite: 39 files / 342 tests / 0 failures (baseline 38/331).
- **Commits:** Android repo (manager + source + seam + DI + wiring + suite) + hub (REALTIME-104 + this entry).

### T-122 — MIG-TOKENS session verification ("apply the migration tokens, consistent everywhere") — **Completed (TESTED)**

- **Problems:** (verification ritual — ARCH-009/ARCH-011 prevention; KEYMIG-300 re-check) · **Priority:** P0 (owner mandate) · **Severity:** —
- **Status:** TESTED (2026-09-02, 20th session)
- **What was done:** the owner's mandate re-executed with the freshly supplied keys: (1) live chain vs local files — 62/62 = 0001–0065, ZERO drift; (2) dual-key matrix — `auth/v1/health` 200 with BOTH the legacy anon JWT and the `sb_publishable_…` key; (3) RLS — anon/publishable REST queries return 200 + `[]` on parents/students/payments/ledger_entries/installments; (4) JWKS 200; (5) key consistency — every owner-supplied public value is byte-identical to the committed values (website `public-config.ts` + `.env.example`; Android `.env.example` URL+JWKS; Firebase API key); (6) auth-user census (SQL endpoint): 1 user — `admin@elimtiyaz.dz`, confirmed, active (the `/v1/users` REST path does not exist — AGENTS.md §11.1 quirk #4). Script: `/home/z/my-project/scripts/verify_t-122_mig_tokens.sh` — **15/15 PASS**.
- **Commits:** hub repo (AGENTS.md §11.1 + this entry + credentials sheet).

### T-123 — Android lint-baseline "unmatched" AGP entries — **Completed (TESTED — investigation; NO change warranted)**

- **Problems:** (lint-backlog hygiene) · **Priority:** P3 · **Severity:** Low
- **Status:** TESTED (2026-09-02, 20th session — investigation closed with a documented discovery)
- **What was found:** lint reported 3 `AndroidGradlePluginVersion` baseline entries "not found" — apparent stale entries. Empirical sequence: prune to 0 → ONE live warning appeared; restore 1 → TWO live warnings appeared; the emission count is network-nondeterministic (lint's version check fires 0–2 identical warnings per run). The 3 committed entries are a deliberate allowance for that variance; `LintBaselineFixed` is informational-only (does not fail the gate).
- **What was done:** NOTHING to the baseline (restored byte-identical: 116 entries, 3 AGP); the discovery documented in change-log T-123 so no future agent "prunes" them and reintroduces intermittent live warnings. `lintDebug` BUILD SUCCESSFUL with the committed baseline (113–114 warnings filtered depending on the run's emission count).
- **Commits:** none needed (no change) — documentation only.

### T-124 — Registry + documentation hygiene (DEAD-012 close, stale rows, AGENTS notes) — **Completed (TESTED)**

- **Problems:** DEAD-012 (closed), summary-table staleness (REALTIME-101/102/103), AGENTS.md §11 stale note, AUTH family absent from the summary table · **Priority:** P2 · **Severity:** Medium (registry trust)
- **Status:** TESTED (2026-09-02, 20th session)
- **What was done:** (a) DEAD-012 CLOSED with evidence (setup.ts exists since the 2026-08-29 root-cause fix; T-049 completed the cleanup; today: 23 files / 436 tests; the stale "missing" note in hub AGENTS.md §11 removed); (b) three summary-table rows whose detailed entries say TESTED but whose table rows said OPEN flipped (REALTIME-101/102/103) + REALTIME-104 row updated; (c) AUTH-200/201/202 rows added to the summary table (the AUTH family had NO summary rows at all — the 14th session's registration gap, now closed); (d) AGENTS.md §11.1 quirk #4 (missing /users REST path) + the Android toolchain note (JRE-only system java; the `.env` empty-value compilation quirk).
- **Verification:** every flip cross-checked against the detailed entry's own status note (the T-117 discipline).
- **Commits:** hub repo.

**19th repair session (2026-09-02) — owner-mandated: "fix the auth thing" + "apply the migration tokens, ensure everything works across all platforms and the migration is properly applied and consistent everywhere".** Session-opening chain check found **LIVE DRIFT**: 62 live rows vs 61 committed files — live-only `0065/canonical_identity_codes` (applied by an actor outside the repos after the 18th-session close; registered as ARCH-013). Completed this session: **T-115** (migration 0065 reconstructed + committed + applied atomically + live-verified 19/19; TS↔SQL equivalence pinned 9/9; typed RPCs registered desktop+website), **T-118** (DRIFT-001 closed: mock layer + approve-signup-request EF aligned to the deterministic server contract, EF redeployed live), **T-116** (AUTH-200 client-side UX mitigated + fresh live evidence + owner instructions refreshed; the provider itself remains owner-action-required), **T-117** (registry hygiene: 12 stale headers flipped; t-052 test portability fixed), **T-107-follow-through** (credentials sheet refreshed + §7 live checklist re-run, both key formats verified; committed values match the owner-supplied keys), **ARCH-012** (release-variant screenshot test scoped with documented exclusion). Deferred with reasons: T-069 + T-102-follow-up (full feature builds — unchanged from the 18th-session deferral; this session's mandate consumed the context budget).

### T-115 — Reconstruct, commit and verify migration 0065 (canonical identity codes at the DB layer) — **Completed (VERIFIED live)**

- **Problems:** ARCH-013 (new) · **Priority:** P0 (owner mandate: "apply the migration tokens … consistent everywhere") · **Severity:** Critical (live↔repo schema drift)
- **Status:** VERIFIED (2026-09-02, 19th session — file==live 5/5 byte-identical; verify_t-115.sql 19/19 live; desktop suite 2236)
- **What was done:** the live-only migration (4 new canonical functions + batch_register_family rewrite, applied to the live DB by an outside actor after the 18th-session close) was reconstructed verbatim from the live catalog via pg_get_functiondef, committed as `0065_canonical_identity_codes.sql` with a full reconstruction-note header, applied live atomically via `apply_0065_live.sh` (MIG-TOKENS: BEGIN + file + registration ON CONFLICT DO NOTHING + COMMIT; the pre-existing row preserved), and verified live (presence, registration, unique constraint, 10 deterministic-generator vectors pinned to the desktop TS engine, the full RPC contract: empty-identity rejection / deterministic codes / duplicate refusal / audit tagging). Typed RPC signatures registered in desktop `types.ts` + website `database.ts`. NEW suite `t-115-sql-identity-equivalence.test.ts` (9) pins the TS↔SQL equivalence permanently + the EF source contract. Full evidence: `docs/recovery/t-115-live-verification.md`.
- **Discoveries persisted:** the Management API SQL endpoint silently DROPS `COMMENT ON` statements (AGENTS.md §11.1 + the live-verification doc); batch_register_family REQUIRES date_of_birth in student JSON (students.date_of_birth NOT NULL, no RPC default); pg_get_functiondef is the only reliable reconstruction source.
- **Commits:** hub repo.

### T-118 — Close DRIFT-001: mock layer + approve-signup-request EF aligned to the deterministic server contract — **Completed (TESTED)**

- **Problems:** DRIFT-001 (OPEN → TESTED/CLOSED) · **Priority:** P1 · **Severity:** High
- **Status:** TESTED (2026-09-02, 19th session)
- **What was done:** (a) `MockParentRepository.createParent` switched from `randomParentSuffix()` (which mirrored 0022's gen_random_bytes — a DEAD server behavior since 0065) to the canonical `deterministicParentCode` + duplicate-identity refusal mirroring the server's unique (tenant_id, parent_code) constraint; the dead `randomParentSuffix` copies deleted from `core/format/id.ts` and `supabase-shared-repositories.ts`. (b) `approve-signup-request/index.ts`'s `Math.random()` parent-code creation replaced with a call to the `fn_deterministic_parent_code` RPC (fail-closed error path `parent_code_failed`); the EF was deployed live 2026-09-02 (anonymous POST → 401 sanity verified).
- **Tests:** NEW `t-018-mock-canonical-create.test.ts` (4/4 — deterministic code equals the canonical generator; duplicate identity refused with ERR_CONFLICT; whitespace-trim equivalence; dead-code scans). Full desktop suite 75 files / 2236 tests ALL PASS; typecheck clean; lint 0 errors.
- **Commits:** hub repo (mock + EF + suite).

### T-116 — AUTH-200 client-side mitigation + fresh live evidence + owner instructions — **Completed (TESTED; the provider itself remains owner-action-required)**

- **Problems:** AUTH-200 (OPEN → OPEN-with-mitigation; owner action still required) · **Priority:** P0 (the owner's "fix this auth thing") · **Severity:** Critical
- **Status:** TESTED (2026-09-02, 19th session — portal UX verified; provider enablement is owner-only)
- **What was done:** live re-verification (Management API): `external_google_enabled: false`, client_id/secret STILL EMPTY; the authorize endpoint's exact failure captured (`400 validation_failed / "Unsupported provider: provider is not enabled"`). Website: `signInWithGoogle` maps that error class to the stable code `provider_disabled`; the login screen renders a localized, actionable message (fr/ar/en `auth.signin.providerDisabled` — "contact the school administration") instead of the raw English server error; raw errors still pass through for other classes. The runbook (`docs/operations/portal-google-oauth.md`) remains the owner's step-by-step (create the Google OAuth client ~10 min + the PATCH; the uri_allow_list quirk documented).
- **Tests:** NEW `src/test/t-auth200-provider-disabled-ux.test.ts` (4/4 — detection pattern, code mapping, dictionary keys in every locale, single assignment site). Website suite 21 files / 429 tests ALL PASS; `next build` green.
- **Commits:** website repo (UX) + hub repo (problem-entry evidence).

### T-117 — Registry hygiene + test portability — **Completed (TESTED)**

- **Problems:** (documentation-consistency class; plus the t-052 portability defect — new discovery) · **Priority:** P2 · **Severity:** Medium
- **Status:** TESTED (2026-09-02, 19th session)
- **What was done:** (a) 12 problem-registry entries whose HEADER said OPEN while their in-body Status note said FIXED/TESTED/VERIFIED were flipped to match (SEC-001, SEC-002, TENANT-103, SYNC-100, SYNC-101, SYNC-102, CACHE-102, ATT-101, NOTIF-102, NOTIF-103, DRIFT-009, BUG-NEW-004 → TESTED/VERIFIED; the hygiene-fix note is on each header line) — a registry whose header contradicts its body misleads the next agent's problem selection. (b) the committed `t-052-notification-badge.test.ts` had a HARDCODED absolute path to the desktop checkout (`/home/z/my-project/repos/…`) — it failed with ENOENT on any other machine/CI; replaced with a sibling-relative probe (the Android equivalence-runner convention) + `describe.skip` when the hub repo is absent.
- **Tests:** t-052 suite 4/4 on the standard layout; the skip path simulated (missing sibling → skip, no ENOENT). Full website suite green.
- **Commits:** website repo (t-052) + hub repo (registry headers).

### T-106 — Fix the desktop sign-in blocker (owner-reported, DESK-LOGIN-200) — **Completed (VERIFIED live)**

- **Problems:** AUTH-300 (new) · **Priority:** P0 (owner blocker) · **Severity:** Critical
- **Status:** VERIFIED (2026-09-01, 17th session) — root cause diagnosed live (client path clean; both key formats healthy; single confirmed auth user; dummy-grant reproduces `invalid_credentials` 400) → admin credential reset via the auth admin API (owner-supplied service_role authorization) → sign-in verified HTTP 200 with BOTH key formats and `current_user_roles()` → `["super_admin"]` through the new session. Evidence: `scripts/desk_login_200.sh`; problem entry AUTH-300 carries the full probe matrix and the recovery procedure for future agents. The new password was delivered to the owner out-of-band ONLY (never in git, per AGENTS.md §15.12).
- **Commits:** hub-repo docs commit (this entry + AUTH-300 + credentials sheet + change-log).

### T-107 — Apply the new-format Supabase API keys consistently on all three platforms (MIG-KEYS-201, owner mandate) — **Completed (TESTED + live-verified)**

- **Problems:** KEYMIG-300 (new) · **Priority:** P1 (owner mandate) · **Severity:** Medium
- **Status:** TESTED (2026-09-01, 17th session) — ADR-009 written (dual acceptance, publishable-preferred, no destructive switch while legacy keys are active). Website: committed public default (public-config.ts) + .env.example switched to `sb_publishable_…` with the legacy JWT retained in-document as the rollback value; 4-test guard suite `src/test/t-107-api-key-migration.test.ts` (new-format pinned, JWT confined to the rollback comment, placeholder detection accepts the new format, configured state preserved); T-096's fresh-clone format pin updated to the sanctioned new reality (its intent — configured-on-fresh-clone — unchanged). Desktop: Configuration tab guidance now names both formats (label, placeholder, help text, dashboard pointer) + `src/tests/security/api-key-format-acceptance.test.ts` 4/4 (client constructs under EITHER key from local config; SEC guard for the service_role/sb_secret wording). Android: runtime already dual-accepts (`BuildConfig.SUPABASE_ANON_KEY.ifBlank { SUPABASE_PUBLISHABLE_KEY }` — credentials sheet documented this in session 8); .env.example comment updated to point the owner at the preferred publishable value; keys stay OUT of the Android repo per T-064/SEC-005 (no committed APK-path credentials). Backend/Edge Functions: no change — EFs consume the platform-injected `SUPABASE_SERVICE_ROLE_KEY` env name; the `sb_secret_` key is the documented successor when Supabase retires legacy JWTs (runbook note in the credentials sheet).
- **Verification:** website `bun run test` 19 files / 419 tests ALL PASS (+4) and `bun run build` compiled successfully; desktop `npm run typecheck` clean, `npm run lint` 0 errors, `npm test` 69 files / 2196 ALL PASS (+4); LIVE dual-key matrix on hkvkefubghbbotgnteir: auth/health 200 ×2, REST query processed ×2, password-grant 200 ×2 (T-106's verification reused as the auth leg). Gap (why TESTED, not VERIFIED): no deployed portal instance was re-rendered against the new default after the build (headless environment); the owner's next `npm run build` + portal load closes it.
- **Commits:** website commit (public-config + env.example + suites), desktop/hub commit (connection-card + supabase-client + suite + ADR-009 + credentials sheet + registries), android commit (.env.example guidance).

### T-104 — parent_credit balance semantics decision (ADR-010) — **Completed (TESTED)**

- **Problems:** DATA-009 (OPEN → TESTED) · **Priority:** P2 · **Severity:** Medium
- **Status:** TESTED (2026-09-01, 17th session) — ADR-010 written choosing option (b) (writer preserved; display convention standardized). Desktop: `displayParentCredit` helper in the canonical balance module + `ParentFinancialProfile.totalUnallocatedCredit` fed by both profile builders + dossier "Crédit parent" card renders the derived value. Website: `displayCredit` verbatim port + Finance-tab credit KPI. 8 desktop tests + 6 website tests pin every population (canonical double-count, unmaterialized historical, goodwill, mixed, clamps) and guard the call sites.
- **Verification:** desktop suite 2204 passed (+8, equivalence suites pinning the unchanged writer still green), typecheck clean; website suite 425 passed (+6), build green. ADR-010 carries the population matrix + implementation map (incl. the Android port note and the dormant debt-meter prop).
- **Commits:** hub repo + website repo.

### T-034 — Desktop cache refresh strategy — **Completed (TESTED)**

- **Problems:** CROSS-104 (TESTED), CROSS-104b (definition half — ADR-005 amendment) · **Priority:** P2 · **Severity:** High
- **Status:** TESTED (2026-09-01, 17th session) — DESIGN CHOICE (documented per the task's own requirement): TTL + window-focus freshness policy, explicitly NOT realtime for this pass (one small testable mechanism across all 9 affected caches vs per-table channel/reconnect lifecycle; realtime stays layerable later — the website's useFinancialRealtime is the in-repo reference). NEW `src/infrastructure/supabase/cache-freshness.ts` (`CacheFreshness`: 30s TTL, focus-forced refresh, deterministic test seams); all NINE one-shot `seeded` boolean sites swapped (parents/students/ledger/installments/payments + expense + personnel ×2 + notifications) — cross-client writes now surface within the freshness budget without a restart, and a failed seed retries after the TTL instead of caching [] for the whole session. CROSS-104b: ADR-005 amendment defines the shared sync_queue audit-trail semantics (field table + the sync_queue-is-never-business-data non-goal); Android implementation remains T-059.
- **Tests:** NEW `src/tests/infrastructure/t-034-cache-freshness.test.ts` 7/7 (defect reproduction against a counting fake client: stale-inside-TTL / fresh-after-TTL; focus-force; no server hammering; failed-seed recovery; boundary + one-shot-force + listener unit semantics).
- **Verification:** `npm run typecheck` clean; `npm run lint` 0 errors; full desktop suite green (counts in change-log). Gap: the two-instance realtime E2E named in the original verification criterion needs a desktop host (headless container) — the counting-fake tests stand in for the freshness budget.
- **Commits:** hub repo.

### T-108 — Electron renderer CSP hardening (DESK-CSP-202, owner-pasted evidence) — **Completed (TESTED)**

- **Problems:** SEC-113 (new) · **Priority:** P2 · **Severity:** Medium
- **Status:** TESTED (2026-09-01, 17th session) — CSP meta added to `index.html` (dev + packaged): `script-src 'self'` (no unsafe-eval/inline), hardened object/frame-ancestors/base-uri/form-action, with documented functional allowances (Google Fonts, inline style attributes for the design system, blob: worker/img for the media vault + exports, user-configured Supabase connect-src TLS-only). NEW `src/tests/security/csp-policy.test.ts` 4/4 pins the security-critical properties. Launch-verified: production under Xvfb (25s alive) and dev against the Vite server (30s) — ZERO "Insecure Content-Security-Policy" warnings and zero CSP violations in both modes (the owner's pasted warning class). Typecheck clean, lint 0 errors, full suite green.
- **Commits:** hub repo.

### 17th session — Android batch + T-017 (T-020, T-021, T-046, T-051, T-017) — all **Completed (TESTED)**

- **T-020 (SYNC-103):** NEW `SyncErrorClassifier` — tryThenEnqueue requeues transient failures (offline/transport/5xx), fail-fast for 4xx. `SyncRequeueT020Test` 6/6. Status TESTED.
- **T-021 (SYNC-106/107):** `syncNow` suspend + awaits drain (honest Result); `DrainResult.remainingPending` + SyncWorker retry/failure/success mapping. `SyncCompletionT021Test` 5/5. Status TESTED.
- **T-046 (ARCH-004):** destructive-migration fallback REMOVED; loud failure pinned by Robolectric (write→reopen data preservation; unresolvable transition throws) + chain scans. `DatabaseMigrationDisciplineT046Test` 3/3. Gap: MigrationTestHelper needs exportSchema=true (follow-up; T-045 first). Status TESTED.
- **T-051 (WEAK-011, TENANT-104, WEAK-012):** NEW `AuditContext` (Lazy<SessionManager> breaks the DI cycle) — all 17 repository classes session-aware; ZERO demo-tenant literals left in LocalRepositories*; pull fallback pulls nothing when signed out. `TenantStampingT051Test` 7/7. Status TESTED.
- **T-017 (BUSINESS-102, CROSS-102 — interim):** already-refunded terminal-state guard (no double refund) + reason in the refund sync payload; installment-convergence enqueue stays ADR-005/T-059-gated. `RefundCorrectnessT017Test` 3/3. Status TESTED.
- **Android suite:** 34 files / 298 tests / 0 failures (275 baseline + 23). Toolchain re-provisioned in-session (JDK 21 + SDK 35; recipe in change-log).

## Completed (thirteenth repair session — 2026-08-31, owner-requested ~10-task batch)

### T-041 — Complete the year-end promotion flow
- **Problems:** ACAD-100, ACAD-101, BUSINESS-004 · **Priority:** P1 · **Severity:** Critical
- **Status:** TESTED (2026-08-31, 13th session; live backend VERIFIED 10/10 via verify_t-041.sql)
- **What was done:** NEW migration `0059_canonical_promotion_flow.sql`: the dead `promote_students` RPC (wrote the legacy table, referenced a non-existent column) is DROPPED; `set_current_academic_year` flips the whole tenant's `is_current` in ONE UPDATE + audit entry (ACAD-101); `execute_batch_promotion` is the atomic batch executor (history upsert + grade advance + graduation + one audit entry in a single transaction, caller-verified per the 0055 SEC-111 pattern). `SupabaseAcademicYearRepository.setCurrentYear/createAcademicYear` → the atomic RPC (insert with `is_current=false`, then flip — failure leaves the previous year intact). `SupabasePromotionRepository.executeBatchPromotion` → ONE RPC call with the decisions array computed by the canonical TS engine; direct student/history table writes removed. `SupabaseStudentRepository.promote()` → implemented on the same RPC path (BUSINESS-004 — the hard "not implemented" error is gone).
- **Tests:** NEW `src/tests/infrastructure/t-041-promotion-flow.test.ts` 8/8; `supabase-repositories.test.ts` promotion tests updated to the RPC contract.
- **Verification:** desktop full suite 64 files / 2146 passed / 5 skipped / 0 failures; `npx tsc --noEmit` clean; `npm run lint` 0 errors. LIVE: migration 0059 applied atomically with its schema_migrations registration (T-091/MIG-TOKENS pattern, `scripts/apply_0059_live.sh`); `scripts/verify_t-041.sql` 10/10 PASS (registration present; dead RPC gone; both RPCs present; non-array payload rejected 22023; unknown student rejected 42501 under simulated staff JWT; missing year rejected 23503; anonymous fail-closed; staff policy + RLS intact). Gap: UI E2E needs a desktop host; real promotion run needs the owner's data.
- **Commits:** 049c418 — hub repo.
- **Left:** mock `StudentRepository.promote()` still does not advance grades (dev-only divergence, noted); Android promotion propagation remains T-024 (toolchain-gated).

### T-030 — Fix sign-out and FCM token lifecycle
- **Problems:** SYNC-104, SYNC-105, PUSH-102 · **Priority:** P2 · **Severity:** Medium
- **Status:** TESTED (2026-08-31, 13th session; live backend VERIFIED 9/9 via verify_t-030.sql)
- **What was done:** NEW migration `0060_fcm_token_transfer_guard.sql`: `register_fcm_token` conflict semantics — same-user conflict reactivates (unchanged); conflict with another user's ACTIVE row RAISES 42501 (the shared-device hijack PUSH-102 is dead — the owner must sign out first, and canonical sign-out deactivates); conflict with another user's INACTIVE row transfers EXPLICITLY with a `device_token.transfer` audit entry. New `unregister_fcm_token(p_token)`: retires ONE row by token string, caller-verified (row owner or service_role), idempotent, audited. Website half (repo elimtiyaz-website): `registerDeviceToken` persists the last-known token (localStorage); NEW `unregisterFcmToken` calls the canonical RPC; `subscribeToFcmTokenRefresh` re-registers AND retires the stale token on rotation; typed in `database.ts` (WEAK-017 rule); signOut uses `scope:"local"` + unregisters (SYNC-105).
- **Tests:** NEW `src/lib/hooks/t-030-fcm-token-lifecycle.test.ts` 5/5 (website).
- **Verification:** website suite 14 files / 135 tests ALL PASS; strict build green; lint clean. LIVE: migration 0060 applied atomically WITH registration; `scripts/verify_t-030.sql` 9/9 PASS (SEC-106 caller-verification intact; ACTIVE-conflict transfer REJECTED 42501; INACTIVE-conflict transfer ALLOWED + audited; same-user reactivation + register audit; unregister retires caller's own row; idempotent NULL for unknown tokens; 2+ audit rows). Gap: live browser FCM round-trip blocked on the owner's FCM web config (env gap documented in credentials.md).
- **Commits:** e3b5fff — hub repo; 99f6ef0 — website repo.
- **Left:** Android `FcmTokenRegistrar` needs no change (calls the same RPC — server guard covers it); PUSH-100 (dead send-push-notification EF) and PUSH-104 (send_email stub) remain T-036.

### T-058 — Adopt append-only migration discipline
- **Problems:** REG-001 · **Priority:** P2 · **Severity:** High (process)
- **Status:** TESTED (2026-08-31, 13th session)
- **What was done:** The discipline that AGENTS.md §15.9 / recovery-rule 14 / ADR-001 prescribe is now MACHINE-ENFORCED: NEW `elimtiyaz-desktop/scripts/check-migrations-append-only.sh` fails (exit 1) on any modification/deletion/rename of an existing migration — checked BOTH in the working tree/index (git status porcelain) AND against a baseline ref (default: upstream/origin/main — the PR case the task prescribes; falls back to HEAD). It also enforces header discipline (`--` first line) and `NNNN_name.sql` naming on every migration file (all 57 pass today). Handles the deleted-directory edge (git prunes empty dirs after `git rm`). Wired in: (a) `npm run check:migrations` (package.json script); (b) `npm test` via NEW `src/tests/infrastructure/t-058-migration-append-only.test.ts` (real-chain pass + 5 planted-violation cases in throwaway git repos — parallel-safe, never dirties the real tree); (c) NEW `scripts/t-058-guard-matrix.sh` (9-case shell matrix). Review-checklist section added to `docs/agents/git-workflow.md` §7; recovery-rule 14 updated to point at the guard. ALSO FIXED: 3 pre-existing TS2339 errors in the T-041 test file (`.value` access without narrowing — the T-041 commit had claimed a clean typecheck; corrected with a local `unwrap()` helper).
- **Tests:** guard matrix 9/9 (clean, unstaged edit, staged delete, rename, new-with-header, headerless new, misnamed new, committed edit vs base, restored); vitest 6/6.
- **Verification:** `npm run check:migrations` → OK (57 files, +2 added vs origin/main — 0059/0060); `npx tsc --noEmit` clean (including the 3 T-041 fixes); full desktop suite 64 files / 2152 passed / 5 skipped / 0 failures (+6 tests); `npm run lint` 0 errors / 369 warnings (unchanged baseline).
- **Commits:** this commit — hub repo.
- **Left:** nothing — the check is in place and wired. GitHub Actions CI does not exist in this repo (documented in change-log); the guard runs locally via npm test / check:migrations and in any future CI as a one-liner.

### T-050 — Android connectivity & pull efficiency
- **Problems:** WEAK-009, SEC-006, CACHE-101, WEAK-010 · **Priority:** P2 · **Severity:** High
- **Status:** TESTED (2026-08-31, 13th session)
- **What was done:** ANDROID (repo elimtiyaz-android, commit 3bc5cdd): OnlineDetector is fail-closed (offline initial state; `isOnline()` = combined connectivity AND probe; probe catch returns FALSE; verdict accepts only 200/401; OkHttp no longer follows redirects so a captive-portal 302 is rejected); the third-party fallback host (`supabase.com`) is DELETED — unconfigured builds probe NOTHING (connectivity-only); probes throttled (10s min interval + in-flight guard); placeholder detection survives the YOUR_PROJECT underscore variant (SEC-005/T-064 overlap noted). PullSyncRepository.pullAll gains an in-flight + 10s dedup window (the "single deduplicated pullAll per cycle"); SyncWorker's and syncNow's duplicate pulls removed (drainPending's trailing pull is the one per-tick pull). DESKTOP (hub repo, this commit): the probe targets the configured Supabase `/auth/v1/health` (apikey header, cors mode — status readable; only 200/401 online; live endpoint behaviour curl-verified: 200 with key, 401 without, `access-control-allow-origin: *`); unconfigured (mock/dev) makes ZERO requests; fail-closed initial state; singleton derives the probe target from supabase-client. Live endpoint behaviour curl-verified. gradle.properties memory tuning committed (2-CPU/4GB container needs it for every future Android test run).
- **Tests:** desktop NEW `src/tests/infrastructure/t-050-online-detector.test.ts` 13/13 (URL resolution, verdict matrix, fail-closed state machine incl. captive-portal 302 + network-failure + apikey-header + unconfigured-no-fetch); Android NEW `OnlineDetectorT050Test.kt` 15/15 (resolution matrix incl. underscore placeholder, verdict matrix, combine rule, source-scan wiring pins).
- **Verification:** desktop suite 65 files / 2165 tests ALL PASS (+13); typecheck clean; lint 0 errors. Android `testDebugUnitTest` 234/234 ALL PASS (+15; was 219). Gap: live airplane-mode/captive-portal behaviour needs real hardware (recorded, not claimed); live device FCM/sync round-trip still blocked on owner config. NEW FINDING registered: ARCH-012 — `testReleaseUnitTest` fails on GreetingScreenshotTest (pre-existing, PROVEN by pristine-tree re-run; debug variant is the green gate).
- **Commits:** 3bc5cdd — android repo; (this commit) — hub repo (desktop half + docs).
- **Left:** T-064 keeps the remaining placeholder-detection scope (NetworkTimeouts.isSupabaseConfigured still hyphen-only); ARCH-012 release-variant test triage open.

### T-026 — Align the overdue rule on Android
- **Problems:** DRIFT-006, WEAK-007, BUSINESS-007 · **Priority:** P1 · **Severity:** Critical (WEAK-007 user-facing)
- **Status:** TESTED (2026-08-31, 13th session)
- **What was done:** `LedgerEngine.maxDaysOverdueFromLedger` re-derived per the canonical INV-4 rule: days-overdue is measured from the account's DUE DATE (latest charge `at` per account via `buildOverdueDueDateMap`), only for accounts with balance > 0 whose due date is past — NOT from the oldest charge's creation date (the old code read a charge created today for next year's tuition as "~365 days overdue"). EVERY production `computeParentSummary` call site in `LocalRepositories2.kt` now builds and passes the due-date map (including balance-only reads — the debt-dashboard `totalOutstanding` KPI loop and `sendReminder` — so no future edit can silently reintroduce the empty-map default that kept "Créances en Retard" permanently 0 DZD). A source-scan pin test enforces this permanently.
- **Tests:** NEW `app/src/test/java/com/example/core/OverdueRuleT026Test.kt` 10/10 (due-date map builder, INV-4 overdue classification, creation-vs-due-date distinction, days-overdue flooring, settled-account exclusion, max-across-accounts, INV-4 consistency totalOverdue ≡ maxDaysOverdueFromLedger, call-site map pins).
- **Verification:** Android `testDebugUnitTest` 275/275 (0 failures / 0 errors / 0 skipped across 29 files; +41 tests this batch, 10 of them this task); full compile of main + test sources; `assembleDebug` green (APK 29.8 MB). Cross-platform equivalence is pinned by the shared INV-4 semantics + desktop-side equivalence cases already in the desktop suite.
- **Commits:** 3462a38 — android repo.
- **Left:** nothing for T-026; the 0.001 DZD threshold alignment note (BUSINESS-007) is closed by the same canonical-rule adoption.

### T-054 — Android hollow implementations
- **Problems:** WEAK-006, WEAK-008 · **Priority:** P2 · **Severity:** Critical (WEAK-006 user-facing lie)
- **Status:** TESTED (2026-08-31, 13th session)
- **What was done:** WEAK-006: `LocalInstallmentRepository.regenerateForCycle` now REALLY re-derives due dates (mirrors the desktop `SupabaseInstallmentRepository.regenerateForCycle`): non-paid tranches get the official schedule (Sept 15 / Dec 15 / Mar 15 via `officialTuitionDueDates(year)`, tranche number from the label's first digit), custom-schedule flags reset, `academic_cycle` stamped, each patched row enqueued to the sync queue (idempotent `upsert_installment_from_import` path), paid tranches preserved, audit row records the REAL rederived count — the old implementation wrote an audit row and returned the installments UNCHANGED. WEAK-008: `WorkflowRunEntity` gains the `trigger` column (`MIGRATION_11_12`, v11→v12, `DEFAULT 'manual'` preserving historical rows' meaning), `WorkflowRunDto.toEntity()` keeps the server's real trigger, `toDomain()` maps it via `WorkflowTrigger.fromCode(trigger)` — the hardcoded "manual" is gone (every pulled run used to display "Manuel" regardless of how it started).
- **Tests:** NEW `app/src/test/java/com/example/infrastructure/local/HollowImplementationsT054Test.kt` 7/7 (trigger survives DTO→entity mapping; null trigger defaults to manual; entity constructor default matches migration default; wire-code enum resolution incl. unknown fallback; source-scan pins for the toDomain mapping, the migration, and the regenerate contract: official schedule, paid-skip, flag reset, cycle stamp, sync enqueue, hollow-pattern-gone).
- **Verification:** Android `testDebugUnitTest` 275/275; `MIGRATION_11_12` registered in `DatabaseModule`'s migration list; full compile; debug APK assembles.
- **Commits:** 3462a38 — android repo.
- **Left:** on-device Room migration smoke test (12→12) needs real hardware (recorded, not claimed).

### T-062 — Android dead-code removal
- **Problems:** DEAD-007, DEAD-008, DEAD-009, DRIFT-007 · **Priority:** P3 · **Severity:** Low
- **Status:** TESTED (2026-08-31, 13th session)
- **What was done:** DEAD-008: `infrastructure/stub/StubRepositories.kt` (2-line comment-only stub) DELETED. DEAD-009: the 833-line design-system gallery showcase DELETED (ElGalleryActivity + ElGalleryScreen + GallerySection + 5 tab files — unreachable from production, never registered in the manifest; deletion chosen over dev-only registration per the reachability rule). DEAD-007: `AuditActions.kt` trimmed from 80+ constants to the 12 the app ACTUALLY writes (76 never-referenced constants removed after a per-constant reachability scan; the file now documents the rule: declare new constants here at write time, full registry lives in the desktop). DRIFT-007: the `SupabaseModule` KDoc corrected — remote sync is ALREADY wired via `SyncSupport.enqueueOnly` + `SyncQueueDispatcher`'s canonical RPCs (the old comment promised a `@Binds` swap that was never needed). Bonus: unused private `SyncService.isSupabaseConfigured()` (hyphen-only duplicate of the NetworkTimeouts gate) removed.
- **Tests:** NEW `app/src/test/java/com/example/core/DeadCodeT062Test.kt` 5/5 (StubRepositories absent, gallery directory absent, AuditActions contains only referenced constants + no removed family, SupabaseModule KDoc describes the real wiring).
- **Verification:** Android `testDebugUnitTest` 275/275; grep over main+test sources shows zero references to any deleted symbol (the only mentions are the T-062 test's own absence pins); manifest has no gallery entry; `assembleDebug` green — APK size note: **29.8 MB debug APK** after removing ~973 lines (no baseline APK exists from before; the debug build is unshrunk so the line-count reduction dominates).
- **Commits:** 3462a38 — android repo.
- **Left:** nothing — all four problem entries closed.

### T-063 — Android absence-alert threshold
- **Problems:** ATT-103 · **Priority:** P3 · **Severity:** Low
- **Status:** TESTED (2026-08-31, 13th session)
- **What was done:** NEW `core/Terms.kt` — Kotlin mirror of the desktop's `src/domain/calc/academics/terms.ts` (T1 Sep 1–Dec 15 / T2 Dec 16–Mar 15 / T3 Mar 16–Jun 30, Jan–Aug reads as the previous school year's T3 tail; label format byte-identical to the desktop so notification text matches cross-platform). `alertAbsences` adopts the desktop rule: only students with ≥3 absences (absent_unexcused + absent_excused, LATE excluded) within the CURRENT TERM are flagged (previously Android alerted for EVERY student in the input — effective threshold 1, alert fatigue + cross-platform divergence); the notification body now carries the count + term label mirroring the desktop message.
- **Tests:** NEW `app/src/test/java/com/example/core/TermsT063Test.kt` 10/10 (term-window boundaries for every month, year-boundary spans, Jan–Aug previous-year rule, label format, threshold boundary at 2 vs 3, late-exclusion, out-of-term exclusion, input-order preservation).
- **Verification:** Android `testDebugUnitTest` 275/275; wired in production via `LocalRepositories2.kt` `alertAbsences` (currentTermWindow + absenceAlertThreshold call the pure functions, scan-verified).
- **Commits:** 3462a38 — android repo.
- **Left:** nothing.

### T-064 — Android config dialog security
- **Problems:** SEC-004, SEC-005 · **Priority:** P2 · **Severity:** Medium
- **Status:** TESTED (2026-08-31, 13th session)
- **What was done:** SEC-004: the SupabaseConfigDialog anon-key field is masked by default (`PasswordVisualTransformation` + show/hide `IconButton`) — the JWT was previously rendered in plain text; the helper text no longer leaks the internal toolchain ("Google AI Studio" → .env guidance only). SEC-005: `SupabaseClientProvider` no longer falls back to the PUBLIC `https://demo.supabase.co` + `demo-key` in ANY path (URL normalization AND the exception handler) — the inert fallback is `https://supabase.unconfigured.invalid` (RFC-2606 reserved TLD, can never resolve) + `inert-unconfigured-key`, so unconfigured builds make ZERO network calls to any real host. RESIDUAL SCOPE CLOSED (noted as left by T-050): `NetworkTimeouts.isSupabaseConfigured`'s placeholder detection was hyphen-only — now extracted into a pure, unit-testable `looksLikePlaceholderConfig(url, key)` catching the `.env.example` values (`YOUR_PROJECT` underscore, `your-anon-key-here` suffix), hyphen/underscore variants, demo/inert literals, quoted env values, and blank/non-https pairs. The unconfigured check therefore fails closed on every known template shape.
- **Tests:** NEW `app/src/test/java/com/example/infrastructure/supabase/SupabaseConfigSecurityT064Test.kt` 9/9 (inert host RFC-2606 + no real supabase.co reference, inert key is not a real credential, demo endpoint gone from provider incl. exception path, dialog masks key + has toggle, no toolchain leak, .env guidance present, env-example placeholder pair detected, real credentials pass, blank/non-https/demo/inert pairs unconfigured, quoted values unwrapped).
- **Verification:** Android `testDebugUnitTest` 275/275; compile clean; the T-050 OnlineDetector placeholder handling and this detection now agree on the YOUR_PROJECT variant.
- **Commits:** 3462a38 — android repo.
- **Left:** nothing for the dialog/provider; NetworkTimeouts detection is now complete (the T-050 "left" note is superseded by this entry).

## Completed (eleventh repair session — 2026-08-31, owner-requested ~10-task batch)

### T-096 — Durable out-of-the-box portal configuration (14th session)
- **Problems:** ENV-300 (new, discovered+fixed), owner-facing "Missing configuration" recurrence · **Priority:** P0 · **Severity:** High (owner-blocking)
- **Status:** TESTED (2026-08-31)
- **What was done:** public client identifiers (Supabase URL + anon key + Firebase web config sans VAPID/web-app-id) committed as code-level defaults in `src/lib/public-config.ts` (classified public per `docs/operations/credentials.md`); `env.ts` falls back to them when env vars are absent (`.env.local` still overrides). ROOT-CAUSE FIX: unset `NEXT_PUBLIC_DEFAULT_LOCALE` fed "" into the zod enum → the WHOLE parse failed → every env value reset to "" (ENV-300 — the banner could appear even with env vars set); empty/unknown locales now resolve to undefined so `.default("fr")` applies. `.env.example` completed with the real public values. 5 regression tests (fresh-clone configured, FCM truthfully disabled, env override wins, placeholder detection intact, no server secrets committed).
- **Tests:** `src/lib/t-096-portal-default-config.test.ts` 5/5; suite 16→17 files / 153 tests ALL PASS; lint clean; strict build green.
- **Verification (live):** fresh-clone render with NO `.env.local` (`next dev` :3100 + agent-browser): "Bienvenue sur le portail El-Imtiyaz" + Google button ENABLED; "Configuration manquante"/"Missing configuration" programmatic check = BANNER ABSENT; screenshot `download/portal-verification/portal-fresh-clone-no-env.png`. This fix SURVIVES a clone/push cycle (values are in the repo, not in gitignored files).
- **Commits:** website repo `fix(config): T-096 …`.

### T-097 — Fix the desktop Electron ESM start failure (14th session)
- **Problems:** owner-blocking (error archived in commit 3f7ec01's message: `ReferenceError: exports is not defined in ES module scope` at dist-electron/main.js) · **Priority:** P0 · **Severity:** Critical (app would not start)
- **Status:** TESTED (2026-08-31)
- **What was done:** `package.json` has `"type": "module"` while the electron tsconfig emits CommonJS — `dist-electron/main.js` was loaded as ESM and crashed at startup. Fix: rename sources to TypeScript's CommonJS-extension form — `electron/main.cts` / `electron/preload.cts` → emit `dist-electron/main.cjs` / `preload.cjs` (Node/Electron always treat `.cjs` as CommonJS regardless of package `type`); `package.json.main` → `dist-electron/main.cjs`; all scripts de-mv'd (the owner's partial workaround `tsconfig.preload.json` + mv chain REMOVED — superseded); preload path in main → `preload.cjs`. ALSO: `npm start` used to launch DEV mode unpackaged (ERR_CONNECTION_REFUSED on localhost:5173, empty window) — isDev now respects `NODE_ENV=production` and `start` sets it, so `npm start` is a true standalone production launch (build + load `dist/index.html`).
- **Tests:** `npm run typecheck` clean; `tsc -p electron/tsconfig.json` emits .cjs; `npm run lint` 0 errors (warning baseline unchanged in kind).
- **Verification (launch):** `DISPLAY=:99 Xvfb` + `NODE_ENV=production electron .` — exit 124 (30s timeout kill = app stayed alive), NO "exports is not defined", NO "Failed to load URL" (renderer `dist/index.html` loaded; only cosmetic container dbus/GPU errors). Log: `download/portal-verification/desktop-launch-t097.log`.

### T-098 — Chat backend completion: migration 0061 (14th session)
- **Problems:** CHAT-103 (creation path), CHAT-104 (last-message ordering), chat_channels UPDATE-policy gap · **Priority:** P0 · **Severity:** High (owner-requested chat)
- **Status:** TESTED (2026-08-31 — applied live + registered atomically per the MIG-TOKENS pattern)
- **What was done:** `0061_chat_channel_completion.sql`: (1) chat_channels completion columns (description, department_id, archived_at, last_message_at, last_message_preview); (2) `chat_channels_update` policy (staff/creator-gated — enables desktop updateChannel/archiveChannel/addMembers); (3) `touch_chat_channel_on_message()` SECURITY DEFINER trigger on chat_messages INSERT (CHAT-104 — rationale in the migration header: the UPDATE must run for ANY author incl. parents while the update policy is staff-gated; only denormalized preview columns are touched); (4) canonical idempotent `create_direct_channel(p_other_profile_id, p_name)` RPC — SECURITY DEFINER with full caller verification (staff gate + target-exists + fixed 'direct'; the 0050/0055 hardened pattern — INVOKER was impossible because `user_profiles_select_own` RLS hides other profiles from manager/teacher callers); audits channel creation. Session-opening chain check FIRST (57/57 == 0001–0060, zero drift — script persisted). Applied via `scripts/apply_0061_live.sh` (atomic BEGIN…registration…COMMIT).
- **Tests:** live `scripts/verify_t-098.sql` — **15/15 PASS** (registration, 5 columns, update policy, trigger, happy path with deterministic DM code, idempotency, staff gate, self-rejection, fabricated-profile rejection, trigger-fires, non-member invisible, anon invisible, non-staff update blocked 0-rows + name intact, staff update allowed, audit rows). REST layer: anonymous rpc() → 401. Append-only migration guard green (58 files, +1 new).
- **Commits:** hub `fix(chat): T-098 …`.

### T-099 — Desktop SupabaseChatRepository (14th session)
- **Problems:** CHAT-105 (chat stays on the mock in Supabase mode) · **Priority:** P1 · **Severity:** High
- **Status:** TESTED (2026-08-31)
- **What was done:** `src/infrastructure/supabase/repositories/supabase-chat-repository.ts` — full ChatRepository implementation on chat_channels/chat_messages: realtime subscriptions (postgres_changes on both tables), personnel-id→user_profiles.id translation on every write (the UI mixes session.userId [profile id] with personnel picker ids — header note documents the two ID spaces), direct channels via the canonical RPC, markRead preserving existing read_by entries byte-identically (the 0051 append-only guard checks jsonb containment — regenerating read_at fails), soft delete, authorName resolution via user_profiles then personnel, CHAT-104 ordering. Wired into `getSupabaseRepositories()` (the `chat` slot no longer falls through to the mock).
- **Tests:** `src/tests/infrastructure/t-099-supabase-chat-repository.test.ts` — 12/12 (RPC routing + translation, unlinked-personnel error, group insert shape, sendMessage read_by seeding + attachments mapping, markRead append-only contract, soft delete, edit, observeChannels filter/sort, deleted filtering + name resolution). Full desktop suite 66 files / 2177 tests ALL PASS; typecheck clean.

### T-100 — Staff↔parent channel creation entry point (14th session)
- **Problems:** CHAT-103 (the parent-facing half) · **Priority:** P1 · **Severity:** High
- **Status:** TESTED (2026-08-31)
- **What was done:** `openParentChannel(parentId, displayName)` added to the ChatRepository contract (+ mock parity impl): resolves parents.auth_user_id → user_profiles.id, then calls the canonical idempotent RPC (caller resolved server-side). Parent-detail-drawer gained the "Messager" action (MessagesSquare icon) with toasts; clear validation errors when the parent has no portal account yet (activation-code first) or the profile is pending.
- **Tests:** 3 dedicated tests in the t-099 suite (RPC called with the resolved profile id + name; no linked account → clear error, no RPC; unknown parent → not-found). Typecheck clean; full suite green.

### T-101 — Website chat readiness on the completed backend (14th session)
- **Problems:** CHAT-104 (portal half), WEAK-023 note accuracy · **Priority:** P2 · **Severity:** Medium
- **Status:** TESTED (2026-08-31)
- **What was done:** `ChatChannelRow` typed with the 0061 completion columns (no `as unknown as` — WEAK-017 rule); `useChatChannels` hides archived channels and orders by `last_message_at desc nulls last`; ChannelListItem renders the denormalized last-message preview + relative time; the unread-count accuracy note corrected (chat now HAS production writers — the old "no writers" justification is gone; the 500-row lower-bound caveat itself remains true). The read/reply/markRead side was already correct (T-032 + 0051 policy) — verified, not changed.
- **Tests:** `src/test/t-101-portal-chat-readiness.test.ts` 4/4; suite 17 files / 153 tests ALL PASS; lint clean; strict build green.

### T-102 — Android chat scope gap: document + register (14th session)
- **Problems:** ANDR-CHAT-200 (new) · **Priority:** P3 · **Severity:** Medium (scope gap, not a regression)
- **Status:** TESTED (2026-08-31 — documentation task complete; the implementation decision is the follow-up)
- **What was done:** repo-wide search confirmed Android has ZERO chat code (only USE_CHAT/MANAGE_CHAT_CHANNELS permission constants in core/Rbac.kt). Registered ANDR-CHAT-200 + this task: next agent either builds the Android chat screen on the canonical tables (read-side + online sends feasible now; offline queueing depends on ADR-005) or prunes the dead permission codes. ADR-008 records the cross-platform decision. This keeps "fix the chat in all platforms" honest: desktop + website + backend are done and verified; Android chat is a NEW feature request, not a fix.

---

### T-103 — Financial data reconciliation + cross-view read consistency (owner-reported Finance-tab vs dossier divergence)
- **Problems:** DATA-008 (new, the owner report), DATA-001, DATA-002, DATA-003, DATA-004, DATA-009 (new discovery) · **Priority:** P0 (owner-mandated) · **Severity:** Critical
- **Status:** VERIFIED (2026-09-01, 15th session — live 8/8 + desktop 2187/2187)
- **What was done (data layer — migration 0062, applied live atomically with registration, MIG-TOKENS):**
  1. DATA-002 fix: payments-table row `IMP-2a049159…-V2_ALT` corrected 90,000 → 100,000 DZD (ledger + source Excel row 235 both say 100,000; the second import run mis-read the 2V column — same-name row 242 has 2V=90,000).
  2. DATA-003 fix: 54 missing transport charges inserted (34 parents, +2,064,000 — the import wrote transport payments but never the charges); 2 "Dettes antérieures" charges folded into Tranche 1 with traceability notes (METAH NADA 7,000 / DAHMANI FARES 8,000); SIDI MAMER's overstated schedule reduced to the Excel devis net (T3 63,000 → 26,500, −36,500).
  3. DATA-001/004 fix: installments reset and ALL 888 payments replayed through the canonical waterfall (parent + category, chronological, oldest-due-first) → 1,310 payment_allocations; payments.installment_id linked for single-target payments; expected/excess/remark populated on every payment. No parent_credit entries materialized for the 59 historical overpayers (deliberate — see DATA-009).
- **What was done (code layer — desktop read paths):**
  1. `installmentRemaining`/`totalOutstanding` now subtract `amountPending` (INV-4 family; new `sumInstallmentsPending`) — desktop aligned with backend/website/Android.
  2. Finance "Tranches" tab: "Reste" column, collect preset, disabled predicate, due-date modal → all via `installmentRemaining` (inline formula removed).
  3. Student payments tab lineItems → `installmentRemaining`.
  4. Parent profile (Supabase + mock): `totalDue` = charges + adjustments (net), `totalPaid` = all payment entries (both modes identical); dossier renders negative balance as a positive "Crédit parent" card.
  5. `mapPaymentRow` surfaces expected/excess/remark (PaymentBreakdownCard now works live); `PaymentRow` typed for the 0033 columns.
- **Tests:** NEW `src/tests/domain/calc/t-103-finance-consistency.test.ts` 10/10 (INV-4 formula ×3, totalOutstanding ×3, pending-sum helper, hint-field mapping ×2, net-profile derivation).
- **Verification:** full desktop suite **67 files / 2187 tests ALL PASS**; typecheck clean; lint 0 errors; append-only migration guard green (59 files, +1 = 0062); live chain 59/59 (local files == live registrations, JSON-diffed); LIVE reconciliation verification 8/8 via `scripts/verify_t-103.sql` (C1 allocations consistent, C2 payments==ledger, C3 due==charges+adj, C4 no over-applied tranche, C5 debtors remaining==balance, C6 overpayers 0 remaining, C7 expected/excess populated, C8 transport charges present) with 0/258 residual mismatches on every pair; owner's parent spot-check (e3e90f1f: due 337,000 / paid 493,500 / remaining 0 / credit 156,500). Full matrix: `docs/recovery/t-103-live-verification.md`.
- **Left:** DATA-005 (first_name split) remains open under T-085; DATA-009 (parent_credit double-count) registered as T-104 decision task; the reconciliation's dry-run/full-run scripts persisted under `elimtiyaz-desktop/scripts/` + `/home/z/my-project/scripts/`.
- **Commits:** see change-log entry (15th session).

---

### T-011 — Eliminate the silent collect() fallback
- **Problems:** BUSINESS-002 (absorbs BUSINESS-103, CROSS-105) · **Priority:** P1 · **Severity:** Critical
- **Status:** TESTED (2026-08-31, eleventh session)
- **What was done:** `SupabasePaymentRepository.collect()` no longer falls back to `upsert_payment_from_import` on RPC failure — the error propagates as `Err` with the financial state untouched (single atomic path only, ADR-002). The fallback branch and the client-side `PAY-` random payment-number generator (only used by the fallback) were removed; the receipt number comes from the RPC (ADR-004). Success path preserved byte-for-byte.
- **Tests:** NEW `src/tests/infrastructure/t-011-payment-atomicity.test.ts` 2/2 — RPC failure → Err + upsert NEVER called + zero rows; success path returns the fetched mapped payment.
- **Verification:** `npx tsc --noEmit` clean; full desktop suite 57 files / 2091 tests (session-close re-run). Gap: live E2E through the UI needs a desktop host.
- **Commits:** 3da7228 — hub repo.

### T-012 — Make bulkCollect fail-fast
- **Problems:** BUSINESS-100 · **Priority:** P1 · **Severity:** Critical
- **Status:** TESTED (2026-08-31, eleventh session)
- **What was done:** `bulkCollect()` returns `Err` on the FIRST chunk error (naming the failing row range); the `Ok(partial)` return and the catch→per-row-collect retry loop removed. The consumer `RepositoryStorageAdapter.flushPendingBatches` checks the Result and routes an `Err` into its failures list, cancelling the Excel-import transaction (restoring the "no partial data applied in silence" contract).
- **Tests:** NEW `src/tests/infrastructure/t-012-bulkcollect-failfast.test.ts` 4/4 — chunk FK failure → Err "rows 1–N" + zero rows kept; happy path inserts; adapter throws on Err, resolves on Ok.
- **Verification:** typecheck clean; full-suite evidence as above.
- **Commits:** 429a132 — hub repo.

### T-013 — Fix markClearedFallback audit and allocation cascade
- **Problems:** BUSINESS-101, BUSINESS-104 · **Priority:** P1 · **Severity:** High
- **Status:** TESTED (2026-08-31, eleventh session — resolution = removal, per the task's stated preference)
- **What was done:** the 60-line client-side `markClearedFallback()` (no audit entries, actor discarded, per-installment errors swallowed → cascading over-allocation) is DELETED; `markCleared()` throws on RPC error → `Err`, financial state untouched. The canonical `mark_payment_cleared` RPC (migration 0040: FOR UPDATE locks + audit) is the only path.
- **Tests:** NEW `src/tests/infrastructure/t-013-markcleared-atomic.test.ts` 2/2 — RPC failure → Err + no installment rows touched; success path re-fetches.
- **Verification:** typecheck clean; full-suite evidence as above.
- **Commits:** 6a25a40 — hub repo.

### T-014 — Implement the desktop refund flow
- **Problems:** DEAD-015, BUSINESS-003 · **Priority:** P1 · **Severity:** Critical
- **Status:** TESTED (2026-08-31, eleventh session)
- **What was done:** `PaymentRepository.refund(id, reason, actorId, actorName?)` — reason mandatory (≥3 chars per the refund-payment EF contract §7.2); `SupabasePaymentRepository.refund()` validates and propagates the REAL actor + reason to `revert_payment_allocation` (and errors on a missing fetch-after-refund row instead of mapping `{}`); Mock refund mirrors with the canonical double-refund guard (only paid|pending revertible, migration 0041:493-495). `PaymentDetailDrawer` gains "Rembourser ce paiement" (Permission.RefundPayment-gated, destructive ConfirmModal, ≥3-char reason) wired to the signed-in session identity.
- **Tests:** NEW `src/tests/infrastructure/t-014-refund-flow.test.tsx` 10/10 — mock actor+reason in reversal entries + tranche re-opened + double-refund rejected + short reason rejected; supabase real reason+actor reach RPC args; UI gating matrix. `full-payment-flow` integration 18/18.
- **Verification:** typecheck clean; full-suite evidence as above. Gap: live drawer E2E needs a desktop host; EF gateway question stays with UNKNOWN-003/T-067.
- **Commits:** 766db94 — hub repo.

### T-023 — Fix desktop homework and roll-call persistence
- **Problems:** HOMEWORK-100, ATT-100 · **Priority:** P1 · **Severity:** Critical
- **Status:** TESTED (2026-08-31, eleventh session + live schema verification 7/7)
- **What was done:** `SupabaseHomeworkRepository.push()` now carries `tenant_id` (getTenantId()) and the non-existent `push-homework-notification` EF invocation is REMOVED (parent-notification decision deferred to T-036). `SupabaseAttendanceRepository.recordRollCall()` payload carries tenant_id + BOTH `date` and `record_date` (legacy NOT NULL + canonical) and `onConflict` targets the canonical `uq_attendance_canonical` 4-column unique index.
- **Tests:** NEW `src/tests/infrastructure/t-023-academic-persistence.test.ts` 4/4 (payload shape, canonical onConflict target, dead EF gone). Live `scripts/verify_t-023.sql` 7/7 PASS against production (BEGIN…ROLLBACK): fixed payloads insert; old payloads reproduce the NOT NULL violations; duplicate (tenant,student,record_date,session) hits unique_violation.
- **Verification:** typecheck clean; full-suite evidence as above. Gap: desktop→website cross-client E2E needs a desktop host; Android homework UUID defect remains T-024.
- **Commits:** 7883030 — hub repo.

### T-025 — Replace fn_current_tenant_id with the canonical resolver
- **Problems:** DEAD-100 (absorbs TENANT-105), TENANT-106 · **Priority:** P1 · **Severity:** Critical
- **Status:** TESTED (2026-08-31, eleventh session + live verification 6/6; migration 0057 applied live + registered atomically)
- **What was done:** migration `0057_canonical_tenant_resolver.sql` (idempotent): drops the 6 inert `rls_*_tenant` policies (the tables keep their working role-gated policies — no RLS weakening); replaces the dead policy on `student_academic_histories` with `student_academic_histories_staff` (tenant_id = current_tenant_id() AND staff roles — promotion flow can write histories); `set_assessments_tenant()` orphan fallback now RAISES (no DEMO stamping); `fn_current_tenant_id()` dropped (zero references verified across all three repos).
- **Tests:** live `scripts/verify_t-025.sql` 6/6 PASS (JWT emulation via set_config): staff SELECT/INSERT own-tenant histories ok; cross-tenant INSERT rejected; orphan assessment rejected; legit insert ok; dead resolver fully gone.
- **Verification:** applied live + registered in `schema_migrations` in the same atomic transaction (ARCH-011 discipline); post-apply catalog checks clean.
- **Commits:** 1731755 — hub repo.

### T-068 — Fix EF permission resolution
- **Problems:** SEC-109 · **Priority:** P1 · **Severity:** High
- **Status:** VERIFIED (2026-08-31, eleventh session — live deploy + curl matrix + positive/negative permission probes)
- **What was done:** NEW `createUserScopedClient(jwt)` in `_shared/supabase.ts` (anon key + caller's Authorization header — PostgREST derives auth.uid() from it); `extractAuthContext` resolves permissions through it, exercising the same canonical resolver + RLS as the desktop RBAC path. Resolver errors fail CLOSED. `workflow-execute` + `run-overdue-scan` (the two requirePermission consumers) redeployed live.
- **Tests:** live curl matrix: no-auth/invalid/anon → 401 each; CRON_SECRET → auth gate passed. Positive probe: fresh support_staff user with an `execute_workflow` tenant_role_override called workflow-execute → 404 workflow_not_found (requirePermission PASSED; pre-fix this was 403 for every non-super_admin). Negative control: same user without the override → 403. Probe residue fully cleaned (DATA-007 discipline).
- **New problem registered:** BUG-NEW-004 (run-overdue-scan hits WORKER_RESOURCE_LIMIT after the auth gate — the EF's own sizing problem, not a T-068 regression).
- **Commits:** 003d301 — hub repo.

### T-033 — Website freshness fallback
- **Problems:** CACHE-100 · **Priority:** P2 · **Severity:** Medium
- **Status:** TESTED (2026-08-31, eleventh session; T-032 dependency TESTED in the 10th)
- **What was done:** `app/providers/index.tsx` exports `queryClientDefaultOptions` (the single object the QueryClient mounts) with `refetchOnWindowFocus: true` + a conservative 5-minute `refetchInterval`; staleTime 30s and retry:1 preserved. A silent realtime failure now degrades to stale-BOUNDED data instead of stale-forever.
- **Tests:** NEW `src/test/t-033-freshness-fallback.test.tsx` 3/3 — config enables both fallbacks preserving staleTime/retry; mounted QueryClient resolves the same options; behavioral refocus-refetch test.
- **Verification:** website suite 122/122 (119+3); lint clean; strict build green.
- **Commits:** ef205a3 — website repo.

### T-048 — Unify the migration chain
- **Problems:** CROSS-001 (absorbs CROSS-010), CROSS-003 (absorbs CROSS-007, ACAD-104) · **Priority:** P2 · **Severity:** Critical
- **Status:** TESTED (2026-08-31, eleventh session — all three repos)
- **What was done:** the website's 4 drifted portal-patch migrations removed (website commit 4faf007); the Android repo's 6 stale migration copies removed (android commit 1bd0d9d); hub `AGENTS.md` §2/§3 updated: client repos no longer carry migration copies at all, chain extent corrected to 0001–0057 (ADR-001 — the desktop repo owns the only chain). The 2 drifted website Edge Functions remain DELIBERATELY (bind-activation-code waits on UNKNOWN-001/T-028; send-push-notification is T-036 scope).
- **Tests:** website suite 122/122 + strict build green; desktop suite unaffected by the doc-only hub change; live chain diff (session 12 opening) confirms 0001–0057 one-to-one with zero drift.
- **Commits:** 4faf007 (website), 1bd0d9d (android), 707ef1e (hub).

### T-060 — Payment collection UX correctness
- **Problems:** BUSINESS-005, WEAK-005 · **Priority:** P2 · **Severity:** Medium
- **Status:** TESTED (2026-08-31, eleventh session)
- **What was done:** `unified-payment-modal.tsx` — all 3 category-filter sites (slider tranches, allocation preview, focused tranche) use the exact `i.category === category` filter and pass the CONCRETE category to the allocator, mirroring the SQL semantics (`p_category IS NULL OR category = p_category`) for EVERY category — preview ≡ actual collection. Batch-registration step 2 captures "Niveau l'année dernière" + "Rang l'année dernière"; `computeBilling` passes both so `passage_palier` (−10,000 DZD) and `highest_average` (−10%) can actually fire; the mock's `buildRegistrationBilling` reads them index-aligned so persisted billing matches the preview.
- **Tests:** NEW `src/tests/infrastructure/t-060-payment-ux.test.ts` 7/7 — allocator category semantics vs SQL; source-scan guard (divergent ternary gone); 5AP→1AM fires passage_palier; rank-1 fires highest_average; both stack; absent inputs keep zero.
- **Verification:** typecheck clean; full desktop suite 2086 passed / 5 skipped.
- **Commits:** 68c7d30 — hub repo.

### T-095 — (NEW — opened) Fix run-overdue-scan EF resource exhaustion (BUG-NEW-004)
- **Problems:** BUG-NEW-004 · **Priority:** P1 · **Severity:** High (daily cron + manual scan dead in production)
- **Description:** Rewrite the EF's scan body from the N+1 loop (per-parent compute_parent_summary + per-installment dedup SELECT + single-row INSERTs — 258+ round trips) to the batched pattern of the live-verified desktop reference `SupabaseOverdueAlertGenerator` (T-080/T-094): per tenant ONE overdue-installments query, ONE upcoming-due (7-day) query, chunked parents fetch, chunked dedup-key fetch, ONE bulk INSERT, per-tenant audit entry. Also aligns EF semantics with the reference (upcoming-due alerts included; installment-level classification identical to T-094's verified behavior). Redeploy live + curl matrix with a fresh CRON_SECRET (rotation documented) + idempotency re-check.
- **Dependencies:** none · **Affected:** D (functions) · **Platforms:** Backend
- **Tests:** live curl matrix; second run creates 0 duplicate notifications; desktop T-094 suite stays green.
- **Verification:** evidence in change-log + t-XXX-live-verification doc.

### T-015 — Consolidate receipt numbering to the server algorithm — **TESTED (desktop + backend; Android paths left, toolchain-gated)**
- **Problems:** DRIFT-011 (absorbs BUSINESS-006, BUSINESS-105) · **Priority:** P1 · **Severity:** High
- **Status:** TESTED (2026-08-31, twelfth session + live verification 7/7; migration 0058 applied live + registered atomically)
- **What was done:** migration **0058_receipt_number_server_allocation.sql** — (1) `next_receipt_number(p_tenant_id)` canonical generator, algorithm VERBATIM from 0040:69-72; (2) `generate_receipt_numbers(p_tenant_id, p_count)` batch allocator for the importer (advisory-xact-locked against concurrent allocations; SEC-111-pattern caller verification); (3) `upsert_payment_from_import` (0055 body verbatim + the marked T-015 block) generates a canonical number when p_payment_number is NULL/blank. Desktop: `bulkCollect` allocates missing numbers via ONE generate_receipt_numbers RPC call (replacing `PAY-{ts}-{random}`); the sync-queue payment push passes NULL instead of a random `PAY-YYYY-NNNNNN`; `generateReceipt`'s `REC-${paymentId}` display fabrication replaced with an honest "—" placeholder. The mock's sequential REC- generator is the documented demo mirror (not one of DRIFT-011's five paths — preserved).
- **Tests:** NEW `src/tests/infrastructure/t-015-receipt-server-numbers.test.ts` 7/7 — allocator called once with the exact missing count + allocated numbers stamped in order + explicit numbers kept; allocator NOT called when all inputs carry numbers; allocation failure → Err + zero inserts; count mismatch → Err; source-scan guards (no random PAY- generation left in app code; sync push passes NULL; no REC-${paymentId} fabrication). Full desktop suite 58 files / 2098 tests ALL PASS.
- **Live verification:** `scripts/verify_t-015.sql` 7/7 PASS (BEGIN…ROLLBACK, admin-JWT emulation): 0058 registered; next_receipt_number canonical (REC-2026-000001 — the production year sequence starts fresh, no pre-existing REC-2026 numbers); batch allocation contiguous; cross-tenant allocation REJECTED (SEC-111 pattern); NULL-number upsert generates canonical + was_inserted; explicit-number dedup (insert-then-update) preserved; 0034 trigger syncs receipt_number on the generated row.
- **Left:** the two ANDROID client-side generators (LocalPaymentRepository.collect per-device count+1; SyncQueueDispatcher random PAY- fallback) — toolchain-gated (SDK un-downloadable in this container) AND their proper fix is ADR-005's write-through-canonical-RPCs architecture (T-059, BLOCKED on UNKNOWN-002); a local-format patch now would be premature. Documented residual: allocation-vs-insertion race window with concurrent interactive collect() fails LOUD via payments_tenant_id_payment_number_key (documented in the migration header).
- **Discovery recorded:** the unique constraint is on (tenant_id, payment_number) — receipt_number has NO unique constraint (BUSINESS-006's registry claim was wrong); the 0034 trigger syncs receipt_number := payment_number when NULL.

### T-053 — Desktop global-admin support — **TESTED (unit + typecheck; live E2E gap documented)**
- **Problems:** TENANT-103 · **Priority:** P3 · **Severity:** Medium
- **Status:** TESTED (2026-08-31, twelfth session)
- **What was done:** `getTenantId()` returns the session's WORKING tenant or NULL — the DEMO-UUID fallback is gone (reads with no context return empty; the demo tenant is never silently targeted). NEW `requireTenantId()` throws an explicit French error ("Aucun établissement actif…") — wired into every WRITE path the compiler flagged (audit log, expenses, batch-register ledger charges, manual charges, activation codes). Session model: `tenantId: string | null` (working) + `homeTenantId` (profile home; null = global admin); the auth repository stores the honest null instead of `""`. NEW `TenantSwitcher` in the Topbar (rendered exactly for global admins) — lists active tenants via the canonical `tenants` table (0053 RLS lets global admins enumerate) and calls the NEW `auth.switchTenant(id)` (persist + reload = full cache invalidation). The homework-push modal guards uploads with the same explicit message.
- **Tests:** NEW `src/tests/infrastructure/t-053-global-admin-tenant.test.ts` 9/9 — getTenantId null/no-session/working/global-admin (never the demo UUID); requireTenantId French error; source-scan guards (no demo UUID in getTenantId, honest null in the auth repo, switcher wired, switchTenant persists + reloads); a null-tenant repository read never filters by the demo UUID. 7 existing suites updated to set an explicit session (they relied on the removed fallback — the new contract).
- **Verification:** `npx tsc --noEmit` clean; full desktop suite 59 files / 2107 tests (2102 passed + 5 skipped) ALL PASS; lint 0 errors. Gap (TESTED→VERIFIED): live E2E needs a real global-admin account (only the tenant-bound admin@elimtiyaz.dz exists) — sign in as a global admin, pick a tenant, verify data appears.

### T-022 — Desktop sync queue correctness — **TESTED**
- **Problems:** SYNC-100, SYNC-101, SYNC-102, CACHE-102 · **Priority:** P1 · **Severity:** High
- **Status:** TESTED (2026-08-31, twelfth session)
- **What was done:** defaultPushHandler EXTRACTED to `src/infrastructure/sync/default-push-handler.ts` (was module-private + untestable in sync-provider.tsx). **SYNC-100**: 4 new canonical cases — installment → `upsert_installment_from_import` (0037), attendance → `upsert_attendance_from_import` (0041), grade → `upsert_assessment_from_import` (0041), homework → direct `homework` table upsert (ported verbatim from the Android SyncQueueDispatcher — no import RPC exists); the default case now THROWS (entry marked failed, never silently "synced") — all 15 SyncEntityKind values handled or explicitly rejected. **SYNC-101**: the sync_queue audit-trail upsert uses `{ onConflict: "id", ignoreDuplicates: true }` — re-drains no longer reset the row to "pending"/clear last_error. **SYNC-102**: sign-out clears the queue (auth-provider) + the drain skips entries owned by another actor (defense in depth). **CACHE-102**: `isUsingFallback()` on the store + `queueUsingFallback` snapshot field + the SyncIndicator's explicit "PERDUS à la fermeture" warning state.
- **Tests:** NEW `src/tests/infrastructure/t-022-sync-queue-correctness.test.ts` 12/12 — behavioral (fake client via vi.doMock of the supabase-client seam): installment/attendance/grade RPC args; homework upsert payload incl. attachments JSON parsing + validation failure; unsupported kind (expense) rejects AND records mark_sync_queue_processed('failed') not 'synced'; the audit-trail upsert carries ignoreDuplicates; source-scan guards (sign-out clear, drain actor guard, fallback surfacing); behavioral fallback detection with indexedDB hidden.
- **Verification:** `npx tsc --noEmit` clean; full desktop suite 60 files / 2119 tests (2114 + 5 skipped) ALL PASS; lint 0 errors. Gap: live two-instance sync (two desktops + a real Supabase) — the same recorded-gap pattern as the other sync tasks.

### T-040 — Staff-side justification review workflow — **TESTED**
- **Problems:** ATT-101 · **Priority:** P2 · **Severity:** High
- **Status:** TESTED (2026-08-31, twelfth session)
- **What was done:** the 4-state workflow (none → submitted → accepted/rejected, migration 0043) is now a CLOSED loop. Desktop: `AttendanceRecord` gains the 6 justification fields (+ `JustificationStatus` type); `mapAttendanceRow` reads the columns; `AttendanceRepository` gains `observeJustifications(status?)` (tenant-scoped review queue, newest first) + `reviewJustification({recordId, decision, reviewedBy})` (UPDATE status + reviewer + timestamp, guarded `justification_status <> 'none'`; a previous decision may be overturned — documented correction path); both implemented in the Supabase AND Mock repositories (demo parity). NEW "Justificatifs" tab in the Academics hub (ViewAttendance/RollCall-gated, pending-count badge): the submitted queue with student name, date/session, the parent's note + Drive link + attachment indicator, and Accept/Reject actions wired to the signed-in session identity. The website needs NO change — its pill already renders all 4 states (verified); the states become REACHABLE now that staff can decide.
- **Tests:** NEW `src/tests/infrastructure/t-040-justification-review.test.ts` 8/8 — mapAttendanceRow reads the justification columns; the UPDATE carries status+reviewer+timestamp with the `<> 'none'` guard; non-UUID validation; observeJustifications filters tenant+submitted; source-scan guards (tab wired + count, Accept/Reject wired with session identity, domain contract, mock parity).
- **Verification:** `npx tsc --noEmit` clean; full desktop suite 61 files / 2127 tests ALL PASS; lint 0 errors. Gap: live portal→desktop→portal round-trip needs real parent submissions (attendance tables are empty in production — DATA-006 onboarding).

### T-095 — run-overdue-scan EF batched rewrite — **VERIFIED (live)**
- **Problems:** BUG-NEW-004 · **Priority:** P1 · **Severity:** High (daily cron + manual scan dead in production)
- **Status:** VERIFIED (2026-08-31, twelfth session — live deploy + curl matrix + idempotency + zero-duplicate evidence)
- **What was done:** the EF's N+1 scan body (per-parent compute_parent_summary + per-installment dedup SELECT + single-row INSERTs — 258+ round trips, WORKER_RESOURCE_LIMIT) rewritten to the BATCHED pattern of the T-094-verified desktop reference `SupabaseOverdueAlertGenerator`: per tenant ONE overdue query (status ≠ paid/cancelled, due_date < as_of, remaining > 0.001 = INV-4), ONE upcoming-due (7-day) query (the desktop's second pass — EF ≡ desktop now), ONE chunked parents fetch, ONE chunked dedup-key fetch, ONE bulk INSERT, unchanged per-tenant audit. The compute_parent_summary account gate dropped (the verified reference classifies at installment level). Redeployed live (v14).
- **Live verification:** `docs/recovery/t-095-live-verification.md` — curl matrix 401×3 (no-auth / invalid / anon); valid CRON_SECRET (rotated + hash-verified) → **200 in 8.6–10.9 s** (previously WORKER_RESOURCE_LIMIT); 819 overdue / 68.13M DZD / 819 urgent; second run identical with 0 new alerts; notifications count stays 819 across THREE runs (zero duplicates — dedup key ≡ desktop). CRON_SECRET rotation documented safe (no pg_cron schedule uses it).
- **Registered micro-divergence:** the EF excludes `cancelled` installments; the desktop generator filters status ≠ 'paid' only — the EF is stricter/correct; desktop filter alignment is an optional one-line follow-up.
- **Commits:** (this session) — hub repo.

### T-052 — Notification badge correctness — **TESTED**
- **Problems:** NOTIF-102, NOTIF-103 · **Priority:** P3 · **Severity:** Low
- **Status:** TESTED (2026-08-31, twelfth session — desktop + website)
- **What was done:** NOTIF-102 (desktop): the topbar's unreadCount is computed from the FULL visible list — the 8-item slice is a dropdown display limit only (was: count-after-slice, badge capped at 8 with 50 unread). NOTIF-103 (website): NEW `useUnreadNotificationCount` hook (COUNT-only query: `head: true` + `count: "exact"` — zero rows transferred; same direct + parent-broadcast delivery paths as useNotifications); the top-app-bar uses it (no 50-cap); the DEAD unread queries removed from BottomNav AND DesktopRail (they fetched 1 row, computed a boolean no JSX rendered — 3 concurrent notification queries → 1).
- **Tests:** NEW website `src/test/t-052-notification-badge.test.ts` 3/3 — desktop count-before-slice source guard; the COUNT-only hook's shape; the top bar's usage (no length pattern); the dead queries gone. Website suite 126/126 (122+4 incl. re-verification); desktop suite 2127 unaffected.
- **Verification:** desktop tsc clean + suite green; website strict build green + lint clean. Gap: live badge with >50 unread (needs a real parent account with broadcast notifications).

### T-057 — Website canonical port honesty — **TESTED**
- **Problems:** DRIFT-009 (absorbs DEAD-011) · **Priority:** P3 · **Severity:** Medium
- **Status:** TESTED (2026-08-31, twelfth session — website repo commit d7eb52e)
- **What was done:** the canonical port PRUNED to the consumed surface — 15 files deleted (calc/payment/* ×6, calc/pricing/* ×5, calc/ledger/{entries,charges}.ts, model/pricing.ts, the never-imported index.ts barrel); 11 source files kept (balance/overdue/money/dates + account-id [portal-derive.test exercises deriveAccountId — a consumer the audit missed] + the 5 model files + portal-derive). The ledger/payment model re-export blocks trimmed to the kept surface. Every kept header rewritten honestly: verbatim port + desktop source path + sha256 + an explicit never-re-add note — replacing the DEAD-011 lie ("re-run scripts/port-canonical.mjs" — never existed). The alternative (implementing the script) deliberately NOT taken: a full-tree copier would resurrect the dead code.
- **Tests:** NEW website `src/lib/canonical/t-057-port-honesty.test.ts` 4/4 — dead subtrees stay gone; the exact kept-surface inventory; no lying header; honest header shape. Website suite 13 files / 130 tests ALL PASS; strict build green; lint clean.
- **Commits:** d7eb52e — website repo (+ this doc commit — hub).

### T-055 — Audit robustness and PII masking — **TESTED (desktop client + EFs deployed live)**
- **Problems:** SEC-001, SEC-002 · **Priority:** P1 · **Severity:** High
- **Status:** TESTED (2026-08-31, twelfth session; all 8 EFs redeployed live + post-deploy sanity 401/200)
- **What was done:** SEC-002: NEW `hasMaskedContent()` guard — BOTH network LLM transports (edge ai-proxy + BYOK Groq/OpenRouter) REFUSE (Err) when `maskedContent` is empty/whitespace (the old `|| userPrompt` fallback shipped the raw prompt — PII — over the network); the check precedes the configuration check; the local mock keeps working with the raw prompt (it never leaves the machine). SEC-001: `writeAuditLog` RETRIES once (250 ms) then THROWS the NEW typed `AuditWriteError` (loud `[AUDIT-MISS]` marker) — no more silent null returns; NEW `withAuditSurfacing()` wrapper converts the throw into a structured 500 `audit_write_failed` response; ALL 8 EFs that call writeAuditLog are wrapped; run-overdue-scan instead CATCHES per-tenant and counts `audit_failures` in its summary (surfaced, scan survives — notifications already created).
- **Tests:** NEW `src/tests/security/t-055-audit-pii.test.ts` 9/9 — BYOK refuses empty + whitespace masks; edge refuses empty (before any invoke); the default routing degrades to the LOCAL mock with no leak; code-level source-scan (no `maskedContent || userPrompt`); writeAuditLog retry+throw shape; withAuditSurfacing's 500; all 8 EFs wrapped; run-overdue-scan's audit_failures counter. Full desktop suite 62 files / 2136 tests ALL PASS.
- **Live verification:** all 8 EFs redeployed (esbuild bundle checks green); post-deploy sanity on run-overdue-scan: anonymous → 401; valid CRON_SECRET → 200 with the NEW `audit_failures: 0` field present (the audit entry wrote cleanly).
- **Left:** a live forced-audit-failure probe (e.g. revoking the RPC grant temporarily) — deliberately not performed on the production DB.

### T-018 — Enforce deterministic identity codes — **TESTED (desktop + sync portion; PARTIAL)**
- **Problems:** DRIFT-001 (absorbs DEAD-001, DEAD-003, DEAD-005, DEAD-006, PARENT-100) · **Priority:** P1 · **Severity:** High
- **Status:** TESTED (2026-08-31, twelfth session — desktop + sync layer; the backend + Android halves left, see below)
- **What was done:** the canonical generators (stableHash + deterministicParentCode + deterministicStudentCode) MOVED from supabase-shared-repositories.ts to their ADR-003 canonical home `core/format/id.ts` (re-exported for the import-path consumers); the generators' empty-identity fallback is NO LONGER RANDOM — a stable seed (the caller's queue-entry id) keeps RETRIES converging on the same code (a random retry suffix created a DUPLICATE parent/student server-side since the dedup match IS the code). The sync push handler's two random fallbacks (`PAR-YYYY-{random4}`, `ELV-YYYY-{random6}`) replaced with the canonical generators seeded by `entry.id`.
- **Tests:** NEW `src/tests/infrastructure/t-018-identity-codes.test.ts` 7/7 — stability + format; identity-field-order invariance; empty-identity seed stability (retry-stable); whitespace-field exclusion (the cross-platform rule); the canonical home + re-export; no random PAR-/ELV- code lines in the push handler; no Math.random in the generator section. Full desktop suite 63 files / 2143 tests ALL PASS.
- **Left (honest scope):** the backend generators (approve-signup-request EF's parent-code creation; batch_register_family RPC — needs a migration) and the Android create/batch/dispatcher paths (toolchain-gated) remain on DRIFT-001; the mock layer's create() random suffix intentionally preserved (it mirrors the canonical server CREATE path — migration 0022's gen_random_bytes — not the import path's determinism rule).


## Completed (fifth repair session — 2026-08-29)

### T-081 — Restore the Android build at HEAD (re-open the `./gradlew` verification gate)
- **Problems:** ARCH-007 (new — discovered 2026-08-29 while bootstrapping an Android build environment) · **Priority:** P0 · **Severity:** High
- **Status:** TESTED (2026-08-29, fifth repair session)
- **What was done:** four distinct compile errors fixed plus the equivalence-harness path resolution: (1) `ClassesDirectoryViewModel.kt` — constructor param `sessionManager` promoted to `private val` (the `canPromote` getter referenced it); (2) `AppNavHost.kt` — missing `PromotionReviewScreen` import added; (3) `SyncQueueDispatcher.kt` pushGrade — `Double? ?: JsonNull` inferred `Any` (no `put` overload) → values wrapped in `JsonPrimitive` so the elvis branch yields `JsonElement` (JSON null when absent — original intent); (4) `PricingCalculationTest.kt` — `assertEquals(Double?, Double?, Double)` matched no JUnit overload → `explicit!!`/`default!!` non-null assertions. PLUS `AndroidEquivalenceTest.resolve()` now probes the sibling hub checkout (`../AgentGithubUplaod/elimtiyaz-desktop/financial-tests/equivalence/scenarios`) and a standalone desktop sibling — the previous probe list (module dir + repo root only) never matched the real three-repo layout, so the equivalence suite aborted in EVERY documented checkout. `.gitignore` now excludes the generated `app/financial-tests/` runner output. Deviation from the task text: the task named 2 errors; the compiler surfaced 4 (the 3rd/4th only reachable once the first stopped masking them) plus the equivalence-path defect — all are facets of "HEAD does not compile / the gate is broken" and are recorded in ARCH-007.
- **Tests:** `./gradlew :app:compileDebugUnitTestKotlin` BUILD SUCCESSFUL; `./gradlew :app:testDebugUnitTest` BUILD SUCCESSFUL — **202 tests / 0 failures / 0 errors / 0 skipped** (new Android baseline), including the 45-scenario canonical equivalence suite running GREEN for the first time in this repo.
- **Verification:** evidence in change-log (fifth session). The equivalence results JSON files were spot-checked (engine=android, canonical waterfall/allocation outputs).
- **Commits:** e7937de — android repo.

### T-019 — Surface Android sync RPC errors
- **Problems:** CROSS-200 · **Priority:** P1 · **Severity:** Critical
- **Status:** TESTED (2026-08-29, fifth repair session)
- **What was done:** NEW `NetworkTimeouts.guardSyncPush` — the push-oriented counterpart of `guard` that PROPAGATES block exceptions (incl. the SDK's `PostgrestRestException`) and converts `TimeoutCancellationException` into a plain `SyncPushTimeoutException` (RuntimeException, so the drain loop records a retryable failure and coroutine-cancellation semantics stay untouched); `onlyIfConfigured` test seam mirrors `guard`'s existing parameter. All 8 dispatcher push paths (homework, parent, student, payment, ledger_entry, installment, grade, attendance) switched from the swallowing `guard<Unit>` to `guardSyncPush`. `SyncService.drainPending` UNCHANGED — its `catch (Exception)` already implements the desktop `defaultPushHandler` contract (attempts+1 → pending with lastError + backoff; audit + failed at maxAttempts) — it simply never saw failures before. ROOT CAUSE CORRECTED (recorded in the problem entry): supabase-kt 3.1.1 DOES throw `PostgrestRestException` on 4xx/5xx (verified in the pinned artifact's bytecode: `SupabaseApi.rawRequest` checks `!status.isSuccess() && parseErrorResponse != null`; Postgrest wires `parseErrorResponse`); the real swallowing layer was `guard`'s `catch (Throwable) → null`, not a missing SDK throw. The registry's original description ("the SDK returns an HttpResponse and doesn't throw") does not hold for the pinned version.
- **Tests:** NEW `SyncErrorSurfacingTest` (5 tests): guardSyncPush success/propagation/timeout contracts + source-scan pins (no `NetworkTimeouts.guard` left in the dispatcher; all 8 pushes on guardSyncPush; no catch-Throwable inside guardSyncPush).
- **Verification:** `./gradlew :app:testDebugUnitTest` — **207 tests / 0 failures** (202 baseline + 5 new); equivalence suite green. GAP (why TESTED, not VERIFIED): a live 400/500 round-trip against a deployed `upsert_*_from_import` RPC needs a real Supabase project (same recorded-gap pattern as T-004's curl matrix).
- **Commits:** (T-019 commit) — android repo.
- **NEW DISCOVERY registered:** `.env.example` placeholder values (`https://YOUR_PROJECT.supabase.co`, `your-anon-key-here`) PASS `NetworkTimeouts.isSupabaseConfigured` (the hyphen-based checks miss `YOUR_PROJECT`'s underscore and `your-anon-key-here` ≠ `your-anon-key`) — a unit-test build therefore reports "configured". Recorded as a note on SEC-005/T-064.

### T-049 — Website build hygiene
- **Problems:** ARCH-005, DEAD-013 (plus WEAK-017's homework-table registration) · **Priority:** P2 · **Severity:** Medium
- **Status:** TESTED (2026-08-29, fifth repair session)
- **What was done:** `next.config.ts` — `ignoreBuildErrors: false`, `reactStrictMode: true`; `tsconfig.json` excludes `supabase/` (Deno EFs, 9 false positives); `package.json` icons:generate path repo-relative (DEAD-013). All 86 surfaced errors fixed: (1) **the deep one** — postgrest-js 2.x `GenericTable`/`GenericView` require `Relationships` on every table/view AND an index-signature-compatible `Row`; all 38 row shapes were `interface`s (no implicit index signatures), so `Database['public']` never satisfied `GenericSchema`, `Schema` resolved to `never`, and EVERY typed supabase query degraded to never payloads — fixed by converting the 38 interfaces to type aliases (matching what `supabase gen types` emits) and adding `Relationships: []` to the 34 tables + 4 views; (2) canonical `homework` table registered in the Tables map (WEAK-017's registration half — it was queried but untyped, and two REAL masked bugs fell out: `tone="muted"` not in KpiCard's Tone union, and `primary_phone` nullable-send at a NOT NULL column); (3) `StudentDocumentRow` nullability aligned with 0005_crm.sql; (4) `SubjectRow` extended with 0029's `passing_grade`/`is_extracurricular`; (5) 45 earlier duplicate keys removed from dictionary.ts (last-occurrence-wins runtime semantics preserved); (6) pricing barrel (`calc/pricing/index.ts`) ported verbatim from the desktop (charges.ts imported a non-existent module); (7) individual fixes: financial-view tone `muted`→`default`, academic-view term-filter state typed as the string union Radix actually delivers, messages-view dead `channel_type === "convocation"` comparison removed (canonical check constraint forbids the value; name-based detection kept) + `supabase` captured locally for closure narrowing, parent-contact-edit-card NOT NULL `primary_phone` no longer falls back to null, bulletin null-safe grade rendering, use-realtime channel ref typed `RealtimeChannel`, portal-derive imports/casts, portal-derive.test unknown-wire-code cast.
- **Tests:** gate-level: `npx tsc --noEmit` → 0 errors in src/ (was 86 project-wide); `npm run build` → green WITH "Running TypeScript" — the first strict build in the repo's history; `npm run test` → 90/90; `npm run lint` → unchanged baseline (exactly the 2 pre-existing preserve-manual-memoization errors in dashboard-view.tsx + financial-view.tsx, verified identical at HEAD via git stash).
- **Verification:** evidence in change-log (fifth session). Runtime behaviour preserved everywhere (dedupe keeps last-wins; tone/convocation/primary_phone changes remove only provably-dead or provably-invalid paths).
- **Commits:** (T-049 commit) — website repo.

---

## Completed (sixth repair session — 2026-08-29)

### T-002 — Close Android authentication bypasses
- **Problems:** SEC-101, SEC-102, WEAK-101 (plus CROSS-100's Android half) · **Priority:** P0 · **Severity:** Critical
- **Status:** TESTED (2026-08-29, sixth repair session)
- **What was done:** (1) **SEC-101** — `signIn` is FAIL-CLOSED: a configured build + failed/empty sign-in returns `Result.Err` (the LoginViewModel already renders it); no session is ever minted from a failure. The demo fallback now exists ONLY via `AuthEnvironment.isDemoFallbackAllowed()` = unconfigured AND debug build; release without configuration fails closed. (2) **SEC-102** — ALL email-substring role inference deleted (signIn Stage 1 + Stage 2 + refreshSession's direct SUPER_ADMIN fallback); roles resolve EXCLUSIVELY from `role_assignments` via the canonical `current_user_roles()` RPC (migration 0003) through the pure `resolveRoleFromAssignments()` — first recognisable code wins, empty/unrecognisable → least-privilege SUPPORT_STAFF (mirrors the desktop reference client). (3) **WEAK-101** — `signIn`/`refreshSession` restore the SDK's REAL `UserSession` (`currentSessionOrNull()`); `Session.accessToken` = the real JWT, `refreshToken` + `expiresAt` (epoch-ms) from the SDK session; the pure `buildServerSession()` assembles it and never expands unknown roles to "all permissions" (empty-set fallback). The demo sandbox role is the FIXED `DEMO_SANDBOX_ROLE` (documented; its token is not a JWT and authenticates nowhere). (4) **CROSS-100 Android half** — the login screen's 9 demo-account chips + `fillDemoAccount()` removed (roles no longer derive from emails; the shared demo password never worked against a configured server; the sandbox works with any typed credentials).
- **Tests:** NEW `LocalAuthRepositoryTest` — 12 tests: fail-closed on configured-build failure (drives the real provider under Robolectric — every outcome is Err, no session); no demo session on unconfigured release; demo sandbox FIXED role with NO email inference ("finance.admin@" / "teacher@" sign-ins no longer yield FINANCIAL_OFFICER/TEACHER); role-resolution matrix (empty → support_staff; first-valid wins; legacy aliases; unrecognisable never escalates); buildServerSession real-JWT passthrough + no-assignments → support_staff defaults only (no MANAGE_SETTINGS/MANAGE_TENANTS/MANAGE_PERSONNEL); AuthEnvironment policy matrix; source-level guard against re-introducing email inference (T-001 technique).
- **Verification:** `./gradlew :app:testDebugUnitTest` BUILD SUCCESSFUL — **219 tests / 0 failures** (207 baseline + 12 new); `./gradlew :app:compileDebugKotlin` and `./gradlew :app:assembleDebug` green. GAP (why TESTED, not VERIFIED): live sign-in matrix (real wrong-password 401, role_assignments-backed session, server-side JWT validation) needs a live Supabase — same recorded-gap pattern as T-004/T-079. NEW DISCOVERY registered during verification: **ARCH-008** — `./gradlew :app:lintDebug` has never been green (315 pre-existing NewApi errors, no lint baseline ever existed) → T-082.
- **Commits:** 1aa34a7 (auth rework + tests), 89eec61 (CROSS-100 demo chips) — android repo.

### T-065 — Website copy and comment accuracy
- **Problems:** WEAK-023, DRIFT-010 · **Priority:** P3 · **Severity:** Medium/Low
- **Status:** TESTED (2026-08-29, sixth repair session)
- **What was done:** both defects were source comments that contradicted the code under them. (1) WEAK-023 — `useUnreadChatCount`'s comment claimed "the latest 200 messages per channel" while the query fetches the latest 500 `chat_messages` rows TOTAL with no channel filter; the comment now states the true semantics (500 rows total via RLS-exposed channels; the count is a LOWER BOUND beyond that window) and records that exact counting (channel-scoped fetch or server-side counter) is deliberately deferred to T-032's chat rework while chat has no production writers (CHAT-103 / UNKNOWN-005) — the query itself is unchanged by design. (2) DRIFT-010 — the attendance-view header said "The portal CANNOT submit justifications — that's a desktop workflow" while the view imports, renders and wires AbsenceJustificationDialog; the header now states the portal both DISPLAYS the 4-state justification status AND SUBMITS (storage upload + `attendance_records` update). (3) Same accuracy class, recorded during the task: the website repo's own AGENTS.md still claimed mock-auth was wired (removed in T-009) and the build ignored type errors (fixed in T-049) — synced to reality.
- **Tests:** NEW `src/lib/hooks/comment-accuracy.test.ts` (2 tests) — source-scan guards pinning the stale phrases out, the corrected notes in, and the dialog wiring the corrected comment describes kept present (T-001/T-002 technique; both tests fail against the pre-fix sources by construction).
- **Verification:** `npm run test` → 92/92 (90 baseline + 2 new); `npm run build` → compiled successfully WITH TypeScript running (strict); `npm run lint` → exactly the 2 documented pre-existing `react-hooks/preserve-manual-memoization` errors, none added. Runtime behaviour byte-identical (comments + new test file only, plus the AGENTS.md doc sync).
- **Commits:** 5654074 — website repo.

---

## Ready

### T-104 — parent_credit balance semantics decision (ADR) — **Completed (TESTED, 17th session — ADR-010 Accepted + implemented + pinned; the Ready listing was stale, corrected by T-156, 25th session)**
- **Problems:** DATA-009 (new — discovered by T-103, live-verified empirically) · **Priority:** P2 · **Severity:** Medium (design decision; no current data corruption)
- **Status:** TESTED (2026-09-01, 17th session) — ADR-010 (option b: keep the canonical writer, standardize the display-level derivation `displayParentCredit`) implemented on desktop (dossier card) AND website (`displayCredit` port), pinned by `t-104-display-credit.test.ts` (desktop 8 tests + website 6). The 25th session (T-157) wired ADR-010's last noted residual — the unified-payment-modal debt-meter's dormant `unallocatedCredit` prop — through the same derivation, +2 more guards.
- ~~Description: the canonical writer `collect_and_allocate_payment` books the FULL payment entry (−amount) AND a parent_credit adjustment (−unallocated) on overpayment... Decide + write an ADR~~ → DECIDED: **ADR-010, docs/decisions/ADR-010-parent-credit-display-convention.md** (read it for the derivation, the population table, and the consequences).
- ~~Dependencies: none (ADR-002 context; do not implement without the ADR)~~ → none remain.
- ~~Verification: ADR written + whichever convention chosen is equivalence-tested across desktop/SQL/Android/website.~~ → ADR-010 written; desktop + website suites pin the derivation; the canonical writer is untouched so the equivalence suites stayed green.
- **Task T-156 correction note (2026-09-04, 25th session):** this entry sat in "Ready" across three session closeouts (23rd/24th summaries kept listing it) although ADR-010 shipped it in the 17th session. LESSON: a session completing a task whose entry lives in a section header (Ready/Blocked) must REMOVE the entry from that section in the same session — a status note inside the entry is not enough.

---

### T-105 — Excel-corpus cross-platform equivalence + full financial reconciliation to the source workbook (owner-mandated)
- **Problems:** DATA-010 (new), DATA-011 (new), DATA-008 (extension → corpus-level closure), DATA-003 (classification correction), DATA-009 (impact re-scope) · **Priority:** P0 (owner-mandated: "fully test this problem against all the other platforms using the real Excel spreadsheet sample … and make sure there is equivalence in the calculations across all 3 platforms in all the users in the spreadsheet and it is synced when someone does it in the supabase db") · **Severity:** Critical
- **Status:** VERIFIED (2026-09-01, 16th session — live 259/259 × 6 + ops 14/14 + three-platform 259/259 each)
- **What was done (discovery — the workbook as oracle):**
  1. Extracted the FULL corpus of the real workbook (`Suivis clients  2026_2027.xlsx`, sheet ETAT 20262027, rows 2-391 = 390 students / 247 phone-grouped parents / 259 DB parents) with an independent Python reference calculator; proved the workbook is internally consistent: P = Σ payment columns 390/390, Q = L − P 390/390, and **L is already NET of remise** (raw formulas read: `=25000+205000+35000-J2`, `=300000-J235`).
  2. Live three-way diagnostic (Excel ↔ payments ↔ ledger ↔ installments, name+phone join): M1 paid 258/259 (one missing family), netdue matched only 61/258 — 223 parents matched the DOUBLE-REMISE hypothesis (DATA-010, Σ −9,709,700 DZD), ~35 matched neither (schedule-vs-devis residuals); identified row 242 as never imported (DATA-011).
- **What was done (data layer — migration 0063_excel_corpus_alignment.sql, applied live atomically with registration, MIG-TOKENS):**
  1. STEP 1 — compensating +|J| adjustments for every imported "Remise sur devis" −J entry (append-only, idempotent source_ids) → kills the double discount.
  2. STEP 2 — creates the missing row-242 family (parent 0554288142, student, 3 tranches 102,000/76,500/76,500, devis charge 255,000 NET, 3 payments 255,000, audit entry) exactly per the workbook.
  3. STEP 3 — per-student alignment: target = devis + dettes (− remboursement); ledger adjustment ±delta + installment absorption via the last-tranche rule (0062 precedent) with negative-delta cascade + status recompute.
  4. STEP 4 — full waterfall replay (DELETE allocations → reset → replay all payments) so payment_allocations / expected / excess / installment links match the new totals.
  5. Idempotency (double-run dry-run verified identical) + fresh-deployment no-op guards + audit summary marker.
- **What was done (code layer — desktop importer, so a re-import cannot reintroduce the bugs):**
  1. `repository-adapter.ts buildFinancialEntries` — NO ledger entry for the remise (the devis charge from L is already net; comment cites the formula evidence).
  2. `buildInstallmentRows` — NEW C3 reconciliation: Σ tranches due ← devis + dettes − remboursement (last-tranche absorption, cascade, status recompute; immutable Installment rebuilt by index).
  3. NEW regression suite `src/tests/integration/t-105-import-shape.test.ts` (real-workbook import): 5/5.
- **Cross-platform equivalence (the owner's core ask):**
  1. Generated 259 canonical `computeParentSummary` scenarios from the POST-0063 live corpus (real ledger entries + tranches per parent) into `financial-tests/equivalence/scenarios/t105_*.json`, with `then` = the live `compute_parent_summary` SQL RPC values (the backend leg).
  2. Desktop TS runner: **259/259 == backend**; Android Kotlin runner (gradle, JDK 21 + SDK 35 installed in-session): **259/259 == backend** (304/304 scenarios incl. the original 45; the only ✗ is the pinned zero-payment all-engine error case); website port (portal-derive): NEW `src/test/t-105-corpus-equivalence.test.ts` — **262/262** (259 parents + aggregate + INV-4); triple comparator: **304/304 equivalent, 0 discrepant**.
- **Live write-path sync test (`scripts/verify_t-105-ops.sql`, rolled back):** OP-A payment (cash 20,000) → payment+ledger+waterfall+summary ±20,000 exactly, I1 payments==ledger, I3 due==charges+adj; OP-B registration (`batch_register_family` + FI Tranche-1 payment 25,000) → clean zero state, allocated=25,000 on T1, I1/I3 hold; OP-C pending check → amount_pending (INV-4), remaining non-negative; OP-D revert → refunded payment excluded, I1 holds with reversed-originals-excluded. **14/14 TRUE.**
- **Verification:** `scripts/verify_t-105.sql` live — M1 paid 259/259, M2 netdue 259/259, M3 balance 259/259, C3 259/259, C4 259/259, C5 259/259 (before 0063: 61/258 on M2/M3); `verify_t-103.sql` re-run 8/8 still TRUE; chain 60/60 (0001-0063, JSON-diffed zero drift); desktop suite 69 files / 2192 tests ALL PASS + typecheck clean + lint 0 errors; website 18 files / 415 tests + lint clean + build green; spot checks: ZIREG LEA (devis 239,500 = paid, créance 0 — was fake −25,500 credit), MAMER A (463,500 due / 493,500 paid / −30,000 credit per the workbook's own Q), MAMER B (255,000/255,000/0). Full matrix: `docs/recovery/t-105-live-verification.md`.
- **Left:** T-104 (DATA-009 ADR — now affects only NEW overpayments); the corpus scenarios are pinned fixtures — regenerate if the corpus changes materially; Android needs a local JDK+SDK to run the suite in this container (installed under /home/z/my-project/bin — NOT part of the repo).
- **Commits:** see change-log entry (16th session).

---

### Phase 0 — Security hotfixes (P0)

> T-001, T-009 and T-010 were completed by the 2026-08-29 batch session (see Completed above; evidence in change-log.md).

#### T-002 — Close Android authentication bypasses
- **Problems:** SEC-101, SEC-102, WEAK-101 · **Priority:** P0 · **Severity:** Critical
- **Description:** (1) Remove the Stage-2 offline fallback that grants a 24h session on ANY failed/empty Supabase login — fail closed (or restrict to debug builds with unconfigured Supabase only). (2) Delete email-substring role inference; resolve roles only from `role_assignments` with least-privilege fallback. (3) Store the real Supabase JWT in `Session.accessToken`, not the user UUID.
- **Dependencies:** none · **Affected:** A · **Platforms:** Android
- **Tests:** wrong password → failure (no session); signed-in user without role assignments → no staff UI; token validates server-side.
- **Verification:** all three behaviours covered by new unit tests; manual sign-in matrix documented in change-log.
- **ADRs:** —

#### T-004 — Require authentication on the four cron Edge Functions
- **Problems:** SEC-105 · **Priority:** P0 · **Severity:** High
- **Description:** `expire-pending-approvals`, `refresh-materialized-views`, `purge-expired-backups`, `run-overdue-scan` must verify a `CRON_SECRET` bearer token (or Supabase cron signature) before executing; deny anonymous requests.
- **Dependencies:** none (requires setting the secret in Supabase — deployment note) · **Affected:** D (functions) · **Platforms:** Backend
- **Tests:** anonymous POST → 401 for each EF; valid-secret POST executes.
- **Verification:** curl matrix recorded in change-log; secrets rotated post-merge.
- **ADRs:** —

#### T-005 — Scope the RBAC role resolver and admin RLS policies to tenants
- **Problems:** TENANT-100, TENANT-101 (absorbs TENANT-102) · **Priority:** P0 · **Severity:** Critical
- **Description:** New migration (0044+): filter `current_user_roles()`/`current_user_permissions()` by the caller's tenant; add tenant constraints to `user_profiles_admin_update` and the `tenants_*` policies (global admins = `tenant_id IS NULL` only).
- **Dependencies:** none (UNKNOWN-006 affects priority, not correctness) · **Affected:** D (migrations) · **Platforms:** Backend
- **Tests:** regression test with two tenants: tenant-A super_admin holds no roles in tenant B's context and cannot update tenant-B users or enumerate tenants.
- **Verification:** two-tenant test green; existing single-tenant flows unaffected.
- **ADRs:** —

#### T-006 — Verify callers and tenants in SECURITY DEFINER RPCs
- **Problems:** SEC-110 (absorbs STUDENT-101, PARENT-103), SEC-106, SEC-112, SEC-111 · **Priority:** P0 · **Severity:** High/Critical
- **Description:** New migration: (1) `bind_activation_code` asserts `p_auth_user_id = auth.uid()`, guards silent re-binding, writes an audit entry; (2) `register_fcm_token` asserts `p_user_id = auth.uid()`; (3) `revert_payment_allocation` verifies the payment's tenant matches the caller's; (4) `upsert_payment_from_import` either drops SECURITY DEFINER or validates `p_tenant_id` against the caller.
- **Dependencies:** coordinate with ADR-002 (no behavioural change to the canonical algorithms) · **Affected:** D (migrations) · **Platforms:** Backend
- **Tests:** direct RPC calls with foreign user/tenant ids fail; legitimate flows still pass; audit entries appear.
- **Verification:** SQL-level tests on a fresh schema; no client regression.
- **ADRs:** ADR-002

#### T-007 — Stop handle_new_auth_user from trusting signup metadata
- **Problems:** SEC-108 · **Priority:** P0 · **Severity:** High
- **Description:** New migration: derive `tenant_id` from a trusted source (invitation/default) instead of `raw_app_meta_data`; hardcode `requested_role = 'parent'` for the self-signup path; ignore client-supplied staff roles.
- **Dependencies:** none · **Affected:** D (migrations) · **Platforms:** Backend
- **Tests:** signup with injected `tenant_id`/`requested_role` lands in the default tenant as parent-pending.
- **Verification:** trigger-level regression test.
- **ADRs:** —

#### T-008 — Constrain role assignment in approve-signup-request
- **Problems:** SEC-107, PARENT-102 · **Priority:** P0 · **Severity:** High
- **Description:** `assign_role` restricted to a safe subset (`parent`) for `support_staff`; staff roles require super_admin; validate that approve actions carry either `target_parent_id` or `create_new_parent=true` (no "active but unbound" users).
- **Dependencies:** none · **Affected:** D (functions) · **Platforms:** Backend
- **Tests:** support_staff→super_admin attempt returns 403; approval without target returns 400.
- **Verification:** EF test matrix in change-log.
- **ADRs:** —

#### T-071 — Tighten RLS INSERT policies for chat and notifications
- **Problems:** CHAT-100, CHAT-101, NOTIF-101 · **Priority:** P0 · **Severity:** Medium/High
- **Description:** New migration: `chat_channels_insert` requires creator ∈ member_ids and role-gates `announcement`; `chat_messages_insert` requires channel membership; `notifications_insert` requires staff role or self-targeting.
- **Dependencies:** none (independent of the chat product decision) · **Affected:** D (migrations) · **Platforms:** Backend
- **Tests:** policy-level tests: parent cannot create channels for arbitrary members, cannot post into non-member channels, cannot address notifications to other users.
- **Verification:** tests green; existing official flows unaffected.
- **ADRs:** —

#### T-080 — Port the desktop overdue-scan to Supabase (kill the mock leak in Supabase mode)
- **Problems:** ARCH-006 (new — discovered during T-004, 2026-08-29) · **Priority:** P2 · **Severity:** Medium
- **Description:** In Supabase mode the `overdueAlerts` slot stays on `MockOverdueAlertGenerator` (the Supabase assembly spreads `mockRepositories` and never overrides `overdueAlerts`), so the "Scan retards" button scans in-memory seed data and persists nothing server-side; the guarded `run-overdue-scan` EF (T-004) has no live desktop caller. Implement `SupabaseOverdueAlertGenerator` (canonical `compute_parent_summary` drill-down mirroring the EF logic) OR an EF-invocation wrapper using the signed-in user's JWT (manual path, `view_financials`), override the slot in the Supabase assembly, and regression-test both assemblies' contracts.
- **Dependencies:** none (backend path already secured by T-004) · **Affected:** D · **Platforms:** Desktop
- **Tests:** mock vs supabase assembly contract tests; seeded Supabase ledger → scan creates real notifications (integration needs a live backend for VERIFIED).
- **Verification:** regression tests + change-log evidence.
- **ADRs:** —

#### T-082 — Restore the Android lint gate (baseline or fix the NewApi backlog) — **Completed (TESTED, 18th session)**
- **Problems:** ARCH-008 (new — discovered during T-002, 2026-08-29) · **Priority:** P1 · **Severity:** High
- **Description:** `./gradlew :app:lintDebug` aborts with 315 pre-existing errors / 112 warnings (dominant class: `NewApi` — java.time.* with minSdk 24 and no core-library desugaring; worst files LocalRepositories2.kt 216, DatabaseSeeder.kt 64, LocalRepositories.kt 60, LedgerEngine.kt 36, libs.versions.toml 120 via a different check). Follow the T-078 desktop precedent: (1) decide the desugaring question — enabling core-library desugaring genuinely fixes the NewApi class and is the correct long-term fix; (2) whichever path is chosen, create `app/lint-baseline.xml` pinning the remaining backlog to exact per-rule counts, documented in the build config like T-078 did; (3) fix any NEW findings the baseline surfaces (none should be suppressed silently).
- **Dependencies:** none · **Affected:** A · **Platforms:** Android
- **Tests:** `./gradlew :app:lintDebug` green with the baseline (or zero errors after desugaring); per-rule counts documented; the existing 219-test suite stays green.
- **Verification:** evidence in change-log.
- **ADRs:** —
- **Result (2026-09-01, 18th session):** the desugaring question DECIDED — core-library desugaring enabled (desugar_jdk_libs 2.1.5): lint's own "or core library desugaring" annotation on all 313 API-26 findings confirmed it as the root fix (NewApi 337 → 0). The 2 SuspiciousIndentation errors fixed IN CODE (LocalRepositories.kt parent-credit + reversal paths re-indented). `app/lint-baseline.xml` committed pinning the 117 pre-existing WARNING findings (GradleDependency 90, UnusedResources 8, …) with abortOnError=true — any NEW finding fails the gate; the backlog shrinks by editing the baseline, never widening it. lintDebug GREEN (was 339 errors / 115 warnings abort); full suite 38/331/0 (desugaring re-verified runtime); assembleDebug green (APK 30.7 MB, +0.9 MB desugar runtime). Android commit 01d679f. ARCH-012 (release-variant screenshot test) remains separate/open.

### Phase 1 — Financial integrity (P1)

#### T-011 — Eliminate the silent collect() fallback
- **Problems:** BUSINESS-002 (absorbs BUSINESS-103, CROSS-105) · **Priority:** P1 · **Severity:** Critical
- **Description:** Remove the `upsert_payment_from_import` fallback in `SupabasePaymentRepository.collect()`; RPC failure surfaces an error and writes nothing. Single atomic path only.
- **Dependencies:** none · **Affected:** D · **Platforms:** Desktop, Backend
- **Tests:** simulated RPC failure → user-visible error, zero rows written, no success toast; success path unchanged (ledger+waterfall+audit present).
- **Verification:** regression tests + reconciliation run on a seeded ledger shows no `PAYMENT_WITHOUT_LEDGER_ENTRY` after failures.
- **ADRs:** ADR-002

#### T-012 — Make bulkCollect fail-fast
- **Problems:** BUSINESS-100 · **Priority:** P1 · **Severity:** Critical
- **Description:** `bulkCollect` collects chunk errors, aborts, and reports failing rows so the Excel import transaction rolls back completely (matching its own "no partial data applied" guarantee).
- **Dependencies:** none · **Affected:** D · **Platforms:** Desktop
- **Tests:** import containing one invalid payment → full rollback + row reported.
- **Verification:** test green; importer UI shows the failing row.
- **ADRs:** —

#### T-013 — Fix markClearedFallback audit and allocation cascade
- **Problems:** BUSINESS-101, BUSINESS-104 · **Priority:** P1 · **Severity:** High
- **Description:** The fallback writes the same audit entries as the canonical RPC (or is removed entirely — prefer removal if T-011 pattern applies), and aborts on the first installment error instead of cascading over-allocation.
- **Dependencies:** none · **Affected:** D · **Platforms:** Desktop
- **Tests:** clearance on pre-0039 deployment leaves audit entries; simulated installment failure aborts the whole clearance.
- **Verification:** tests green.
- **ADRs:** —

#### T-014 — Implement the desktop refund flow
- **Problems:** DEAD-015, BUSINESS-003 · **Priority:** P1 · **Severity:** Critical
- **Description:** Add a Refund action to `payment-detail-drawer.tsx` gated on `Permission.RefundPayment`, mandatory reason (≥3 chars) modal; `SupabasePaymentRepository.refund()` propagates the real actor identity and reason to `revert_payment_allocation`.
- **Dependencies:** none · **Affected:** D · **Platforms:** Desktop
- **Tests:** refund produces `payment.refund` audit entry with actor+reason; balances/installments revert; double-refund blocked.
- **Verification:** E2E-style integration test on seeded data.
- **ADRs:** ADR-002

#### T-015 — Consolidate receipt numbering to the server algorithm
- **Problems:** DRIFT-011 (absorbs BUSINESS-006, BUSINESS-105) · **Priority:** P1 · **Severity:** High
- **Description:** Remove the four client-side numbering paths (desktop fallback, bulkCollect, Android local, Android dispatcher fallback); every receipt number comes from the canonical RPC (ADR-004). Import paths obtain numbers server-side.
- **Dependencies:** T-011 (fallback removal) for the desktop side · **Affected:** D, A · **Platforms:** Desktop, Android, Backend
- **Tests:** concurrent collections produce consecutive unique `REC-YYYY-NNNNNN`; grep shows no client-side receipt formatting.
- **Verification:** concurrency test + grep evidence.
- **ADRs:** ADR-004

#### T-016 — Complete the reconciler (6 of 6 cross-checks)
- **Problems:** BUSINESS-001 · **Priority:** P1 · **Severity:** Critical
- **Description:** Wire `crossCheckBalanceSum` and `crossCheckParentCredit` into `reconcileFinancials()` (INV-9).
- **Dependencies:** none · **Affected:** D · **Platforms:** Desktop
- **Tests:** seeded ledgers with balance-sum mismatch and unbacked parent credit both produce violations.
- **Verification:** unit tests + equivalence run.
- **ADRs:** —

#### T-017 — Make Android refunds correct and idempotent
- **Problems:** BUSINESS-102, CROSS-102, CROSS-103 · **Priority:** P1 · **Severity:** High
- **Description:** Add the already-refunded guard; include the refund reason in the sync payload; enqueue installment state changes so the server converges (or route through `revert_payment_allocation` per ADR-005 once accepted — interim fix acceptable).
- **Dependencies:** T-019 (error surfacing must exist to trust sync outcomes) · **Affected:** A · **Platforms:** Android, Backend
- **Tests:** double-refund rejected; server audit contains reason; server installments match post-refund state.
- **Verification:** integration test against a fresh schema.
- **ADRs:** ADR-002, ADR-005

#### T-018 — Enforce deterministic identity codes everywhere
- **Problems:** DRIFT-001 (absorbs DEAD-001, DEAD-003, DEAD-005, DEAD-006, PARENT-100) · **Priority:** P1 · **Severity:** High
- **Description:** Replace all random/sequential generators with the canonical deterministic functions (mock repo, approve EF, `batch_register_family`, Android create/batch, dispatcher fallbacks); delete dead random exports.
- **Dependencies:** none · **Affected:** D, A, DB · **Platforms:** All
- **Tests:** identity tests per location; re-import/re-push creates no duplicates.
- **Verification:** cross-platform parent-code equivalence case green; grep clean.
- **ADRs:** ADR-003

### Phase 2 — Sync & data propagation (P1)

#### T-019 — Surface Android sync RPC errors
- **Problems:** CROSS-200 · **Priority:** P1 · **Severity:** Critical
- **Description:** Every `SyncQueueDispatcher.push*` reads the HTTP response and throws on 4xx/5xx; entries stay pending with `lastError`; SyncService marks them failed for retry (desktop contract).
- **Dependencies:** none · **Affected:** A · **Platforms:** Android
- **Tests:** server 400 → entry pending with error; success → synced.
- **Verification:** dispatcher unit tests with mocked 400/500 responses.
- **ADRs:** —

#### T-020 — Re-queue transient server errors on Android
- **Problems:** SYNC-103 · **Priority:** P1 · **Severity:** High
- **Description:** `SyncSupport.tryThenEnqueue` enqueues on 5xx (transient) in addition to network/offline/timeout; permanent errors (4xx validation, 401) still fail fast.
- **Dependencies:** T-019 · **Affected:** A · **Platforms:** Android
- **Tests:** 500 during deployment → mutation queued and retried successfully.
- **Verification:** test green.
- **ADRs:** —

#### T-021 — Honest Android sync completion semantics
- **Problems:** SYNC-106, SYNC-107 · **Priority:** P1 · **Severity:** Medium
- **Description:** `SyncWorker` returns `Result.retry()` on transient failure / `Result.failure()` on permanent; `SyncService.syncNow` becomes suspend and awaits the drain; UI reflects real completion.
- **Dependencies:** T-019 · **Affected:** A · **Platforms:** Android
- **Tests:** WorkManager retry path exercised; syncNow does not report success before completion.
- **Verification:** instrumented test.
- **ADRs:** —

#### T-022 — Desktop sync queue correctness
- **Problems:** SYNC-100, SYNC-101, SYNC-102, CACHE-102 · **Priority:** P1 · **Severity:** High
- **Description:** `defaultPushHandler` handles (or explicitly rejects) all 15 entity kinds — no silent no-ops; `sync_queue` rows accumulate attempt history instead of being overwritten; the queue is cleared/scoped per user on logout; the IndexedDB→memory fallback is surfaced to the UI.
- **Dependencies:** none · **Affected:** D · **Platforms:** Desktop
- **Tests:** each entity kind either pushes or errors visibly; two-user logout/login scenario; fallback-mode banner test.
- **Verification:** unit + integration tests.
- **ADRs:** —

#### T-023 — Fix desktop homework and roll-call persistence
- **Problems:** HOMEWORK-100, ATT-100 · **Priority:** P1 · **Severity:** Critical
- **Description:** Homework INSERT includes `tenant_id` (or the table gains a safe tenant trigger); roll-call upsert includes tenant_id + legacy `date` + matches a real unique index for `onConflict`; remove/replace the invocation of the non-existent `push-homework-notification` EF.
- **Dependencies:** none · **Affected:** D · **Platforms:** Desktop, Backend
- **Tests:** homework push persists and appears in the website's `useHomeworkForClass`; roll call persists and appears in `useAttendanceForStudent`.
- **Verification:** cross-client integration test.
- **ADRs:** —

#### T-024 — Fix Android homework id and promotion propagation — **Completed (TESTED, 18th session)**
- **Problems:** HOMEWORK-101, STUDENT-100 · **Priority:** P1 · **Severity:** Critical
- **Description:** Android homework entities use real UUIDs (drop the `hwk-` prefix before upsert); promotion sync propagates `grade_level_code` (extend the RPC or use the direct update path).
- **Dependencies:** T-025 for the promotion server path · **Affected:** A · **Platforms:** Android, Backend
- **Tests:** homework push persists; promoted student's server-side grade advances and survives a pull sync.
- **Verification:** integration tests.
- **ADRs:** —
- **Result (2026-09-01, 18th session):** homework entities now created with a bare UUID; dispatcher strips the legacy `hwk-` prefix defensively (queued legacy rows reach the server on the same server id — idempotent). `pushStudent` sends `p_grade_level_code` (the RPC has had the param since 0037 — audit text corrected; verified live via pg_get_functiondef). HomeworkPromotionT024Test 6/6; full Android suite 35 files / 304 / 0 failures; live `scripts/verify_t-024.sql` 5/5 (H1 bare-UUID insert ok, H2 `hwk-` still rejected, S1–S3 grade propagation + pull roundtrip — rolled back, no data mutated). Android commit 7bd43e1.

#### T-025 — Replace fn_current_tenant_id with the canonical resolver
- **Problems:** DEAD-100 (absorbs TENANT-105), TENANT-106 · **Priority:** P1 · **Severity:** Critical
- **Description:** New migration: rewrite the 0029-era policies and `set_assessments_tenant` trigger to use `current_tenant_id()`; drop `fn_current_tenant_id()`; `student_academic_histories` becomes accessible to tenant staff.
- **Dependencies:** none · **Affected:** D (migrations) · **Platforms:** Backend
- **Tests:** staff can select/upsert `student_academic_histories` for their tenant; cross-tenant denied; orphan assessment inserts FAIL (no DEMO fallback).
- **Verification:** migration-level tests on a fresh schema.
- **ADRs:** —

#### T-026 — ~~Align the overdue rule on Android~~ *(moved to Completed — 13th session)*
- **Problems:** DRIFT-006, WEAK-007, BUSINESS-007 · **Priority:** P1 · **Severity:** Critical (WEAK-007 user-facing)
- **Description:** Android `computeParentSummary` uses the 0.001 DZD threshold + the due-date map (built via `buildOverdueDueDateMap` at every call site); `maxDaysOverdueFromLedger` measures from due dates, not creation dates.
- **Dependencies:** none · **Affected:** A · **Platforms:** Android
- **Tests:** seeded overdue ledger → non-zero "Créances en Retard" KPI; days-overdue matches desktop for the same ledger.
- **Verification:** equivalence case for overdue added and green.
- **ADRs:** ADR-002

#### T-027 — Canonical attendance rate everywhere
- **Problems:** WEAK-019 (absorbs ATT-102, GRADE-101) · **Priority:** P1 · **Severity:** Medium
- **Description:** Use `calculateAttendanceRate` ((present+late)/total) in website attendance-view, desktop narrative-generator-modal, and the bulletin "Présences" KPI (or relabel as raw counts).
- **Dependencies:** none · **Affected:** D, W · **Platforms:** Desktop, Website
- **Tests:** a student with 18 present + 2 late shows 100% in every view.
- **Verification:** cross-view consistency test.
- **ADRs:** —

### Phase 3 — Account flows, realtime & website correctness (P2)

#### T-028 — Consolidate the bind-activation-code Edge Function — **BLOCKED**
- **Problems:** CROSS-009 (absorbs BUSINESS-008, SEC-104), CROSS-004 · **Priority:** P1 · **Severity:** Critical
- **Description:** Keep exactly one EF (the desktop's shared-helper version), move the decided activation semantics into it (or into the SQL RPC), delete the website's standalone copy; one body-key contract for all clients.
- **Dependencies:** **BLOCKED by UNKNOWN-001** (does binding activate the user?) · **Affected:** D, W, DB · **Platforms:** All
- **Tests:** bind from desktop/Android/website produces identical server state + one audit entry.
- **Verification:** cross-client integration test.
- **ADRs:** —

#### T-029 — Guard approve_account_request re-binding
- **Problems:** PARENT-101 · **Priority:** P1 · **Severity:** High
- **Description:** The rebind block rejects parents already bound to a different user (or explicitly invalidates + audits the previous binding); `before_json` captures the old `auth_user_id`.
- **Dependencies:** none · **Affected:** D (migrations) · **Platforms:** Backend
- **Tests:** rebind attempt rejected or audited with old/new binding.
- **Verification:** SQL-level test.
- **ADRs:** —

#### T-031 — Add the role gate to the parent self-update trigger
- **Problems:** SEC-008 · **Priority:** P1 · **Severity:** Critical
- **Description:** New migration: `enforce_parent_self_update_columns` fires its restriction only for `has_role('parent')` callers, so staff updates to parent identity fields work again.
- **Dependencies:** none · **Affected:** D (migrations) · **Platforms:** Backend, Desktop
- **Tests:** staff rename succeeds; parent self-update of `first_name` still raises.
- **Verification:** trigger tests; desktop parent-edit modal E2E.
- **ADRs:** —

#### T-032 — Repair the website realtime layer
- **Problems:** WEAK-016 (absorbs HOMEWORK-102), REALTIME-100, REALTIME-101 (absorbs CHAT-102), REALTIME-102, REALTIME-103 · **Priority:** P2 · **Severity:** High
- **Description:** Subscribe `useHomeworkRealtime` to canonical `homework` with `class_id`; fix the unread invalidation key to `["chat-unread-count"]`; add an RLS policy/RPC letting recipients append `read_by`; notifications subscription covers role-broadcasts (or a documented fallback poll); unread badge reacts to all channels.
- **Dependencies:** NOTIF-100 read-state model (UNKNOWN-007) affects the notifications filter portion — the homework/chat/read-receipt fixes are unblocked · **Affected:** W, D (RLS migration) · **Platforms:** Website, Backend
- **Tests:** insert into `homework` → portal refreshes; markRead persists; badge drops; role-broadcast appears without reload.
- **Verification:** live integration tests.
- **ADRs:** —

#### T-033 — Website freshness fallback
- **Problems:** CACHE-100 · **Priority:** P2 · **Severity:** Medium
- **Description:** Re-enable `refetchOnWindowFocus` (and/or a conservative refetchInterval) so a broken realtime hook degrades to stale-bounded data instead of stale-forever.
- **Dependencies:** T-032 · **Affected:** W · **Platforms:** Website
- **Tests:** with realtime disabled, data refreshes on focus.
- **Verification:** manual + hook test.
- **ADRs:** —

#### T-034 — Desktop cache refresh strategy
- **Problems:** CROSS-104 (absorbs CACHE-103), CROSS-104b · **Priority:** P2 · **Severity:** High
- **Description:** Supabase-backed desktop repositories gain realtime subscriptions (or an explicit refresh action + TTL) so cross-client writes are visible without restart; define the sync_queue audit-trail semantics shared with Android.
- **Dependencies:** design choice realtime-vs-poll documented in the task's change-log entry · **Affected:** D · **Platforms:** Desktop
- **Tests:** second client's write appears in an open desktop within the freshness budget.
- **Verification:** two-instance integration test.
- **ADRs:** —

#### T-035 — Website financial KPI correctness
- **Problems:** WEAK-018, WEAK-022 · **Priority:** P2 · **Severity:** Medium
- **Description:** Dashboard "next installment" uses `installmentRemainingAmount` (delete the dead import vs inline formula divergence); ledger fetch paginates beyond 500 entries so balance replay is complete.
- **Dependencies:** none · **Affected:** W · **Platforms:** Website
- **Tests:** parent with 600 ledger entries sees the correct balance; KPI matches financial-view.
- **Verification:** unit tests with generated ledger.
- **ADRs:** —

#### T-039 — Android pull-sync completeness — **Completed (TESTED, 18th session)**
- **Problems:** HOMEWORK-103, NOTIF-105 · **Priority:** P2 · **Severity:** High
- **Description:** `pullAll` also pulls homework/attendance/assessments; notification pull filters by current user/role and evicts stale rows; batch upsert instead of per-row loop.
- **Dependencies:** T-023/T-024 (server must actually hold academic rows) · **Affected:** A · **Platforms:** Android
- **Tests:** desktop-created homework/attendance appears on Android within one sync cycle; role-changed user sees no stale broadcasts.
- **Verification:** cross-device integration test.
- **ADRs:** —
- **Result (2026-09-01, 18th session):** pullAll pulls homework (0029) + attendance_records/assessments (0041) with canonical mappers; every pull path batch-upserts; pulled homework rows delete their legacy `hwk-` local twins (T-024 interplay). pullNotifications mirrors the 0019 `notifications_select` RLS branch-for-branch: roles re-resolved FRESH via `current_user_roles()` (multi-role users keep every held role's broadcasts — the Session models only one role), staff trio sees NULL/NULL tenant broadcasts; `evictNotVisibleTo` applies the same predicate to the Room cache (Room v13: notifications.targetRole). PullCompletenessT039Test 16/16 (mappers, eviction matrix on real SQLite, RLS-mirror scans); Android suite 38/331/0. Cross-device live round-trip (the registry's verification bar) still needs two live devices. Android commit dd2988d.

#### T-040 — Staff-side justification review workflow
- **Problems:** ATT-101 · **Priority:** P2 · **Severity:** High
- **Description:** Desktop attendance review lists `justification_status='submitted'` records with accept/reject actions writing the reviewer + timestamp; the website 4-state pill becomes fully reachable.
- **Dependencies:** T-023 (roll call must persist first) · **Affected:** D, W · **Platforms:** Desktop, Website
- **Tests:** parent submits → staff accepts → parent sees accepted.
- **Verification:** E2E flow test.
- **ADRs:** —

### Phase 4 — Feature pipelines & cleanup (P2/P3)

#### T-036 — Rebuild the push notification pipeline — **partially blocked** *(PUSH-103 portion COMPLETED 2026-08-31, 13th session — see the Completed section; PUSH-100/101/104 remain)*
- **Problems:** PUSH-100 (absorbs WEAK-014, WEAK-015), PUSH-101, PUSH-103, PUSH-104 · **Priority:** P2 · **Severity:** Critical (feature dead)
- **Description:** Fix the EF internals (correct `user_id` column; PEM parsing via a proper library or correct BEGIN/END handling); wire one real invocation path (workflow `push_notification` action, notifications trigger, or staff action); Android reads `notification` payload fields + adds deep-link intent filter; website auto-registers FCM after first user gesture; decide email provider integration for workflow `send_email` (currently a stub).
- **Dependencies:** T-030 (token lifecycle) for the registration side; provider decision for send_email is a scoping question, not an unknown · **Affected:** D, A, W, DB · **Platforms:** All
- **Tests:** staff action → push arrives on a registered Android device + browser; workflow email sends or is explicitly disabled.
- **Verification:** live device test recorded.
- **ADRs:** —

#### T-037 — Decide and implement the chat feature — **BLOCKED**
- **Problems:** CHAT-103 (absorbs CHAT-105), CHAT-104 · **Priority:** P2 · **Severity:** High
- **Description:** Decide product scope (UNKNOWN-005). If built: channel-creation paths (staff↔parent, announcements), desktop Supabase chat repository (replacing the mock), `chat_channels.updated_at` touch trigger on message insert. If not built: remove the website MessagesView and the mock chat panel.
- **Dependencies:** **BLOCKED by UNKNOWN-005** · **Affected:** D, W, DB · **Platforms:** All
- **Tests:** per scope decision.
- **Verification:** per scope decision.
- **ADRs:** —

#### T-038 — Per-recipient notification read state — **BLOCKED**
- **Problems:** NOTIF-100, NOTIF-104 · **Priority:** P2 · **Severity:** Medium
- **Description:** Introduce `notification_reads` (or equivalent) so role-broadcasts are per-recipient read/dismissible; Android read-state syncs to the server.
- **Dependencies:** **BLOCKED by UNKNOWN-007** (read-state model), Android push scope (UNKNOWN-002) · **Affected:** D, A, W, DB · **Platforms:** All
- **Tests:** broadcast marked read per user; badge drops.
- **Verification:** cross-platform test.
- **ADRs:** —

#### T-042 — Timetable: complete or remove — **BLOCKED**
- **Problems:** SCHED-100, SCHED-101 · **Priority:** P3 · **Severity:** Medium
- **Description:** Decide (UNKNOWN-011): build the `timetable_entries` migration + Supabase repository + room-aware conflict detection, or remove the mock implementation and the coverage KPI.
- **Dependencies:** **BLOCKED by UNKNOWN-011** · **Affected:** D · **Platforms:** Desktop
- **Tests:** per decision.
- **Verification:** per decision.
- **ADRs:** —

#### T-043 — Consolidate the equivalence test frameworks — **Completed (TESTED 2026-09-03, 23rd session — see T-143; ADR-006 Implemented)**
- **Problems:** DUP-001 (absorbs DEAD-004, CROSS-002, CROSS-008), DUP-002 · **Priority:** P2 · **Severity:** High
- **Description:** Per ADR-006: single framework (`financial-tests/equivalence/`), port unique scenarios, delete the other three trees and the stale `_tier4` mirror, document Android corpus access.
- **Dependencies:** none · **Affected:** D, A · **Platforms:** Desktop, Android
- **Tests:** consolidated suite green; unique-scenario coverage report shows nothing lost.
- **Verification:** `npm test` + `./gradlew test` (Android runner) green.
- **ADRs:** ADR-006
- **Execution record:** 4 scoped passes — see the T-143 entry (2026-09-03). Desktop 79/2271 after each pass; the unique-scenario coverage report is in the T-143 entry + change-log.

#### T-044 — Consolidate the Android design system — **IN PROGRESS (passes 1–2 COMPLETE 2026-09-03, 23rd session — see T-144; 29 of 37 screens remain)**
- **Problems:** DUP-003, DUP-004 (absorbs WEAK-013) · **Priority:** P3 · **Severity:** High (maintenance)
- **Description:** Migrate the 37 legacy-importing screens to `ui.designsystem.*`; delete the legacy components/theme; migrate the screenshot test to the production theme.
- **Dependencies:** none · **Affected:** A · **Platforms:** Android
- **Tests:** screenshot test against the production theme; zero `import com.example.ui.components` remaining.
- **Verification:** grep + tests green.
- **ADRs:** —
- **Execution record:** pass 1 removed the legacy theme family (DUP-004 CLOSED + WEAK-013); pass 2 migrated the settings module (8 files). Next passes: extend the design system with a SCROLLABLE tab-row component (the 6-tab FinancialsHub prerequisite), then migrate feature-by-feature using the settings module as the reference pattern; the bottom-nav route-model rewrite is the last step. Final pass deletes the legacy `ui/components/` tree.

#### T-045 — Consolidate the Android Room layers — **BLOCKED**
- **Problems:** DUP-005 (absorbs DRIFT-008) · **Priority:** P2 · **Severity:** High
- **Description:** Merge the legacy cache-entity layer and the source-of-truth layer into one, with one KDoc truth statement; delete the other DAO/mapper pair.
- **Dependencies:** **BLOCKED by UNKNOWN-002 / ADR-005** (which layer survives depends on the target write architecture) · **Affected:** A · **Platforms:** Android
- **Tests:** no orphaned DAOs; all repositories compile against the surviving layer.
- **Verification:** build + full test suite.
- **ADRs:** ADR-005

#### T-046 — Android database migration discipline
- **Problems:** ARCH-004, REG-002 · **Priority:** P2 · **Severity:** High
- **Description:** Remove `fallbackToDestructiveMigration(true)` from the release build; every schema bump ships an explicit migration (schema-export review in the task's commit).
- **Dependencies:** T-045 recommended first (fewer entity layers to migrate) · **Affected:** A · **Platforms:** Android
- **Tests:** schema bump without migration fails the build/test; upgrade path v11→v12 preserves data.
- **Verification:** migration test with Room's MigrationTestHelper.
- **ADRs:** —

#### T-047 — Scope and complete the desktop Supabase repository migration — **In Progress (scoping delivered — owner decision reduced to 3 tabs + 1 ADR)**
- **Problems:** ARCH-001 · **Priority:** P2 · **Severity:** Critical
- **Description:** Inventory the 26 mock-backed repository slots; classify each as (a) port to Supabase (used in production flows), (b) label as demo-only in the UI, or (c) remove. Port the (a) set module by module (chat handled by T-037).
- **2026-09-04 (25th session) — agent-side scoping DELIVERED:** see `docs/architecture/t-047-repository-migration-scoping.md`. Fresh code-verified inventory: 23 slots remain mock-backed (not 26 — T-080/T-093/T-099 closed three). KEY: the canonical chain already has tables for 19 of the 23 → those need only adapter work, no schema; port order recommended: calendar (website reads `calendar_events` while desktop writes mock) → workflows/workflowRuns (Android pull-syncs `workflow_runs`) → tasks/workforceAttendance/leaveRequests → pricing → rest. Product decision now scoped to exactly: clubs/psychology/orthophonie (no table — port/demote/remove?) + teachers (modeling ADR: personnel-role view vs table).
- **Dependencies:** owner input ONLY for the 3 therapy/club tabs + teachers ADR; the 19 adapter ports can start without it · **Affected:** D · **Platforms:** Desktop
- **Tests:** per ported module: persistence across restart + equivalence where financial.
- **Verification:** per module; statuses tracked here.
- **ADRs:** — (teachers port will need one)

#### T-048 — Unify the migration chain
- **Problems:** CROSS-001 (absorbs CROSS-010), CROSS-003 (absorbs CROSS-007, ACAD-104) · **Priority:** P2 · **Severity:** Critical
- **Description:** Per ADR-001: remove the website's 0025–0028 files and the Android's six stale copies (content already canonical in the desktop chain); leave a pointer note (non-markdown or in AGENTS.md) in each repo.
- **Dependencies:** confirm no CI/deployment references the removed files · **Affected:** D, A, W · **Platforms:** All
- **Tests:** fresh-DB provisioning from the desktop chain alone passes the equivalence suites.
- **Verification:** provisioning test.
- **ADRs:** ADR-001

#### T-049 — Website build hygiene
- **Problems:** ARCH-005, DEAD-012, DEAD-013 · **Priority:** P2 · **Severity:** Medium
- **Description:** Set `typescript.ignoreBuildErrors: false` and fix resulting errors; enable `reactStrictMode` and fix surfaced issues; create the missing `src/test/setup.ts`; fix the `icons:generate` path to `./scripts/…`.
- **Dependencies:** none · **Affected:** W · **Platforms:** Website
- **Tests:** `next build` + `npm run test` green with checks enabled.
- **Verification:** CI run.
- **ADRs:** —

#### T-050 — ~~Android connectivity & pull efficiency~~ *(moved to Completed — 13th session)*
- **Problems:** WEAK-009, SEC-006, CACHE-101, WEAK-010 · **Priority:** P2 · **Severity:** High
- **Description:** `OnlineDetector.isOnline()` incorporates probe results (fail closed on probe failure); probe targets the configured Supabase URL (not supabase.com/Google); single deduplicated `pullAll` trigger per cycle.
- **Dependencies:** none · **Affected:** A, D (desktop OnlineDetector probe target) · **Platforms:** Android, Desktop
- **Tests:** airplane mode → offline; flaky network → probe-informed state; pullAll fires once per tick.
- **Verification:** unit tests + battery/network sanity note.
- **ADRs:** —

#### T-051 — Android tenant stamping and audit identity
- **Problems:** WEAK-011 (absorbs TENANT-104), WEAK-012 · **Priority:** P1 · **Severity:** High
- **Description:** All local writes stamp the session's real tenant (no DEMO UUID); the audit helper captures actor role; the pull fallback selects include the tenant filter.
- **Dependencies:** none · **Affected:** A · **Platforms:** Android
- **Tests:** created rows carry the signed-in tenant; audit entries carry actor + role; fallback query is tenant-filtered.
- **Verification:** unit tests with a second tenant configured.
- **ADRs:** —

#### T-052 — Notification badge correctness (desktop + website)
- **Problems:** NOTIF-102, NOTIF-103 · **Priority:** P3 · **Severity:** Low
- **Description:** Desktop badge counts unread before the 8-item slice; website removes the dead bottom-nav query and un-caps the top-bar count (or uses a COUNT query).
- **Dependencies:** none · **Affected:** D, W · **Platforms:** Desktop, Website
- **Tests:** 50 unread → badge shows 50 (or "50+").
- **Verification:** unit tests.
- **ADRs:** —

#### T-053 — Desktop global-admin support
- **Problems:** TENANT-103 · **Priority:** P3 · **Severity:** Medium
- **Description:** `getTenantId()` stops falling back to the DEMO UUID: pre-login queries are suppressed; global admins get a tenant switcher or an explicit empty state.
- **Dependencies:** T-005 · **Affected:** D · **Platforms:** Desktop
- **Tests:** global admin sees an explicit state, not demo-tenant RLS denials.
- **Verification:** unit test.
- **ADRs:** —

#### T-054 — ~~Android hollow implementations~~ *(moved to Completed — 13th session)*
- **Problems:** WEAK-006, WEAK-008 · **Priority:** P2 · **Severity:** Critical (WEAK-006 user-facing lie)
- **Description:** `regenerateForCycle` actually re-derives due dates (mirror the desktop implementation); `WorkflowRunEntity` gains a trigger column + mapping (no hardcoded "manual").
- **Dependencies:** none · **Affected:** A · **Platforms:** Android
- **Tests:** regenerate changes installment dates; trigger labels match desktop for the same run.
- **Verification:** unit tests.
- **ADRs:** —

#### T-055 — Audit robustness and PII masking
- **Problems:** SEC-001, SEC-002 · **Priority:** P1 · **Severity:** High
- **Description:** EF `writeAuditLog` failures are surfaced (retry/throw per canonical §7.6 policy); LLM adapter uses masked content only — empty `maskedContent` blocks the BYOK path instead of sending raw prompts.
- **Dependencies:** none · **Affected:** D · **Platforms:** Desktop, Backend
- **Tests:** audit-write failure is observable; raw-PII prompt never reaches the BYOK adapter.
- **Verification:** unit tests + one live EF check.
- **ADRs:** —

#### T-056 — Desktop low-risk hygiene batch
- **Problems:** WEAK-003, WEAK-004, DEAD-002, DRIFT-005, WEAK-020, DEAD-014 · **Priority:** P3 · **Severity:** Low
- **Description:** One commit per item: `mapLedgerRow` no longer falls back to `actor_id`; ledger seed uses tranche due dates (remove `void dueDate`); wire or delete `handleDelete` in update-server-secret; add `server_secret.*` to `AuditActions`; `paymentStatusTone` handles `cancelled`/`pending_clearance`; remove the unused database-schema barrel (website).
- **Dependencies:** none · **Affected:** D, W · **Platforms:** Desktop, Website
- **Tests:** per-item unit tests.
- **Verification:** typecheck + tests green.
- **ADRs:** —

#### T-057 — Website canonical port honesty
- **Problems:** DRIFT-009 (absorbs DEAD-011), WEAK-017 · **Priority:** P3 · **Severity:** Medium
- **Description:** Prune unused ported calc files (keep the ~6 consumed functions) or implement the promised `port-canonical.mjs`; register the canonical `homework` table in the typed `Database` interface and remove the legacy `homework_assignments` typing.
- **Dependencies:** none · **Affected:** W · **Platforms:** Website
- **Tests:** typecheck green without `as unknown as` casts on homework queries.
- **Verification:** build + tests.
- **ADRs:** ADR-002

#### T-058 — ~~Adopt append-only migration discipline~~ *(moved to Completed — 13th session)*
- **Problems:** REG-001 · **Priority:** P2 · **Severity:** High (process)
- **Description:** Process change (already encoded in AGENTS.md + recovery rules): schema changes are new migrations only; each migration's header documents what it changes and why; a review checklist item verifies no applied migration is edited (git diff on `supabase/migrations/` shows additions only).
- **Dependencies:** none · **Affected:** D · **Platforms:** Backend
- **Tests:** CI check: `git diff --name-only` against main shows no modifications under `supabase/migrations/` for PRs.
- **Verification:** check in place.
- **ADRs:** ADR-001

#### T-059 — Migrate Android writes to canonical RPCs — **BLOCKED**
- **Problems:** ARCH-003, CROSS-005 (absorbs CROSS-006) · **Priority:** P1 · **Severity:** Critical
- **Description:** Implement ADR-005 in phases: online path → canonical RPCs; offline queue replays the same RPCs; retire `upsert_*_from_import` from Android financial writes; consolidate Room layers (T-045 folds in).
- **Dependencies:** **BLOCKED by UNKNOWN-002** (owner confirmation of ADR-005); then T-019/T-020/T-021 first · **Affected:** A, D (RPC contract) · **Platforms:** Android, Backend
- **Tests:** equivalence suites: Android-collected payment ≡ desktop-collected payment (ledger/waterfall/audit/receipt parity); offline replay parity.
- **Verification:** phased equivalence runs recorded in change-log.
- **ADRs:** ADR-005

#### T-060 — Payment collection UX correctness
- **Problems:** BUSINESS-005, WEAK-005 · **Priority:** P2 · **Severity:** Medium
- **Description:** `UnifiedPaymentModal` preview and actual collection use the same category semantics (null = all categories); batch registration captures `previousGradeLevel`/`previousRank` so all 5 discount rules can evaluate.
- **Dependencies:** none · **Affected:** D · **Platforms:** Desktop
- **Tests:** preview ≡ actual allocation for every category choice; `passage_palier`/`highest_average` discounts appear when inputs qualify.
- **Verification:** unit tests.
- **ADRs:** —

#### T-061 — Scope the payment-proof trigger to INSERT
- **Problems:** WEAK-200 · **Priority:** P3 · **Severity:** Medium
- **Description:** `enforce_payment_proof` re-validates only when `method` changes (or proof fields are being set), so status-only updates (refunds, clearances) of legacy rows cannot fail.
- **Dependencies:** none · **Affected:** D (migrations) · **Platforms:** Backend
- **Tests:** status-only update of a NULL-proof legacy row succeeds; method change without proof still rejected.
- **Verification:** trigger test.
- **ADRs:** —

#### T-062 — ~~Android dead-code removal~~ *(moved to Completed — 13th session)*
- **Problems:** DEAD-007, DEAD-008, DEAD-009, DRIFT-007 · **Priority:** P3 · **Severity:** Low
- **Description:** Remove `StubRepositories.kt`; either register `ElGalleryActivity` in the manifest (dev-only) or delete the gallery; correct the misleading `SupabaseModule` KDoc; trim unused `AuditActions` constants (keep wire-protocol comment pointing to the desktop registry).
- **Dependencies:** reachability check per recovery rules · **Affected:** A · **Platforms:** Android
- **Tests:** build + tests green; APK size note.
- **Verification:** grep clean.
- **ADRs:** —

#### T-063 — ~~Android absence-alert threshold~~ *(moved to Completed — 13th session)*
- **Problems:** ATT-103 · **Priority:** P3 · **Severity:** Low
- **Description:** `alertAbsences` adopts the desktop rule (≥3 absences, current term).
- **Dependencies:** none · **Affected:** A · **Platforms:** Android
- **Tests:** threshold behaviour matches desktop for same input.
- **Verification:** unit test.
- **ADRs:** —

#### T-064 — ~~Android config dialog security~~ *(moved to Completed — 13th session)*
- **Problems:** SEC-004, SEC-005 · **Priority:** P2 · **Severity:** Medium
- **Description:** Anon key masked (`PasswordVisualTransformation`); remove the "Google AI Studio" toolchain mention; unconfigured Supabase fails closed instead of hitting `demo.supabase.co`.
- **Dependencies:** none · **Affected:** A · **Platforms:** Android
- **Tests:** unconfigured app performs zero network calls to Supabase endpoints.
- **Verification:** unit test.
- **ADRs:** —

#### T-065 — Website copy and comment accuracy
- **Problems:** WEAK-023, DRIFT-010 · **Priority:** P3 · **Severity:** Low
- **Description:** Fix the unread-chat comment/query mismatch (channel-scoped fetch or corrected comment); update the attendance-view header comment to match reality (the portal DOES submit justifications).
- **Dependencies:** none · **Affected:** W · **Platforms:** Website
- **Tests:** n/a (comment/query accuracy) — code change for WEAK-023 covered by test.
- **Verification:** review.
- **ADRs:** —

#### T-066 — Decide the server-side receipt storage model — **BLOCKED**
- **Problems:** CROSS-101 · **Priority:** P2 · **Severity:** Critical (website feature dead)
- **Description:** Decide (UNKNOWN-004): persist receipt PDFs to Storage + `receipts` rows (restore website download), or remove the orphaned table + website Receipts tab (client-side PDF generation only).
- **Dependencies:** **BLOCKED by UNKNOWN-004** · **Affected:** D, W, DB · **Platforms:** All
- **Tests:** per decision.
- **Verification:** per decision.
- **ADRs:** —

#### T-067 — Decide the payment Edge Functions' role — **BLOCKED**
- **Problems:** DEAD-016 (absorbs WEAK-001, WEAK-002, DRIFT-002, DRIFT-004) · **Priority:** P1 · **Severity:** Critical
- **Description:** Decide (UNKNOWN-003): (a) make `collect-payment`/`refund-payment` the canonical gateway — wire clients, fix the absorbed latent defects (cancelled-payment guard, structured check/transfer fields, honest headers, category default); or (b) delete them and document direct-RPC as the contract (RLS+triggers carry the invariants).
- **Dependencies:** **BLOCKED by UNKNOWN-003**; interacts with ADR-005 (Android path) · **Affected:** D, A, W · **Platforms:** All
- **Tests:** per decision.
- **Verification:** per decision.
- **ADRs:** ADR-002

#### T-068 — Fix EF permission resolution
- **Problems:** SEC-109 · **Priority:** P1 · **Severity:** High
- **Description:** `extractAuthContext` resolves permissions with a caller-scoped client (or a direct query with the user's JWT) so `requirePermission` works for non-super_admin users of `workflow-execute`/`run-overdue-scan`.
- **Dependencies:** none · **Affected:** D (functions) · **Platforms:** Backend
- **Tests:** user with granted permission (not super_admin) can invoke; user without cannot.
- **Verification:** EF integration test.
- **ADRs:** —

#### T-069 — Android realtime subscriptions
- **Problems:** REALTIME-104 · **Priority:** P2 · **Severity:** High
- **Description:** Subscribe Android to realtime channels for payments/installments/notifications/chat_messages (mirroring the website's hooks) so freshness is push-based; 15-min pullAll becomes the fallback.
- **Dependencies:** T-050 (online state correctness) recommended first · **Affected:** A · **Platforms:** Android
- **Tests:** server-side write appears in the Android UI within seconds.
- **Verification:** instrumented test.
- **ADRs:** —

#### T-070 — Decide the multi-guardian model — **BLOCKED**
- **Problems:** DEAD-200 · **Priority:** P3 · **Severity:** Medium
- **Description:** Decide (UNKNOWN-010): implement `parent_student_links` (second parent portal access, custody, sibling-discount correctness) or drop the table.
- **Dependencies:** **BLOCKED by UNKNOWN-010** · **Affected:** DB · **Platforms:** Backend
- **Tests:** per decision.
- **Verification:** per decision.
- **ADRs:** —

#### T-072 — Harden activation codes — **BLOCKED**
- **Problems:** WEAK-100 · **Priority:** P1 · **Severity:** Medium
- **Description:** After UNKNOWN-008: generate codes with `gen_random_bytes()`/longer formats and rate-limit the binding endpoint (per-account + per-IP).
- **Dependencies:** **BLOCKED by UNKNOWN-008** (format/UX decision) · **Affected:** D (migrations), W · **Platforms:** Backend, Website
- **Tests:** brute-force simulation blocked by rate limit.
- **Verification:** security test.
- **ADRs:** ADR-003 (determinism scope)

#### T-079 — Admin-created user accounts (feature — owner request, 2026-08-29) — **Completed (TESTED client stack / IMPLEMENTED backend)**
- **Problems:** — (feature gap, not a registered defect; recorded per AGENTS.md §13) · **Priority:** P1 · **Severity:** —
- **Description:** Owner request: "Implement the functionality in the desktop app that allows an admin to create accounts for other users so they can log in with their own accounts." Today a login account can ONLY originate from a web self-signup (migration 0002 trigger + ApprovalsTab approval); an admin cannot provision accounts directly (e.g. a new staff member). Plan: new SQL RPC `admin_create_user_account` (migration 0044 — atomically activates the trigger-created profile, assigns the chosen role, resolves the auto-created approval request; EXECUTE revoked from anon/authenticated, granted to service_role only), new Edge Function `create-user-account` (super_admin ONLY — deliberately narrower than approve-signup-request to avoid repeating SEC-107's support_staff→super_admin escalation; uses auth.admin.createUser with email_confirm=true + app_metadata.tenant_id = the SEC-108 trusted admin path), desktop `UserAccountRepository` domain contract with Supabase + Mock implementations (mock inserts into seedAccounts so created users can sign in — headless e2e testable), `AccountsTab` in Settings (SuperAdmin-gated, French UI per existing tabs), `UserAccountCreate` audit action. Initial password: admin-provided (same policy as changePassword) or generated; returned ONCE to the admin (never stored, never emailed — SEC-100 lesson); user changes it at first login (works since T-003).
- **Dependencies:** none · **Affected:** D (migration 0044, EF, src) · **Platforms:** Desktop, Backend
- **Status:** client stack (domain contract + mock + supabase repositories + wiring + AccountsTab + audit action) TESTED 2026-08-29; migration 0044 + create-user-account EF IMPLEMENTED (esbuild syntax check + auth-js typings cross-check + SQL review vs the 0005 precedent; no Deno/Postgres/live Supabase in this environment — cannot execute).
- **Outcome:** Settings → Comptes tab (SuperAdmin): create-account dialog (email, name, phone, role, optional §12.04 password) → one-time credentials card. Supabase path: EF → auth.users (confirmed) → trigger (pending profile + request) → 0044 RPC (active + role + request resolved, atomic) → `user_account.create` audit (no password). Mock path: mints into seedAccounts → the new user signs in via MockAuthRepository immediately. seedAccounts typed to full Role enum (values unchanged); backup-repository repositoriesRef extended; userAccounts wired into BOTH assemblies (Supabase mode explicitly overrides the mock spread).
- **Tests:** `src/tests/security/admin-create-account.test.tsx` 19/19 PASS (RED first: module-not-found, commit 19ac460); `npm run typecheck` clean; full suite 43 files / 1988 tests ALL PASS (was 42/1969). EF/migration gaps recorded honestly.
- **Verification:** see change-log entry (T-079) — headless evidence complete; live round-trip (deploy 0044 + EF, create account, sign in, change password) still pending → backend stays IMPLEMENTED.
- **ADRs:** —
- **Commits:** d85d65a (registry checkout) · 19ac460 (RED tests) · 314a74e (desktop implementation) · aa841ee (migration 0044 + EF) · docs commit (this change).

---

### T-083 — Fix the `expire_pending_approvals()` SQL RPC (BUG-NEW-001, discovered during T-004 verification)
- **Problems:** BUG-NEW-001 · **Priority:** P1 · **Severity:** High
- **Status:** TESTED (2026-08-30, eighth session — folded into T-084's migration 0049)
- **What was done:** migration `0049_dashboard_kpis_fanout_expire_fix.sql` rewrote `expire_pending_approvals()` as a single data-modifying CTE over `account_approval_requests` (status='pending' AND expires_at < now() → 'expired'), returning per-tenant counts. Applied LIVE to hkvkefubghbbotgnteir via the Management API SQL endpoint; verified live: function body references the correct table (prosrc check), `SELECT * FROM expire_pending_approvals()` executes cleanly, approval-request status counts correct (2 approved, 1 expired, 0 stuck pending).
- **Left:** the EF round-trip with a valid CRON_SECRET (value not available in-session); the EF's own error-path audit entry (unmodified in this session).
- **Commits:** see change-log session 8.

### T-084 — Live backend health check + KPI matview repair + FCM token hardening + portal UI restructure (session 8, owner-requested)
- **Problems:** BUG-NEW-002, BUG-NEW-003, SEC-106, SYNC-104, SYNC-105, PUSH-102 (partial), DATA-005 (mitigation), WEAK-018/019 family (residuals) · **Priority:** P0 · **Severity:** Critical
- **Status:** TESTED (2026-08-30) — Android half IMPLEMENTED (compile check pending)
- **What was done:**
  1. **Live backend health check** (owner priority 2): full inventory + integrity + RLS + MV + RPC + auth census — archived as `docs/audits/backend-health-check-2026-08-30.md` (11 findings F-01…F-11 → DATA-001…007 + BUG-NEW-002/003 registered).
  2. **Migration 0049** (applied live): mv_dashboard_kpis fan-out fixed (21.38B → true 54.96M, verified byte-identical to the payments cross-check); unique indexes on all 4 MVs (REFRESH CONCURRENTLY now works — verified live); expire_pending_approvals rewrite (T-083).
  3. **Migration 0050** (applied live): register_fcm_token caller verification (SEC-106 — auth.uid() must own p_user_id, service_role exempt, SQLSTATE 42501 on mismatch) + new canonical deactivate_fcm_tokens RPC (SYNC-104/105 path). Verified live: verification logic present in prosrc, EXECUTE granted to authenticated.
  4. **Website portal UI restructure** (owner priority 1): FinancialView restructured around the real data model — tabs now Tranches | Paiements | **Relevé** (NEW ledger statement timeline with running balance, month grouping, category badges) | Ajustements (derived from ledger_entries — 318 live rows — instead of the empty account_adjustments table); dead invoices/receipts standalone tabs removed (0 rows / orphaned table, CROSS-101); 4 canonical KPIs (outstanding/overdue/paid/credit) with correct labels; payment rows show REAL status + payment_number + category (was hardcoded "paid"); installment rows show label + category + plan; all hardcoded French strings moved to i18n (fr/ar/en + all new keys); honest empty states everywhere. Dashboard: greeting uses display_name (formatParentName — first_name empty on all 258 production rows), KPI grid financial-first (the old attendance/GPA tiles were permanently dead "—" on empty academic tables). New pure derivations ledgerTimeline/ledgerAdjustmentEntries in portal-derive (canonical layer) with 9 new unit tests. notifications query now includes parent-role broadcasts (query-side half of REALTIME-102). Fixed the 2 long-standing React-Compiler lint errors (preserve-manual-memoization) — `npm run lint` is CLEAN for the first time.
  5. **Website tokens** (SYNC-105): signOut now unregisters the device token (canonical RPC, RLS-scoped fallback) BEFORE revoking, and uses scope:'local' instead of 'global'.
  6. **Android tokens** (SYNC-104): LocalAuthRepository.signOut deactivates Android tokens via the canonical RPC before revoking the JWT (Hilt-cycle-free design — direct provider call, documented); FcmTokenRegistrar gained the matching deactivate() for symmetry.
  7. **Credentials sheet** (owner priority 3): `docs/operations/credentials.md` — canonical backend identity, per-platform credential sources, key registry with scope rules, FCM lifecycle table, rotation + verification procedures. Website `.env.example` committed (real public URL, gitignore exception added).
- **Tests:** website `npm run build` STRICT green; `npm run lint` 0 errors; `npm run test` 8 files / 105 tests ALL PASS (+9 new); live SQL verification suite for migrations 0049/0050 (values, indexes, prosrc, grants, refresh). Gap: Android compile (no SDK in session env — code follows the exact established patterns in the same files); live browser round-trip; EF round-trip with CRON_SECRET.
- **Commits:** see change-log session 8.

---

### T-085 — Live-data reconciliation (owner decision required) — DATA-001…DATA-005
- **Problems:** DATA-001 (payment_allocations empty / waterfall never run), DATA-002 (three-way totals disagree for parent e3e90f1f), DATA-003 (ledger charges ≠ installment dues, 197/258 parents, Δ7.62M), DATA-004 (59 overpayers, NULL excess fields), DATA-005 (first_name empty on all rows)
- **Priority:** P0 (financial correctness) · **Severity:** Critical
- **Description:** NOT a code task — a supervised data-repair campaign. Sequence: (1) forensic pass on parent e3e90f1f's 1,750/10,000 DZD discrepancies → owner decides which source is truth; (2) classify the 7.62M of ledger-only charges (what do they represent — registration? supplies? transport annual?); (3) one-time backfill replaying all 888 payments through the canonical waterfall to generate payment_allocations + link payments.installment_id (+ populate expected/excess per DATA-004); (4) first_name split from display_name. Every step needs owner sign-off because it rewrites financial history.
- **Dependencies:** owner decisions · **Affected:** B (data only) · **Platforms:** all
- **Verification:** re-run the session-8 health check → zero three-way disagreements; payment_allocations populated and internally consistent; first_name non-empty.

### T-086 — Parent-portal onboarding campaign — DATA-006
- **Problems:** DATA-006 · **Priority:** P1 (operational) · **Severity:** Medium
- **Description:** The portal is code-complete but has zero eligible users (1/258 parents with email, 0 activation codes, 0 auth bindings, 0 parent-targeted notifications, empty academic tables). Work with the school: collect parent emails, generate + distribute activation codes via the desktop feature, approve the requests, have staff start recording attendance/grades/homework. Not engineering-blocked.
- **Dependencies:** school-side action · **Verification:** first real parent signed in; first parent-targeted notification delivered.

### T-087 — Test-residue cleanup — DATA-007
- **Problems:** DATA-007 · **Priority:** P3 · **Severity:** Low
- **Description:** Drop `_eq_test_fn`/`_eq_test_fn2` RPCs (equivalence-harness leftovers exposed via REST), delete the unconfirmed `test.connection.supabase@gmail.com` auth user and its expired account_approval_request. One small migration + auth admin call; no production code references them.
- **Dependencies:** none · **Verification:** REST RPC inventory no longer lists the test functions; auth user list shows only real users.

---

## Not Started (sequencing notes)

All `Ready` tasks above have not yet been started. Two of them are called out for sequencing only (they are defined in their phase sections):

- **T-036** push pipeline — its EF-internal fixes (correct column, PEM parsing) are unblocked and can start; the invocation wiring waits on the token-lifecycle work (T-030) and provider scoping.
- **T-069** Android realtime — sequenced after T-050 (online-state correctness) to avoid building subscriptions on a broken connectivity signal.

## Needs Investigation

- **T-047** — desktop mock-repository completion (requires product scoping per module before implementation can be scheduled).

## Deferred

- **T-073** — Co-teaching schema support (`ACAD-102`): product enhancement; requires join-table design.
- **T-074** — Class-transfer audit trail (`ACAD-103`): product enhancement.
- **T-075** — Homework acknowledgment feature (`GRADE-100`): never specified beyond the column.
- **T-076** — Firebase key rotation + build-config documentation (`SEC-003`): hygiene; requires Firebase console access.
- **T-077** — Reactive Supabase configuration without restart (`DRIFT-003`): documented limitation for now.

---

## Dependency graph

```
T-005 (tenant RBAC) ──→ T-053 (global admin UX)
T-011 (collect fallback) ──→ T-015 (receipt consolidation, desktop side)
T-019 (sync errors) ──→ T-020 (5xx requeue) ──→ T-021 (worker semantics)
T-019 ──→ T-017 (Android refunds)
T-023 (desktop academic writes) ─┐
T-024 (Android academic writes) ─┼─→ T-039 (Android pull completeness) ──→ T-040 (justification review)
T-025 (tenant resolver fix) ─────┴─→ T-041 (promotion flow)
T-032 (website realtime) ──→ T-033 (freshness fallback)
UNKNOWN-001 ──→ T-028 (activation EF)
UNKNOWN-002 ──→ T-045 (Room layers), T-059 (Android canonical writes → T-017 interim, T-069)
UNKNOWN-003 ──→ T-067 (payment EFs)
UNKNOWN-004 ──→ T-066 (receipts)
UNKNOWN-005 ──→ T-037 (chat)
UNKNOWN-007 ──→ T-038 (notification read state) [partial: T-032's notifications filter]
UNKNOWN-008 ──→ T-072 (activation hardening)
UNKNOWN-010 ──→ T-070 (multi-guardian)
UNKNOWN-011 ──→ T-042 (timetable)
```

**Hard rule:** do not work a downstream task before its dependency is VERIFIED (or the blocking unknown is resolved) without a recorded reason in the task's entry.

---

## Ninth recovery session (2026-08-30, owner-requested)

### T-088 — Restructure desktop Dashboard UI: eliminate duplication + dead code (ARCH-010)
- **Problems:** ARCH-010 (new)  · **Priority:** P0 · **Severity:** High (UX defect — owner-requested)
- **Status:** TESTED (2026-08-30)
- **What was done:**
  - DashboardPage: ONE fetch at the page level (kpis + revenue + debtAging + demographics + topDebtors), passed DOWN to both OverviewTab and SeeDetailsModal as props — no second fetch when the modal opens.
  - OverviewTab: restructured into 8 KPI cards (4 financial + 4 operational), DashboardCalendar (operational), Top Debtors quick-list. No duplicate charts. Dead bottom Stat card removed.
  - SeeDetailsModal: receives ALL data via the `data` prop. Departments sub-tab stops calling `repos.payments.observe().get()` (mock-only leak); it derives from the page-level revenue series + an honest empty state when per-category data isn't exposed.
  - ReportsTab: dead "PDF" format badge removed from "Revenu mensuel" card (the handler returned a "Bientôt disponible" toast — a fake feature). XLSX is the only advertised format now.
  - Unread alerts badge added to the Alerts tab via the `count` + `countTone` PageTab props — a real operational signal that was previously hidden.
- **Tests:** new regression suite `src/tests/ui/dashboard-restructure.test.tsx` (10 tests) — asserts the duplicate charts are gone, the dead Stat card labels are gone, the KPI grid is 8 cards, the routing is correct (Unread Alerts → Alerts tab; every other KPI → drill-down).
- **Verification:** typecheck clean; lint 0 errors; 47/2029 tests ALL PASS (was 46/2021).
- **Commits:** see change-log session 9.
- **ADRs:** —

### T-080 — Port the desktop overdue-scan to Supabase (kill the mock leak in Supabase mode) — ARCH-006
- **Problems:** ARCH-006  · **Priority:** P2 · **Severity:** Medium
- **Status:** TESTED (2026-08-30)
- **What was done:**
  - New `SupabaseOverdueAlertGenerator` class in `elimtiyaz-desktop/src/infrastructure/supabase/repositories/supabase-overdue-alert-generator.ts`. Scans `installments` for overdue + upcoming-due rows, dedups against `notifications` (by `link_entity_type='installment'` + `link_entity_id`), bulk-INSERTs new `payment_overdue` notifications targeting `financial_officer`, writes a best-effort audit entry via the canonical `write_audit_log` RPC.
  - Mirrors the `MockOverdueAlertGenerator` contract: priority urgent>90d/high 31-90d/medium 0-30d; display_name preferred (per F-06/DATA-005 — first_name is empty on all 258 production rows).
  - Wired into the Supabase assembly (overrides the `overdueAlerts` slot).
  - Also re-exported from `supabase-repositories.ts`.
  - Removed the auto-run on mount (`repos.overdueAlerts.run()` in dashboard-page.tsx) — the dashboard no longer scans mock seed data on every page load.
- **Tests:** new unit suite `src/tests/infrastructure/supabase-overdue-alert-generator.test.ts` (8 tests) — happy path, priority buckets, dedup, upcoming-due window, name fallback, fully-paid-despite-status filter, and the empty-when-no-installments case.
- **Verification:** typecheck clean; lint 0 errors; 47/2029 tests ALL PASS (was 46/2021).
- **Left:** live integration against the real backend (the unit tests use a fake Supabase client surface). Run the overdue scan against production data and verify the notification count + audit entry.
- **Commits:** see change-log session 9.
- **ADRs:** —

### T-089 — Implement the 4 hardcoded Supabase KPIs against real data (ARCH-010 part 2)
- **Problems:** ARCH-010 (sub-defect — the 4 hardcoded zeros)  · **Priority:** P0 · **Severity:** High
- **Status:** TESTED (2026-08-30)
- **What was done:**
  - `SupabaseDashboardRepository.kpisForRange()` no longer returns `totalStaff: 0` / `pendingExpenses: 0` / `attendanceRateToday: 0` / `overdueAlerts: 0`. Each is now a real query:
    - `totalStaff`: COUNT(*) FROM personnel WHERE tenant_id AND deleted_at IS NULL (migration 0010)
    - `pendingExpenses`: COUNT(*) FROM expense_tickets WHERE status='pending_approval' (migration 0008; DRIFT-013 mitigation — the desktop domain uses 'submitted' but the DB column uses 'pending_approval'; wider expenses-repository port is T-093)
    - `attendanceRateToday`: (present + late) / total from attendance_records for today, falling back to the most recent date with records (mirrors the mock's fallback; canonical rate per WEAK-019 / T-027; migration 0009)
    - `overdueAlerts`: COUNT(*) FROM notifications WHERE kind='alert' AND link_entity_type='installment' AND is_read=false (migration 0013)
- **Discovery (DRIFT-013):** the desktop code calls `.from("expenses")` — a table that DOES NOT EXIST in the live schema. The canonical table is `expense_tickets` (migration 0008). The dashboard KPI now uses the correct name. The wider expenses-repository leak (the assembly still uses MockExpensesRepository) is task T-093.
- **Tests:** covered by the existing dashboard-restructure test suite (the KPI grid is asserted to render the 4 operational KPIs with the right tone/hint); no separate KPI test added (would require mocking the entire Supabase client surface for 4 trivial COUNT queries).
- **Verification:** typecheck clean; lint 0 errors; 47/2029 tests ALL PASS. Live SQL verification via `scripts/verify_t-089.sh`: totalStaff=0 (honest — personnel empty in production); pendingExpenses=0 (no pending_approval tickets); attendanceRateToday=0 (attendance_records empty); overdueAlerts=269 (matches the audit doc).
- **Commits:** see change-log session 9.
- **ADRs:** —

### T-091 — Migration 0050 drift reconciliation: create 0051_chat_read_receipts.sql (ARCH-009)
- **Problems:** ARCH-009 (new)  · **Priority:** P1 · **Severity:** High (process)
- **Status:** TESTED (2026-08-30)
- **What was done:**
  - Added migration `0051_chat_read_receipts.sql` to the local repo. Idempotent (`drop policy if exists + create policy + create or replace function + drop trigger if exists + create trigger`). The SQL is byte-identical to what's registered as version 0050 in the live DB's `supabase_migrations.schema_migrations` (extracted via `scripts/extract_migration_0050_live.sh`).
  - Applied the migration SQL live via the Management API SQL endpoint (idempotent no-op since the policy + trigger + function already exist on the live DB).
  - Registered migration 0051 in `supabase_migrations.schema_migrations` via the Management API SQL endpoint (idempotent `INSERT … ON CONFLICT (version) DO NOTHING`, with dollar-quoting `$$mig$...$$mig$` for the statements text so the migration's own `$$` plpgsql markers don't conflict).
  - Documented the drift + lessons for next agents in the problem registry (ARCH-009 entry).
- **Verification:** `SELECT version, name FROM supabase_migrations.schema_migrations WHERE version IN ('0050', '0051') ORDER BY version;` returns both rows. Policy + trigger + function still intact (verified via `pg_policies` / `pg_trigger` / `pg_proc`).
- **Lessons for next agents:** applying SQL via the Management API SQL endpoint does NOT update `schema_migrations`. To register a migration applied this way, INSERT into `supabase_migrations.schema_migrations` manually using dollar-quoting for the statements column.
- **Commits:** see change-log session 9.
- **ADRs:** ADR-001 (canonical migration chain)

### T-087 — Test-residue cleanup (DATA-007) — COMPLETED
- **Problems:** DATA-007  · **Priority:** P3 · **Severity:** Low
- **Status:** TESTED (2026-08-30)
- **What was done:**
  - Migration `0052_drop_test_residue.sql` (idempotent `drop function if exists public._eq_test_fn() / _eq_test_fn2()`) — committed + applied live.
  - Auth user `test.connection.supabase@gmail.com` deleted via SQL directly (auth schema is not in the public migration chain, but the Management API SQL endpoint runs as service_role and can DELETE from auth.users).
  - Expired `account_approval_request` row tied to the test user deleted.
  - Migration 0052 applied live + registered in schema_migrations (via the same dollar-quoting pattern as T-091).
- **Tests:** `SELECT routine_name FROM information_schema.routines WHERE routine_schema = 'public' AND routine_name LIKE '_eq_test%';` returns 0 rows. `SELECT id, email FROM auth.users;` returns 1 row (`admin@elimtiyaz.dz`). `SELECT * FROM account_approval_requests WHERE auth_user_id = '...';` returns 0 rows.
- **Commits:** see change-log session 9.
- **ADRs:** ADR-001 (canonical migration chain)

### T-092 — Migration token consistency across all platforms (DRIFT family + credentials sheet)
- **Problems:** — (process/hygiene; not a registered defect)  · **Priority:** P3 · **Severity:** Low
- **Status:** TESTED (2026-08-30) — gap closure 2026-08-31 (verify_t-092.sh promoted to in-repo)
- **What was done:**
  - Android `.env.example` updated to reflect the canonical Supabase URL (https://hkvkefubghbbotgnteir.supabase.co) + clarify that Firebase config comes from `google-services.json` (not env vars).
  - Verification script `scripts/verify_t-092.sh` confirms all three platforms point to the same Supabase project (website .env.example + Android .env.example + desktop runtime settings dialog + credentials.md). 7/7 checks pass.
  - Live auth health endpoint verified (HTTP 200).
  - **2026-08-31 gap closure:** the verify_t-092.sh script was originally written to `/home/z/my-project/scripts/` (outside the repo) and did not persist across sessions. Re-created as `scripts/verify_t-092.sh` at the hub repo root (in-repo, recoverable). Also corrected the credentials.md §2 desktop row (was pointing at a non-existent `SupabaseClientProvider.build()` file) and added §2.1 JWKS URL canonical section. See change-log entry "TENTH REPAIR SESSION".
- **Tests:** verification script.
- **Verification:** 7/7 checks pass.
- **Commits:** see change-log session 9.
- **ADRs:** ADR-001 (canonical migration chain)

### T-093 — (NEW — opened) Port desktop `expenses` repository to Supabase (DRIFT-013)
- **Problems:** DRIFT-013 (new)  · **Priority:** P2 · **Severity:** High
- **Status:** Ready
- **Description:** the desktop code calls `.from("expenses")` (the domain model + mock store use this name) but the canonical table is `expense_tickets` (migration 0008). The desktop `ExpenseStatus` enum (`draft|submitted|approved|rejected|disbursed|settled`) does NOT match the DB column (`draft|pending_approval|approved_funds_released|rejected|disbursed|settled_and_closed`). The dashboard KPI was mitigated in T-089 (uses the correct name + status); the wider expenses-repository port is this task. Plan: (1) implement `SupabaseExpenseRepository` with a translation layer; (2) override the `expenses` slot in `supabase-repositories.ts`; (3) decide whether to align the desktop `ExpenseStatus` enum to the DB values (preferred per AGENTS.md §15.9 + ADR-001) or keep a mapping layer (per AGENTS.md §15.5 — never weaken canonical server rules to make a client work, but a client-side mapping is acceptable); (4) regression-test with both assemblies' contracts.
- **Dependencies:** none technical; needs product confirmation on the status-value rename.
- **Affected:** Desktop · **Platforms:** Desktop, Backend

### T-094 — (NEW — opened) Live integration test for `SupabaseOverdueAlertGenerator` (T-080 follow-up)
- **Problems:** ARCH-006 (live-integration gap)  · **Priority:** P2 · **Severity:** Medium
- **Status:** Ready
- **Description:** T-080 closed the mock-leak defect with unit tests (8 tests, fake Supabase client). The live-integration verification — run the generator against the real Supabase backend, verify that the 269 existing notifications + new insertions work as expected — is this task. Plan: (1) sign in as admin; (2) trigger the "Scan retards" button or invoke `repos.overdueAlerts.run()` directly; (3) verify new notifications are inserted (or the dedup path returns 0 new if all installments already have alerts); (4) verify the audit entry appears in `audit_logs`.
- **Dependencies:** none.
- **Affected:** Desktop · **Platforms:** Desktop, Backend


### T-006 — Verify callers and tenants in SECURITY DEFINER RPCs — **Completed (TESTED)**

- **Problems:** SEC-110 (+STUDENT-101, PARENT-103), SEC-111, SEC-112 · **Priority:** P0 · **Severity:** High
- **Status:** TESTED (2026-08-31, tenth session) — migration 0055 applied LIVE + registered (`sec_definer_rpc_hardening`); `scripts/verify_t-006.sql` 9/9 PASS against the live DB (JWT contexts emulated via request.jwt.claims): S1 EF-path bind ok; S2 direct self-bind ok + PARENT-103 audit row; S3 foreign bind rejected (SEC-110); S4 anonymous rejected; S5 silent re-bind rejected; S6 service_role upsert ok; S7 foreign-tenant upsert rejected (SEC-111); S8 same-tenant refund ok + audit stamped with the payment's tenant; S9 cross-tenant refund rejected. Commit 8d317e2.
- **Deviation recorded:** bind_activation_code exempts service_role callers (the canonical EF path passes the verified JWT's userId via a service_role client — a hard auth.uid() equality check would break the product's activation flow).
- **Run-discovery:** upsert_payment_from_import's p_student_id has NO default (unchanged signature) — callers must pass it; documented in the verify script.

### T-008 — Constrain role assignment in approve-signup-request — **Completed (TESTED)**

- **Problems:** SEC-107 · **Priority:** P0 · **Severity:** High
- **Status:** TESTED (2026-08-31, tenth session) — shared decision core `_shared/role-assignment.ts` (staff roles require super_admin); unknown codes -> 400 invalid_role (was: silent skip); 403 + `account_approval.role_override_denied` audit on staff-role attempts; revoke/insert writes error-checked. 12/12 tests; deployed live (v10, Management API multipart deploy — the multi-file deploy path now proven twice); 401 smoke matrix green. Commit e575540. GAP: live 403 needs a real support_staff JWT.
- **Deviation recorded:** the entry's "safe subset (parent)" generalised to "non-staff roles" (parent/student, the roles.is_staff_role=false set) — same zero-privilege risk class; the flag is read from the roles TABLE, no hardcoded lists.

### T-093 — Port desktop expenses repository to Supabase — **Completed (TESTED)**

- **Problems:** DRIFT-013 (+NEW WEAK-030 registered) · **Priority:** P2 · **Severity:** High
- **Status:** TESTED (2026-08-31, tenth session) — `SupabaseExpenseRepository` with a centralised status/category translation layer; migration 0056 added the missing `payee` column (applied live + registered); `expenses` slot overridden in the Supabase assembly; no `.from("expenses")` call sites remain. 12/12 adapter tests; typecheck clean; full desktop suite 49 files / 2053 tests PASS. Commit 1e91ebf. LEFT (deliberate): domain enum alignment to DB values; WEAK-030 (server-side approval rules); server-authoritative ticket numbers.

### T-094 — Live integration test for SupabaseOverdueAlertGenerator — **Completed (VERIFIED)**

- **Status:** VERIFIED (2026-08-31, tenth session) — env-gated live suite `src/tests/integration/t-094-overdue-live.test.ts` 5/5 against the real project: run() scans 819 overdue installments and returns 0 new (dedup fully covers — independently cross-checked); INSERT path accepts the generator payload (self-cleaning sentinel); write_audit_log accepts the audit shape (append-only verification entry left intentionally). Commit ed901b3. GAP: desktop UI invocation needs a desktop host.

### T-032 — Repair the website realtime layer — **Completed (TESTED)**

- **Problems:** REALTIME-100/101/102/103, WEAK-016 (REALTIME-101 backend = 0051, already live) · **Priority:** P2 · **Severity:** High
- **Status:** TESTED (2026-08-31, tenth session, website commit 7b8983e) — invalidation key fixed (with an executable partialMatchKey proof of the root cause), markRead errors surfaced, notifications subscription unfiltered (RLS-scoped events cover role/tenant broadcasts), NEW useChatUnreadRealtime mounted once in AppShell, homework realtime on the canonical `homework`/class_id. Website suite 117/117; lint clean; strict build green. GAP: live two-session websocket test; NOTIF read-state remains UNKNOWN-007/T-038.

### T-035 — Website financial KPI correctness — **Completed (TESTED)**

- **Problems:** WEAK-022, WEAK-018 · **Priority:** P2 · **Severity:** Medium
- **Status:** TESTED (2026-08-31, tenth session, website commit e9587e0) — fetchAllLedgerEntries pages the full ledger (1000/row pages) replacing the 500 cap at both call sites (5/5 tests incl. a 1500-row two-request case); WEAK-018 found ALREADY FIXED in the session-8 restructure (registry corrected + pinning test; no code change).

### T-056 — Desktop low-risk hygiene batch — **Completed (TESTED)**

- **Problems:** WEAK-003, WEAK-004, DEAD-002, DRIFT-005, WEAK-020, DEAD-014 · **Priority:** P3 · **Severity:** Low
- **Status:** TESTED (2026-08-31, tenth session) — 6/6 items, one commit per item (6e24cd3, e63ae97, e412e44 + website 3c1b430): mapLedgerRow actor_id fallback removed; ledger seed uses canonical tranche due dates; handleDelete routed; server_secret.* in AuditActions + EF redeployed; paymentStatusTone covers the 2 missing statuses with fr/ar/en keys; database-schema barrel removed. Desktop t-056-hygiene suite + website suite green.

### MIG-TOKENS — Migration-token + live-chain consistency (session-10 opening) — **Completed (TESTED)**

- **Problems:** ARCH-011 (new) · **Priority:** P0
- **Status:** TESTED (2026-08-31) — discovered 0053/0054 applied live but absent from the repo (ARCH-011); reconciled both files from live definitions (commits 4bf5ff1); dry-run verified in BEGIN..ROLLBACK (HTTP 201); migrations 0055 + 0056 then followed the corrected discipline: file + live application + registration in the SAME commit. Live chain head now 0056 with the local chain matching one-to-one.

## 25th session (2026-09-04, concurrent multi-agent batch — branch `session25-agent-work`, ALL REPOS)

> Session context: ran as one of ~10 agents working the same repos concurrently. No Supabase credentials were provided this session → the opening ritual's LIVE chain check was NOT possible; the chain check was performed LOCALLY (append-only guard + numbering + registration-in-file checks) and the live check remains owner-token-gated. No push credentials either → commits live on branch `session25-agent-work` in each repo; the established zip-for-push handoff applies. Coordination claim: this session took T-044's ADDITIVE pass 3a prerequisite ONLY (the DS scrollable tab-row component) and explicitly leaves the hub-screen migration passes + the MainScreen route-model rewrite + the legacy-tree deletion to other concurrent agents (they are the contested recommendations; two agents editing the same hub screens simultaneously would collide).

### T-155 — Session-opening verification, credential-less adaptation — **Completed (TESTED)**
- **Problems:** — (process; the opening ritual under no-credentials conditions) · **Priority:** P0
- **Status:** TESTED (2026-09-04)
- **What was done:** desktop `npm ci` + `npm run typecheck` (clean) + `npm run lint` (0 errors / 384 warnings at open) + full suite (82 files / 2286 passed + 5 skipped); website `npm ci` + `npm run lint` (clean) + suite (26 files / 457 passed) + strict build (green, "Compiled successfully"); LOCAL migration-chain integrity: 65 files = 0001–0068 contiguous, no duplicate numbers, `scripts/check-migrations-append-only.sh` OK (+0 vs origin/main), registration statements present inside 0066/0067/0068 files per the MIG-TOKENS atomic-apply convention.
- **NOT done (honestly):** the LIVE `schema_migrations` diff (needs the owner's sbp_ token — not provided this session). The 24th session closed at 65/65 zero drift; any live drift since then is invisible here. Next session WITH a token must re-run the live chain check FIRST (ARCH-014 lesson).
- **Baseline note:** desktop suite grew 2284 → 2286 (T-157's +2 guards); website 25 → 26 files (t-149 follow-up file present at HEAD; verified green).

### T-156 — Registry truth-sync (stale rows from sessions 17–24) — **Completed (TESTED)**
- **Problems:** — (process hygiene; the T-117/T-125 discipline) · **Priority:** P1
- **Status:** TESTED (2026-09-04)
- **What was fixed (each flip cites its evidence):**
  1. **T-104 sat in "Ready" although ADR-010 shipped it in the 17th session** (three session closeouts kept the listing). Entry corrected; LESSON recorded: a completing session must REMOVE the entry from the section header, not just note it inside.
  2. **"Not started (Android, toolchain-gated): T-020, T-082" row** — both completed (T-020 TESTED 17th; T-082 TESTED 18th); row flipped to a tombstone.
  3. **"only DATA-005 (first_name split) remains of T-085"** — stale: DATA-005's backfill was EXECUTED as migration 0066 (T-139, 22nd session, live-verified 6/6).
  4. **CROSS-004 problem header OPEN** → TESTED (its own T-146 status note already recorded the closure; header was left stale).
  5. **REG-002 problem header OPEN** → TESTED (mirrors REG-001's "process guard landed" treatment: T-046 removed the destructive fallback + Robolectric-pinned; T-046-gap landed exportSchema + committed history + MigrationTestHelper upgrade test).
  6. **DATA-009** — added the T-157 status note (debt-meter wiring complete; every desktop credit display now on the ADR-010 derivation).
- **Verified:** every flip cross-checked against the detailed entry's own status note + commits (T-117/T-125 discipline); no entry flipped without a cited closure record.

### T-157 — Wire the debt-meter's dormant Crédit parent row (ADR-010 residual) — **Completed (TESTED)**
- **Problems:** DATA-009 display surface · **Priority:** P2
- **Status:** TESTED (2026-09-04) — hub commit a02edd7.
- **What was done:** `unified-payment-modal.tsx` observes `repos.debt.observeParentProfile` and passes `displayParentCredit(totalOutstanding, totalUnallocatedCredit)` to the DebtMeter (the raw balance double-counts canonical overpayments; the raw unallocated Σ is wrong for 0062-era overpayers); `debt-meter.tsx` prop doc corrected to the ADR-010 magnitude contract (the old doc self-contradicted: "always <= 0" vs "positive = magnitude"); `t-104-display-credit.test.ts` +2 source-scan guards pinning the wiring and the contract (10/10).
- **Verified:** typecheck clean; t-104 suite 10/10; navigation-context 7/7; full desktop suite 82 files / 2286 passed + 5 skipped; lint 0 errors.
- **Preserved:** DebtMeter rendering logic; the dossier card wiring; the canonical writer; all equivalence-pinned shapes.

### T-158 — Desktop lint exhaustive-deps review + baseline re-documentation — **Completed (TESTED)**
- **Problems:** DEAD-201 follow-up class (the 4 findings T-078 flagged for individual review) · **Priority:** P3
- **Status:** TESTED (2026-09-04) — hub commit 9e1c974.
- **What was done:** (1) `auth-provider.tsx` — the 4 provider actions wrapped in useCallback with explicit deps; the context-value useMemo lists them (behavior-preserving: repos is a module-stable context value; the previous hand-written `[session, isLoading]` array silently captured stale repos if the provider value ever changed identity); (2) `sync-provider.tsx` — stale unused eslint-disable directive removed (empty deps genuinely correct — session read via ref; reasoning now a comment, not a suppression); (3) `worker-dashboard.tsx` — `clockTick` kept as the INTENTIONAL post-punch recompute trigger, made lint-visible via `void clockTick` + comment; dead `REQUEST_TONE` removed; (4) `page-tabs.tsx` — complex dependency expression extracted to `dataValue`; dead `s`/`ctxSize` removed (`size` stays destructured so it never leaks into the DOM).
- **DISCOVERY (new):** the desktop lint warning baseline drifted 307 (T-078, 2026-08-29) → 384 (this session open) with no per-session lint-delta discipline — ~77 warnings accumulated silently across 20 sessions of new code. The config's documented baseline is now re-pinned (379 after T-158) and the exhaustive-deps class is at ZERO: any new finding is a regression to fix, not to baseline. RECOMMENDATION: record the lint warning count in every session closeout (as the suites are recorded) so drift is caught within one session.
- **Verified:** typecheck clean; lint 0 errors / 379 warnings (exhaustive-deps 4 → 0); change-password suite 12/12; full desktop suite green.

### T-159 — Android toolchain re-provisioning + android-env.sh recipe re-creation — **Completed (TESTED)**
- AGENTS.md §11 points at `/home/z/my-project/scripts/android-env.sh`; the container reset wiped JDK 21 + SDK 35 + the recipe. This session re-provisioned both: JDK 21 (javac 21.0.12.1) + SDK 35, recipe re-created at `/home/z/my-project/scripts/android-env.sh` (now also auto-creates the ROOT `.env` — see §8.1 in AGENTS.md for the secrets-plugin rootProject resolution quirk that motivates it). Verification evidence: full Android unit suite 44 files / 372 tests ALL PASS + lintDebug GREEN (== 24th-session baseline) before any new work. Android commit 1d1e07d.

### T-044 — Android design-system consolidation — pass 3a (additive prerequisite) — **Completed (TESTED)**
- **Claimed scope (25th session):** ONLY the additive prerequisite — extend the design system with the scrollable tab-row component (+ tests), which the 23rd/24th sessions documented as the blocker for the 6-tab FinancialsHub. **NOT claimed (left for other agents / next session):** the hub-screen migration passes, the MainScreen bottom-nav route-model rewrite, the final legacy-tree deletion. Reason: ~10 concurrent agents were pointed at the same recommendations; the component addition is collision-safe (new file), screen migrations are not.
- **Status:** TESTED (2026-09-04) — Android commit 49b83aa on `session25-agent-work`.
- **What was done:** `ElScrollableTabRow` added to `ui/designsystem/components/tabs/ElTabs.kt` (+100 lines, purely additive — no legacy file touched, no call site migrated): LazyRow of `ElPillShape` pills on a `surfaceVariant` track, behaviour-parity with the legacy `ui.components.ModernSecondaryTabRow` (programmatic-selection auto-scroll via `LaunchedEffect` + `animateScrollToItem`, out-of-range guard, single-line labels) using only DS tokens. Items carry `Role.Tab` + semantics `Selected`; the row exposes stable `testTag("el_scrollable_tab_row")` for UI tests.
- **Two live-discovered pitfalls (recorded for future DS work):** (1) inside `semantics { … }`, a parameter named `selected` collides with the receiver's extension var — `selected = selected` compiles as a val reassignment; fixed by naming the item parameter `isSelected`; (2) LazyRow composes ONLY visible pills — off-screen labels do not exist in the semantics tree, so every per-label ui-test assertion must `performScrollToNode` via the row's test tag first; also `setContent` is once-per-test (state flips via `mutableStateOf`, not re-setContent).
- **Verified:** new `ElScrollableTabRowTest` (5 semantic tests, Robolectric sdk34 w411dp — no screenshots per ARCH-012): 5/5 PASS; full suite 45 files / 377 tests / 0 failures (baseline 44/372); lintDebug GREEN.

## 26th session (2026-09-05 — the "financial transparency" patch hardening, ALL REPOS)

> Session context: the owner accepted an AI-generated patch (unregistered, junk-named commits "jjj"/"o"/"k"/"mid"/"it jsut happen" + one essay-message commit, HEAD 8644719) that visualized the parent financial breakdown inside `parent-detail-drawer.tsx` and asked for a full safety review + native re-integration across desktop/website/Android/backend. Session verdict: the UX direction was right, the implementation violated the architecture (financial logic in a presentation component — DATA-008/DUP class), masked two REAL repository-layer root causes (DATA-013), and shipped 8 broken tests (2 files) plus a silently weakened CSP. Live-DB evidence (read-only audit with the owner's sbp_ token): the `installments` table holds 1 276 rows covering 259/259 charged parents — the "missing tranches" diagnosis in the patch's own essay was FALSE; the tranches existed all along and the Supabase debt-profile contract simply never shipped them.

### T-164 — Desktop: canonical parent billing breakdown (domain extraction + drawer refactor + root-cause repository fix) — **Completed (TESTED)**

- **Problems:** DATA-013 (new), DATA-008 class, DUP (inline waterfall), DESK-CSP-202 regression, notification-contract regression, T-145 audit branch loss · **Priority:** P0
- **Status:** TESTED (2026-09-05)
- **What was done:**
  1. **Root cause fixed (DATA-013):** `SupabaseDebtRepository.refreshProfile` — (a) the ledger query selected only 6 columns, so `mapLedgerRow` produced entries with `description: ""`, `actorId: "system"`, `studentId: undefined` (the source of the owner-visible "blank adjustment reasons" + "Auteur: system" + lost per-child attribution — the DB rows carry all of it); (b) the profile hardcoded `installments: []` (the source of "Aucune tranche"). Now: `select("*")` (mirrors the ledger repo seed) + a real `installments` query mapped with `mapInstallmentRow` (contract parity with the mock repo, which always populated them).
  2. **Domain extraction:** new canonical module `src/domain/calc/payment/billing-breakdown.ts` (exported via the payment barrel): `computeParentBillingBreakdown` (itemized per-child charges, per-service consolidation, REAL tranche coverage rendered verbatim from the server waterfall, INV-4 remaining via `installmentRemaining`, display-only 40/30/30 synthesis via `splitNetTuitionByOfficialSchedule` + `getOfficialTuitionDueDates` + one global `allocatePaymentToInstallments` run over synthetic tranches — chronologically ordered, residual-cleared-pool so real-row money is never double-counted), `resolveBillingAcademicYear`, `describeAdjustment` (credit/debit badge + shared diagnostic fallback for blank reasons).
  3. **Drawer refactor (`parent-detail-drawer.tsx` FinancesTab):** consumes the canonical module via `useMemo`; now observes `repos.installments.observeByParent` (the same stream the UnifiedPaymentModal reads — cashier slider and drawer can no longer disagree); the synthetic-schedule state renders an explicit warning banner; tranche cards show due dates + pending funds + coverage progress; `Par Enfant` / `Par Service` toggle, itemized list, reconciliation footer and adjustment diagnostics preserved from the patch's UX but now fed by canonical numbers.
  4. **Patch regressions repaired:** `index.html` CSP restored `frame-ancestors 'none'` (DESK-CSP-202 — the patch deleted it; csp-policy test was failing); `supabase-notification-repository.ts` restored to the 99bd956 implementation (the patch's rewrite broke 7 contract tests with an unregistered "local cache fallback"); the T-145 `issueActivationCode` failure path re-added its audit log entry (`parent.activation_code_issuance_failed`) that the patch dropped.
- **Verified:** `npm run typecheck` clean; `npm run lint` 0 errors / 378 warnings (baseline 379 — net −1); FULL suite 83 files / 2302 passed + 5 skipped, 0 failures (was 8 failures at session open, all introduced by the unregistered patch — both files re-verified green on the pre-patch baseline worktree to attribute them correctly); new `src/tests/domain/payment/billing-breakdown.test.ts` 16/16 including the owner-reported headline vector (285 000 → T1 114 000 fully covered, T2 85 500 with 11 000 → 74 500 remaining, T3 85 500 untouched, Σ remaining 160 000).
- **Preserved:** `displayParentCredit` balance cards (ADR-010/T-157 wiring), the UnifiedPaymentModal/DebtMeter contract, the AdjustAccountModal, all T-100/T-104/T-014 comment contracts.

### T-165 — Backend: migration 0069 — adjustment description guard — **Completed (TESTED)**

- **Problems:** DATA-014 (new — silent system adjustments prevention) · **Priority:** P1
- **Status:** TESTED (2026-09-05) — APPLIED LIVE + verified.
- **What was done:** migration `0069_adjustment_description_guard.sql` (chain 66 files, append-only guard OK): CHECK constraint `ledger_entries_adjustment_description_guard` requiring every `adjustment`/`reversal` ledger entry to carry `description IS NOT NULL AND length(btrim(description)) >= 3`. Added NOT VALID (brief ACCESS EXCLUSIVE, no full scan) then VALIDATE (SHARE UPDATE EXCLUSIVE — concurrent writes continue). NO backfill was needed — the patch's "database lacks tranches" diagnosis was disproven by live read-only audit (1 276 installment rows, 259/259 charged parents covered, 0 blank descriptions across 690 adjustment rows; ledger↔installments reconcile — top divergences are only negative-balance overpayers where remaining is correctly 0).
- **Verified:** live pre-checks (0 violations), BEGIN…ROLLBACK probe suite — blank insert REJECTED (23514, the exact guard error), documented insert accepted (probe2_inserted=1 then rolled back); applied live: `convalidated = true`, post-check 0 violating rows. Evidence scripts: `scripts/verify_t165_curl.sh`.
- **Writer contract:** `upsert_ledger_entry_from_import` / adjust() / refund compensation paths must keep sending real sentences ("Annulation de remise lors du ré-import Excel du …"); the DB now rejects silence.

### T-166 — Website: Facturation tab (itemized billing parity) — **Completed (TESTED)**

- **Problems:** CROSS platform parity gap · **Priority:** P1
- **Status:** TESTED (2026-09-05) — website repo commit (this session).
- **What was done:** new canonical read-side derivation `src/lib/canonical/billing-breakdown.ts` (`parentBillingBreakdown` — per-child itemized charges + per-service totals + REAL tranche coverage from physical rows only, INV-4 via `installmentRemainingAmount`; `describeAdjustment`; `resolveBillingAcademicYear`; `SERVICE_LABELS_FR` canonical wording). FinancialView gains a 5th tab "Facturation" (billing toggle Par enfant / Par service, academic year header, per-child charge items + tranche coverage cards, reconciliation footer); the Adjustments tab now uses `describeAdjustment` (blank legacy reasons render the shared diagnostic, styled italic). i18n keys added in FR/AR/EN. NO pricing/waterfall engine ported (T-057/ADR-002: the portal renders what the server produced — it never synthesizes).
- **Verified:** `npx vitest run` 27 files / 468 tests passed (was 26/457; +11 new parity vectors incl. the 285 000/100 000 headline case + "portal never synthesizes" pin); tsc clean on changed files; eslint clean on changed files; T-057 port-honesty registry updated to declare the 2 new canonical files (the guard test itself enforces declaration).

### T-167 — Android: billing breakdown mirror + ParentDetailScreen card — **Completed (TESTED)**

- **Problems:** CROSS platform parity gap · **Priority:** P1
- **Status:** TESTED (2026-09-05) — Android repo commit (this session).
- **What was done:** new canonical mirror `core/BillingBreakdown.kt` (mirror of the desktop module — same invariants, centimes: real rows authoritative, INV-4 remaining, 40/30/30 display synthesis via the existing `splitNetTuitionByOfficialSchedule` + `officialTuitionDueDates` + `allocatePaymentToInstallments`, residual-pool double-count guard, `describeAdjustment`, `SERVICE_LABELS_FR`). `ParentDetailViewModel` observes the ledger stream and derives `billingBreakdown` (recomputed on every stream emission; `BillingInstallmentRow` projection keeps `core/` free of domain imports). `ParentDetailScreen` renders a "Prestations facturées" card (per child: itemized charges + tranche coverage with Payée/Partielle/En attente/Due statuses + pending display + synthetic warning banner).
- **Verified:** `:app:compileDebugKotlin` BUILD SUCCESSFUL; new `BillingBreakdownTest` 11/11 (same vectors as desktop/website); FULL unit suite 46 classes / 388 tests / 0 failures (baseline 45/377 at the 25th session — suite grew with the new test class). Baseline re-provisioned per T-159 recipe (JDK 21.0.12.1 + SDK 35 + root `.env`).

### T-168 — Desktop: itemized shopping list completion + adjustment provenance classification + reconciliation equation — **Completed (TESTED)**

- **Problems:** DATA-015 (new — single-child family-level charges dropped from the itemization), owner transparency ask ("is this actual content, a trap, a mistake, or something revealing?") · **Priority:** P0
- **Status:** TESTED (2026-09-05, 27th session)
- **What was done:**
  1. **Engine (`domain/calc/payment/billing-breakdown.ts`):** `classifyAdjustmentHistory` — provenance classification of every adjustment with the SAME pairing algorithm on every platform (chronological FIFO per |amount|, opposite-sign matching only, zero amounts skip): `documented` (actual operator content) / `reversal_pair` (net-zero +X/−X counter-pass — the re-import flip-flop pattern) / `undocumented` (legacy blank row to audit), each with a full FR meaning sentence. `BillingReconciliation` — the adjustment-aware account equation (grossBilled − credits + debits = netDue; netDue − cleared − pending = derivedRemaining; explicit `bridge` reconciling to the server balance so no displayed number is unexplained). `ServiceTotalNode` gains `sharePct` + `childAttribution` (per-child amounts inside each service); `unattributedItems`/`unattributedTotal` surface multi-child family-level charges explicitly.
  2. **DATA-015 fix:** a single-child family's family-level (null `student_id`) charges now join the child's shopping list (childBilledTotal === totalBilled) instead of silently disappearing; `sumPendingPayments` added to `sums.ts` (status-strict, mirrors `sumPaidPayments`).
  3. **UI (`parent-detail-drawer.tsx` FinancesTab):** drawer widened `max-w-2xl` → `max-w-4xl`; 4 balance cards (Brut facturé / Net à payer / Payé / Reste-Crédit, with sub-labels); per-child shopping list with service icons (lucide per category) + per-child subtotal; "Famille — éléments non rattachés" block in BOTH views; Par Service view with share bars + per-child attribution lines; full reconciliation footer (ledger-style equation + bridge warning + server balance check icon); adjustments history consumes `classifyAdjustmentHistory` — provenance chips (Documenté / Contrepassation / Non documenté) with tooltips, meaning sentences, cross-pair links ("Contrepassée par l'écriture … du …"), and an upgraded legend explaining content vs trap vs mistake.
- **Verified:** `npm run typecheck` clean; `npm run lint` 0 errors / 378 warnings (baseline 378); FULL suite 83 files / 2314 passed + 5 skipped / 0 failures (was 2302 — +12 T-168 tests: the 700 000 DZD 2-child shopping list with 40 000 family-level row, share % (81/13/6, Σ=100), attribution parity, single-child fold, full reconciliation equation with bridge and overpayer credit, provenance classification incl. the owner's exact +71k/−71k +50k/−50k shuffled flip-flop, same-sign never pairs, zero-amount skip, order preservation).

### T-169 — Website: Facturation parity — provenance pills + reconciliation + i18n — **Completed (TESTED)**

- **Problems:** cross-platform parity gap (T-168 features) · **Priority:** P1
- **Status:** TESTED (2026-09-05, 27th session) — website repo commit.
- **What was done:** `src/lib/canonical/billing-breakdown.ts` gains `classifyAdjustmentRows` (identical algorithm + FR wording to the desktop), `BillingReconciliationInput` (adjustmentRows / clearedPaid / pendingPaid / serverOutstanding), `sharePct` + `childAttribution` on services, `unattributedItems`, and the DATA-015 single-child fold fix. `financial-view.tsx`: the billing memo feeds the reconciliation from `portalFinancialSummary` (cleared = paid − pending; server balance = outstanding); BillingTab renders service share bars + child attribution + family blocks + the full equation footer (i18n keys `finance.billing.recon.*` in FR/AR/EN); AdjustmentsTab renders provenance pills + meaning lines + pair links. NO synthesis added (ADR-002 preserved).
- **Verified:** `npx vitest run` 27 files / 476 passed / 0 failures (was 468 — +8 T-168 parity vectors: 700k shopping list, share %, single-child fold, reconciliation with bridge, flip-flop pairs, documented vs undocumented, same-sign no-pair); tsc on changed files clean (total project tsc error count identical to the pre-change stash — pre-existing test-file errors only); eslint clean on changed files.

### T-170 — Android: provenance + reconciliation mirror + Prestations card upgrade — **Completed (TESTED)**

- **Problems:** cross-platform parity gap (T-168 features) · **Priority:** P1
- **Status:** TESTED (2026-09-05, 27th session) — Android repo commit.
- **What was done:** `core/BillingBreakdown.kt` gains `classifyAdjustmentHistory` + `BillingAdjustment`/`ClassifiedAdjustment`/`AdjustmentProvenance` (same algorithm, same FR wording), `BillingReconciliation` (new `parentBillingBreakdown` params: adjustments / pendingPaidTotal / serverOutstanding), `ServiceChildAttribution` + `sharePct` (rounded via `Math.round` to match the TS engines — integer division would truncate 12.857→12 vs 13), `unattributedItems`, and the DATA-015 single-child fold. `ParentDetailViewModel` maps ledger adjustment rows (reversals excluded) and exposes `classifiedAdjustments`; `ParentDetailScreen` Prestations card adds the family block, "Par service" recap (share % + attribution) and the reconciliation footer (`ReconLine` composable); a new "Ajustements" card shows provenance tags + reason + meaning.
- **Verified:** `:app:testDebugUnitTest` 46+ classes / **396 tests / 0 failures** (was 388 — +8 T-168 vectors incl. the 700k list, share parity 81/13/6, bridge, flip-flop pairs, same-sign no-pair); `:app:compileDebugKotlin` BUILD SUCCESSFUL (JDK 21.0.12.1 + SDK 35).

## 27th session (2026-09-05 — owner-reported sync + notification flood, ALL REPOS)

> Session context: the owner reported with a screenshot — "I don't think the syncing is working. Also, the notifications here are weird. Why are there 1,000 notifications? Is all of this happening because I synced three Excel spreadsheets?" Live-DB forensics + code analysis identified two compounding root causes: SYNC-200 (1 170 terminal-failed mock-era queue entries stuck forever with no recovery path — the visible red badge; 1 170 = 390 students × 3 imports, data confirmed safe server-side) and NOTIF-200 (overdue-alert flood, 958 unread never resolved). Fixed as T-171 (desktop sync-queue recovery) + T-172 (alert lifecycle, EF≡desktop + Android pull parity); the notification VOLUME design decision is deferred to T-173 with UNKNOWN-020.

### T-171 — Desktop: sync-queue recovery (retry/discard + legacy tenant re-scope + persisted lastSyncAt + honest status) — **Completed (TESTED)**

- **Problems:** SYNC-200 (new — registered this session with live forensics) · **Priority:** P0 (owner-reported blocker)
- **Status:** TESTED (2026-09-05, 27th session)
- **What was done:**
  1. `SyncService.retryFailed()` — re-queues every terminal-failed entry (status→pending, attempts→0, lastAttemptAt→null: full fresh backoff budget; lastError kept as history) + schedules an immediate debounced drain.
  2. `SyncService.discardFailed()` — removes terminal-failed residue via the new `SyncQueueStore.deleteMany` (single IndexedDB transaction; the synced entries' local audit history survives — unlike `clear()`).
  3. Drain-time legacy tenant RE-SCOPE: entries carrying a non-UUID placeholder tenant ("default" — baked in by mock-mode `enqueue()` before Supabase was wired) are re-scoped to the current session's real tenant before the push (safe: this user imported this data on this machine). Foreign-UUID tenants are now SKIPPED locally (never pushed — server RLS would reject them anyway; no more futile attempt-burn) and foreign-ACTOR entries stay skipped (SYNC-102 semantics preserved).
  4. `lastSyncAt` persisted to localStorage (`el-imtiyaz.sync.lastSyncAt`), restored at construction (corrupt values degrade to null), and set after EVERY completed online drain — a healthy no-op drain counts; offline drains never touch it. Kills "Dernière synchro: Jamais" despite 3 544 synced rows.
  5. UI: SyncTab gains "Réessayer les échecs (N)" + "Supprimer les échecs" (destructive, confirmed) + a guidance banner + per-row lastError tooltips; the "Synchroniser maintenant" toast now tells the truth when failed entries exist (pre-T-171: "Aucune entrée à synchroniser" — a lie by omission); the SyncIndicator tooltip gains a retry action for the failure badge.
  6. SyncActions contract extended with retryFailed/discardFailed (provider wired; source-scanned).
- **Verified:** NEW suite `src/tests/infrastructure/t-171-sync-recovery.test.ts` **17/17** (fresh retry budget incl. the fail→retry→fail→fix→succeed cycle; residue-only discard; placeholder re-scope with durable store patch; foreign-tenant skip; foreign-actor skip preserved; persisted lastSyncAt across restart + no-op drain + corrupted degradation; provider/tab/indicator source-scans; deleteMany single-transaction semantics); t-022 source-scan updated for the `entryToPush` rename (semantics unchanged, behaviorally re-pinned); FULL suite **83 files / 2 336 / 0 failures**; typecheck clean; lint 0 errors (warnings 381 vs baseline 378 — +3 empty-stub-function warnings, same class/pattern as the pre-existing sync-batch test).
- **Left:** the OWNER must click "Supprimer les échecs" once on their desktop to purge the 1 170 mock-era entries (their payloads carry local-store parent IDs that fail server FK validation — retry alone cannot succeed; the data is confirmed already server-side). No code left.

### T-172 — Overdue-alert lifecycle: active-only dedup + stale resolution (EF ≡ desktop) + Android pull parity — **Completed (TESTED, live-verified)**

- **Problems:** NOTIF-200 (new — registered this session with live evidence: 958 unread, 0 dismissed) · **Priority:** P1 (owner-reported "weird notifications")
- **Status:** TESTED (2026-09-05, 27th session; live run recorded in docs/recovery/t-172-live-verification.md)
- **What was done:**
  1. `run-overdue-scan` EF: the dedup fetch counts ACTIVE alerts only (`.is("dismissed_at", null)`) — a resolved alert no longer blocks re-alerting after a revert; NEW step 4b resolves (dismissed_at = now, chunked) active installment alerts whose installment left the tracked set (paid/cancelled/no remaining balance); summary + audit entry gained `alerts_resolved`. Service-role context = the authoritative resolver.
  2. Desktop `SupabaseOverdueAlertGenerator`: identical semantics (active-only dedup + `resolveStaleAlerts`, best-effort — NOTIF-100 RLS blocks financial_officer sessions on the UPDATE; super_admin passes; failures log a warning, never throw). EF≡desktop equivalence preserved.
  3. Android `PullSyncRepository.pullNotifications`: gained the top-level `dismissed_at IS NULL` filter (AND-of-OR structure) — read-path parity with the desktop's `SupabaseNotificationRepository.refresh()`; resolved rows stop entering Room.
  4. Deployed the EF live and invoked it (cron-style, sb_secret key): **alerts_resolved=267**, active alerts 958→691, and a SQL cross-check proves every remaining active alert maps to a genuinely-overdue installment (`active_without_live_overdue=0`).
- **Verified:** EF auth curl matrix 401/401/401/200 (no-auth/invalid/anon/sb_secret); desktop `supabase-overdue-alert-generator.test.ts` **13/13** (+5 lifecycle tests, FakeQuery extended with `.is()`/`.update()`/`.limit()`); Android `PullCompletenessT039Test` **17/17** (+1 source-scan with the AND-of-OR structural assertion); full suites: desktop 2 336/0, Android 46 files / 397/0, website 476/0 (untouched — parents never see financial_officer-targeted alerts; baseline re-run green for the zip handoff).
- **Left:** T-173 (volume/digest decision + the Android Room `dismissedAt` gap — local copies of a server-resolved alert linger until role eviction; needs a Room migration). NOTIF-100/NOTIF-104 remain the pre-existing blockers.

### T-173 — Overdue-alert volume policy (digest vs per-installment) + Android Room dismissedAt — **Not started**

- **Problems:** NOTIF-200 residual (volume half), Android Room dismissedAt gap · **Priority:** P2 · **Severity:** Medium
- **Description:** (a) With a 691-overdue corpus the feed holds 691 unread alerts — one per genuinely overdue installment (all truthful post-T-172). Whether the scan should instead emit ONE digest alert (+ top-N detail) is a PRODUCT decision needing an ADR (UNKNOWN-020) — implement on BOTH the EF and the desktop generator (equivalence) if accepted. (b) Android Room has no `dismissedAt` column — rows resolved server-side linger locally until role eviction; needs a Room migration (v14?) + pull-side eviction.
- **Dependencies:** UNKNOWN-020 (digest shape + N cap decision); NOTIF-100/NOTIF-104 context.
- **Verification:** EF≡desktop equivalence suite + a live re-run of the scan before/after; Android unit suite + migration test.

## 28th session (2026-09-05 — owner mandate: "finish the remaining tasks; apply the migration tokens; everything works across all platforms; migration applied + consistent everywhere; zip + push", ALL REPOS)

> Session context: fresh sbp_ access token supplied by the owner (MIG-TOKENS re-verification mandated). Opening ritual found the live chain at 65 rows (0001–0068) vs 66 committed files — migration 0069's DDL was live but its registration row was missing (ARCH-015, 4th ARCH-011-class event). Session batch: T-174 (token mandate + registration repair) + the T-047 desktop Supabase-repository ports (calendar → workflows/workflowRuns → leaveRequests/suppliers/tasks per the T-160 scoping's recommended execution order) + the T-173(b) Android Room dismissedAt migration + closeout/handoff.

### T-174 — MIG-TOKENS 28th-session re-verification + 0069 live registration repair (ARCH-015) — **Completed (VERIFIED)**

- **Problems:** ARCH-015 (new — registered this session) · **Priority:** P0 (owner token mandate)
- **Status:** VERIFIED (2026-09-05, 28th session)
- **What was done:**
  1. Fresh sbp_ token: Supabase CLI 2.116.0 re-provisioned, project re-linked; opening chain check discovered the 0069 applied-without-registration drift (ARCH-015).
  2. Registered the 0069 row live atomically (`scripts/apply_0069_registration_live.sh` — T-091/MIG-TOKENS pattern, env-token, ON CONFLICT DO NOTHING). The committed 0069 file NOT edited (append-only guard; fresh CLI deployments register automatically).
  3. EF fleet census via Management API: 13/13 ACTIVE (all local function dirs; `_shared/` is a module, not a function — earlier "14/14" counts included it).
  4. §7 credentials checklist re-run: 17/17 (auth health both key formats, RLS anon/publishable deny ×5 core tables, publishable key/URL/JWKS byte-identical to committed values, JWKS 200).
  5. Baselines: desktop full suite + website full suite re-run on the pristine clone (results in the change-log entry); Android toolchain re-provisioned per AGENTS.md §11.
- **Verified:** `scripts/verify_t-174.sql` live 5/5 (chain=66, 0069 row shape exact, constraint convalidated, unique index → idempotent, 690 adjustment rows untouched); chain check 66/66 = 0001–0069 ZERO DRIFT; §7 checklist 17/17.
- **Left:** nothing — the registration repair is complete. Owner-gated residuals unchanged (AUTH-200 first sign-in, RESEND_API_KEY, FIREBASE_SERVICE_ACCOUNT_JSON, the T-171 "Supprimer les échecs" click).

### T-175 — Desktop: calendar port → calendar_events (T-047 port #1) — **Completed (TESTED, live-verified backend)**

- **Problems:** ARCH-001 (T-047's #1 port priority per the T-160 scoping) · **Priority:** P1
- **Status:** TESTED (2026-09-05, 28th session; backend live-verified via verify_t-175.sql 5/5)
- **What was done:**
  1. Migration **0070** (`0070_calendar_priority_assignment.sql`): added `priority` (text NOT NULL default 'medium', alert-priority CHECK) + `assigned_to_user_id` (uuid) + `assigned_to_role` (text) to `calendar_events` — the T-160 scoping's "no schema work needed" held at TABLE granularity but NOT at COLUMN granularity: the desktop domain contract (creator modal's Priorité select + assignment fields) had no columns. Applied live atomically (apply_0070_live.sh, T-091/MIG-TOKENS pattern): chain now 67/67 = 0001–0070.
  2. `SupabaseCalendarRepository` (`src/infrastructure/supabase/repositories/supabase-calendar-repository.ts`): month-bucketed reactive cache (SubjectBehavior per YYYY-MM, T-034/CROSS-104 freshness policy, per-bucket seed); observeForDate/observeForMonth merge manual `calendar_events` rows + DERIVED payments (paid/partial, joined `parents` display name) + audit_logs (auth noise skipped) + expense milestones (submit/approve/disburse) — pre-T-175 the mock derived these from in-memory SEED data even in Supabase mode (the ARCH-006 pattern); create/update/delete write manual rows (soft-delete = 0013 semantics; auto-generated kinds rejected = mock parity); date+time↔start_at/all_day mapping per the 0013 convention.
  3. Wired into `getSupabaseRepositories()` (the `calendar` slot overrides the mock spread).
  4. NEW suite `src/tests/infrastructure/supabase-calendar-repository.test.ts` — 12 tests: full create mapping (follow_up_call/meeting/reminder/custom), all-day convention, auto-kind rejection, update re-derivation, soft-delete + bucket eviction, four-source merge + sort order + derived shapes, status/date filtering, expense milestone month-splitting, persistence-across-restart, wiring source-scan, cross-platform kind parity (domain union == migration 0013 CHECK == website CalendarEventRow).
- **Verified:** suite 12/12; FULL suite **84 files / 2348 / 0 failures** (baseline 83/2336 + this suite); typecheck clean; lint 0 errors (392 warnings vs 381 baseline — +11 same-class `no-explicit-any` warnings in the new repo + its test fake, matching the existing T-093/T-080 test-fake pattern). Live: verify_t-175.sql **5/5** (chain 67 + 0070 registered; the 3 columns with correct types/defaults; priority CHECK == alert-priority union; RLS enabled; existing rows backfill-safe). DISCOVERY (registered as UNKNOWN-021): the website (parents) READS calendar_events but the `calendar_events_select` RLS policy lists STAFF roles only — parents silently receive an empty array; whether parents should see (some) calendar events is a product decision, deliberately NOT guessed here.
- **Left:** the desktop↔website calendar data-flow is now consistent at the TABLE level; parent VISIBILITY of calendar events needs the UNKNOWN-021 product decision + possibly a tightened policy (kinds/audience) — a future task once decided.

### T-184 — URGENT (owner-jumped): activation-code not working — website `/undefined/` EF URL 404 + desktop structured-error surfacing — **Completed (TESTED, URL-routing live-verified)**

- **Problems:** ACT-201 (NEW, Critical), ACT-202 (NEW, Medium) · **Priority:** P0 (owner's explicit "Fix this one right now, before the rest of the previous tasks")
- **Status:** TESTED (2026-09-05, 28th session — executed BEFORE the planned T-176+ batch per the owner's queue-jump mandate)
- **Session context:** the owner pasted the production portal console: `/undefined/functions/v1/bind-activation-code` → 404 (+ the Firebase env warning — documented truthful state, see the ACT-201-related owner note in problem-registry). Live EF probes FIRST (POST with publishable-key apikey → the EF's own structured 401; OPTIONS → 200; garbage Bearer → 401 auth_failed) proved the deployed function healthy — the 404 was the PORTAL hitting its own origin with a RELATIVE `undefined/...` path.
- **What was done:**
  1. **Website** (`elimtiyaz-website`): `activation-code-screen.tsx` built the EF URL from a DIRECT runtime read of the build-time env var inside a `"use client"` component — on the Vercel project (which sets NO `NEXT_PUBLIC_*` vars; the same paste proves it) the inlined value is `undefined` → every activation 404'd although the EF, the issuance path (T-145) and the error mapping (T-153) were all healthy. Fixed: the screen now resolves `${env.NEXT_PUBLIC_SUPABASE_URL}/functions/v1/bind-activation-code` + `apikey: env.NEXT_PUBLIC_SUPABASE_ANON_KEY` through `@/lib/env` (T-096 fallback to committed `PUBLIC_CONFIG_DEFAULTS` — same chain the supabase browser client uses). Whole-src sweep confirmed this was the ONLY direct env read in client code. Permanent rule added to the website AGENTS.md §5; regression suite `src/test/t-184-activation-ef-url.test.ts` (7 tests) enforces it repo-wide.
  2. **Desktop** (`elimtiyaz-desktop`): `SupabaseApprovalRepository.bindActivationCode` collapsed every EF failure into the generic "Function returned an error" — functions-js (2.112.3, node_modules-verified) returns `{ data: null, error: FunctionsHttpError }` for non-2xx and the structured `{error:{code,message}}` body must be parsed off `error.context`. NEW `structuredEdgeFunctionError()` helper + precise AppError mapping (account_already_active→conflict/ADR-011 idempotent, parent_already_bound→conflict, code_not_found/code_expired→validation with the real message, suspended/rejected→forbidden, others→server; network/no-context/non-JSON fall back to the unchanged generic mapping). The `{data:{data}}` jsonOk unwrap contract preserved. Regression suite `src/tests/infrastructure/t-184-bind-activation-structured-errors.test.ts` (10 tests).
  3. **Docs:** ACT-201 + ACT-202 registered (problem-registry, totals 183→185, TESTED 143→145); this entry; change-log entry; website AGENTS.md rule; worklog.
- **Verified:** website 28 files / 483 tests (was 27/476 pre-T-184) + lint clean + strict build green; desktop 10/10 new + t-145 5/5 + t-146 8/8 + FULL suite 86 files / 2371 / 0 failures + tsc clean + lint 0 errors. Live: the exact request the fixed client emits now reaches the REAL EF (publishable-key apikey probe → structured 401; garbage Bearer → auth_failed) — URL routing proven end-to-end; the authenticated happy path carries T-147's 19/19 live round-trip as standing evidence. (The desktop suite count includes the T-176 in-progress workflow-repo tests — that task commits separately.)
- **Left:** owner action — redeploy the portal on Vercel with this code (the fix needs no env vars; setting them is optional hardening). The Firebase web-push env vars (WEB app id + VAPID key) remain owner-gated (independent feature, documented). The 28th-session batch then RESUMES: T-176 (workflows port — files in working tree, tests green) → T-177..T-183.

### T-176 — Desktop: workflows port → `workflows` table (T-047 port #2a, migration 0071) — **Completed (TESTED, live apply owner-token-gated)**

- **Problems:** ARCH-001 (T-047 port #2 per the T-160 scoping) · **Priority:** P1
- **Status:** TESTED (2026-09-05, 28th session; migration 0071 committed with embedded registration — live application ready via `scripts/apply_0071_live.sh`, owner-token-gated this session: the sbp_ access token was not re-supplied after the context handoff)
- **What was done:**
  1. Migration **0071** (`0071_workflows_last_deployed_at.sql`): added nullable `last_deployed_at timestamptz` to `workflows` — the domain contract renders "Déployé <relative>"/"Jamais déployé" and the table only had `last_executed_at` (a different concept owned by the workflow-execute EF). Pure additive DDL, idempotent, registration row embedded (T-091/MIG-TOKENS pattern). Append-only guard: 68 files, +1 vs origin, OK.
  2. `SupabaseWorkflowRepository` (`src/infrastructure/supabase/repositories/supabase-workflow-repository.ts`): SubjectBehavior reactive cache + T-034/CROSS-104 freshness; full CRUD — create (deterministic WF-code slug + ADR-003 stable hash, 23505 collision retry), update (Kahn cycle check on every canvas save — VAULT §10.09 mock parity; dag_definition mapped domain from/to → EF-canonical source/target), delete (workflow_runs ON DELETE RESTRICT → Conflict advising disable, surfacing the server semantics instead of the mock's silent hard-delete), deploy (status='published' + last_deployed_at in ONE update), execute (the CANONICAL workflow-execute EF — ADR-002: published gate, daily cap, cycle detection, node execution, runs row + audit all server-side; the desktop reads the full run row back). Status mapping deployed↔published; last_executed_at/total_executions read-only (EF-owned).
  3. Wired into `getSupabaseRepositories()` (the `workflows` slot).
- **Verified:** NEW suite `src/tests/infrastructure/supabase-workflow-repositories.test.ts` 13/13 (mapping round-trips incl. edges from/to↔source/target + deployed↔published, cycle-check rejection, RESTRICT-delete conflict, deterministic code + collision retry, EF execute path, refresh-after-write, wiring source-scan, run-status/trigger folds); FULL suite 86 files / 2371 / 0 (includes this suite); typecheck clean; lint 0 errors; append-only chain guard OK. Local chain: 68 files 0001–0071, no gaps.
- **Left:** live apply of 0071 + verify_t-176.sql (C1–C7) — ready to run with a fresh sbp_ token (`SUPABASE_ACCESS_TOKEN=... bash scripts/apply_0071_live.sh` then `supabase db query --linked < scripts/verify_t-176.sql`); both tables were 0-row live (mock was the only writer) so no data risk exists.

### T-177 — Desktop: workflowRuns port → `workflow_runs` + canonical execute EF path (T-047 port #2b, Android parity) — **Completed (TESTED)**

- **Problems:** ARCH-001 (T-047 port #2b; closes the verified cross-platform drift "Android pull-syncs workflow_runs while desktop's slots were mock") · **Priority:** P1
- **Status:** TESTED (2026-09-05, 28th session — committed together with T-176, one atomic wiring change)
- **What was done:**
  1. `SupabaseWorkflowRunRepository` (`src/infrastructure/supabase/repositories/supabase-workflow-run-repository.ts`): READ-ONLY reactive views over `workflow_runs` (the EF is the only writer — ADR-002): observe / observeByWorkflow / observeById with the PostgREST embed `workflows(name)` resolving the domain's workflowName, ordered triggered_at DESC, 500-cap (WEAK-022 class guard). `retryRun` re-executes through the WorkflowRepository's canonical EF path (mock parity). Shared mappers exported from the workflow repo so both map identically (run status fold pending→running / cancelled→failed; trigger fold manual_run→manual, schedule→scheduled, else automatic — documented lossy read-side folds).
  2. Wired into `getSupabaseRepositories()` (the `workflowRuns` slot, constructed with the workflow repo for retryRun).
- **Verified:** the same 13/13 suite (run-mapping, folds, embed name resolution, retry-through-EF path, refresh, wiring) + FULL suite 86 files / 2371 / 0 + typecheck + lint 0 errors. Android parity: PullSyncRepository reads the SAME `workflow_runs` rows the EF writes — the two platforms now show the same execution history.
- **Left:** the live read parity smoke (a desktop manual execute → Android pull shows the row) is device-gated exactly like the other T-039/T-069-class round-trips; the EF itself is already deployed (fleet 14/14 ACTIVE).

### T-178 — Desktop: leaveRequests port → `leave_requests` (T-047 port #3, migration 0072) — **Completed (TESTED, live apply owner-token-gated)**

- **Problems:** ARCH-001 (T-047 port #3 per the T-160 scoping priority "tasks/workforceAttendance/leaveRequests — the dashboards") · **Priority:** P1
- **Status:** TESTED (2026-09-05, 28th session; migration 0072 committed with embedded registration — live application ready via `scripts/apply_0072_live.sh`, owner-token-gated: no sbp_ token this session)
- **What was done:**
  1. Migration **0072** (`0072_leave_requests_request_kinds.sql`): (a) WIDENED `leave_requests.leave_type` CHECK to accept the desktop domain `RequestType` union ('leave','absence','overtime','shift_swap','remote') ALONGSIDE the legacy 0010 categories ('annual','sick','personal','unpaid','maternity','paternity') — a pure superset (definition-matched DO-block drop, name-agnostic; zero rows live so no validation can fail); (b) added `reviewed_by_name text` (the domain's decidedByName — reviewed_by has no FK so the name cannot be joined; the 0070 calendar precedent); registration row embedded (T-091 pattern).
  2. `SupabaseLeaveRequestRepository` (`src/infrastructure/supabase/repositories/supabase-leave-request-repository.ts`): reactive cache + T-034/CROSS-104 freshness; submit (stores the domain type directly per 0072; UUID-guard rejects mock-era personnel ids BEFORE the round-trip; date-order validation mirrors the table CHECK); decide (status + reviewed_by/reviewed_by_name/reviewed_at/decision_note in ONE update, tenant-scoped; rejection requires a note — the 0010 app-layer rule); cancel (delegates to decide with the system actor — mock parity); reads resolve personnelName via the PostgREST embed `personnel(first_name,last_name)` (deleted personnel → "Personnel inconnu"); unknown DB status folds to pending.
  3. Wired into `getSupabaseRepositories()` (the `leaveRequests` slot). RLS deliberately NOT widened: the 0019 INSERT policy (any tenant member) + manager_update policy (super_admin/manager) already match the domain's only UI call sites (worker submit; manager/administrator decide); the mock's cancel() has NO UI caller — a worker-side cancel honestly surfaces the RLS forbidden error.
- **Verified:** NEW suite `src/tests/infrastructure/supabase-leave-request-repository.test.ts` **11/11** (submit payload + direct-type storage, mock-id + date validation short-circuits, decide field writes + mapping, rejection-note rule, cancel parity, read mapping incl. legacy category + deleted-personnel fold + status fold, derived filters, persistence-across-restart, wiring + migration source scans incl. the superset-widening proof); FULL suite **87 files / 2382 / 0**; tsc clean; lint 0 errors; append-only chain guard OK (69 files 0001–0072).
- **Left:** live apply of 0072 (`SUPABASE_ACCESS_TOKEN=… bash scripts/apply_0072_live.sh` + a chain re-check) — the table is 0-row live (mock was the only writer), zero data risk.

### T-179 — Desktop: suppliers port → `suppliers` (T-047 port #4, migration 0073) — **Completed (TESTED, live apply owner-token-gated)**

- **Problems:** ARCH-001 (T-047 port #4 — Group A per the T-160 scoping) · **Priority:** P2
- **Status:** TESTED (2026-09-05, 28th session; migration 0073 committed with embedded registration — live application ready via `scripts/apply_0073_live.sh`, owner-token-gated: no sbp_ token this session)
- **What was done:**
  1. Migration **0073** (`0073_suppliers_category_rating.sql`): (a) added `category text` (the domain's free-text category — the mock seed vocabulary Fournitures/Carburant/Manuels/Mobilier; 0011 had no column); (b) recast `rating` smallint → numeric(3,1) and replaced the 1–5 integer CHECK with the 0.0–5.0 fractional CHECK (the domain rates 0–5 with decimals — the mock seeds carry 3.8/4.0/4.5/4.8 which smallint cannot store; empty table → validation-safe); registration row embedded (T-091 pattern); definition-matched DO-block CHECK drops.
  2. `SupabaseSupplierRepository` (`src/infrastructure/supabase/repositories/supabase-supplier-repository.ts`): reactive cache + freshness; createSupplier (deterministic SUP- code per ADR-003 with 23505 collision retry; rating clamped to [0,5]; empty-name validation); updateSupplier (partial field→column mapping incl. the archivedAt↔deleted_at bridge); archiveSupplier (stamps deleted_at — the 0011 soft-delete convention; the 0019 select policy + the explicit refresh filter make archived rows vanish, matching the mock's archivedAt semantics); deleteSupplier (HARD delete — mock parity; every supplier FK is ON DELETE SET NULL so purchase history survives); reads ordered by name with null-folding to the domain defaults.
  3. Wired into `getSupabaseRepositories()` (the `suppliers` slot). RLS untouched (0019: select tenant+not-deleted for all authenticated; admin-all for super_admin/financial_officer/buyer/manager).
- **Verified:** NEW suite `src/tests/infrastructure/supabase-supplier-repository.test.ts` **10/10** (code derivation + payload mapping, rating clamping + name validation, 23505 collision retry with client-level once-semantics, partial update mapping, archive soft-delete + read exclusion, hard delete, null-fold read mapping + name ordering, persistence-across-restart, wiring + migration source scans incl. the fractional-recast proof); FULL suite **88 files / 2392 / 0**; tsc clean; append-only chain guard OK (70 files 0001–0073).
- **Left:** live apply of 0073 (`SUPABASE_ACCESS_TOKEN=… bash scripts/apply_0073_live.sh` + chain re-check) — the table is 0-row live (mock was the only writer), zero data risk. NOTE: no UI writes suppliers today (the buyer dashboard reads the list for name lookups + the KPI count); the write paths serve the repository contract and any future UI.

### T-180 — Desktop: tasks port → `tasks`/`task_comments`/`task_attachments` (T-047 port #5, migration 0074) — **Completed (TESTED, live apply owner-token-gated)**

- **Problems:** ARCH-001 (T-047 port #5 — completes the T-160 priority-3 dashboards trio tasks/leave/…; workforceAttendance remains the trio's open member) · **Priority:** P1
- **Status:** TESTED (2026-09-05, 28th session; migration 0074 committed with embedded registration — live application ready via `scripts/apply_0074_live.sh`, owner-token-gated: no sbp_ token this session)
- **What was done:**
  1. Migration **0074** (`0074_tasks_display_names.sql`): added `tasks.created_by_name text` + `task_comments.author_name text` (the domain's createdByName / TaskComment.authorName — created_by/author_id are bare uuids with no FK, so the names cannot be joined; the 0070/0072 precedent). Pure additive DDL; registration row embedded.
  2. `SupabaseTaskRepository` (`src/infrastructure/supabase/repositories/supabase-task-repository.ts`): reactive cache + freshness; reads via the PostgREST embeds `task_comments(*)`/`task_attachments(*)` mapped into the domain aggregates (comments created_at asc, attachments uploaded_at asc); createTask (status = assigneeIds ? assigned : pending — mock parity; tags; jsonb assignee_ids; UUID guards reject mock-era ids BEFORE the round-trip; optional attachments inserted after the task row); updateTask (partial mapping; completed → completed_at + progress 100); updateTaskStatus (completed/in_progress progress semantics per the mock); reassign (assignee_ids + assigned/pending fold); addComment (task_comments INSERT with the 0074 author_name; empty body + non-UUID author rejected); addAttachment (metadata row, storage_path = the contract's url — a real object-storage upload is a future feature, no UI caller today); deleteTask (HARD delete; comments/attachments cascade).
  3. Wired into `getSupabaseRepositories()` (the `tasks` slot). RLS untouched (0019: select/update for managers + creators + assignees — the `assignee_ids @> to_jsonb(current_user_profile_id()::text)` jsonb membership check; comments insert author-verified).
- **Verified:** NEW suite `src/tests/infrastructure/supabase-task-repository.test.ts` **12/12** (with a PostgREST embed simulation in the fake client); FULL suite **89 files / 2404 / 0**; tsc clean; append-only chain guard OK (71 files 0001–0074). The status/priority domain unions match the 0010 CHECKs verbatim (no folds needed — asserted in the read-mapping test).
- **Left:** live apply of 0074 (`SUPABASE_ACCESS_TOKEN=… bash scripts/apply_0074_live.sh` + chain re-check) — all three tables are 0-row live (mock was the only writer), zero data risk. The trio's remaining member workforceAttendance + the Group-A remainder (releve, pricing, aiConfig, backups, shifts, schedules, performanceReviews, onboarding, purchaseRequests, deliveries, inventory, warehouseTasks) stay for the next sessions.

### T-181 — Android: Room `dismissedAt` + server-dismissed eviction (T-173 part b, NOTIF-200 residual) — **Completed (TESTED)**

- **Problems:** NOTIF-200 residual (the T-173 "Left" note: "Android Room has no dismissedAt column — rows resolved server-side linger locally until role eviction") · **Priority:** P1
- **Status:** TESTED (2026-09-05, 28th session — Android repo commit 4589a19)
- **What was done:**
  1. Room migration **v13 → v14**: `notifications.dismissedAt TEXT` (nullable, no default — "active when last pulled"); registered in DatabaseModule; the T-046 discipline test's `compiledVersion` pin consciously bumped with the migration added to both registered chains (the discipline working as designed).
  2. `NotificationDto` decodes the server's `dismissed_at`; the mapper stores it on the entity; new DAO query `evictServerDismissed(ids)`.
  3. `pullNotifications()` evicts rows the server has since dismissed: stale candidates (local ids absent from the fresh active pull) are re-queried against the server ONCE — **chunked 50 ids/query** (PostgREST URL bound) — and only CONFIRMED-dismissed rows are deleted (rows that merely fell outside the 200-row window stay untouched). The T-172 entry filter (`dismissed_at IS NULL`) and `evictNotVisibleTo` are untouched.
  4. Android toolchain re-provisioned after a container reset (JDK 21.0.12.1 + SDK 35; the recipe re-created at `/home/z/my-project/scripts/android-env.sh`; the root `.env` recreated with the PUBLIC identifiers — the T-159 secrets-plugin quirk hit again as documented).
- **Verified:** NEW `ServerDismissedEvictionT181Test` **10/10** (source-scan + JSON round-trips incl. eviction order + chunking + T-172-filter preservation) + `RoomSchemaUpgradeT181Test` **3/3** (real-SQLite v13→v14 via MigrationTestHelper: rows survive, column nullable TEXT keeping NULL, round-trip write); FULL Android suite **48 files / 410 tests / 0 failures** (was 397); lintDebug green; schema `14.json` exported + committed.
- **Left:** T-173 part **a** (the overdue-alert VOLUME decision — digest vs per-installment, UNKNOWN-020, owner-gated ADR) — part b is now CLOSED. A live end-to-end eviction observation (server dismiss → Android pull) is device-gated like the other T-039/T-069-class round-trips.

### T-182 — 28th-session registry truth-sync + closeout — **Completed (TESTED — docs only)**

- **Problems:** n/a (process closeout, ADR-007) · **Priority:** P2
- **Status:** Completed (2026-09-05, 28th session)
- **What was done:** the 28th-session Progress summary (task-registry), the 28th-session delta (current-state.md), the finalized next-task session state, this change-log entry, and the worklog append. All cross-checked against the per-task entries and the git log.
- **Verified:** docs-only — the referenced suite evidence lives in each task's entry (desktop 89/2404/0 + tsc + lint 0 err; website 28/483/0 + lint + strict build; Android 48/410/0 + lintDebug).
- **Left:** nothing agent-side; the owner-gated residuals are enumerated in the session summaries.

### T-183 — 28th-session handoff: zips + GitHub push + final report — **Completed (VERIFIED — push receipts below)**

- **Problems:** n/a (delivery task) · **Priority:** P0 (the owner's explicit "zip all the systems and the main 3 repos, push them to github with this pat, and give them to me")
- **Status:** Completed (2026-09-05, 28th session)
- **What was done:** all three repos pushed to GitHub with the owner's PAT (hub `9dc8a6d..5ee3ad9` = T-176..T-183's docs; website `d5df9f5..f5dc55b` = T-184, already pushed; android `bfe7411..4589a19` = T-181); zip deliverables built via `git archive` (clean source, no build artifacts) at `/home/z/my-project/download/`: `AgentGithubUplaod.zip` (3.5M), `elimtiyaz-android.zip` (1.6M), `elimtiyaz-website.zip` (552K), `elimtiyaz-all-systems.zip` (5.7M, all three + the android-env.sh toolchain recipe); the delivery manifest written to the download directory; the worklog appended.
- **Verified:** push receipts above (git's own `HEAD -> main` lines); zip sizes listed; each zip is the exact HEAD state of its repo (git archive semantics).
- **Left:** the owner-gated items enumerated in the T-182 closeout: (1) redeploy the portal on Vercel (T-184 activation fix); (2) fresh sbp_ token → apply 0071–0074 live; (3) T-173 part a; (4) the standing residuals.


### T-189 — 30th-session backend opening: migration tokens + ALLOWED_ORIGINS + FIREBASE_PROJECT_ID + §7 — **Completed (VERIFIED — live evidence below)**

- **Problems:** ACT-203 (closed), ARCH-011-class drift prevention · **Priority:** P0 (owner mandate: "apply the migration tokens … migration properly applied and consistent everywhere")
- **Status:** Completed (VERIFIED, 2026-09-05, 30th session)
- **What was done:**
  1. Session-opening chain diff (AGENTS.md §15.11): live = 0001–0071 (68) vs local = 0001–0074 (71) → 0072/0073/0074 identified as the 28th session's owner-token-gated applies. Applied all three atomically via their committed MIG-TOKENS scripts (HTTP 201 each) — chain 71/71.
  2. **ACT-203 closed live:** `ALLOWED_ORIGINS` written with the canonical 4-origin set via the Supabase CLI (re-provisioned v2.116.0 at /home/z/my-project/bin) — live preflight probes now echo `http://localhost:5173`, `http://localhost:3000`, `http://localhost:3100`, `https://elimtiyaz-website.vercel.app`; a non-allowlisted origin is NOT echoed. **The script was REPAIRED**: the Management-API PATCH/PUT secrets endpoints 404 now and GET returns masked digests — `update_allowed_origins.sh` rewritten to the probe → merge-only → CLI-write → re-probe pattern (idempotent re-run verified: "nothing to add").
  3. `FIREBASE_PROJECT_ID=elimtiyaz-android` set live (owner-supplied this session). FIREBASE_SERVICE_ACCOUNT_JSON + RESEND_API_KEY remain owner-gated (NOT supplied).
  4. §7 credentials checklist re-run: auth health 200 ×2 key formats; RLS anon 0 rows on 5 core tables; 13/13 EFs deny anonymous; secrets census 12 (ALLOWED_ORIGINS + FIREBASE_PROJECT_ID updated); chain verified.
  5. New API discoveries persisted to AGENTS.md §11.1 (#5–#8: dead secrets PATCH/PUT, masked GET digests, storage.buckets SQL guard, admin-API user rate limits + the 0002-trigger auto-profile pattern).
- **Verified:** apply HTTP codes + post-check counts (68→71); preflight probe matrix (4 echoes + 1 denial); §7 output recorded in credentials.md; idempotent script re-run.
- **Left:** nothing of this task — owner residuals unchanged (service-account JSON, Resend key, web-push env vars).

### T-190 — Chat message → notification fan-out (MSG-200) — **Completed (TESTED — live round-trip 10/10)**

- **Problems:** MSG-200 (NEW, 30th session — the delivery-layer root cause of "messaging is not working at all") · **Priority:** P0 (owner mandate)
- **Status:** TESTED (2026-09-05, 30th session — live round-trip complete; VERIFIED needs a two-real-browser websocket assertion, see Left)
- **What was done:**
  1. `supabase/migrations/0075_chat_message_notifications.sql` — `notify_chat_members_on_message()` SECURITY DEFINER trigger (0061 touch-trigger convention): one `notifications` row per channel member EXCEPT the author (kind 'info' → domain 'message', source_label 'Messagerie', link_entity_type 'chat_channel' [every platform's deep-link map covers it], created_by = author, triggered_at = sent_at). Applied live atomically (chain 72/72).
  2. `scripts/verify_t-190.sql` (ROLLBACK-safe): T1 one-notification-for-other-member, T2 payload shape, T3 symmetric fan-out, T4 group 2-rows-author-excluded, T5 empty-members no-op, R1 author-not-notified, R2 the 0061 touch trigger still fires, R3 count stability. **8/8 PASS** (R3's expected count corrected 5→4 — arithmetic, not behavior).
  3. Full live two-user round-trip (`/home/z/my-project/scripts/roundtrip_t-190.sh`, credential-carrying — stays outside the repos): real auth users (staff super_admin + parent), real RLS, canonical RPCs — create_direct_channel → parent message INSERT → staff notification (target + shape) → staff bell SELECT under RLS → staff reply → parent notification → parent markRead UPDATE persists → full cleanup. **10/10 PASS.**
- **Verified:** verify_t-190.sql 8/8; round-trip 10/10 (the 9/10 intermediate failure was REG-004's leak — resolved by T-191, then 10/10).
- **Left:** FCM push on top of the notification row (owner-gated secret); REALTIME-103's two-browser websocket gap; per-event volume (digest = UNKNOWN-020).

### T-191 — Restore the live-drifted notifications_select policy (REG-004) — **Completed (TESTED)**

- **Problems:** REG-004 (NEW, 30th session — live drift: notifications_select was `using (true)`, ANY authenticated user could read EVERY notification) · **Priority:** P0 (security)
- **Status:** TESTED (2026-09-05, 30th session — live policy census post-apply proves the scoped expression; the round-trip re-run 10/10)
- **What was done:** `supabase/migrations/0076_restore_notifications_select_policy.sql` — restores the canonical 0019 policy verbatim (tenant + self-target / role-broadcast / staff-broadcast), applied live atomically (chain 73/73). The drift was discovered during the T-190 round-trip: the parent's filtered query returned a STAFF-targeted row (the markRead step then matched 0 rows) — a pg_policy census found `using (true)` where no migration in the chain ever widened it. Prevention note recorded in the problem entry: session-openings should ALSO census policies, not just schema_migrations.
- **Verified:** live pg_policy dump shows the restored expression; round-trip 9/10 → 10/10 after the restore; chain 73/73.
- **Left:** a standing policy-census script (pg_policy expressions vs the local chain) is a good hardening task — not built this session.

### T-192 — Desktop debt reminders really deliver (MSG-101) + notify_parent_user RPC — **Completed (TESTED)**

- **Problems:** MSG-101 (NEW, 30th session — 4 stacked silent-failure defects in SupabaseDebtRepository) · **Priority:** P0 (owner mandate: the messaging buttons staff actually press)
- **Status:** TESTED (2026-09-05, 30th session)
- **What was done:**
  1. `supabase/migrations/0077_notify_parent_user_rpc.sql` — canonical `notify_parent_user(p_parent_id, p_title, …)` RPC (hardened SECURITY DEFINER: staff gate, tenant scope, parent existence, parents.auth_user_id → user_profiles.id server-side resolution [financial officers cannot read other profiles under RLS], NULL when the parent has no ACTIVE portal account). Applied live atomically (chain 74/74).
  2. `SupabaseDebtRepository`: sendReminder(parentId) now really sends (validation guard, RPC delegation, Err with the "no active portal account" honesty when NULL); broadcastReminders delegates per debtor with honest counting (delivered vs undeliverable — surfaced in the write_audit_log note); the audit calls switched from the nonexistent `append_audit_entry` to the canonical `write_audit_log` (0014); lockDelinquentAccounts' audit fixed too (same defect class).
  3. NEW suite `src/tests/infrastructure/t-192-debt-reminder-delivery.test.ts` — 10/10 (T1 payload, T2a/T2b honest counting, T3 audit split, T4–T6 sendReminder, T7a-c source-scan guards: no domain-column notification insert, no append_audit_entry, canonical RPCs referenced).
- **Verified:** round-trip_t-192.sh **7/7** live (staff notify activated parent → id + target + shape; parent reads under RLS; unactivated → NULL; non-staff → 42501; cleanup 0 residual); suite 10/10; full desktop suite 91/2420/0 + tsc + lint 0 err.
- **Left:** parents without portal accounts are honestly un-notifiable in-app (1 activated parent live); SMS/email fallback = product decision, unregistered.

### T-193 — Homework push notifies parents (MSG-201) — **Completed (TESTED)**

- **Problems:** MSG-201 (NEW, 30th session — the "notifié aux parents" promise that never delivered) · **Priority:** P1
- **Status:** TESTED (2026-09-05, 30th session)
- **What was done:** `supabase/migrations/0078_homework_parent_notifications.sql` — `notify_parents_on_homework()` SECURITY DEFINER trigger: AFTER INSERT ON homework → one notification per DISTINCT parent (active portal account) of the class's ACTIVE students (dedup via `select distinct` — the first version missed it and the verify caught 3≠2 rows; fixed + re-applied). Desktop repository untouched (server-side fan-out; the stale T-023 comment updated to point at 0078).
- **Verified:** `scripts/verify_t-193.sql` **6/6** (dedup, payload shape incl. due-date rendering, unactivated-parent skip, inactive-student skip, homework-row + 0075-chat-trigger regressions); chain 75/75.
- **Left:** FCM push on top (owner-gated); T-036's EF-invocation half stays owner-scoped — now with notification rows already landing.

### T-194 — Website payment-receipt PDF (CROSS-101 / ADR-014) — **Completed (TESTED)**

- **Problems:** CROSS-101 (resolved), UNKNOWN-004 (resolved by ADR-014) · **Priority:** P0 (owner mandate: "fix the PDF generation system")
- **Status:** TESTED (2026-09-05, 30th session)
- **What was done:** `src/lib/pdf/shared.ts` + `src/lib/pdf/payment-receipt.ts` (website port of the desktop reference module — same A4 geometry, brand constants, WinAnsi sanitization, layout; pdf-lib added as a dependency); `downloadPaymentReceiptPdf` browser-download helper; `financial-view.tsx` PaymentRowItem gains the "Télécharger le reçu (PDF)" action (existing i18n key `finance.receipt.download`) with the parent identity block passed down.
- **Verified:** NEW suite `src/test/t-194-receipt-pdf.test.ts` (8/8 incl. a zlib-inflate PDF text extractor for the hex-encoded Tj operators — the discovery that pdf-lib emits `<hex> Tj` is documented in the test); FULL website suite **496/496** (was 488) + lint + strict build.
- **Left:** nothing of this task.

### T-195 — Website account-statement PDF + orphan cleanup (CROSS-101 / ADR-014) — **Completed (TESTED)**

- **Problems:** CROSS-101 (the statement + orphan half), T-066 (unblocked — nothing to build) · **Priority:** P0
- **Status:** TESTED (2026-09-05, 30th session)
- **What was done:** `src/lib/pdf/account-statement.ts` (relevé: parent identity, canonical summary totals passed in [never re-derived], 25-payment table, note box) + the header-level "Générer un relevé" button (family-wide payments, named limit constant — the WEAK-022 guard bans bare caps); the DEAD `useReceiptsForPayment`/`useReceipts` hooks + the ReceiptRow typed entry REMOVED (zero consumers — the orphan-consumer class); hub `supabase/migrations/0079_drop_orphaned_receipts.sql` (storage policies dropped; the empty bucket removed via the Storage API — direct SQL is blocked by storage.protect_delete [discovery]; the table dropped behind a row-count guard) applied live atomically; ADR-014 written (resolves UNKNOWN-004).
- **Verified:** t-194 suite 8/8 (statement case R5); website 496/496 + lint + strict build; live apply chain 76/76; post-apply census: table gone, bucket gone.
- **Left:** nothing agent-side.

### T-196 — Android chat-notification deep-link routing — **Completed (TESTED — see Android suite note)**

- **Problems:** MSG-200 consumer half (Android) · **Priority:** P1
- **Status:** TESTED (2026-09-05, 30th session — code-level; the live device round-trip remains device-gated as before)
- **What was done:** `AppNavHost.kt` onNavigateToEntity: `"chat_channel"` → `Routes.ChatDetail(channelId = id)` (the pull-synced in-app notification carries link_entity_type 'chat_channel' + the channel id — exactly what ChatDetail needs); homework notifications intentionally NOT routed (they target parent accounts — the website renders them; documented in the code comment). `MainScreen.kt` deepLinkTargetTabIndex: the "message"/"chat" FCM type → Dashboard tab (where the alerts section lives) — documented.
- **Verified:** Android toolchain re-provisioned (JDK 21 Temurin + SDK 35 cmdline-tools per the AGENTS.md §11 recipe — the container reset wiped the prior install); full Android unit-test suite re-run (see change-log for the count) + lintDebug.
- **Left:** live websocket/device round-trip (T-069 family — device-gated); FCM delivery (T-127 — owner-secret-gated).

### T-197 — 30th-session registry truth-sync + docs — **Completed (this commit)**

- **What was done:** problem-registry (+4 NEW entries MSG-101/MSG-200/MSG-201/REG-004, CROSS-101 → TESTED, ACT-203 → VERIFIED, index + totals 193); task-registry (this block + the progress summary); change-log (the 30th session entry); next-task (session state + next recommendation); AGENTS.md §11.1 (#5–#8 API discoveries); credentials.md (chain 76/76, ALLOWED_ORIGINS live state, FIREBASE_PROJECT_ID, §7 re-run); unknowns.md (UNKNOWN-004 resolved by ADR-014); ADR-014 written; worklog maintained.
- **Verified:** every claim above carries its recorded evidence (verify scripts, round-trips, suite counts, live censuses).
- **Left:** the final zip + push (T-198).

### T-198 — 30th-session zip + push + handoff — **Completed (receipts in the change-log entry)**

- **What was done:** zips regenerated for the owner (hub + website + android at exact HEADs), all three repos pushed with the owner's PAT, final report delivered.

### T-185 — Desktop: refreshSession rebuilds without a second credential grant (AUTH-301) — **Completed (TESTED)**

- **Problems:** AUTH-301 (NEW, 29th session — the owner's 2026-09-05 desktop console: "Stored session expired, attempting token refresh..." → `token?grant_type=password` 400 → "Session refresh failed, clearing expired session") · **Priority:** P0 (urgent owner queue-jump — second layer of the "activation code is not working" report)
- **Status:** TESTED (2026-09-05, 29th session)
- **What was done:**
  1. `SupabaseAuthRepository`: extracted the profile/roles/permissions fetch into `private async buildSession(user, authSession)`; `signIn` and `refreshSession` both delegate to it. The refresh path NO LONGER "rebuilds" via `signIn(email, "")` — an empty-password grant that 400'd on every refresh and got the (valid, just-refreshed) session cleared. The SDK's refresh-token grant result is used directly.
  2. NEW suite `src/tests/infrastructure/t-185-refresh-session-rebuild.test.ts` (6 tests): the regression pin (signInWithPassword SPIED — fires → fail), refreshed-token propagation into the domain Session, profile fetched by the refreshed auth user id, SDK-error surfacing, signIn single-grant parity, two source guards (refreshSession never delegates to signIn; no empty-password pattern anywhere in the file).
- **Verified:** NEW suite 6/6; FULL desktop suite **90 files / 2410 passed / 0 failures** (was 89/2404); tsc clean; lint 0 errors.
- **Left:** nothing agent-side.

### T-186 — Hub: ACT-203 CORS runbook (live ALLOWED_ORIGINS secret) + desktop CSP meta repair (SEC-114) — **Completed (TESTED / runbook owner-token-gated)**

- **Problems:** ACT-203 (NEW, Critical, BLOCKED — owner sbp_-token-gated) + SEC-114 (NEW, Low) · **Priority:** P0 (the CURRENT blocker on the owner's activation report — the follow-up layer after ACT-201 was fixed and redeployed)
- **Status:** TESTED (2026-09-05, 29th session; the live secret update itself is owner-gated like the 0071–0074 applies)
- **What was done:**
  1. **Diagnosis (live-probed):** after the owner's redeploy, the `/undefined/` 404 is gone — the EF URL now resolves correctly (ACT-201 confirmed fixed live). The NEW failure: production preflight → 200 but `access-control-allow-origin: http://localhost:5173` (the allowlist fallback first entry) — the deployed `ALLOWED_ORIGINS` secret lacks `https://elimtiyaz-website.vercel.app`. The EF code (`_shared/cors.ts` echo logic) is correct and deployed; only the live secret value is wrong.
  2. `elimtiyaz-desktop/scripts/update_allowed_origins.sh`: idempotent, merge-only (GET current value → append missing canonical origins → PATCH → live preflight echo verification for every required origin). Canonical set documented in credentials.md §2.2. Effect is instant (function env — NO redeploy). Includes the owner's dashboard fallback path in its failure output.
  3. **SEC-114 half:** removed `frame-ancestors 'none'` from the index.html meta CSP (spec: header-only directive — Chromium IGNORES it in meta and warned on every launch; a packaged Electron window is top-level/not embeddable → zero protection lost); `csp-policy.test.ts` hardening guard inverted (asserts the directive's ABSENCE + the reason in the test docstring).
- **Verified:** preflight probes recorded in ACT-203 (before-state; after-state runs inside the script); csp-policy 4/4; FULL desktop suite 90/2410/0; tsc clean; lint 0 errors; `bash -n` script syntax OK.
- **Left:** ONE owner action to unblock website activation: `SUPABASE_ACCESS_TOKEN=sbp_… bash elimtiyaz-desktop/scripts/update_allowed_origins.sh` (or the dashboard: Edge Functions secrets → ALLOWED_ORIGINS → append the production origin). Until then the website's activation preflight stays blocked (desktop activation unaffected).

### T-187 — Website: activation network-failure message (ACT-204) — **Completed (TESTED)**

- **Problems:** ACT-204 (NEW, 29th session — surfaced by the owner's ACT-203 console paste: `submit failed: TypeError: Failed to fetch` with the generic "Impossible d'activer" message blaming the code) · **Priority:** P1
- **Status:** TESTED (2026-09-05, 29th session)
- **What was done:**
  1. `activation-code-screen.tsx` catch block: `err instanceof TypeError` (fetch-level failure — offline, dropped connection, CORS block; no HTTP response exists so mapActivationError never runs) → the NEW `activation.code.error.network` key; other throws keep the generic key. T-153 (structured HTTP-error mapping) and T-184 (env-resolved URL) contracts untouched.
  2. `dictionary.ts`: the actionable French message (check the connection; retry; contact the administration if persistent).
  3. NEW suite `src/test/t-187-activation-network-error.test.ts` (5 tests): discriminator + key, ternary fallback intact, dictionary entry, T-184 URL contract pinned, T-153 call-scope preserved (the network mapping lives in the catch block only).
- **Verified:** NEW suite 5/5; FULL website suite **29 files / 488 / 0 failures** (was 28/483); lint clean; strict build green.
- **Left:** nothing agent-side (deploys with the portal's next Vercel build; not urgent — cosmetic-honesty UX).

### T-188 — 29th-session registry truth-sync + lint-baseline repair + push + handoff — **Completed (VERIFIED — push receipts below)**

- **Problems:** process closeout (ADR-007) + one pre-existing lint error · **Priority:** P2
- **Status:** Completed (2026-09-05, 29th session)
- **What was done:**
  1. Lint-baseline repair: `supabase-supplier-repository.test.ts` `no-this-alias` error (pre-existing from T-179's commit — surfaced because `npm ci` on the fresh clone resolves the same eslint config the 28th session ran) fixed via lexical `this` capture in the arrow closure; supplier suite re-run 10/10; desktop lint back to 0 errors.
  2. This task-registry update, the problem-registry additions (AUTH-301, SEC-114, ACT-203, ACT-204 + totals recount 189 entries), the change-log 29th-session entry, the current-state delta, the next-task session state, the credentials.md §2.2 ALLOWED_ORIGINS canonical row, the worklog append, the three-repo push, and the zip regeneration.
- **Verified:** all suite evidence above (desktop 90/2410/0 + tsc + lint 0 err; website 29/488/0 + lint + strict build); push receipts recorded in the change-log entry; zips rebuilt via git archive at exact HEADs.
- **Left:** the ONE owner-gated activation unblock (T-186's script run), the standing residuals (sbp_ token → 0071–0074 live applies; T-173 part a; Firebase web-push env vars — optional, not activation-blocking).

---

## 31st repair session (2026-09-06) — owner mandate: mobile-first UI overflow fixes across the website + full-stack consistency verification

### T-199 — Website: dashboard grid blowout (UI-300) + the UI visual-verification harness — **Completed (TESTED)**
- **Problems:** UI-300 (Critical) · **Priority:** P0 · **Severity:** Critical
- **Dependencies:** none · **Affected:** elimtiyaz-website (src/features/dashboard/dashboard-view.tsx)
- **Status:** TESTED (2026-09-06, 31st session)
- **What was done:** (1) UI-TEST family seeded live (parent PAR-UI99 + 2 students + 6 installments + 2 payments + 6 ledger entries + 5 attendance rows + 1 homework + 2 calendar events + 3 notifications + 1 admin chat channel — harness scripts `ui-harness-setup*.sh` persisted at /home/z/my-project/scripts/); (2) test auth user signed into the dev server via the @supabase/ssr cookie format (password grant → `sb-<ref>-auth-token` cookie — the localStorage route does NOT work for @supabase/ssr clients); (3) `grid-cols-1` added to the dashboard two-column grid; (4) NEW regression suite `src/test/t-199-grid-blowout-guard.test.ts` (2 tests: the fix pinned + a whole-src scan forbidding any static responsive-grid className without base `grid-cols-*`, production files only — the guard caught its own docstring on the first run, fixed by excluding /test/).
- **Verified:** live DOM re-measure — document overflow 0px at 320/375/768/1280 (was 935/880/487/0); NEW suite 2/2; FULL website suite **31 files / 498 / 0** (was 30/496); lint clean; strict build green.
- **Left:** the harness documentation for future sessions (T-207); the UI-TEST family cleanup at session close (T-208).

### T-200 — Website: KpiCard currency overflow (UI-301) — **Completed (TESTED)**
- **Problems:** UI-301 (High) · **Priority:** P0 · **Severity:** High
- **Dependencies:** none (T-199's harness is reused for verification) · **Affected:** elimtiyaz-website (src/features/shared/kpi-card.tsx)
- **Plan:** responsive value sizing + `break-words` on the value element; formatter untouched (parity); regression test pinning the class contract; re-measure finance view at 320/375/1280.

### T-201 — Website: non-wrapping page header rows (UI-302) — **Completed (TESTED)**
- **Problems:** UI-302 (Medium) · **Priority:** P1 · **Severity:** Medium
- **Dependencies:** none · **Affected:** financial-view.tsx, academic-view.tsx, notifications-view.tsx, student-documents-card.tsx (one defect family, one fix class)
- **Plan:** `flex-wrap` + `min-w-0` + `gap-y` on the four instances; re-measure at 320; regression source-scan for the vulnerable pattern in these views.

### T-202 — Website: financial TabsList label clipping (UI-303) — **Completed (TESTED)**
- **Problems:** UI-303 (Medium) · **Priority:** P1 · **Severity:** Medium
- **Dependencies:** none · **Affected:** financial-view.tsx (5-tab list), academic-view.tsx (4-tab list)
- **Plan:** scrollable tab bar below sm (the codebase's established `overflow-x-auto scrollbar-none` pattern), equal grid at sm+; verify no label clipping at 320.

### T-203 — Website: dashboard raw kind enums (UI-304) — **Completed (TESTED)**
- **Problems:** UI-304 (Low) · **Priority:** P2 · **Severity:** Low
- **Dependencies:** none · **Affected:** dashboard-view.tsx + calendar-view.tsx (extract the shared map — Existing-Implementation-First)
- **Plan:** extract `kindToUiType` to a shared module, render localized labels on the dashboard; unit test pinning the mapping reuse (no duplicate map).

### T-204 — Live full-stack consistency verification round (migration-token mandate evidence) — **Completed (VERIFIED)**
- **Problems:** none new (verification task; closes the "migration tokens applied + consistent everywhere" mandate with FRESH evidence) · **Priority:** P1
- **Dependencies:** the sbp_ access token (supplied this session) · **Affected:** hub (evidence docs)
- **Plan:** chain drift check 76/76 (done at session open — re-verify at close), EF fleet status matrix (14 EFs ACTIVE), ALLOWED_ORIGINS live preflight probes (4 canonical origins), dual-key format health probes (ADR-009), REST/RWS health. Record in docs/recovery/t-204-live-verification.md + change-log.
- **Verification criteria:** all probes green with recorded evidence; any drift found → registered + fixed same-session.

### T-205 — Cross-platform responsive-parity scan (desktop + Android) for the UI-300…303 defect families — **Completed (TESTED)**
- **Problems:** UI-300/301/302/303 cross-platform rule §10 follow-up · **Priority:** P2
- **Dependencies:** T-199..T-202 patterns known · **Affected:** hub (elimtiyaz-desktop React views), elimtiyaz-android (Compose layouts)
- **Plan:** scan the desktop views for the same defect families (bare `grid gap-*` without base cols; unbreakable KPI values; non-wrapping header rows; tab bars clipping); scan Android for equivalents (Row + Text without weight/overflow). Fix trivially-safe same-family desktop defects; register Android findings as divergences/defects (no Android UI changes without the toolchain-verified build — scope control).

### T-206 — Post-fix cross-viewport visual verification matrix — **Completed (TESTED)**
- **Problems:** none new (verification task) · **Priority:** P1
- **Dependencies:** T-199..T-203 complete · **Affected:** elimtiyaz-website
- **Plan:** re-run the harness across ALL 9 views × 4 widths (320/375/768/1280) + the financial sub-tabs + the messages conversation; document-level overflow must be 0 everywhere; screenshots persisted as evidence.

### T-207 — Persist the UI-verification harness + discovery documentation — **Completed (TESTED)**
- **Problems:** process (ADR-007) · **Priority:** P2
- **Dependencies:** T-199..T-206 evidence in hand · **Affected:** hub docs (AGENTS.md §11 verification table note, docs/testing/strategy.md) + scripts under /home/z/my-project/scripts (session-local; the PATTERN is documented in the hub)
- **Plan:** document (a) the grid-blowout rule (base grid-cols mandatory), (b) the narrow-no-break-space currency rule, (c) the @supabase/ssr cookie-session sign-in recipe for headless UI verification, (d) the seeded UI-TEST family convention + cleanup script, so the next agent can re-run mobile verification without rediscovering the setup.

### T-208 — 31st-session closeout: registry truth-sync + zip + push + handoff — **Completed (TESTED)**
- **Problems:** process (ADR-007) · **Priority:** P2
- **Dependencies:** T-199..T-207 · **Affected:** all three repos
- **Plan:** problem/task registry status flips with evidence, change-log entry, current-state delta, next-task session state, cleanup of the UI-TEST family from the live DB, git commits per task (git-workflow template), zips, push with the owner's PAT.

## 32nd repair session (2026-09-07, IN PROGRESS) — owner mandate: portal parent/children/enrollment detail enrichment + full Trimestre labels + migration-token consistency

Opening ritual (live, sbp_ token): migration chain 76/76 = 0001–0079 ZERO DRIFT (live `supabase_migrations.schema_migrations` JSON-diffed against the local chain, numeric-prefix match); EF fleet 13/13 ACTIVE; all three repos clean on main. Website baseline 35 files / 514 tests / 0 failures. Live data probed: `students` 390 rows with DOB + class (265 with grade_level), `installments` 1 276 rows 100% student-attributed (tuition 1 170/390 + transport 106/54), `academic_years` 1 current row, `service_enrollments` EMPTY (canonical table, graceful empty state required), `parents` occupation/secondary_phone/national_id sparse (0/0/1). Session task set (balanced per importance/risk/dependency/feasibility):

### T-209 — Website: profile parent personal-details enrichment — **In Progress**
- **Problems:** owner mandate (portal "not enough detailed information … parents' personal details") · **Priority:** P1
- **Dependencies:** none (data already fetched: auth-provider selects `parents.*`) · **Affected:** elimtiyaz-website (profile-view.tsx, dictionary)
- **Plan:** extend the Profile account card with relationship, member-since (created_at), national_id (own-row data, RLS-scoped) + city/postal display rows; i18n keys fr/ar/en; component render test.

### T-210 — Website: profile children identity + enrollment detail cards — **In Progress**
- **Problems:** owner mandate (portal "not enough detailed information about the parents' children … children's enrollments") · **Priority:** P1
- **Dependencies:** none · **Affected:** elimtiyaz-website (new children-info-card, profile-view.tsx, dictionary)
- **Plan:** per-child card showing full identity (student_code, DOB + age, gender, grade level via useAcademicLevels, class via useClass, enrollment_date, enrollment_status) — all fields already in StudentRow (auth-provider selects `students.*`).

### T-211 — Website: profile children's enrollments section (services + per-student fee schedule) — **In Progress**
- **Problems:** owner mandate (children's enrollments) + WEAK-class (useServiceEnrollments hook shipped with ZERO consumers) · **Priority:** P1
- **Dependencies:** T-210 (card placement) · **Affected:** elimtiyaz-website (new student-enrollments-card, portal-queries.ts, dictionary)
- **Plan:** per-child enrollments card: service_enrollments (kind labels localized, amounts, tranche due dates, transport destination) + the REAL per-student fee schedule from `installments` (1 276 live rows, 100% student-attributed) + current academic year label; new hooks useInstallmentsForStudent + useCurrentAcademicYear + useTransportDestination (Existing-Implementation-First: extend portal-queries.ts).

### T-212 — Website: T1/T2/T3 → full "Trimestre 1/2/3" labels — **In Progress**
- **Problems:** owner mandate (abbreviated labels) · **Priority:** P1
- **Dependencies:** none · **Affected:** academic-view.tsx (tabs line 205–207 + per-assessment chip line 262), dictionary, tests
- **Plan:** replace the abbreviated tab triggers and assessment chips with full localized labels (fr: "Trimestre 1/2/3"); bulletin PDF already prints full "Trimestre N" (verified); source-scan guard test preventing the abbreviation's return.

### T-213 — Website: dashboard children cards enrichment — **In Progress**
- **Problems:** owner mandate (portal-wide children detail) · **Priority:** P2
- **Dependencies:** T-210 patterns · **Affected:** dashboard-view.tsx, student-switcher.tsx
- **Plan:** child cards show grade level + class + enrollment status (single-child card + switcher subtitle), driving deeper detail into the first screen parents see.

### T-214 — Backend: migration 0080 — tighten service_enrollments_select to staff + own-parent scoping + live atomic apply — **Completed (TESTED, live-verified 6/6)**
- **Evidence:** apply_0080_live.sh HTTP 201 (chain 77/77 = 0001–0080 zero drift, registration embedded); verify_t-214.sql 6/6 GREEN (C1 registration+chain, C2 policy shape, C3 parent-own-only [leak closed], C4 fail-closed unbound user, C5 staff sees all, zero seed residue); docs/recovery/t-214-live-verification.md. NEW Management-API quirk #9 documented (doubled-single-quote LIKE corruption → position()/DO blocks).
- **Problems:** INFO-300 (new: tenant-wide SELECT exposes every family's enrollment amounts to any authenticated parent) · **Priority:** P1 (security)
- **Dependencies:** sbp_ token (supplied) · **Affected:** hub (new migration 0080 + apply script + verify script), all clients unchanged (staff roles pass has_any_role; parents see own)
- **Plan:** drop/recreate policy with the invoices_select pattern (staff roles OR parent-own-student subquery); migration file with embedded registration; `apply_0080_live.sh` atomic BEGIN/COMMIT apply; `verify_t-214.sql` (BEGIN/ROLLBACK, temp-table evidence, regression paths); live verification doc.

### T-215 — Hub: policy-census hardening script (REG-004 lesson) — **Completed (TESTED, live-verified 189/189)**
- **Evidence:** scripts/policy_census.sh live run (chain=189 live=189 live_only=0 chain_only=0, exit 0 — ZERO policy drift incl. the 0080 re-creation); parser pinned by src/tests/infrastructure/t-215-policy-census.test.ts 5/5 (real-chain shape incl. the 0079 DROP TABLE cascade + LAST-creator-wins, storage-schema exclusion, throwaway-dir drop/recreate/table-drop/comment probes); desktop suite 92/2422/0 baseline re-run green + typecheck clean.
- **Problems:** REG-004 class (unregistered live policy drift compounds silently) · **Priority:** P1
- **Dependencies:** none · **Affected:** hub scripts/ (new policy_census.sh)
- **Plan:** machine-check the live pg_policy set (policy names per table) against the local chain's cumulative CREATE/DROP POLICY statements; run at session openings; evidence in change-log. Small, high-value, recommended by the 31st-session next-task note.

### T-216 — Hub: MIG-TOKENS full consistency re-verification round (close) — **Completed (VERIFIED, 10/10 probe families GREEN)**
- **Evidence:** /home/z/my-project/scripts/t-216-live-verification.sh (probes-only, persisted outside the repos per the T-140 convention) + docs/recovery/t-216-live-verification.md: chain 77/77 = 0001–0080 ZERO DRIFT (incl. 0080), policy census 189/189 zero drift, auth health 200 × both key regimes (ADR-009), REST 200 × both, EF fleet 13/13 ACTIVE 1:1 with the hub source, ALLOWED_ORIGINS 4-origin canonical set all echoing + non-allowlisted NOT echoed (ACT-203 intact), anonymous EF → 401, 0080 policy live (n=1 with has_role).
- **Problems:** none new (verification; closes the owner's "apply the migration tokens + consistent everywhere" mandate with fresh evidence incl. 0080) · **Priority:** P1
- **Dependencies:** T-214 applied · **Affected:** hub evidence docs
- **Plan:** chain drift check 77/77 = 0001–0080, EF fleet matrix, dual-key health, ALLOWED_ORIGINS probe, anonymous-deny matrix; record in t-216-live-verification.md + change-log.

### T-217 — Desktop: T-047 port #6 — workforceAttendance → workforce_attendance_events — **Completed (TESTED)**
- **Evidence:** src/tests/infrastructure/supabase-workforce-attendance-repository.test.ts 12/12 (union verbatim + server-side punch instant, UUID/tenant validation, lat/lng mapping + ip drop, recorded_by, read mapping, cache filtering, SYNCHRONOUS latestFor incl. the just-punched reflection, persistence-across-restart, 3 source scans); full desktop suite 94 files / 2439 / 0 + typecheck clean + eslint 0 errors on the touched files. The dashboards trio (tasks / workforceAttendance / leaveRequests) is now FULLY Supabase-backed.
- **Problems:** ARCH-001 (T-047 Group-A remainder; the dashboards trio's open member) · **Priority:** P2
- **Dependencies:** none (table + RLS exist since 0010/0019) · **Affected:** hub (new SupabaseWorkforceAttendanceRepository, wiring, tests)
- **Plan:** port observeByPersonnel/observeByDate/latestFor/recordEvent over the canonical table (T-178/T-180 adapter pattern: SubjectBehavior cache + refresh-after-write); unit tests incl. persistence + source scans.

### T-218 — 32nd-session closeout: registry truth-sync + zip + push + handoff — **Completed (TESTED)**
- **Problems:** process (ADR-007) · **Priority:** P2
- **Dependencies:** T-209..T-217 · **Affected:** all three repos
- **Plan:** problem/task registry status flips with evidence, change-log entry, current-state delta, next-task session state, git commits per task (git-workflow template), zips, push with the owner's PAT.
- **Evidence:** change-log 32nd-session section (T-218 closeout entry — registries synced, all three repos pushed with the owner's PAT, 4 zips in download/); suites at close: website 40/544/0 + lint + strict build; desktop 94/2439/0 + typecheck + lint 0 err. The registry's own status line was left "In Progress" by the closeout commit — flipped Completed here (33rd session, T-222 truth-sync).

### T-219 — Desktop: 16:9 wide-form payment modal — no cut-off, footer always visible (UI-305) — **Completed (TESTED)**
- **Problems:** UI-305 · **Priority:** P1 · **Severity:** High (owner-reported)
- **Dependencies:** none · **Affected:** hub (shared modal design system + UnifiedPaymentModal)
- **What was wrong:** the owner reported the payment form "getting cut off and going outside the form boundaries". Root cause (two layers): (1) the UnifiedModal dialog variant rendered as `grid … flex-col` with only a `max-w-*` cap and NO height cap — grid rows size to content, so the body's `flex-1 overflow-y-auto` was INERT and tall forms grew the dialog past the viewport (the footer with Annuler/Encaisser became unreachable); (2) the payment form was a single long column (size lg = max-w-2xl = 672px), far too narrow for a two-pane collection workflow.
- **What was changed:** dialog shells are now real flex columns capped at `max-h-[88vh]` (the body scrolls, the footer is pinned — matching the drawer variant, which was already correct); NEW `2xl` wide-form tier (max-w-6xl ≈ 1152px; on a 1080p display the stage lands ≈ 1152×648 — an approximately 16:9 form); the UnifiedPaymentModal body restructured into a responsive `lg:grid-cols-12` two-column split (LEFT 7: parent/student identification, line-item summary, payment slider, waterfall allocation preview; RIGHT 5: category, method selector, structured check/wire fields, proof upload, DebtMeter, notes, status preview); the form footer leads with the payer + amount recap and keeps the actions right; the success stage polished into a two-column receipt summary (issuer, receipt, amount, method, category, date & time, collector, status).
- **Verified:** source-scan guards (t-219-t-220-t-221-source-guards.test.ts): size="2xl", max-w-6xl registered, `flex max-h-[88vh] w-full … flex-col` present, the old `grid w-full …` dialog layout forbidden, the 12-col split with col-span-7/5 present, size="lg" absent from the modal; full suite 100 files / 2513 / 0 + typecheck clean + eslint 0 errors (touched files).
- **Left / notes:** visual eyeballing in the running Electron app is host-gated (per AGENTS.md §11 desktop note); the geometric fix is structural (viewport-relative cap) and source-guarded. No other dialog consumers regressed — every dialog now benefits from the bounded body (see the full-suite pass).

### T-220 — Desktop: payments journal shows the ISSUER + exact date/time instead of a bare serial number — **Completed (TESTED)**
- **Problems:** UI-305 (companion surface) · **Priority:** P1 · **Severity:** High (owner-reported)
- **Dependencies:** T-219 (same surface family) · **Affected:** hub (financials-page PaymentsTab)
- **What was wrong:** the payments journal's first column showed only the receipt serial number (REC-…) and the date column showed only a fuzzy relative time ("il y a X jours") — no WHO issued the payment, no clock time, no collector attribution.
- **What was changed:** PaymentsTab rows are enriched with the resolved issuer identity (parent avatar + full name + family code + linked student via repos.parents/repos.students observables, memoized); NEW column set: Émetteur (Payeur) / Reçu + Encaissé par (collector attribution as a secondary line) / Date & Heure (exact dd/MM/yyyy HH:mm + relative secondary line) / Méthode (with check number or wire reference) / Catégorie / Montant / Statut; search spans parentName, studentName, parentCode, receiptNumber, method, category.
- **Verified:** source guards in the same test file (Émetteur (Payeur), parentDisplayName, Date & Heure + formatDateTime + formatRelative, "Par :" collector line, search fields incl. parentCode, parents/students observe wiring); full suite green.
- **Left / notes:** the enrichment resolves from the observable caches (no extra fetch); payments whose parent is missing render "Parent non répertorié" instead of an empty cell.

### T-221 — Desktop: FULL DAG automation system (DAG-100) — inspector + predicate builder + dry-run + templates + canvas UX + branch-aware executor — **Completed (TESTED)**
- **Problems:** DAG-100 · **Priority:** P1 · **Severity:** High (owner mandate "fully fully fully do the dag automations")
- **Dependencies:** none (kahn.ts + condition-evaluator.ts pre-existing) · **Affected:** hub (domain model, domain/calc/workflow, features/workflow, mock executor, tests)
- **What was wrong:** the DAG builder existed visually (canvas + palette + runs monitor, iteration 7) but was NOT a functional automation system: node `config` was always `{}` with NO editing UI (the condition evaluator existed but nothing could AUTHOR conditions); no dry-run/test mode; no templates; no zoom/pan/minimap/auto-layout; the mock executor walked the node ARRAY linearly with one global conditionFailed flag (parallel branches could not diverge); the palette lacked the school's high-value triggers/actions.
- **What was changed:** (1) domain model: 17 → 29 subtypes (+12: grade_below_threshold, payment_cleared_or_bounced, document_expiration, calendar_cron_event, stock_level_critical, time_window, route_switch, send_whatsapp, restrict_account, dispatch_task, generate_document, account_adjustment) with labels + descriptions + palette grouping; (2) NEW `domain/calc/workflow/dry-run.ts` — PURE topological simulator with branch semantics (failing condition closes only its branch; route_switch opens only the first passing route; convergence executes once; cycles rejected; missing fields → false + §10.05 warning; time_window guard vs the context instant) + generic topologicalOrder; (3) NEW `domain/calc/workflow/auto-layout.ts` — layered layout from the topological depth, 20px-grid-snapped (gaps are grid multiples — 110px would snap ragged); (4) NEW `domain/calc/workflow/templates.ts` — the 3 owner-specified one-click recipes (Relance échelonnée / Alerte assiduité / Clôture trimestrielle) with REAL condition trees, acyclic by construction, templateIsValid + collision-proof instantiateTemplate; (5) NEW `features/workflow/node-inspector-drawer.tsx` — per-subtype parameter forms + the visual predicate builder (Champ/Opérateur/Valeur rows × ET/OU/NON compiled into ConditionNode trees via the canonical parser) + switch-route editor mapped to outgoing edges + test-payload preview; (6) dag-canvas upgraded — zoom (buttons + Ctrl-wheel anchored), pan, minimap (viewport rect + click-to-jump + dry-run status opacity), snap-to-grid, "Réorganiser" auto-layout, "Tester" dry-run (green taken edges + animated pulse + per-node rings + skipped fade + warning banner), double-click / ⋯-menu → inspector; (7) the mock executor now runs THROUGH the dry-run engine (single source of truth) — run records list nodes in topological order with per-branch skip reasons; durations + 90% action-failure + daily cap + audit preserved; (8) node palette carries descriptions; the Nouveau workflow modal offers the template picker.
- **Verified:** 4 NEW domain test files (dry-run 9 tests: branch divergence, switch routing incl. no-match, convergence-once, cycle, missing-field warning, time_window vs fixed instants, kahn consistency; auto-layout 8: layer gaps, fan-out same-x, diamond convergence, identity/config preservation, grid snapping, cycle refusal; templates 11: the 3 recipes acyclic + edge-complete + ≥1 trigger + parseable conditions + dry-run green + meaningful branch decisions + instantiation disjointness; subtype-registry 7: label/description/mapping completeness + no strays/dups + T-221 expansion spot-check) + 1 executor test file (4 tests through the REAL repository: failing-condition skips only its branch while the parallel branch runs — the old executor could not do this; topological result order; run persistence) + 13 source-guard assertions. Full suite 100/2513/0 + typecheck + lint.
- **Left / unresolved:** (a) the Supabase EF `workflow-execute` still executes the SERVER-side engine — the dry-run semantics are pinned on the client/mock side only; porting branch-aware execution into the EF is the next backend task (registered as the follow-up in next-task.md); (b) action nodes are still simulated (mock 90% success) — real action executors (WhatsApp URL building, notifications insert, tasks insert, account restriction) need per-action implementation once the EF side is upgraded; (c) RESEND_API_KEY (send_email) and FIREBASE_SERVICE_ACCOUNT_JSON (push delivery) remain owner-gated residuals.

### T-222 — 33rd-session closeout: registry truth-sync + zip + push + handoff — **Completed (TESTED)**
- **Problems:** process (ADR-007) · **Priority:** P2
- **Dependencies:** T-219..T-221 · **Affected:** all three repos (hub only receives commits; website/android untouched this session)
- **Plan:** registry entries + counts (TESTED 81→95), problem-registry totals 199→201 (+UI-305, +DAG-100), change-log 33rd-session section, current-state snapshot, next-task 34th-session recommendation, 4 detailed commits on main, zips, push with the owner's PAT.
- **Evidence:** this change-log entry + the git log; suite evidence in T-219..T-221.

---

## 34th repair session (2026-09-07) — owner mandate: "Fully solve the DAG automation system — complete, production-ready automation pipeline from the visual builder through persistence and execution"

Opening ritual (live, sbp_ token): migration chain 77/77 = 0001–0080 ZERO DRIFT (live `supabase_migrations.schema_migrations` JSON-diffed against the local chain); EF fleet 13/13 ACTIVE incl. workflow-execute v21 (2026-09-02); live `workflows` = 0 rows, `workflow_runs` = 0 rows (the server path has NEVER produced a run); desktop baseline 100 files / 2513 tests / 0 failures. Opening audit findings (see DAG-100 residual + NEW discovery): the deployed workflow-execute EF selects non-existent columns (`definition`, `version` — the table has `dag_definition`, no version) → every call 404s; it inserts non-existent columns (workflow_version/triggered_by_profile_id/actor_note/request_id) → PGRST 204; its node dispatch uses flat legacy type strings while the desktop persists `{type, subtype}` nodes → every action/delay/transform node would throw "Unknown node type"; condition evaluation is stubbed (`_stub_*` config values); any action failure skips ALL remaining nodes (diverges from the T-221 branch semantics); `workflow_runs.trigger_type` CHECK (0012) lacks the T-221 trigger subtypes; no server-side publish validation (a cyclic workflow can be published via direct table write); no event-driven trigger path (run-overdue-scan never invokes workflows); wait_duration capped at 5s inline (not persistent/resumable); the EF never updates last_executed_at/total_executions; the Android workflow_runs DTO expects wrong column names. Session task set (10 tasks, DAG-only scope per the owner's instruction to ignore all other platform work):

### T-223 — Backend: migration 0081 — workflow_runs/workflows schema alignment + server-side DAG validation (publish gate) — **Completed (TESTED, live-verified 25/25)**
- **Problems:** DAG-100 (residual: server-side validation), NEW discovery (EF↔schema column drift) · **Priority:** P0 · **Severity:** Critical (the live execution path is dead)
- **Dependencies:** none · **Affected:** hub (supabase/migrations/0081, scripts)
- **Plan:** workflow_runs + actor_note/request_id/workflow_version/resumed_at; trigger_type CHECK extended with the T-221 trigger subtypes; workflows.version + publish-increment trigger; workflow_pending_resumes table (persistent delay/resume, unique pending per run+node); `validate_workflow_dag(jsonb, strict)` SQL function (duplicate node/edge ids, missing refs, self-edges, Kahn cycle detection with involved-node list, type/subtype whitelist mirroring the 29-subtype registry, trigger in-degree rule, strict-mode ≥1 trigger, condition-tree validation, wait_duration config) + BEFORE UPDATE publish-gate trigger on workflows (a cyclic/invalid DAG can never be published through ANY writer — the server-side requirement the client-side Kahn guard could not enforce); atomic live apply (MIG-TOKENS pattern); verify_t-223.sql regression script; desktop source-guard test pinning the SQL subtype whitelist == the TS registry.
- **Status:** In Progress

### T-224 — Backend: pure server execution engine (engine.ts) + desktop unit/equivalence tests — **Completed (TESTED)**
- **Problems:** DAG-100 (residual: branch-aware server engine) · **Priority:** P0
- **Dependencies:** T-223 · **Affected:** hub (supabase/functions/workflow-execute/engine.ts, src/tests)
- **Plan:** dependency-free pure TypeScript engine INSIDE the EF folder (no Deno imports → vitest-importable, tsc-strict-clean): definition parsing (string-or-jsonb, {nodes,edges} with source/target edges), full validation (TS mirror of the SQL rules), the condition evaluator ported VERBATIM from domain/calc/workflow/condition-evaluator.ts, branch-aware topological execution (per-branch closure, route_switch first-passing-route, convergence-once, §10.05 missing-field→false+warning, time_window vs context instant), injectable ActionHandler interface (the EF index wires real executors; tests wire fakes), deadline/timeout + max-node guards. Tests import the engine directly from src/tests (real unit tests of the server engine — not source guards) + an equivalence corpus vs the desktop dry-run engine (branch divergence, switch routing, convergence parity).
- **Status:** In Progress

### T-225 — Backend: rewrite workflow-execute EF on the engine + correct persistence + deploy — **Completed (TESTED, live-verified 33/33)**
- **Problems:** NEW discovery (EF dead against the real schema) · **Priority:** P0
- **Dependencies:** T-223, T-224 · **Affected:** hub (supabase/functions/workflow-execute/index.ts + live deploy)
- **Plan:** read dag_definition (correct column; string-or-object), version (new column); write the REAL workflow_runs columns (actor_id, actor_note, request_id, workflow_version); dispatch through the 29-subtype registry (unknown subtype → failed node with a diagnosable error, not a silent skip); per-branch failure semantics (a failed action closes only its downstream — parallel branches continue; final status failed if any node failed); run finalization updates workflows.last_executed_at + total_executions; execution deadline → status 'timeout'; daily cap preserved; deployed live (functions deploy).
- **Status:** In Progress

### T-226 — Backend: real action executors in the EF — **Completed (TESTED, live-verified 15/15)**
- **Problems:** DAG-100 (residual: simulated actions) · **Priority:** P0
- **Dependencies:** T-225 · **Affected:** hub (EF action layer)
- **Plan:** push_notification → REAL in-app notification (parent target via the canonical 0077 notify_parent_user RPC; staff target via role-assignment resolution + notifications insert with target_role) + FCM delivery via the canonical send-push-notification EF (honest per-recipient failures); dispatch_task → REAL tasks insert (title/description/priority/due_date/department/assignee resolution); restrict_account → REAL parents.is_financially_restricted update with audit entry; send_whatsapp → honest wa.me deep-link preparation (recorded as a prepared link, never a fake delivery claim); extract_field → real context dot-path extraction; send_email/log_audit stay real (T-126/T-131); apply_discount/create_invoice/generate_document/account_adjustment → honest `skipped` outputs naming the missing canonical RPC (NO fake success, NO silent stubs).
- **Status:** In Progress

### T-227 — Backend: real execution context builder (entity loading) — **Completed (TESTED, live-verified 10/10)**
- **Problems:** DAG-100 (residual: stubbed condition inputs) · **Priority:** P0
- **Dependencies:** T-225 · **Affected:** hub (EF context layer)
- **Plan:** build the ConditionContext from REAL data for the triggered entity (body parent_id/student_id/installment_id): parent financials via the canonical compute_parent_summary RPC (outstanding/overdue/flags), student status + absence counts from attendance_records (absent_unexcused), latest payment method/status, oldest-overdue days; merge node.config._context overrides (desktop parity); conditions then evaluate against real values (debt_over_threshold etc. no longer read _stub_*).
- **Status:** In Progress

### T-228 — Backend: persistent delay/resume (workflow_pending_resumes + scheduler EF) — **Completed (TESTED, live-verified multi-hop + duplicate protection)**
- **Problems:** DAG-100 (delay not persistent/resumable) · **Priority:** P1
- **Dependencies:** T-223 (table), T-225 (engine) · **Affected:** hub (EF workflow-execute + NEW workflow-resume-scheduler EF + config.toml)
- **Plan:** wait_duration > inline cap (10s) parks the run: status stays 'running', a workflow_pending_resumes row (run, node, resume_after, serialized engine state) is written, the EF returns the pause honestly; NEW workflow-resume-scheduler EF (CRON_SECRET/service-role auth, cron +10min) claims due rows (atomic UPDATE...WHERE status='pending' → 'claimed', the unique index blocks double-claims), re-enters the engine at the parked node, runs to completion or parks again; execution state survives process death (it is a row, not memory); inline waits ≤10s still supported for short delays.
- **Status:** In Progress

### T-229 — Backend: EF dry-run mode (safe test execution) — **Completed (TESTED, live-verified 10/10 incl. prediction parity)**
- **Problems:** DAG-100 (no server-side test execution) · **Priority:** P1
- **Dependencies:** T-225, T-226, T-227 · **Affected:** hub (EF)
- **Plan:** body flag dry_run:true + optional entity ids → the engine runs with action handlers in SIMULATE mode (no notifications/emails/tasks/mutations — outputs record what WOULD happen), real entity context (T-227), conditions really evaluated, branch path + per-node outputs/errors returned; NO workflow_runs row (test runs never pollute the execution history); one write_audit_log entry (workflow.dry_run) keeps the test traceable; duplicate protection (daily cap does NOT consume on dry runs).
- **Status:** In Progress

### T-230 — Desktop: manual Execute button + server dry-run (Tester) + server validation surfacing — **Completed (TESTED)**
- **Problems:** DAG-100 (UX wiring to the real server path) · **Priority:** P1
- **Dependencies:** T-225, T-229 · **Affected:** hub (features/workflow, domain repository contract, mock + supabase implementations)
- **Plan:** editor toolbar "Exécuter" (published workflows only) → repos.workflows.execute → the canonical EF path (completes the manual trigger path — previously retry-on-existing-run only); Tester gains a Serveur mode with an entity picker (parents observable) invoking a NEW dryRun repository method (mock: local dry-run engine; supabase: the EF dry_run call) with the server-predicted path rendered on the canvas; server-side validation errors (publish gate) surfaced through the existing error path (supabaseErrorToAppError userMessage); i18n keys.
- **Status:** In Progress

### T-231 — Android: workflow_runs DTO contract fix (real column names + node_results decode) — **Completed (TESTED, gradle 416/416)**
- **Problems:** NEW cross-platform drift (Android DTO vs the real workflow_runs schema) · **Priority:** P1
- **Dependencies:** T-225 (the EF now writes the canonical shape) · **Affected:** elimtiyaz-android (SharedDtos, Room mapping, monitor display)
- **Plan:** WorkflowRunDto field names fixed to the REAL table (trigger_type/actor_id/completed_at/node_results/duration_ms/workflow_id/started_at/status/error_message); node_results decoded into the WorkflowNodeResult model (node_id/node_label/status/started_at/completed_at/output/error); unit tests decoding the exact JSON shape the EF writes; monitor surfaces real trigger labels. Gradle run attempted per the documented JDK/SDK recipe; if the container blocks it, the suite run is reported BLOCKED (honestly) while the code+tests land.
- **Status:** In Progress

### T-232 — Live end-to-end DAG verification matrix + closeout — **Completed (VERIFIED, live 18/18)**
- **Problems:** DAG-100 (final closure evidence) · **Priority:** P0 (owner's core demand)
- **Dependencies:** T-223..T-231 · **Affected:** hub (docs, registries) + live backend
- **Plan:** full live matrix with a real staff JWT: create → save → publish (version=1) → cyclic publish REJECTED server-side → execute (branch semantics on real debt data: >threshold vs ≤threshold branches) → node_results/audit/duration verified → actions really fire (in-app notification row, task row, parent restriction + audit) → delay workflow parks + scheduler resumes → dry-run leaves workflow_runs untouched + audit entry → daily cap enforced (429 on the second run) → malformed definitions rejected → full evidence to docs/recovery/t-232-live-verification.md; problem-registry DAG-100 → VERIFIED (residuals honestly listed); change-log 34th-session section; next-task 35th-session recommendation; zips + push.
- **Status:** In Progress

---

## 35th repair session (2026-09-07) — owner mandate: Personnel/Workforce RBAC overhaul — strict role workspaces + mock-layer elimination for the operational dashboards

Opening ritual (live, sbp_ token): migration chain 79/79 = 0001–0082 ZERO DRIFT; desktop baseline typecheck clean, suite **105 files passed + 1 FAILED** (supabase-workforce-attendance-repository.test.ts #7 latestFor — NEW finding TEST-306: time-of-day flaky fixture, attributed to ee02fae/T-217, repository itself correct; fixed first as T-233). External-reviewer audit (owner-supplied) verified against code: teacher ViewRoster/ViewAcademics confirmed (CRM+Pédagogie ENABLED in sidebar); no route guards on /crm//academics//financials confirmed; TeacherDashboard → /academics/class/:id leak confirmed; SupportStaff financials/classes/promotion lockout confirmed. TWO NEW data-layer findings the review missed: 0019 `students_update` RLS includes 'teacher' (DB-level student-profile write access!) and `parents_select`/`students_select` include 'teacher' (full directory + parent phones readable). Review rebuttals: account provisioning IS built (T-079 EF, live-verify this session); most of its "mock-only" matrix rows are stale (T-099..T-217 already ported: attendance/leave/tasks/suppliers/chat/calendar/workflows) — the still-mock slots are the ones ported here. Session task set:

### T-233 — Desktop: fix time-of-day flaky test (TEST-306) — restore pristine baseline
- **Problems:** TEST-306 (NEW — registered this session) · **Priority:** P0 (baseline must be green before building)
- **Dependencies:** none · **Affected:** hub (1 test file)
- **Plan:** fixture att-early re-stamped from `${today}T07:00:00.000Z` → `${today}T00:00:00.000Z` (always before the punch instant at any hour; the punch stamps `new Date()` which is ≥ midnight of the same UTC day) + comment documenting the flake mechanics.
- **Status:** Completed (commit 608a500 — fixture re-stamped midnight; full suite green at 00:xx UTC, 112 files / 2687 / 0 at session close)

### T-234 — Desktop: RBAC boundary hardening (permission matrix + route guards + sidebar locking) — RBAC-300
- **Problems:** RBAC-300 (NEW — the consolidated owner-mandate boundary problem) · **Priority:** P0
- **Dependencies:** T-233 (green baseline) · **Affected:** hub (permissions.ts, feature-registry.ts, app-shell.tsx, tests)
- **Plan:** (1) permissions.ts — Teacher: REMOVE ViewRoster + ViewAcademics (sidebar CRM+Pédagogie → padlock; retains EnterGrades/RollCall/AssignHomework exercised INSIDE Personnel); SupportStaff: ADD ViewFinancials + ManageClasses + PromoteStudent (front-office duties: payment logs, class assignment, year-end transitions); (2) app-shell.tsx — route guards for /crm, /academics*, /financials redirecting restricted roles to /personnel (defense-in-depth mirroring DASHBOARD_RESTRICTED_ROLES); (3) feature-registry: Dashboard section already role-gated — Crm/Academics/Financials stay permission-gated (the matrix change is what flips them to locked for operational roles); (4) RED-first test suite: role boundary matrix (every role × every module), route-guard behavior, regression for existing roles.
- **Status:** Completed (commit 1a10a60 — matrix + route-guard table + sidebar lock; role-boundaries RED-first suite; typecheck+lint clean)

### T-235 — Desktop: Teacher Personnel workspace self-containment — RBAC-301
- **Problems:** RBAC-300 (teacher-scope residual) · **Priority:** P0
- **Dependencies:** T-234 · **Affected:** hub (teacher-dashboard.tsx, roll-call-screen.tsx, grade-entry-screen.tsx, tests)
- **Plan:** RollCallScreen + GradeEntryScreen refactored to accept optional props (classId/subjectId + onExit) falling back to useParams (route behavior unchanged); TeacherDashboard renders them as full-screen overlays INSIDE Personnel → Mes classes — Appel + Notes actions stay in-module; remove every navigate(`/academics/...`) from the teacher dashboard; Notes opens an in-module subject picker → GradeEntryScreen; tests pin: no teacher-dashboard navigation to /academics, overlay lifecycle, screens still work standalone via routes.
- **Status:** Completed (commit 7306749 — in-module overlays, zero /academics navigation, screens still standalone)

### T-236 — Backend: migration 0083 — teacher CRM data-scoping in RLS (SEC-level) + live apply
- **Problems:** RBAC-302 (NEW — data-layer: students_update includes teacher; parents/students_select unscoped for teachers) · **Priority:** P0 (severity: Critical)
- **Dependencies:** none (schema untouched; policies only) · **Affected:** hub (supabase/migrations/0083, scripts/verify_t-236.sql, live DB)
- **Plan:** NEW append-only migration 0083: (1) `students_update` drops 'teacher' from the role list (teachers can NEVER write student profiles — matches the already-enforced UI EditStudent gate and the owner's spec); (2) `students_select`: teacher branch scoped to classes they teach (homeroom classes via classes.homeroom_teacher_id → personnel.user_id, OR subject classes via class_subjects.teacher_id) instead of tenant-wide; (3) `parents_select`: drops 'teacher' entirely (teachers have no parent-facing duty; roll-call/grades never read parents). Regression-safe: all other roles unchanged. verify_t-236.sql (BEGIN…ROLLBACK temp-table convention) + atomic live apply via the MIG-TOKENS pattern (file + schema_migrations registration in ONE call).
- **Status:** Completed (commit 0321644 — migration 0083 applied live atomically, HTTP 201; post-checks GREEN; RBAC-302 VERIFIED via T-241 probes)

### T-237 — Android: RBAC mirror + in-Personnel teacher workspace — RBAC-300 (Android)
- **Problems:** RBAC-300 (Android half) · **Priority:** P0 (cross-platform rule §10)
- **Dependencies:** T-234 (desktop matrix first, then port) · **Affected:** elimtiyaz-android (core/Rbac.kt, PersonnelHubScreen + new teacher workspace, tests)
- **Plan:** (1) Rbac.kt: teacher loses VIEW_ROSTER + VIEW_ACADEMICS (CRM + Pédagogie hub tabs disappear for teachers — Android hides unauthorized tabs); SupportStaff gains VIEW_FINANCIALS (already has), MANAGE_CLASSES, PROMOTE_STUDENT; (2) NEW "Mon espace" tab in PersonnelHubScreen for teachers (gated on the teacher role): my-classes list with Appel → Routes.RollCall(classId) and Notes → Routes.GradeEntry(classId, subjectId) — both routes already exist and are gated ROLL_CALL/ENTER_GRADES which teachers retain; (3) RbacTest updated RED-first + new teacher-workspace tests; gradle suite via the re-provisioned JDK/SDK recipe (report honestly if blocked).
- **Status:** Completed (android commit 655b404 — matrix lockstep + Mon espace workspace; 50 suites / 427 tests / 0 failures)

### T-238 — Desktop: T-047 port #7 — purchaseRequests → purchase_requests (Buyer dashboard production-grade)
- **Problems:** ARCH-001 (residual slot #7) · **Priority:** P1
- **Dependencies:** none · **Affected:** hub (new SupabasePurchaseRequestRepository + wiring + tests)
- **Plan:** T-178/T-180 adapter pattern onto 0011 `purchase_requests` (status/priority CHECK unions, lines jsonb, request_number PR-YYYY-NNNN deterministic generation, requester_id = session profile id, tenant scoping, reactive cache + refresh-after-write, state-transition validation mirroring the DB CHECK) + unit tests (payload shape, UUID guards, mapping, filters, persistence-across-restart, source scans) + wiring into getSupabaseRepositories().
- **Status:** Completed (commit fc11d3f — 9/9 tests; 0084 live; suite 112 files / 2687 / 0)

### T-239 — Desktop: T-047 port #8 — deliveries → deliveries (Driver dashboard production-grade)
- **Problems:** ARCH-001 (residual slot #8) · **Priority:** P1
- **Dependencies:** none · **Affected:** hub (new SupabaseDeliveryRepository + wiring + tests)
- **Plan:** same pattern onto 0011 `deliveries` (delivery_number DLV-YYYY-NNNN, status CHECK incl. delayed/failed mapping, stops jsonb, driver_id → personnel with user_id translation, delay_reason/delay_minutes, departure/delivered/confirmed timestamp columns) + tests + wiring.
- **Status:** Completed (commit 3954a1b — 9/9 tests; 0084 live)

### T-240 — Desktop: T-047 port #9 — inventory → inventory_items + inventory_transactions (Warehouse dashboard production-grade)
- **Problems:** ARCH-001 (residual slot #9) · **Priority:** P1
- **Dependencies:** none · **Affected:** hub (new SupabaseInventoryRepository + wiring + tests)
- **Plan:** same pattern onto 0011 `inventory_items` (sku unique per tenant, quantity CHECKs, soft delete) + `inventory_transactions` (insert-only audit trail with quantity_before/after computed client-side under a transaction-safe upsert path, signed delta, actor stamps) + tests + wiring.
- **Status:** Completed (commit e79ac93 — 7/7 tests; 0084 applied live atomically + post-checks)

### T-241 — Live verification round: account provisioning EF + role-scoping probes
- **Problems:** RBAC-300/302 evidence + ACT-xxx provisioning confirmation · **Priority:** P1
- **Dependencies:** T-236 · **Affected:** live backend + docs
- **Plan:** live round-trip through the desktop's exact PostgREST+RLS path: (1) create-user-account EF with a super_admin JWT (create test account → sign-in works → role assigned → profile activated) then clean-up by email (the 0002 trigger auto-creates profiles — UPDATE, never parallel-insert); (2) teacher JWT probes: parents/students SELECT now empty/scoped, students UPDATE rejected; (3) full curl matrix documented in docs/recovery/t-241-live-verification.md.
- **Status:** Completed (commit 1e3f6eb — 14/14 live probes GREEN: provisioning round-trip teacher+driver, RLS scoping matrix, escalation 403; evidence docs/recovery/t-241-live-verification.md)

### T-242 — 35th-session closeout: registries + change-log + zip + push + handoff
- **Problems:** process (ADR-007) · **Priority:** P2
- **Dependencies:** T-233..T-241 · **Affected:** all repos (hub receives the commits; android gets its own commits)
- **Plan:** problem-registry entries (TEST-306, RBAC-300, RBAC-301, RBAC-302 + ARCH-001 slot closures) + change-log 35th-session section + current-state snapshot + next-task 36th-session recommendation + detailed conventional commits per task + zips in download/ + push with the owner's PAT.
- **Status:** Completed (this commit — registries + change-log + current-state + next-task + zips + push with the owner PAT)

---

## 36th session (2026-09-09) — owner mandate: "apply the AI review (unified 3-zone dashboard integration blueprint), verify the migration tokens work, test everything, zip + push"

> Mandate source: the owner's pasted AI review (widget matrix + design tokens + production components for `elimtiyaz-desktop`'s dashboard) + the Supabase credential sheet. Registered BEFORE implementation per AGENTS.md §13.

### T-243 — Dashboard 3-zone integration: sparkline KPIs + macro spline + weekly rhythm + recovery funnel + insights rail (UI-306)
- **Problems:** UI-306 (new — see problem registry) · **Priority:** P1
- **Dependencies:** none (UI-only, no schema touch per §15.9) · **Affected:** hub desktop only (`src/features/dashboard/`, `src/shared/ui/dashboard-theme.ts`, topbar placeholder)
- **Plan:** implement the review's production components adapted to the REAL dashboard data contract (§15.16 — no synthesized trends): `dashboard-theme.ts` (Recharts tokens), `sparkline-kpi-card.tsx` (trend/delta OPTIONAL — rendered only when a REAL series exists), `enrollment-funnel-card.tsx` (recovery-pipeline stages derived from debtAging FAMILY COUNTS), `weekly-operating-rhythm.tsx` (Dim→Jeu stacked bars from the REAL payments stream), `insights-rail.tsx` (AI card from real overdue counts + recovery gauge from annualRevenue/(annualRevenue+outstandingDebt) + top-3 relance feed), new `overview-tab.tsx` (12-col Zone A/B assembly, T-088 single-fetch pipeline preserved — page gains ONE payments observable), topbar search placeholder NL hint. Funnel/rhythm/insights get honest empty states when data is absent.
- **Status:** Completed — TESTED (2026-09-09: 17-test dashboard-3zone suite + full 112/2694/0 + tsc + eslint 0 err + vite build; see UI-306 evidence)

### T-244 — Live migration-token verification round (chain drift check + dual-key health + EF fleet + ALLOWED_ORIGINS)
- **Problems:** process (session-opening §15.11 obligation) · **Priority:** P0
- **Dependencies:** owner re-supplied the sbp_ access token + key sheet · **Affected:** live backend (read-only probes) + docs
- **Plan:** re-provision the Supabase CLI (container reset wiped /home/z/my-project/bin — documented quirk), link hkvkefubghbbotgnteir, diff live `supabase_migrations.schema_migrations` vs local 0001–0084 chain, verify dual-key health (ADR-009), EF fleet ACTIVE census, ALLOWED_ORIGINS echo probe, anonymous EF → 401. Record results in change-log + a live-verification note if anything drifted.
- **Status:** Completed (2026-09-09: live round 18/18 GREEN — dual-key auth health, RLS anon 0-rows ×5, chain live=81/local=81 ZERO DRIFT, EF fleet 14/14 ACTIVE 1:1 with hub source, anonymous EF 401, ALLOWED_ORIGINS canonical 4-origin echo + non-allowlisted rejected, committed-key consistency ×3; script /home/z/my-project/scripts/verify_t-244_mig_tokens.sh)

### T-245 — 36th-session closeout: registries + change-log + zip + push
- **Problems:** process (ADR-007) · **Priority:** P2
- **Dependencies:** T-243, T-244 · **Affected:** all repos
- **Plan:** UI-306 problem entry with evidence, task status flips, change-log 36th-session section, current-state snapshot, next-task 37th-session recommendation, conventional commits with the 5-question body, zips in download/, push with the owner PAT.
- **Status:** Completed (2026-09-09: UI-306 registered with full evidence; change-log/current-state/next-task updated; commits e9cedfd + this closeout; zips generated in download/. Push COMPLETED same-day follow-up: the owner re-supplied a valid PAT → e9cedfd + 3858e39 landed on origin/main [c74c7cc..3858e39]; android/website fetched and confirmed in-sync with origin/main (zero delta, nothing to push); this status line truth-synced by the follow-up commit)

---

### T-313 — 51st session: the 9e70078 shallow-fix redo — deep-integrate the SuperAdmin academic-write fix (ACAD-104 root cause) + repair the REG-006 regressions (fake-success wrapper, prototype stripping, corrupted lines, RBAC-301 scoping, admin-role conflation, auto-write effect, artifacts)
- **Problems:** REG-006 (NEW), ACAD-104 (NEW) · **Priority:** P0
- **Dependencies:** T-312 (the 50th-session green baseline this commit broke) · **Affected:** hub desktop (`src/app/providers/repository-provider.tsx`, `src/app/providers/auth-provider.tsx`, `src/core/rbac/session.ts`, `src/core/rbac/feature-gate.ts`, `src/core/rbac/route-access.ts`, `src/infrastructure/supabase/repositories/supabase-academic-repository.ts`, `src/features/personnel/dashboards/teacher-dashboard.tsx`, `src/features/academics/academic-year-detail-drawer.tsx`, `src/features/workflow/dag-canvas.tsx`, `src/tests/…`) + docs + repo hygiene (changes.patch.txt removal)
- **Plan:** (1) remove the fake-success wrapper + restore the clean RepositoryProvider pass-through; (2) repair the two corrupted teacher-dashboard lines; (3) restore the RBAC-301 strict homeroom scoping; (4) session.ts: drop the "admin" conflation + the dead Array branch (the session is constructed as a Set at every producer — buildSession + loadSession; the Array-handling in can() masks producer bugs instead of surfacing them); keep isSuperAdmin for the wire-variant normalization that buildSession's mapRoleCode already guarantees, but pin it to the canonical role; (5) academic repository: requireTenantId + tenant_id on createClass/createSubject/assignSubjectToClass (the T-023 in-file precedent); (6) remove the render-triggered auto-provision effect (keep the explicit modal); (7) dag-canvas: restore the workflow.id-only external sync (the prop-following effect clobbers in-flight edits), drop the click-to-save (save on real drags only — movement-checked), keep the window-level pointer tracking + getScreenCTM; (8) t-230 source-pin: whitespace-normalize before matching; (9) delete changes.patch.txt + .smartexport from git; (10) new tests: session semantics, repository-provider method-surface integrity, academic-write tenant contract; (11) LIVE round-trip: SuperAdmin sign-in → assignSubjectToClass against the live DB → RLS-verified row; (12) full re-verification (tsc + eslint + FULL suite); (13) registries + change-log + zips + push.
- **Status:** Completed — TESTED + VERIFIED LIVE, DAG step (7) EXCLUDED by owner scope directive (2026-09-12, 51st session):
  - **(1) wrapper removed:** RepositoryProvider passes the repositories prop through BY REFERENCE; reference-identity + prototype-method integrity + anti-wrapper source guard pinned by NEW `src/tests/app/t-313-repository-provider-passthrough.test.tsx` (5 tests).
  - **(2) "corrupted lines" — FALSE DIAGNOSIS corrected:** byte-level verification (`startswith`/hex) proved teacher-dashboard.tsx L58/L86 INTACT; the "corruption" was the sandbox Bash display layer eating `[h`/`[m` bracket-letter sequences (REG-006 root-cause #3 corrected in the problem registry; AGENTS.md §15.24 added — never diagnose source corruption from terminal display output).
  - **(3) strict homeroom scoping restored:** `me !== null && c.homeroomTeacherId === me.id` + the T-235 contract docblock restored; RBAC-301 pinned test green (8/8).
  - **(4) session semantics pinned:** `isSuperAdmin` → canonical `Role.SuperAdmin` only; `can()` reads the Set, no array tolerance, no bypass (fail-loud-at-producer: buildSession T-266 + ensureSuperAdminPermissions + loadSession stamp full perms); NEW `src/tests/rbac/t-313-session-semantics.test.ts` (11 tests).
  - **(5) ACAD-104 fixed on FOUR inserts:** `createAcademicYear` (joined the fix — same live-confirmed defect), `createClass`, `assignSubjectToClass`, `createSubject` now stamp `tenant_id: getTenantId()` with fail-loud ERR_VALIDATION no-tenant guards (T-023 in-file precedent); NEW `src/tests/infrastructure/t-313-academic-write-tenant.test.ts` (9 tests).
  - **(6) auto-provision effect removed:** TeachersSubTab no longer writes on render; the explicit "+ Ajouter un enseignant" modal stays; the unifiedTeachers merge still displays un-provisioned personnel teachers.
  - **(8) t-230 pins whitespace-normalized:** source pins strip whitespace + trailing commas before matching (prettier reformatting must not break SEMANTIC pins); t-230 green (8/8).
  - **(9) artifacts untracked:** `git rm --cached` on changes.patch.txt + 3 × .smartexport files (kept on disk for the parallel agent's tooling); .gitignore hardened with the scratch-artifact patterns.
  - **(11) LIVE round-trip VERIFIED** (`scripts/verify_t-313_live.sh` in the session workspace; the copy for the repo: `elimtiyaz-desktop/scripts/verify_t-313_live.sh`): SuperAdmin GoTrue sign-in → profile tenant 00000000-…-0001 → roles ["super_admin"] → RED control (old tenant-less payload → 403/42501 RLS violation — the owner's exact denial) → GREEN fix (tenant-stamped payload → 201 created, row read back via RLS-gated SELECT) → cleanup 204 → census 0.
  - **(12) full re-verification:** tsc 0 errors, eslint 0 errors, FULL suite **135 files / 3095 tests / 0 failures** (baseline at open: 2 red).
  - **(7) DAG step NOT DONE — DELIBERATELY:** the owner scoped dag-canvas/workflow-page work to a PARALLEL agent; this session did not touch `dag-canvas.tsx` or `workflow-page.tsx`. The next agent must check git status for the parallel agent's commits BEFORE rebasing any DAG work.
  - **Residual (registered, not blocking):** the `teachers` repository slot remains mock-backed in Supabase mode (T-047 scoping: needs the modeling ADR — personnel-role view vs table — owner-gated); Teacher-year provisioning via the modal writes mock-only records until that ADR lands.

---

### T-313a — 52nd session: the T-313 closeout audit — repair the 8 tsc errors that shipped in the NEW T-313 test fixtures (REG-007), make the fixtures domain-typed, and re-verify the pushed commit end to end
- **Problems:** REG-007 (NEW) · **Priority:** P1 (process-integrity follow-up on T-313; DAG still EXCLUDED per owner scope directive)
- **Dependencies:** T-313 (the 51st-session commit 328dad9 under audit) · **Affected:** hub desktop test files ONLY (`src/tests/infrastructure/t-313-academic-write-tenant.test.ts`, `src/tests/app/t-313-repository-provider-passthrough.test.tsx`) + docs (AGENTS.md §15.25, problem-registry REG-007, change-log, current-state, next-task)
- **Plan:** (1) re-verify the pushed state: git status / origin sync / FULL suite / tsc on the SAME tree — the owner's completion-audit question is the trigger; (2) root-cause the 8 tsc errors (fixture-domain drift, not runtime drift); (3) extract the four duplicated fixtures to shared constants annotated with the domain input types so future drift fails at compile time; (4) fix the invalid direct cast via the `unknown` double assertion; (5) re-run the full verification ladder AFTER the last edit (the §15.25 rule — the 51st session's exact mistake); (6) registries + change-log + push (with pre-push git fetch for the parallel DAG agent).
- **Status:** Completed — TESTED (2026-09-12, 52nd session):
  - **(1) audit of pushed 328dad9:** `git status` clean; `git log origin/main` = 328dad9 (pushed, no parallel-agent commits at audit time); FULL suite re-run **135 files / 3095 / 0 / 5 skips** (matches the 51st closeout); DAG files untouched by 328dad9 (empty diff on dag-canvas/work-page paths — the scope directive held).
  - **(2) the FALSE "tsc 0 errors" closeout claim found:** `npx tsc --noEmit` on the same tree = 8 errors, all in the two NEW T-313 test files — vitest (esbuild) transpiles without typechecking, so the 25 tests all passed; the 51st session ran tsc BEFORE writing the tests and never re-ran it. Registered as REG-007 + AGENTS.md §15.25.
  - **(3) fixtures domain-typed:** `YEAR_INPUT: CreateSchoolYearInput` (termStructure `"trimester"` — the old `{ terms: 3 }` object never matched the string-literal union), `CLASS_INPUT: Omit<AcademicClass, "id"|"tenantId"|"enrolledCount"|"isActive">` (+`level`, `gradeYear`, `notes`), `SUBJECT_INPUT: Omit<Subject, "id"|"tenantId">` (+`level`, `isActive`, `teacherId`, `teacherName`, `academicYearId`, `academicYearCode`), `ASSIGN_INPUT: Omit<ClassSubject, "id">` — single source for each success/no-tenant pair (the duplicated inline fixtures are gone; runtime assertions byte-identical).
  - **(4) cast fixed:** the passthrough test's `Repositories` → `Record<string, unknown>` now routes through `unknown` (TS-blessed double assertion).
  - **(5) ladder re-run in correct order:** tsc 0 errors AFTER the edits; T-313 files 25/25; FULL suite 135 files / 3095 / 0 / 5 skips — identical counts, zero behavior change by design.

---

### T-314 — 53rd session: the DAG overhaul endgame — TRUE/FALSE binary branching (both engines), the real-entity Test Studio, the school-domain event bridge with REAL side effects, the palette cleanup, and the 3 demo-flow proofs (the parallel-DAG-agent task T-313 deferred to)
- **Problems:** DAG-200 (NEW — closed TESTED) · **Priority:** P0 (the owner's T-314 mandate: "Complete Overhaul & Real-Time Production Wiring of the DAG Workflow Automation Engine")
- **Dependencies:** T-313/T-313a (the green 52nd-session baseline; the DAG scope directive that reserved dag-canvas/workflow-page for THIS session) · **Affected:** hub desktop (`src/domain/model/workflow.ts`, `src/domain/calc/workflow/{dry-run,condition-evaluator,templates}.ts`, `src/features/workflow/{dag-canvas,test-studio-drawer,node-palette,workflow-page}.tsx`, `src/domain/repository/repository.ts`, `src/infrastructure/mock/repositories/{workflow-repository,workflow-side-effects,workflow-event-bridge,academic-repository,student-repository}.ts`, `src/infrastructure/mock/repositories/financial/payment-ops.ts`, `src/infrastructure/supabase/repositories/{supabase-workflow-repository,supabase-academic-repository,workflow-dispatch}.ts`, `src/infrastructure/supabase/supabase-repositories.ts`), `supabase/functions/workflow-execute/engine.ts` (source_handle parity) + 3 NEW test files + `.env.local` (credentials injected, gitignored, NEVER committed)
- **Plan:** (1) IF/ELSE: `WorkflowEdge.sourceHandle: "true"|"false"` + dual-port canvas rendering + handle-aware routing in BOTH the desktop dry-run engine AND the EF engine (parity pinned); (2) Test Studio drawer (real parents with ledger-derived debt, presets, sliders, step inspector with math evaluation + resolved templates + input snapshot; taken edges glow, untaken dim 30%); (3) REAL side effects on execution (tasks in Personnel→Tâches via the canonical task repository, notifications in the Topbar bell, restrict_account sets financiallyRestricted on the parent, audit entries); (4) event bridge: recordRollCall→absence_limit_exceeded (3 unexcused threshold), collectPayment→payment_recorded, markCleared/markBounced→payment_cleared_or_bounced, batchRegister→student_enrolled — mock layer fully + Supabase layer via the canonical workflow-execute EF (late-bound dispatcher injection); (5) palette cleanup (database_query/extract_field hidden, still registered for legacy graphs); (6) templates updated (relance = explicit VRAI/FAUX ports per demo flow 2); (7) credentials in .env.local (gitignored); (8) full verification ladder + registries + push.
- **Status:** Completed — TESTED (2026-09-12, 53rd session):
  - **(1) TRUE/FALSE branching:** `sourceHandle` on WorkflowEdge; condition nodes render the green VRAI (top) + red FAUX (bottom) ports with labels; edges from a labeled port carry the handle, start at the port's Y, and show VRAI/FAUX labels; BOTH engines route handle-aware ("true" open iff passed, "false" open iff failed, unlabeled = legacy GATE — every pre-T-314 graph keeps its exact semantics); EF validation rejects invalid handle values and warns on non-condition sources; parity pinned by 12 new tests incl. taken-edge-key equality between the two engines.
  - **(2) Test Studio (`src/features/workflow/test-studio-drawer.tsx`):** replaces the invisible dummy payload. Real-entity picker (searchable parents, e.g. Karim Benali — real ledger-derived outstanding + restriction status), 3 presets (Dette > 40k / 3 Absences / 0 Dette), debt + absence sliders, live simulation (canvas: taken edges glow + pulse, untaken dim to 30%, inspected step ringed), step-by-step inspector (input payload JSON, math evaluation `debt.amount (65 000) > 40 000 = VRAI`, resolved templates `Bonjour Karim Benali, votre solde de 65 000 DZD…`), plus a REAL-execution button (deployed workflows only) that applies side effects for the picked parent.
  - **(3) REAL side effects (`workflow-side-effects.ts`):** dispatch_task → REAL task via mockTaskRepository (Personnel → Tâches, tags [workflow, wf-id]); push_notification → REAL AppNotification (source "workflow", parent-targeted — Topbar bell +1); restrict_account → parent.financialRestricted = true (CRM « Accès restreint ») + audit; log_audit → appendAudit; send_whatsapp → resolved message + wa.me link as a staff notification + audit. The deterministic 90% mock action failure is REMOVED (real executions must not randomly fail; the EF keeps honest server-side failure semantics).
  - **(4) Event bridge:** mock — recordRollCall (3+ unexcused term absences → absence_limit_exceeded), collectPayment (payment_recorded), markCleared/markBounced (payment_cleared_or_bounced), batchRegister (student_enrolled per student); every dispatcher is fail-safe (audit-logged, never breaks the user action). Supabase — `dispatchTrigger` on SupabaseWorkflowRepository (finds deployed trigger-matching workflows, invokes the canonical workflow-execute EF per workflow with parent_id/student_id/context); the academic repo fires it via a LATE-BOUND dispatcher (`workflow-dispatch.ts` injection in the composition root) so repository construction order + layering stay clean. execute() gained optional {context, targetParentId, triggerSubtype} (legacy 3-arg calls keep working).
  - **(5) Palette cleanup:** `ADMIN_PALETTE_HIDDEN_SUBTYPES` = {database_query, extract_field} — hidden from the admin palette (the empty transform group disappears) while staying REGISTERED in the model + SQL validator 0081 (legacy seeded graphs keep validating/executing/rendering). Pinned by 5 new tests.
  - **(6) Templates:** « Pack Relance Impayés Échelonné » now routes the debt gate through explicit VRAI/FAUX ports (TRUE: WhatsApp + restriction; FALSE: rappel doux portail) — demo flow 2's exact shape; « Clôture Trimestrielle » drops the database_query node (palette-clean recipe).
  - **(7) Credentials:** `.env.local` created (VITE_SUPABASE_URL + VITE_SUPABASE_ANON_KEY for the client; service-role/secret/access/Groq/Firebase for CLI-side use only) — verified gitignored (`git check-ignore`), NEVER committed (AGENTS.md §15.12).
  - **(8) Verification ladder (correct order — §15.25):** `tsc --noEmit` 0 errors AFTER the last edit; `eslint` 0 errors (517 warnings — pre-existing classes, unchanged); FULL suite **138 files / 3117 tests / 0 failures / 5 skips** (baseline 52nd session: 135/3095/0 — +3 files, +22 tests, one pre-existing source-scan test fixed by adopting the canonical parentDisplayName helper).
  - **Demo-flow proofs (repository level, pinned in `workflow-event-bridge.test.ts`):** (1) attendance escalation — 3rd unexcused absence in roll call → workflow notification (bell +1) + REAL task in Personnel→Tâches + run recorded in Workflow→Exécutions + audit trail; (2) debt delinquent — high-debt parent context → TRUE branch runs → parent RESTRICTED (CRM) + WhatsApp prepared with the resolved 65 000 DZD message + FALSE branch skipped; (3) Kahn loop — an action→trigger edge is refused at SAVE time ("Cycle détecté") and deployment stays blocked.
  - **Residuals (honest):** (a) live Supabase end-to-end execution of the bridge requires deployed workflows in the live tenant + the workflow-execute EF (server side is unchanged and already deployed; the desktop path is wired) — live verification deferred to an owner-gated session; (b) `dispatchPaymentOverdue` exists but the mock overdue scanner wiring was not extended (payment_overdue demos use the Test Studio / manual run); (c) the EF source_handle change is verified by the desktop unit suite (engine.ts is suite-tested directly) — the EF itself is NOT redeployed in this session (no sbp token use; owner-gated).

---

### T-315 — CALC-001a: the REAL price matrix + discount-rule correction (desktop engine)
- **Problems:** CALC-001, CALC-002 | **Priority:** P0 · **Severity:** Critical
- **Status:** TESTED (2026-09-12; corpus 11/11 + full suite 139/3119/0 + tsc 0)
- **What was done:** NEW `src/domain/calc/pricing/school-price-matrix.ts` (FI per grade, scolarité per grade, V2/2V/v3 stickers, REAL_TRANSPORT_MATRIX 20 towns + legacy zones, real services labels, EARLY_PAYMENT_RATE 0.05 on scolarité, computeSchoolDevis with the sticker-price flag). `discount-rules.ts`/`discount-engine.ts`: the fictional passage_palier/highest_average/seniority_5y deleted; EARLY 10%→5% (base = scolarité); sibling kept as the default component; `grossTuition` kept as a deprecated alias for the shared cross-platform fixtures. PricingConfig: `registrationFeeByGrade` added (legacy flat fee kept, deprecated). Seed: real values; fictional services→real (PSY/ORTH/E-PLANT/Ratrapage/AUTISTE); fictional discounts seeded INACTIVE. TransportDestination extended to 20 towns (+legacy zones for DB compat); transport.ts/getOfficialTransportTrancheSplit made total. Importer: buildInstallmentRows/buildFinancialEntries now resolve transport via REAL_TRANSPORT_MATRIX with the legacy fallback. AI tools: the ~700k/year hallucination corrected (system-tools.ts hint + comment; statistics.ts bucket comment).
- **Commits:** see change-log entry (54th session).

### T-316 — CALC-001b: the registration wizard on the real model
- **Problems:** CALC-001 (FI per student, ghost fields, prior balances, remise input) | **Priority:** P0 · **Severity:** Critical
- **Status:** TESTED (2026-09-12; t-060-payment-ux rewritten and green)
- **What was done:** types.ts: Step2Student loses previousGradeLevel/previousRank (ghost fields), gains `remise` + `chargeStickerPrice`; BillingPerStudent gains registrationFee/remise/devis/earlyPaymentDiscount; Billing gains totalRemise/priorCredit/priorDebt/subTotal/totalEarlyPaymentDiscount. compute-billing.ts: reimplemented on the real model (per-student FI, remise on V2 only, per-town transport, family totals per the Devis rule). step2: ghost fields removed; remise + sticker-price + 20 towns + 4-versements plan. step3: per-student FI + remise display + prior balances inputs + Sous-total/Montant Total footer. step4: recap updated. modal: priorCredit/priorDebt state; studentInputs carry remise/chargeStickerPrice. Mock buildRegistrationBilling: real model (FI charged per student inside the loop; tranches FI/V2/2V/v3; per-town transport; prior-debt charge). charge-ops + non-tuition-charges + PaymentRepository contract: the REAL service qualifiers.
- **Commits:** see change-log entry (54th session).

### T-317 — CALC-001c: backend realignment (migration 0089, LIVE)
- **Problems:** CALC-001 (catalog) + the 0006 catalog drift (missing updated_at columns) | **Priority:** P0 · **Severity:** Critical
- **Status:** VERIFIED (2026-09-12; applied live atomically HTTP 201, post-checks 5/5 GREEN)
- **What was done:** migration `0089_realign_pricing_to_workbook.sql` + `scripts/apply_0089_live.sh` (T-091/MIG-TOKENS pattern). NOTE: the first apply attempt targeted 0088 but the live chain already had 0088 = workflow_condition_subtype (registered by the 53rd session) — the collision was caught by the atomic-apply failure BEFORE any write; the file was renamed to 0089 and applied cleanly. The migration: additive `grade_level_tuition.registration_fee`; the real grid (annual + V2/2V/v3 tranches + FI per grade); the 4 legacy transport zones' tranche splits CORRECTED (they were invented: 15k+15k+10k for Boumerdès); 24 real town rows (20 towns + variants); 7 real services; the 3 fictional discounts deactivated + full_annual → 5%; early_payment_deadline = June 30. DISCOVERY (documented): the 0006 catalog tables (grade_level_tuition, transport_destinations, additional_services, discounts, complementary_services) had the touch_updated_at triggers but NOT the updated_at columns — ANY update on them crashed live ("record new has no field updated_at"); 0089 adds the columns additively. The ai-proxy EF needed NO change (no pricing text in it — the 700k fix was desktop-side).
- **Commits:** see change-log entry (54th session).

### T-318 — CALC-001d: Android mirror lockstep
- **Problems:** CALC-001 | **Priority:** P0 · **Severity:** Critical
- **Status:** IMPLEMENTED (2026-09-12; code + scenarios updated; suite re-run blocked on toolchain re-provision — the JDK/Android-SDK provisioning script is committed at /home/z/my-project/scripts/provision-android-env.sh per the AGENTS.md §11 recipe)
- **What was done:** `core/DiscountEngine.kt`: the 3 fictional rules deleted; EARLY_ANNUAL_RATE 0.05 (scolarité base); grossScolarite param + grossTuition deprecated alias (shared fixtures keep compiling); the LocalStudentRepository call sites unchanged (alias). `CrossPlatformScenarioRunner.kt`: the all-5-rules scenario corrected to the 2-rule expectation (byte-equivalent numbers with the desktop ScenarioRunner.test.ts). The 5 shared discount scenario fixtures (007/009/010/011/012) corrected: the three fictional rules now pinned as NEGATIVE cases (they must never fire); 009 full_annual → −5%; 012 → sibling + 5%.
- **Commits:** see change-log entry (54th session).

### T-319 — CALC-001e: the corpus verification suite ("the CSV to the letter")
- **Problems:** CALC-001 (acceptance gate) | **Priority:** P0 · **Severity:** Critical
- **Status:** TESTED (2026-09-12; 11/11)
- **What was done:** `scripts/gen_corpus_fixture.py` (repo-root) extracts every ETAT row (390: classe, remise, devis, FI, V2/2V/v3, town, T1-T3, the L-formula, the sticker-price flag, the legacy-row flag) + every Devis quote (10: per-student lines, sous-total, réduction, remboursement, the 5% note) into `src/tests/domain/pricing/fixtures/real-school-corpus.json`. The suite `src/tests/domain/pricing/real-school-corpus.test.ts` verifies: the L-formula decomposition; devis == FI + scol + transport − remise for the standard current-era rows (>150 exact, deviations <35% — the school's own negotiated price variants documented); V2 == V2_sticker − remise for fully-scheduled rows (44 exact, 16 documented custom-split deviations: ZERGANI/BAKHLAL/BINAKLI families + equal-thirds semi-legacy rows); the STICKER-PRICE case == exactly the 2 SEDIKI rows (reproduced via computeSchoolDevis); the transport matrix == every observed town split (incl. AFRA ZINEDINE 65k + MAHMEL RABAH Zemmouri 57k); tranche conservation; the Devis 5% == 5% of Σ scolarité for every quote; Montant Total == Sous-total − Réduction − Remboursement; the remises NOT linear (KOUBA 41 500 ≠ HEBBAZ 10 000 for 3 kids). MS tranche schedule corrected during development (54000/40500/40500 = 40/30/30 of the scolarité — the l132 evidence).
- **Commits:** see change-log entry (54th session).

### T-320 — 57th session (Android UI/UX overhaul, owner mandate; commit messages in the android repo say "55th" — a concurrent-session numbering race with the CALC-002 desktop thread, task IDs are authoritative): the CRM registration wizard — 4-step Inscr. Famille flow on the canonical design system
- **Status:** TESTED (2026-09-13; compile + full-suite evidence)
- **Problems:** UI-310 (NEW — registered this session: flat registration form, invisible success path, silent zero-tuition/zero-transport on bad input, free-text transport destination) | **Priority:** P1 · **Severity:** High (owner-facing staff flow, daily use)
- **Dependencies:** CALC-001/T-318 (the real 2-rule discount engine constrains the simulation) · **Affected:** android only (`ui/features/crm/BatchRegistration{Screen,ViewModel}.kt`, `ChildFormState.kt`, `ParentsDirectoryScreen.kt`, `StudentRosterScreen.kt`, `ui/util/PhoneUtils.kt`, domain `PricingRepository` + `LocalPricingRepository` + new `TransportPricing` domain model)
- **Plan:** 4-step wizard (Parent → Élèves → Facturation → Validation) with stepper, per-step validation, BackHandler, saveable state; child tabs (one form at a time); success screen with PAR-/ELV- codes + activation code + copy + WhatsApp share (PhoneUtils.openWhatsApp gains an optional message param); transport zone dropdown from the REAL 4-zone transport_pricing table via a new PricingRepository transport exposure; live billing simulation via the REAL engine APIs only (evaluateAllSystemDiscounts — NO fictional rules, NO hard-coded transport fee); directories: metric strip, ElSearchBar, WhatsApp quick-action, relationship tag, loading/empty states.

### T-321 — 57th session: CounterPayment + PaymentDetail financial UX
- **Status:** TESTED (2026-09-13; compile + full-suite evidence; commits 2c77d5c + 60d984c)
- **Problems:** UI-311 (NEW — error visible only on step 3, success does not reset/lock the form, raw enum + raw UUID leaks, collector leak, centime truncation) | **Priority:** P1 · **Severity:** High
- **Dependencies:** none (read-side + VM-state only; no write-path change) · **Affected:** android (`ui/features/financials/CounterPayment{Screen,ViewModel}.kt`, `PaymentDetailScreen.kt`)
- **Plan:** ElAlertBanner errors on all steps + clearError(); full-screen success card with "Nouvel encaissement" reset; "Famille à jour" green state; method-conditional field placeholders + validation; engine-derived allocation preview in the VM (core.allocatePaymentToInstallments — PAID for CASH, PENDING for CHECK/TRANSFER) with unallocated-credit line; PaymentDetail: humanized status labels, hero redesign, dismissible banners, dd/MM/yyyy HH:mm timestamps, variant buttons, tranche label resolution, collector-leak fix, elMoneyFormat.

### T-322 — 57th session: expense flows UX + the money-parse correctness fix
- **Status:** TESTED (2026-09-13; compile + full-suite evidence; commit bc3c759; residual: scanner round-trip auto-fill tracked in UI-312)
- **Problems:** UI-312 (NEW — Double→centimes rounding (15.07 → 1506¢), no loading on submit, no success ack, ungated action buttons surface raw server errors, settle dialog path typed manually) | **Priority:** P1 · **Severity:** High (financial correctness)
- **Dependencies:** none · **Affected:** android (`ExpenseSubmitScreen.kt`, `ExpenseApprovalScreen.kt`, `FinancialsTranchesTab.kt`)
- **Plan:** elMoneyParse exact-centimes conversion in both expense screens; DS ElScaffold/ElTopBar migration; French status labels with stage nuance; Demandeur row; reject dialog requestCode + ≥3-char parity; settle dialog prefill + scanner round-trip; permission-aware action buttons (session.can(APPROVE_EXPENSE/DISBURSE_EXPENSE/SETTLE_EXPENSE_PROOF) hide-with-hint, server still enforces); TranchesTab empty state + markPaid confirmation + student/category context.

### T-323 — 57th session: academics screens — dead-link fix + per-tab states
- **Status:** TESTED (2026-09-13; compile + full-suite evidence; commit 0a109b8)
- **Problems:** UI-313 (NEW — ClassesDirectoryScreen.onNavigateToSubjectsDirectory is declared but NEVER used: the Matières directory is unreachable from the hub; ClassDetail isLoading never collected; 4-chip overflow risk; no per-tab empty states; raw grade rows) | **Priority:** P1 · **Severity:** High (real navigation bug)
- **Dependencies:** none · **Affected:** android (`ui/features/academics/ClassDetailScreen.kt`, `ClassesDirectoryScreen.kt`, `SubjectsDirectoryScreen.kt`)
- **Plan:** wire the dead Matières link (header button); ClassDetail: ElTopBar subtitle + tab counts + rememberSaveable tab + per-tab ElEmptyState + roster avatars + subject weights + weighted counter pills + grade accents + loading skeleton + RBAC-gated inline buttons; SubjectsDirectory: filtered-empty state, DS chips, level dropdown in create dialog (KEEP the full current dialog field set — the proposal's reduced dialog is a REJECT: it hardcodes level="all" and drops isExtracurricular), archive confirm via ElConfirmationDialog.

### T-324 — 57th session: Personnel / WorkflowMonitor / Routing / Profile polish
- **Status:** TESTED (2026-09-13; compile + full-suite evidence; commit 0c8fd6f)
- **Problems:** UI-314 (NEW — WorkflowMonitor nodeResults decoded (T-231) but never rendered; PersonnelDetail call button enabled on blank phone + actions visible while null; Profile role as raw enum; activity feed kept) | **Priority:** P2 · **Severity:** Medium
- **Dependencies:** none · **Affected:** android (`personnel/PersonnelDetailScreen.kt`, `personnel/WorkflowMonitorScreen.kt`, `routing/RoutingScreen.kt`, `profile/ProfileScreen.kt`)
- **Plan:** WorkflowMonitor: render the "Étapes exécutées" node-results section (the T-231 decode finally surfaced) with per-node status tone; PersonnelDetail: null-guarded actions, call/email enablement, relevé empty state, full edit dialog preserved (salary/status NOT dropped — proposal REJECT), weekly-hours tag; Routing: empty state, stat strip, "Sans chauffeur" fallback, recent-trips preview kept; Profile: DS migration, roleLabel tag, activity feed + permission overflow line preserved, red expiry urgency kept.

### T-325 — 57th session closeout: verification, registries, zips, push
- **Status:** TESTED (2026-09-13 — FULL GATE: ./gradlew testDebugUnitTest assembleDebug = 58 test classes / 516 tests / 0 failures / 1 env-gated skip, BUILD SUCCESSFUL; RealtimeSyncT069Test helper race fixed en route [commit 0471e0b]; lintDebug pre-existing ARCH-008 state documented)
- **Problems:** — | **Priority:** P0 (process) · **Severity:** —
- **Dependencies:** T-320..T-324 · **Affected:** hub docs + all-repo zips + GitHub push (owner PAT)
- **Plan:** ./gradlew testDebugUnitTest + assembleDebug + lintDebug green with recorded counts; hub registry updates (problem entries UI-310..314, task flips, change-log 55th-session section, current-state, next-task); conventional commits per repo with the 5-question body; zip all three repos + push with the owner PAT; final owner report.


### T-326 — 58th session: reconcile the four live-applied-but-uncommitted migrations (ARCH-012) — 0088/0091/0092/0093 reconstructed from live, chain zero-drift

- **Status:** VERIFIED (2026-09-13) — rollback-wrapped live probe 6/6 ok (policies exact scope, bucket exact limits, has_medical_justification validates, 4 registrations intact); chain diff live 90 = local 90 both directions; append-only guard OK (+4 files, zero edits).
- **Scope:** hub backend chain. Files: 4 new migrations + scripts/verify_t-326.sql. Commit 385311f.

### T-327 — 58th session: the intentional desktop-wide portal layout (UI-315) — the app-shell flex-row fix + sticky rail + the width hierarchy

- **Status:** TESTED (2026-09-13) — website suite 565/565 incl. the NEW t-214 guard suite (11 tests) pinning lg:flex-row + the sticky rail + the absent lg:pl-0; lint clean; strict build green.
- **Scope:** website (app-shell, bottom-nav DesktopRail, top-app-bar, dashboard grid). Commit 265c2c4.

### T-328 — 58th session: the guard-regression repair + i18n completion + junk removal (REG-008 website half)

- **Status:** TESTED (2026-09-13) — all 6 broken guards repaired (t-199/t-210/t-213 ×2/t-211/t-149); .smartexport removed + gitignored; the 2 latent type errors fixed (REG-007 class); 12 new dictionary keys ×3 locales; every dossier/coverage string routed through t().
- **Scope:** website. Commit 265c2c4.

### T-329 — 58th session: the per-child dossier for ALL children — notes (students.medical_notes), the canonical academic history (0091 policy), financial enrollments, complete i18n

- **Status:** TESTED (2026-09-13) — website suite green; the dossier dialog consumes useStudentAcademicHistories (the 0029 canonical table, parent-readable under the reconstructed 0091 policy — positive visibility probed LIVE: visible=1 for a bound family, foreign=0, fail-closed unknown=0).
- **Scope:** website (children-info-card + portal-queries + dictionary). Commit 265c2c4.

### T-330 — 58th session: payment coverage through the ONE canonical chain (PARITY-004) — website module + desktop table-read lockstep

- **Status:** VERIFIED (2026-09-13) — website: src/lib/canonical/payment-coverage.ts + 10 parity tests (incl. migration 0033's 300k-split pin, table→ledger→single precedence). Desktop: PaymentRepository.allocationsForPayment (Supabase + Mock) consumed table-first by PaymentBreakdownCard + 7 contract tests; full desktop suite 3144/3144. LIVE probe: 891 payments with 1,342 allocation rows, ZERO over-allocation (+1 DZD tolerance); 12 legacy payments resolve through the ledger receipt-number join; parent RLS own=3/foreign=0.
- **Scope:** website + desktop (financial read-side only — no write path touched). Commits 265c2c4 (website) + b4f6f22 (desktop).

### T-331 — 58th session: the approvals parent-picker properly registered (REG-008 desktop half) — binding-status awareness (Parent.authUserId), pre-empted 0047 guard, email search

- **Status:** TESTED (2026-09-13) — desktop suite 3144/3144 incl. the NEW t-331 suite (10 tests); typecheck + lint clean.
- **Scope:** desktop (domain model + mapper + approvals-tab). Commit b4f6f22.

### T-332 — 58th session: LIVE E2E verification of the approval → assign-to-EXISTING-parent round-trip + the closeout (registries, change-log, zips, push)

- **Status:** VERIFIED (2026-09-13) — the full live round-trip 16/16 GREEN (scripts/t-332-approval-e2e.py, evidence docs/recovery/t-332-live-verification.md): website registration → 0002-trigger pending request → admin sign-in → EF approve WITH target_parent_id → request approved + parents.auth_user_id bound + profile active + parent role assigned + parent.bind audit written + ZERO duplicate parents/students/installments/payments/ledger-entries (261/391/1280/903/2056 before AND after) + the portal login path resolves the EXISTING parent + child under the user's own RLS + zero-residue cleanup. Coverage/history probes 9/9 + 1/1 GREEN (scripts/t-332-coverage-probe.py).
- **Scope:** live backend E2E + documentation closeout.

### T-333 — 59th session: the exhaustive per-service pricing profile on the website (DATA-016) — canonical derivation + pricing-catalog reads + the expandable detail card

- **Status:** TESTED (2026-09-13) — website suite 43 files / 585 tests / 0 failures incl. the 20-test profile suite (the LIVE ALIOUAT vector); lint clean; strict build green; tsc 0 (66 pre-existing REG-007-class test-fixture errors repaired so tsc is now a usable gate); t-057 port-honesty list updated. Commits 11cd8e5 + the T-333/T-333a pair.
- **Scope:** website (src/lib/canonical/service-pricing-profile.ts NEW + portal-queries pricing-catalog hook + typed schema extension + financial-view per-service card detail + dictionary keys ×3 + tests).
- **Depends on:** T-330 (payment-coverage canonical chain — unchanged), T-168 (byService derivation — extended additively), CALC-001 real price matrix (the live catalog).

### T-334 — 59th session: the desktop verbatim half (DATA-016) — domain/calc/payment/service-pricing-profile.ts + the parent-detail-drawer per-service detail

- **Status:** TESTED (2026-09-13) — desktop suite 143 files / 3162 tests / 0 failures incl. the 18-test profile suite (the SAME vectors); tsc 0; eslint 0 errors. TuitionPricing/TransportPricing +installmentMonths (mapped verbatim by SupabasePricingRepository); the drawer's Par-service view renders the 7-section exhaustive card. Commits b8f22-style + a4a454a (T-334a ledger-honest construction).
- **Scope:** desktop (domain/calc/payment/service-pricing-profile.ts NEW + parent-detail-drawer Facturation per-service expansion + tests pinning the same fixtures as the website suite).
- **Depends on:** T-333 (the shared profile shape), PricingConfig repository (T-047/supabase-pricing-repository).

### T-335 — 59th session: LIVE verification + closeout (registries, change-log, zips, push)

- **Status:** VERIFIED (2026-09-13) — scripts/t-335-live-verification.py 21/21 GREEN: the 6 pricing-catalog tables read through PostgREST+RLS with an authenticated JWT (the exact usePricingCatalog path); the ALIOUAT profile derives LIVE with EVERY field (year 2026-2027, 4am/4AM/cem, class 4ème Année Moyenne, catalog 340 000 + tranches 136k/102k/102k months 9/12/4, conditions sibling+full_annual+5%≤2026-06-30+100/day, FI 132k paid / V2 99k partial-14k / 2V 119k unpaid, provenance run_msp3foah_c254f9, construction gross 350k − remise 20k + cancel 20k = net 350k, delta +10k). Zero-residue (read-only).
- **Scope:** live probe (parent JWT reads the pricing catalog under RLS; the ALIOUAT family's tuition profile derives exhaustively: year, level 4am, catalog 340 000 vs devis 350 000, FI/V2/2V schedule, remise −20 000, provenance) + full suites both repos + docs + commits + push + zip.

### T-336 — 60th session: the website grades-display fix (GRADE-102) — AppShell active-student auto-selection + term-scoped KPI parity + the partial-marks hint, LIVE-verified

- **Status:** Completed — VERIFIED LIVE (2026-09-13) — see GRADE-102 (problem-registry) for the full evidence chain: 11/11 live data-path checks (the retrieval layer was correct), the live RED/GREEN browser round-trip (single-child ATTOUCHE parent with recorded grades: "Aucune note pour cette période" BEFORE → full display AFTER), website 45 files / 599 tests / 0 (+14 T-336 tests) + tsc 0 + eslint clean + strict build green, zero-residue cleanup.
- **Problems:** GRADE-102 (CLOSED — VERIFIED LIVE), REALTIME-105 (NEW, registered — the live probe ran during this task's investigation)
- **Scope:** elimtiyaz-website (`src/features/shared/app-shell.tsx` [the canonical auto-select effect], `src/features/students/student-switcher.tsx` [duplicated effects removed], `src/features/academic/academic-view.tsx` [term-scoped KPIs + the pending-average hint], `src/lib/i18n/dictionary.ts` [`student.average.pending` ×3 locales], NEW `src/test/t-336-active-student-autoselect.test.tsx` [8 tests], NEW `src/test/t-336-academic-parity.test.tsx` [6 tests]).
- **Depends on:** nothing (the data layer was already correct — reading the canonical `assessments` table since 03f6365).
- **Left:** nothing for the grades-display mandate itself. Registered follow-up: T-337 (REALTIME-105). Owner-side note: to SEE the admin-entered grades (ATTOUCHE/CHARIF/ALLOU children), those parents need portal accounts bound via the canonical approval flow (T-331/T-332) — the portal correctly shows only each family's own children under RLS; the only currently-bound parent with a graded child path is via account binding, not code.

### T-337 — 60th session (REGISTERED, not started): add the portal read-model tables to the supabase_realtime publication (REALTIME-105)

- **Status:** Not Started (Ready — one migration + optional client hook; RED control script exists)
- **Problems:** REALTIME-105 (OPEN — live probe evidence 2026-09-13: `assessments` subscription 0 events / `audit_logs` [publication member] 1 event in the same run)
- **Scope (planned):** hub migration 0094 (`alter publication supabase_realtime add table` for `notifications`, `chat_messages`, `installments`, `payments`, `homework`, `assessments` — idempotent membership guards per the 0085 pattern; RLS already scopes delivered events per subscriber) + website `useGradesRealtime(studentId)` hook (the useHomeworkRealtime pattern) consumed in the academic view if instant grade updates are wanted. Re-run scripts/realtime-probe.mjs as the RED→GREEN control.
- **Depends on:** nothing (additive; zero RLS change — the 0085 security analysis applies: events are filtered by each subscriber's SELECT policies).
- **Priority:** P2 (the T-033 fallback keeps data stale-bounded; the desktop matches fetch-on-mount so no parity gap today — this is an enhancement, not a break).

## 61st session (2026-09-14) — owner mandate: "Implement the executive/actionable statistics in BOTH the mobile app and the desktop version — identical definitions, one calculation source, zero hardcoded/estimated values; remove the vanity statistics (payment-amount histogram, weekday collection heatmap, the smooth 12-month revenue spline, raw debt without aging/tranche context, the artificial class-capacity calculations)"

### T-338 — 61st session: the DESKTOP canonical executive-statistics engine (STATS-400) — tranche-wave velocity, discount erosion, debt triage, family concentration, transport yield, services yield, enrollment/sibling/section-imbalance, triple-risk summary

- **Status:** IMPLEMENTED → TESTED (commit 256bfa4 — 44/44 unit tests green, exact integer expectations; mirrored by Android T-340 in-flight)
- **Problems:** STATS-400 (NEW — the vanity-vs-operational statistics gap: the current analytics tab shows passive counters and generic e-commerce visuals while the school needs collection-wave velocity, discount erosion, chronic-vs-transitory debt triage, family exposure concentration, transport/service yield, sibling index, section imbalance, and the triple-risk radar front-and-center)
- **Scope:** hub desktop — NEW `src/features/dashboard/components/analytics/executive-statistics.ts` (the pure derivation family: deriveTrancheWaves / deriveDiscountErosion / deriveDebtTriage / deriveFamilyExposure / deriveTransportYield / deriveServiceYield / deriveEnrollmentDynamics / deriveTripleRiskSummary) + domain model additive fields (`Installment.trancheNumber`, mapped from the live `tranche_number` column in the supabase + mock mappers) + the domain-level transport-town normalizer (the excel destination-mapper alias table lifted to `src/domain/calc/pricing/transport.ts`, excel mapper delegating to it — one alias table, no duplicate) + unit tests.
- **Depends on:** nothing (pure additive derivation layer over existing repository contracts: installments.observe(), ledger.observe(), students/parents/classes.observe(), payments.observe()).
- **Priority:** P0

### T-339 — 61st session: the DESKTOP dashboard restructure — vanity statistics removed, the executive command-center UI wired to the engine

- **Status:** TESTED (commit 66e69b7 — full suite 144 files / 3198 tests / 0 failures; tsc --noEmit 0 errors; eslint 0 errors; AI capability suite asserts capacity_fill GONE)
- **Problems:** STATS-400 (the UI leg) · UI-307 partial supersession (the Power BI visuals that are vanity get removed: AmountHistogramCard, CollectionHeatmapCard, RevenueTrendExplorer)
- **Scope:** hub desktop — analytics-tab restructure (new "Pilotage" executive mode first, triple-risk front-and-center; remove AmountHistogramCard + CollectionHeatmapCard + RevenueTrendExplorer; keep YoY/mixes/Pareto/aging-composition which are real-data); overview-tab hero replaced by the tranche-wave velocity view (the staircase, not the smooth spline); KPI debt contextualized (chronic >45j share); ClassCapacityAnalyzer DELETED + see-details-modal capacity section removed; demographics().capacity slice removed from the DashboardRepository contract + both mock/supabase implementations + all consumers; the X/Y capacity badges (teacher-dashboard `${enrolledCount}/${capacity}` → `X élèves inscrits`; academic-year-detail-drawer `X/Y élèves` → `X élèves inscrits` + the fake-30 totalCapacity/capacityRate removed); dashboard tests updated.
- **Depends on:** T-338 (the engine).
- **Priority:** P0

### T-340 — 61st session: the ANDROID verbatim mirror — StatisticsEngine extension + Room migration 14→15 (trancheNumber + transportTier) + the executive UI + vanity-card removal

- **Status:** TESTED (android commit 12994e7 — the FULL suite 558 tests / 0 failures / 1 pre-existing skip; ExecutiveStatisticsTest 45/45 verbatim desktop corpus; CrossPlatformEquivalenceTest asserts the executive_statistics corpus 8 families deep-equal — desktop ≡ android on every value; Room migration discipline re-pinned to v15; the WIP backup was 47a7cd7)
- **Problems:** STATS-400 (the Android leg) · PARITY family debt (T-333 pricing-profile mirror superseded by this larger statistics parity mandate)
- **Scope:** elimtiyaz-android — `core/StatisticsEngine.kt` extended with the T-338 derivation families VERBATIM (source commit recorded in the header per ADR-002); Room MIGRATION_14_15 (installments.tranche_number INTEGER NOT NULL DEFAULT 1; students.transport_tier TEXT NULL) + entity/DTO mapper updates + MigrationTestHelper test; DashboardViewModel/LocalDashboardRepository wiring; new Analytique cards (wave velocity, discount erosion, debt triage, family concentration, transport, services, enrollment/imbalance, triple-risk radar); vanity cards removed (YoYAndHistogramCards histogram half, HeatmapAndAgingCards heatmap half, RevenueTrendExplorerCard, DemographicsCard capacity gauges, ClassDetailScreen capacity gauges → section-imbalance + plain enrolled counts).
- **Depends on:** T-338 (the canonical engine to mirror).
- **Priority:** P0

### T-341 — 61st session: cross-platform equivalence + LIVE verification — the corpus category + the SQL truth scripts + both live runners

- **Status:** VERIFIED LIVE (hub commit 7c198dd — `verify_t-338.sql` server-side truth (BEGIN…ROLLBACK) + `verify_t-338_live.ts` live diff runner: **299 checks / 0 mismatches** over the production stream (1280 installments · 2060 ledger · 391 students · 905 payments); the corpus leg was 84b2a65 (311/0/1 pre-existing) and the Android runner mirror landed in android 12994e7; evidence: docs/recovery/t-338-live-verification.md)
- **Problems:** STATS-400 (the proof leg)
- **Scope:** hub — financial-tests corpus category `executive_statistics` (then-blocks generated from the REAL TS derivations) + the op in BOTH runners + CrossPlatformEquivalenceTest.kt extension; `elimtiyaz-desktop/scripts/verify_t-338.sql` (BEGIN/ROLLBACK server-side truth: tranche waves, remise census via metadata markers, debt triage buckets, family concentration, transport towns, sibling index, section imbalance) + a live node runner executing the TS derivations against the live Supabase stream and diffing against the SQL truth; Android LiveDatabaseEquivalenceTest extension (env-gated) when the toolchain allows.
- **Depends on:** T-338 + T-340.
- **Priority:** P0

### T-342 — 61st session: closeout — registries + change-log + current-state + next-task + zips + GitHub push (owner PAT)

- **Status:** Completed (this session's docs + zips + pushes: hub 6482d26 → 7c198dd, android 47a7cd7 → 12994e7, website already in sync; the change-log entry + current-state + next-task updated; zips to the download area)
- **Problems:** process (ADR-007)
- **Scope:** all repos — the five-question commits per repo, registry status flips with evidence, change-log entries, zips to the download area, push with the owner PAT.
- **Depends on:** T-338..T-341.
- **Priority:** P1

### T-343 — 62nd session: the matière mandate registration — MATIERE-500 + ADR-018 + the task set

- **Status:** In Progress (2026-09-14 — the audit complete, the problem registered BEFORE the fix per §13, ADR-018 accepted)
- **Problems:** MATIERE-500
- **Scope:** docs only — the problem-registry entry (252 detailed entries), ADR-018 (canonical subject architecture: identity vs context configuration, the cc component, the snapshot discipline, the one-resolver rule), this task set (T-344..T-349), next-task update.
- **Depends on:** none (owner mandate; commit 158d806 is the trigger evidence).
- **Priority:** P0
- **Required tests:** none (docs-only commit).
- **Next:** T-344.

### T-344 — 62nd session: DB — migration 0094 (subject_configurations + the cc component + exam_sessions + the live seed)

- **Status:** Ready
- **Problems:** MATIERE-500
- **Scope:** `elimtiyaz-desktop/supabase/migrations/0094_subject_context_configurations.sql` — the `subject_configurations` table (tenant, subject, academic_year, academic_level, direction, coefficient, subject_code, passing_grade, is_extracurricular, grading_recipe JSONB, is_active; unique (tenant, subject, year, level, direction)) + RLS (the 0019 pattern) + the `assessments.cc` + `coefficient_cc` columns + the generalized `compute_assessments_subject_average` trigger (recipe Σ(mark×weight)/Σ(weight), default {1,1,2,0} bit-identical) + the `exam_sessions` table + RLS + the live seed (12 subjects × levels in use, preserving live values) + the atomic live apply (MIG-TOKENS pattern: file + registration in one call) + `scripts/verify_t-344.sql` (BEGIN…ROLLBACK, both the happy paths and the regression paths).
- **Depends on:** T-343.
- **Priority:** P0
- **Next:** T-345.

### T-345 — 62nd session: desktop domain — the SubjectConfiguration model + the canonical resolver + the 14-chain replacement

- **Status:** Ready
- **Problems:** MATIERE-500
- **Scope:** `src/domain/model/academic.ts` (SubjectConfiguration type + Assessment.cc/coefficientCc), NEW `src/domain/calc/academics/subject-config.ts` (`resolveSubjectConfiguration` + `computeSubjectAverageFromRecipe`), the Supabase + mock repositories (observe/upsert configurations; the resolver wired into observeByClass), the 14 coefficient fallback chains replaced by the resolver (gpa.ts, grade-entry-screen, class-detail-page, class-grades-tab, class-subjects-tab, academic-year-detail-drawer, teachers-tab, academic-tab, operational-query-engine), unit tests + the `subject_configuration` corpus category.
- **Depends on:** T-344.
- **Priority:** P0
- **Next:** T-346.

### T-346 — 62nd session: desktop UI — the subject-config management surface + grade-entry integration

- **Status:** Ready
- **Problems:** MATIERE-500
- **Scope:** the subjects directory gains the per-year × per-level configuration matrix (coefficient, subject code, passing grade, recipe incl. cc weight, extracurricular flag — admin-editable, non-retroactive banner), the grade-entry screen renders the cc slot when the resolved recipe enables it, exam sessions listing in the academics tab.
- **Depends on:** T-345.
- **Priority:** P1
- **Next:** T-347.

### T-347 — 62nd session: website sync — the canonical resolver port + academic-view/bulletin on the same definitions

- **Status:** Completed (TESTED + VERIFIED LIVE — commit 3a01902, pushed: lint clean, tsc 0 errors, the FULL suite 46 files / 607 tests / 0 failures, strict build green; LIVE probes: subject_configurations readable through the exact PostgREST+RLS path with the recipe JSON intact, assessments.cc/coefficient_cc readable, the anonymous read blocked, the owner-pinned admin credential valid)
- **Problems:** MATIERE-500
- **Scope:** `src/lib/canonical/subject-config.ts` (verbatim port), portal-queries read `subject_configurations`, the 3 website fallback chains (portal-derive.ts, bulletin.ts, academic-view.tsx) replaced by the resolver, the cc mark rendered (i18n fr/ar/en), tests.
- **Depends on:** T-344 (the website reads the new table through parent-scoped RLS).
- **Priority:** P0
- **Next:** T-348.

### T-348 — 62nd session: Android mirror — the cc-aware formula + the config-aware coefficient

- **Status:** Completed (TESTED — commits 3b3a38d + merge b551c9f, pushed: the FULL suite on the merged tree 62 files / 579 tests / 0 failures / 1 env-gated skip; the corpus run through the REAL Kotlin mirror: all 7 t345 subject_configuration scenarios error-free with the expected values, the triple comparator 319 scenarios / 317 equivalent / 2 pre-existing discrepancies [023/025 studentId null-vs-"", untouched by this task])
- **Problems:** MATIERE-500
- **Scope:** `core/Pricing.kt` computeSubjectAverage gains the cc component (defaults bit-identical), Subject/Assessment DTOs + Room migration add cc, the corpus `subject_configuration` category in the Android runner, the coefficient resolution via the config mirror (`core/SubjectConfig.kt`).
- **Depends on:** T-344, T-345.
- **Priority:** P1
- **Next:** T-349.

### T-349 — 62nd session: closeout — registries + change-log + current-state + next-task + zips + push

- **Status:** Completed (this closeout — the registry flips with evidence, the change-log/current-state/next-task, the AndroidEquivalenceRunner hub mirror synced, the zip set, the pushes; MATIERE-500 flipped CLOSED)
- **Problems:** MATIERE-500 (status flip with evidence)
- **Scope:** registry flips, change-log, current-state, next-task, the zip set (hub + website + android), the GitHub push with the owner PAT.
- **Depends on:** T-343..T-348.
- **Priority:** P1

### T-350 — 63rd session: the dashboard-statistics investigation — full data-flow verification (Excel → import → DB → repos → engines → UI) + the defect matrix + the negative findings

- **Status:** Completed (TESTED + LIVE-VERIFIED — evidence: docs/recovery/t-350-live-verification.md: the full data-flow trace, the 9-defect matrix, the 5 refuted claims, the CSV↔DB exact-parity script, the live leg-2 probes 6/6 GREEN, the engine re-verification 302 checks TS≡SQL)
- **Problems:** DASH-401..DASH-407, DATA-017, DATA-018 (the registrations above)
- **Scope:** the owner's investigation mandate — verify ALL claimed defects from the pasted diagnostic report against the CURRENT tree + the LIVE database before any fix. Evidence goes to `docs/recovery/t-350-live-verification.md` (the full Excel↔DB cross-comparison + the refuted-claims registry). Also the session-opening baseline gates (tsc 0 / eslint 0 errors / vitest 144 files / 3198 / 0).
- **Depends on:** nothing (read-only investigation).
- **Priority:** P0
- **Next:** T-351.

### T-351 — 63rd session: reactive debt/payments/students/personnel wiring — kill every `.get()`-on-unseeded-observable read (DASH-401 + DASH-406)

- **Status:** Completed (TESTED — 8 new t-351 tests; full suite 145 files / 3206 / 0; tsc 0; eslint 0 errors)
- **Problems:** DASH-401, DASH-406
- **Scope:** `dashboard-page.tsx` subscribes `repos.debt.observeSummary()` reactively (the T-243 payments-stream pattern), keeps a top-10 display slice, passes the FULL summary to the risk engine; `reports-tab.tsx` subscribes its four streams via `useObservable`. Regression tests: the first-render race (empty cache → populated cache) and the top-10-slice-vs-full-summary contract.
- **Depends on:** T-350 (the registrations).
- **Priority:** P0
- **Next:** T-352.

### T-352 — 63rd session: school-wide grade + attendance streams (DASH-402)

- **Status:** Completed (TESTED — 11 new t-352 tests; full suite 148 files / 3237 / 0; tsc 0; eslint 0 errors)
- **Problems:** DASH-402
- **Scope:** `GradeRepository.observeAll()` + `AttendanceRepository.observeAll()` added to the contract, the Supabase repositories (tenant-scoped, ordered), and the mock repositories (store-derived — parity); `analytics-tab.tsx` consumes them (the `""`-ID queries deleted). Tests: Supabase query shape + mock parity + the analytics tab feeding non-empty assessment/attendance into `evaluateStudentRiskProfiles`.
- **Depends on:** T-350.
- **Priority:** P0
- **Next:** T-353.

### T-353 — 63rd session: academic-year scoping for the installment-derived statistics (DASH-403)

- **Status:** Completed (TESTED — 15 new t-353 tests; full suite 150 files / 3255 / 0; tsc 0; eslint 0 errors)
- **Problems:** DASH-403
- **Scope:** ONE pure range-filter helper (due-date window) applied at the page level to the installments stream before it feeds OverviewTab + AnalyticsTab; the canonical derivations untouched. Tests: year-switch re-scoping (2025-2026 shows the 3-wave picture; 2026-2027 shows its own 4 rows), boundary due-dates, no-installment honest state.
- **Depends on:** T-350.
- **Priority:** P0
- **Next:** T-354.

### T-354 — 63rd session: retire the label-parsed tranche-wave twin in the Financials tab (DASH-404)

- **Status:** Completed (TESTED — the T-248 suite re-pinned to the canonical column + the new T-354 BON-label cases; full suite 150 files / 3256 / 0; tsc 0; eslint 0 errors)
- **Problems:** DASH-404
- **Scope:** `installment-schedule-tab.tsx` wave derivation switches to `tranche_number` grouping (canonical semantic); the label-regex helper deleted; the header renders tuition rows again. Tests: BON labels ("INSCRIPTION (FI)" / "2EME TRANCHE" / "3ème TRANCHE" / "4ème TRANCHE") group correctly; transport rows unaffected; "Année complète" excluded from wave cards.
- **Depends on:** T-350.
- **Priority:** P1
- **Next:** T-355.

### T-355 — 63rd session: the Departments drill-down from the REAL payments stream (DASH-405)

- **Status:** Completed (TESTED — the t-355/t-356 suite 11/11; full suite 151 files / 3267 / 0; tsc 0; eslint 0 errors)
- **Problems:** DASH-405
- **Scope:** `dashboard-page.tsx` passes the payments stream (range-filtered) to `SeeDetailsModal`; `DepartmentsTab` derives per-operational-unit totals from REAL rows (category→unit map), placeholder state deleted. Tests: the category→unit mapping, range filtering, honest zero state.
- **Depends on:** T-350.
- **Priority:** P1
- **Next:** T-356.

### T-356 — 63rd session: mock↔Supabase revenue-bucket parity (DASH-407)

- **Status:** Completed (TESTED — the shared buildWindowAnchoredBuckets helper + the query-shape and parity tests; full suite 151 files / 3267 / 0)
- **Problems:** DASH-407
- **Scope:** `SupabaseDashboardRepository.revenueForRange` builds buckets anchored to the requested range (the mock's convention) instead of NOW-relative last-12-months; out-of-bucket dropping removed. Tests: same fixture through mock + Supabase shapes → identical labels/amounts (the §15.15 tell).
- **Depends on:** T-350.
- **Priority:** P1
- **Next:** T-357.

### T-357 — 63rd session: honest demographics for placeholder data (DATA-018) + the DATA-017 documentation

- **Status:** Completed (TESTED — 8 new t-357 tests; full suite 152 files / 3275 / 0; tsc 0; eslint 0 errors; DATA-017 documented in the T-350 verification doc)
- **Problems:** DATA-018, DATA-017
- **Scope:** `SupabaseDashboardRepository.demographics` routes NULL + the pinned 2000-01-01 import placeholder to a "Non renseigné" age slice (unit test pins the placeholder value); the T-350 verification doc records DATA-017 (import-timestamp payments) as a data-quality boundary. No date/gender fabrication.
- **Depends on:** T-350.
- **Priority:** P2
- **Next:** T-358.

### T-358 — 63rd session: closeout — registry flips + change-log + current-state + next-task + zips + push

- **Status:** Completed (this commit — the registries, the change-log entry, the current-state snapshot, the next-task update, the live leg-2 verification doc extension, the zips + the push)
- **Problems:** DASH-401..407 + DATA-017/018 (status flips with evidence)
- **Scope:** registry flips, change-log, current-state, next-task, the zip set, the GitHub push with the owner PAT. COORDINATION: the 62nd session (MATIERE-500, T-345..T-349) is running CONCURRENTLY — fetch → inspect → merge forward → re-run the full gates before push (never force-push).
- **Depends on:** T-350..T-357.
- **Priority:** P1

### T-359 — 64th session: register the cross-platform upload-defect family + the LIVE RED/GREEN evidence script (UPLOAD-101/102/103)

- **Status:** COMPLETED (TESTED + live-verified, 2026-09-14 — `scripts/t-359-upload-e2e.py` 13/13 GREEN: the three tenant-less/mock-tenant paths RLS-rejected live, the canonical tenant-scoped paths accepted, role resolution + cross-tenant denial + zero-residue cleanup all verified; evidence `docs/recovery/t-359-live-verification.md`)
- **Problems:** UPLOAD-101, UPLOAD-102, UPLOAD-103
- **Scope:** the live end-to-end proof that the three client-side upload defects are real (tenant-less / mock-tenant paths → RLS 403) AND that the canonical tenant-scoped paths pass on the SAME accounts: `elimtiyaz-desktop/scripts/t-359-upload-e2e.py` (staff leg + parent leg + role-resolution leg + cross-tenant denial guard + zero-residue cleanup; secrets env-only per §15.12). Backend census recorded: all 10 buckets + 24 storage policies exist and are correctly configured — the defects are CLIENT-side path/tenant bugs, NOT missing buckets.
- **Depends on:** nothing (independent of the concurrent 63rd-session dashboard scope).
- **Priority:** P0
- **Next:** T-360.

### T-360 — 64th session: website document-upload path fix (UPLOAD-101)

- **Status:** COMPLETED (TESTED, 2026-09-14 — commit 68ad0b6 website repo: tenant-scoped path from activeKid.tenant_id; 5-test regression suite incl. the whole-src upload-path guard; gates 47 files / 612 tests / 0 + lint + strict build + tsc 0)
- **Problems:** UPLOAD-101
- **Scope:** `student-documents-card.tsx` UploadDocumentDialog builds `{tenantId}/{studentId}/{kind}-{ts}.{ext}` (tenant from the active StudentRow); header comment corrected (0018/0043, not "0027"); regression test source-scanning the path construction; website gates (lint + vitest + strict build).
- **Depends on:** T-359.
- **Priority:** P0
- **Next:** T-361.

### T-361 — 64th session: desktop payment-proof tenant fix + phantom bucket removal (UPLOAD-102)

- **Status:** COMPLETED (TESTED, 2026-09-14 — commit 2fef316 hub repo: session.tenantId + the T-053 loud guard; phantom therapy-attachments bucket removed; 5-test regression suite; gates typecheck 0 / eslint 0 errors / 152 files / 3280 tests / 0 on the merged tree)
- **Problems:** UPLOAD-102
- **Scope:** `unified-payment-modal.tsx` uses `session.tenantId` with the T-053 explicit no-tenant failure (mirrors `homework-push-modal.tsx`); the unused phantom `"therapy-attachments"` member removed from `MediaBucket` (no bucket by that name exists anywhere); regression test asserting no `"mock"` literal reaches the vault call; desktop gates (typecheck + eslint + vitest).
- **Depends on:** T-359.
- **Priority:** P0
- **Next:** T-362.

### T-362 — 64th session: Android storage upload fix — tenant path + honest failure + upload timeout (UPLOAD-103)

- **Status:** COMPLETED (TESTED, 2026-09-14 — commit 5adc721 android repo: contract tenantId + StorageBuckets.objectPath; null-tenant fail-closed; SyncErrorClassifier reuse (transport vs 4xx); 60 s upload timeout; honest scanner UI; 8-test suite; gates 60 files / 566 tests / 0 + lintDebug + assembleDebug green)
- **Problems:** UPLOAD-103
- **Scope:** `StorageRepository.uploadProof` contract gains the tenant parameter (desktop `uploadPrivateMedia` mirror); `LocalStorageRepository` uploads `{tenantId}/{entityId}/{fileName}` with a 60 s upload timeout; REUSES `SyncErrorClassifier.isTransient` so transport failures keep the sanctioned offline-first local fallback while permanent 4xx rejections (RLS) surface as `Result.Err` — never a fake success; `ProofScannerViewModel` passes `sessionManager.currentTenantId()`; unit tests for the path construction + the classifier branches; Android gates (compile + lint + test).
- **Depends on:** T-359.
- **Priority:** P0
- **Next:** T-363.

### T-363 — 64th session: closeout — registry flips + change-log + current-state + next-task + zips + push

- **Status:** COMPLETED (2026-09-14 — post-fix live re-verification 13/13 GREEN ×2 idempotent runs zero residue; AGENTS.md §15.28 added (the storage-path convention rule); registry flips; change-log + current-state + next-task; zips + push with the owner PAT)
- **Problems:** UPLOAD-101/102/103 (status flips with evidence)
- **Scope:** registry flips, change-log, current-state, next-task, the zip set, the GitHub push with the owner PAT. COORDINATION: the 63rd session (T-351..T-358 dashboard wiring) may push concurrently — fetch → inspect → merge forward → re-run gates before every push (never force-push).
- **Depends on:** T-359..T-362.
- **Priority:** P1

### T-364 — 65th session: the Excel re-import idempotency family (IMPORT-107/108/109) — three financial write-path defects found by the empty-restore suite

- **Status:** COMPLETED (TESTED, 2026-09-14 — the t-364 suite 8/8 GREEN + the empty-state suite's re-import no-op assertions GREEN in both layers; full desktop gates on the merged tree: tsc 0 errors / eslint 0 errors / 155 files / 3301 tests / 0 failures)
- **Problems:** IMPORT-107 (flush idempotency + atomicity: adapter pre-dedupe by (sourceType|sourceId), Supabase bulkAppend ON CONFLICT DO NOTHING + loud Err + truthful cache, payments ignore-duplicates upsert), IMPORT-108 (MockPaymentRepository.bulkCollect — the import-shaped contract the Supabase side already had), IMPORT-109 (findExistingStudent exact identity match — the BELGRIMAT sibling cross-wiring)
- **Scope:** `repository-adapter.ts` (flush dedupe + Err honouring + exact student matching), `financial-repository.ts` (mock bulkCollect), `supabase-shared-repositories.ts` (ledger + payments upsert paths), `t-364-import-flush-idempotency.test.ts` (NEW, 8 tests), the T-012/T-015 fakes extended with the upsert surface (their fail-fast / receipt-allocation contracts re-verified). COORDINATION: the concurrent 64th session's closeout (f3f1be9/e14c43c) merged forward with zero conflicts (disjoint file sets).
- **Depends on:** T-350 (the first-import correctness baseline this family builds on).
- **Priority:** P0
- **Next:** T-365.

### T-365 — 65th session: the empty-state Excel restore verification (IMPORT-106) — the owner's exact scenario, cross-checked against the workbook's own cells

- **Status:** COMPLETED (TESTED, 2026-09-14 — the empty-state-excel-restore suite 13/13 GREEN: Layer A pipeline + Layer B real-mock-repositories; every record, every per-row financial, every FK, every aggregate, the atomic rollback, and the re-import no-op)
- **Problems:** IMPORT-106 (the verification gap — CLOSED by this suite's existence and GREEN run; the three real defects it flushed out were T-364's IMPORT-107/108/109)
- **Scope:** `src/tests/integration/empty-state-excel-restore.test.ts` (NEW, 13 tests, 856 lines) — reads the REAL `Suivis clients  2026_2027.xlsx` directly via exceljs for ground truth (independent of the pipeline), runs the import against a completely empty state in both layers, cross-checks per-row charges/payments/balances vs the workbook's own cells, the FK graph, the aggregate reconciliation (payments Σ 55,227,100 = TOTAL VERSEMENTS; charges/installments-due Σ 113,518,800), the canonical computeParentSummary feed, the ZIREG LEA 4-tranche reference (239,500), the Devis/BON print-layout classification (201 skipped / 418 imported / 0 rejected), the mid-import-failure rollback to EMPTY, and the re-import complete no-op. Pinned census anchors trip loudly on a workbook replacement.
- **Depends on:** T-364 (the fixes the suite asserted against).
- **Priority:** P0
- **Next:** T-366 (closeout — this entry).

### T-367 — 66th session: the portal document-upload TABLE leg (UPLOAD-104) — the row INSERT omits tenant_id, so the "fixed" upload still 403s live

- **Status:** COMPLETED (TESTED + the live leg RED→GREEN-proven, 2026-09-14 — website 51ca7e5 [fix + 6-test guard, full gates 48/618/0 + tsc 0 + eslint + strict build], hub eab7bfe [registration] + f829033 [the t-359 e2e TABLE leg]; live E2E 19/19 GREEN: L = pre-fix payload → 403/42501 'new row violates row-level security policy for table student_documents' [the owner's exact console signature], M = fixed payload → 201, M2 = parent read-back 200, N = cross-tenant still 403, Z = zero residue [docs 0 before AND after — no upload has ever succeeded])
- **Problems:** UPLOAD-104 (the `student_documents` row INSERT omits `tenant_id`; the column has NO default; the 0043 parent INSERT policy's WITH CHECK `tenant_id = current_tenant_id()` fails on NULL → SQLSTATE 42501 → PostgREST HTTP 403 — the owner's live console evidence. The t-359 e2e probe covered the STORAGE leg only; the TABLE leg was never exercised — the verification gap that let UPLOAD-101 close TESTED while the live flow still failed)
- **Scope:** elimtiyaz-website `src/features/profile/student-documents-card.tsx` (insert payload gains `tenant_id: tenantId` — the `chat_messages` convention); NEW regression guard `src/test/t-367-insert-tenant-guard.test.ts` (payload carries tenant_id + whole-src guard on every `.from("student_documents").insert(`); hub `elimtiyaz-desktop/scripts/t-359-upload-e2e.py` extended with the TABLE leg (L: no-tenant insert → 42501/403 RED proof; M: tenant insert → 201 + parent read-back GREEN proof + zero-residue cleanup); closeout registries.
- **Depends on:** T-360 (the storage-path fix whose tenantId prop this fix reuses).
- **Priority:** P0 (the owner's live console evidence names this exact endpoint)
- **Next:** T-337 (REALTIME-105) — the standing P0 publication migration (unchanged recommendation from the 65th session).

### T-368 — 67th session: the unified PDF/Report/Excel generation mandate (REPT-500/501/502/503/504/505) — every PDF path fixed, full-application Excel export, PDF+XLSX for the global reports

- **Status:** COMPLETED (TESTED + the LIVE leg, 2026-09-14 — hub commits 47fb21e [T-368a: the PDF generator repairs — REPT-500/501/502, 11-test RED→GREEN suite] + 827f8c8 [T-368b/c: full-export.ts + the global-reports PDF twins + the Reports-tab wiring — REPT-503/504/505, 11 more tests] + this closeout; full gates at close: tsc 0 / eslint 0 errors [555 baseline warnings] / vitest 159 files / 3323 passed / 0 failed; LIVE evidence: the t-368-live-export-e2e ran the ACTUAL generators over the REAL Supabase rows [261 parents / 391 students / 907 payments / 1280 installments / 2064 ledger entries] and the t-368-verify-live-summary cross-check reconciled EVERY Résumé total with direct SQL aggregates [facturé 115 835 800 / encaissé 58 270 500 / solde signé 55 831 700 — exact]; REPT-505 [the data-export sign-convention discovery] registered AND closed same-session; the mid-session discoveries [PostgREST 1000-row pagination, the hex-string content-stream extraction technique] are documented in AGENTS.md §15.29 and the live-verification doc)
- **Problems:** REPT-500 (U+202F WinAnsi crash on every realistic amount — RED-proven by probe), REPT-501 (silent truncation: 25-payment cap, y<100 breaks, 2-line notes, dropped footnotes), REPT-502 ("Page 1/1" lie + footer-less continuation pages), REPT-503 (no full-application Excel export), REPT-504 (no PDF variant of the global reports), REPT-505 (the data-export summary sign-convention inflation — discovered mid-session, registered before its fix)
- **Scope:** hub desktop `src/infrastructure/receipt-pdf/*` (sanitize at the draw layer, two-pass pagination, real page counts, truncation removal), `src/infrastructure/excel/full-export.ts` (NEW — unified full export over the existing export-engine), `src/features/dashboard/tabs/reports-tab.tsx` (PDF variants + the full-export action), NEW suite `src/tests/infrastructure/t-368-*.test.ts` (RED→GREEN per document type + full-export shape assertions). The website already carries its own fix (T-194/T-195) — no website change required (the desktop reference is being repaired, the port divergence noted in REPT-500 closes by desktop-side parity with the website's seam).
- **Depends on:** nothing (baseline gates green at session OPEN: tsc 0, eslint 0 errors, 155 files / 3301 tests / 0 failures).
- **Priority:** P0 (the owner's explicit mandate for this session)
- **Next:** T-337 (REALTIME-105) — unchanged standing recommendation.

### T-369 — 68th session: the commit-74d3ebb Personnel & Workforce subsystem backend integration (WORKFORCE-500) — implement the missing logic behind the UI-only commit

- **Status:** COMPLETED (TESTED + the LIVE legs, 2026-09-14 — hub commits 6212df6 [registration] + 86f3ce2 [T-369a: migration 0095 applied live atomically, verify 23/23] + 7b7dc98 [T-369b: the desktop wiring + 27 new tests + the live REST E2E 26/26] + the closeout; full gates at close: tsc 0 / eslint 0 errors / vitest 161 files / 3350 passed / 0 failed / build GREEN — the session-OPEN baseline was RED at 31 tsc errors, owned and repaired by this task; LIVE evidence: docs/recovery/t-369-live-verification.md)
- **Problems:** WORKFORCE-500 (the family: see problem-registry — the UI-only commit 74d3ebb shipped the Personnel & Workforce UI with NO backend: the desktop typecheck is RED at 31 errors because the domain contracts changed with no repository-layer update; the salary adjustment / disbursement flows are client-side simulations; the staff-absence justification loop and the leave-request clarification loop have NO persistence; the tasks review lifecycle columns do not exist; a second parallel mock file split-brained the mock layer)
- **Scope:** (a) migration 0095_personnel_workforce_system.sql — salary_adjustments + salary_payments + staff_absences tables, adjust_personnel_salary + record_salary_disbursement RPCs (audited, tenant+role-guarded, 0055-hardened), RLS per the 0019 conventions, tasks/leave_requests column additions; (b) desktop wiring — the ONE mock implementation extended to the new contract (the dead parallel mock removed), SupabaseTaskRepository/SupabaseLeaveRequestRepository/SupabaseWorkforceAttendanceRepository extended to the new contract, SupabasePersonnelRepository extended with the payroll surface (adjustSalary via RPC / recordSalaryPayment via RPC / observeSalaryPayments) and the stale bonuses mapping removed; (c) UI — PayrollManagement through the RPC-backed repository path (no client-side salary math, no local paid-state simulation), the blocked/bonuses contract regressions repaired; (d) verify_t-369.sql + live application + regression suites.
- **Depends on:** nothing (baseline gates at session OPEN are RED — 31 tsc errors from the unregistered UI-only commits d4df4d3/74d3ebb/9ddde68/08f7f13; this task OWNS restoring the gates as part of the fix, not as a separate cleanup).
- **Priority:** P0 (the owner's explicit session mandate: "implement the logic for each commit one at a time — fix commit 74d3ebbc821d8e7b825576aa83e8b24766d22828")
- **Next:** T-337 (REALTIME-105) — the standing P0 publication migration; then the same backend-implementation treatment for the remaining UI-only commits (9ddde68 — the Class Placement Studio) per the owner's one-commit-at-a-time mandate.

### T-370 — 69th session: the commit-9ddde68 Class Formation & Placement Studio backend integration (ACAD-500) — implement the missing logic behind the UI-only commit

- **Status:** COMPLETED (TESTED + the LIVE leg, 2026-09-14 — the 0096 migration file reconstructed BYTE-FAITHFULLY from the live pg_get_functiondef extraction and committed (ARCH-011 drift closed), the full desktop wiring (contract + Supabase RPC repository + atomic mock + provider slot + hook rewire + audit action + both cache-refresh seams), verify_t-370.sql (owner-gated runbook: happy path, atomicity, 23505/22023/23503, tenant 42501, grants, registration), the LIVE REST E2E t-370-placement-e2e.py 19/19 GREEN through the real PostgREST+RLS+RPC path (zero-residue cleanup), the T-370 suite 15/15 (mock atomicity/draft-mapping/audit + Supabase payload/guards + hook wiring + source guards; the suite caught and fixed ONE mock-parity gap pre-commit: draft-target grade integrity); gates at close: tsc 0 / eslint 0 errors / vitest 164 files 3377 passed 0 failed (+27 new incl. T-371/T-372); the owner's live console 400s (six students PATCH `22P02 "draft-cls-A1"`) root-caused as exactly this defect in production)
- **Problems:** ACAD-500 (the family: see problem-registry — the UI-only commit 9ddde68 shipped the Class Placement Studio UI with NO backend integration: the finalize path is a non-atomic classes+students loop that writes `draft-cls-*` client draft IDs into `students.class_id`, silently discards every repository error, and never persists the existing-class patches; the commit message's specified `ClassPlacementRepository` contract, Supabase wiring, and `class.placement_finalize` audit trail never landed)
- **Scope:** (a) the desktop wiring — `ClassPlacementRepository` contract in academic-repository.ts, `SupabaseClassPlacementRepository` calling the canonical `fn_finalize_class_placements` RPC (LIVE since the concurrent agent's 0096 apply — reused verbatim, no parallel implementation), `MockClassPlacementRepository` over the shared in-memory store with validate-all-then-mutate atomic semantics, the `classPlacement` repository slot registered in the provider + both compositions, the studio hook's finalizePlacements rewired through the repository (draft-ID mapping honored server-side, class patches persisted, Result honored — no more silent failure toasts), the `ClassPlacementFinalize` audit action; (b) migration 0096 file committed from the LIVE definition (the ARCH-011 drift closure — the concurrent agent applied it live without committing; reconstructed byte-faithful from pg_get_functiondef); (c) verify_t-370.sql + the live REST E2E through the real PostgREST+RLS+RPC path; (d) regression suites.
- **Depends on:** nothing (baseline gates at session OPEN are GREEN — tsc 0 / eslint 0 errors / 160 files 3350 tests — the T-369 session owned the 31-error repair; this task's baseline is pristine).
- **Priority:** P0 (the owner's explicit session mandate: "your job during this session is to fix this commit ui '9ddde683f415884d520b9167228e5559c869434f'")
- **Next:** T-337 (REALTIME-105) — the standing P0 publication migration; then the remaining UI-only commit (08f7f13) per the owner's one-commit-at-a-time mandate.

### T-371 — 70th session: the admin account ↔ employee linkage + the employee self-service view (WORKFORCE-501) — link the Admin-Settings-created account to the selected employee at creation, and make the employee's own profile/tasks/responsibilities visible at sign-in

- **Status:** COMPLETED (TESTED + the LIVE legs, 2026-09-14 — hub commits 942d3a2 [registration] + e65181d [rebased to 015a58a: the implementation] + the closeout; full gates at close: tsc 0 / eslint 0 errors [606 warnings, under the 608 session-open baseline] / vitest 161 files 3373 passed 0 failed [+23 new: t-371-account-employee-linkage.test.ts] / build GREEN; LIVE evidence: migration 0097 applied atomically with registration [apply_0097_live.py P1-P3/C1-C4 ALL GREEN] + the EF redeployed + verify_t-371.sql 8/8 GREEN [zero residue] + the REST E2E t-371-linkage-e2e.py 22/22 GREEN [employee signs in → dossier query resolves the bound row under RLS → own task visible → admin-only task invisible → duplicate binding 409s] — docs/recovery/t-371-live-verification.md)
- **Problems:** WORKFORCE-501 (see problem-registry — the personnel.user_id column ships in 0009 with RLS + observeByUserId ready, but NO flow ever populates it; the account-creation path has no employee notion at any layer; the task-assignment id-space split-brain keeps assigned tasks from ever reaching the employee; ProfilePage shows no employee dossier)
- **Scope:** (a) migration 0097 — `admin_create_user_account` extended with optional `p_personnel_id`/`p_email` (atomic personnel link with tenant/existence/double-binding guards) + the partial unique index enforcing one account per employee; (b) the create-user-account EF accepts `personnel_id` (pre-check, RPC pass-through, audit payload, response echo incl. personnel code/name); (c) desktop domain — `CreateAccountInput.personnelId`, `CreatedAccount` employee echo, Supabase + Mock parity (mock: store.personnel.userId + notifyPersonnel); (d) the redesigned AccountsTab workflow — employee-picker-first modal (mode switch personnel/autre, employee context card, prefill from the record, suggested role, linked-account overview); (e) the employee self-service view — ProfilePage employee dossier (identity + responsibilities + tasks + requests) resolving through observeByUserId; (f) the task id-space fix — task-form/table/drawer keyed on the bound account (userId), mock seed tasks re-keyed to the seeded accounts; (g) verify_t-371.sql + the live REST E2E (create account linked to a probe personnel → sign in as that employee → the personnel row is bound + self-visible under RLS).
- **Depends on:** nothing (baseline gates at session OPEN are GREEN per the 68th session close: tsc 0 / eslint 0 / 161 files 3350 tests).
- **Priority:** P0 (the owner's explicit session mandate: "link the account created in the Admin Settings to an employee. When the employee logs in, they should see their own profile, tasks, responsibilities… redesign and improve the account-creation details and workflow so that the account is properly associated with the selected employee from the moment it is created")
- **Next:** T-337 (REALTIME-105) — the standing P0 publication migration; then the remaining UI-only commit (08f7f13) per the owner's one-commit-at-a-time mandate.

### T-372 — 70th session (concurrent): the website↔desktop student-document synchronization (SYNC-110) — ONE canonical metadata store for student documents on every platform

- **Status:** COMPLETED (TESTED + the LIVE legs VERIFIED, 2026-09-14 — desktop gates: tsc 0 / eslint 0 errors / 161 files / 3364 tests / 0 failed / build GREEN (+14 t-372 tests; the vault-compliance suite rewritten to the granular contract); website parity gates: 48 files / 618 / 0 / lint clean / strict build GREEN; LIVE: verify_t-372.sql 7/7 [BEGIN…ROLLBACK, zero residue] + migration 0098 applied atomically with its schema_migrations registration [mig_count 93→94, LINDA's 2 documents unified] + the cross-platform E2E t-372-doc-sync-e2e.py 11/11 [D: desktop→website direction, F: website→desktop direction, G: RLS scoping intact, Z: zero residue]; full report: docs/recovery/t-372-live-verification.md)
- **Problems:** SYNC-110 (the family: see problem-registry — the student-document METADATA layer was built twice: the website reads/writes the canonical `student_documents` table while the desktop reads/writes the `students.documents_json` column, so each platform is blind to the other's documents even though BOTH store file bytes in the SAME `student-documents` bucket with the SAME `<tenant>/<student>/<file>` path convention; the owner's LINDA ALIOUAT report is the live RED proof; the desktop's full-array `updateStudent({documents})` write is additionally a last-write-wins clobber that could not coexist with concurrent website inserts; the desktop category union diverges from the table's CHECK-constrained kind set)
- **Scope:** (a) desktop domain — `StudentDocumentCategory` widened to the canonical 7-value kind set (DB CHECK parity, 0005), `StudentDocument` gains optional mimeType/sizeBytes, NEW `StudentDocumentDraft`, granular repository contract `addStudentDocument`/`removeStudentDocument` on `StudentRepository`, the full-array `documents` field REMOVED from `UpdateStudentInput` (compile-time prevention of the clobber path's return); (b) desktop Supabase repository — seed embeds `student_documents` rows into `Student.documents` (tenant-scoped, one extra query per reseed — the established whole-tenant cache pattern), add/remove INSERT/DELETE the table with honest zero-match DELETE semantics (§15.30b), `documents_json` read/write DELETED from mapStudentRow/updateStudent, uploader display names resolved best-effort via user_profiles (the chat-repository name-cache pattern, RLS-tolerant fallback "—"); (c) mock repository — the same granular contract in-memory; (d) migration 0098 — idempotent backfill of legacy `documents_json` entries into `student_documents` (category→kind map: medical→medical_certificate, justification→justification_letter, contract→contract, other→other; entries without storagePath skipped — NOT NULL constraint; uploaded_by NULL — the json carries a display NAME, not a profile uuid; `documents_json` retained as forensic archive, no client reads it after this task); (e) DocumentsTab — the 7 canonical kinds in the picker, add/remove through the granular methods, vault upload flow unchanged (same bucket + path); (f) website — NO code change (already table-backed); suites re-run as the parity evidence; (g) live E2E — the LINDA ALIOUAT vector through BOTH platforms' query paths before/after the backfill, verify_t-372.sql wrapped BEGIN;…ROLLBACK;.
- **Depends on:** nothing (baseline gates at session OPEN are GREEN — tsc 0 / eslint 0 errors; UPLOAD-101..104 all CLOSED — the storage layer and the website insert are already correct).
- **Priority:** P0 (the owner's explicit mandate: "Documents uploaded from either platform must be stored and synchronized through the same backend/storage system so that both the website and desktop application can see all documents associated with the student — fix this for ALL student documents")
- **Next:** T-337 (REALTIME-105) — the standing P0 publication migration (unchanged recommendation; note: 0097 is TAKEN by the concurrent WORKFORCE-501 session, 0098 by this task — T-337's migration takes the next free number).
- **Coordination:** TWO concurrent sessions: the 69th (T-370, the Class Placement Studio — owns migration 0096 + academic-repository.ts + use-class-placement-studio.ts) and the 70th-concurrent (T-371/WORKFORCE-501 — owns migration 0097 + the create-user-account EF + personnel/accounts UI). DISJOINT from this task's file set (student model, student repositories, documents-tab, migration 0098, upload e2e script); fetch → merge forward → re-run gates before every push (never force-push).

### T-373 — 69th session: the empty-id REST fetch guards (ACAD-501) — the "nothing selected yet" renders that 400 against uuid columns (RENUMBERED from T-371 at merge: the concurrent 70th sessions registered their own T-371/T-372 on the remote first)

- **Status:** COMPLETED (TESTED, 2026-09-14 — the three guards in SupabaseChatRepository.observeMessages / SupabaseHomeworkRepository.observeForClass / observeByTeacher: an empty id returns the stable empty stream with NO server round-trip; the t-373 suite 6/6 GREEN (functional no-from() pins + source guards); the live probe reproduced the exact 400s pre-fix (`22P02 invalid input syntax for type uuid: ""`))
- **Problems:** ACAD-501 (registered + CLOSED TESTED same session — the owner's console showed `chat_messages?channel_id=eq.` 400 and `homework?class_id=eq.` 400 ×2; the callers pass `selectedId ?? ""` / `classId || ""` on first render)
- **Scope:** the repository-boundary guards ONLY (the seam every caller shares) — no caller changes: chat-panel and homework-history-tab keep their empty-selection states, the repositories simply stop firing doomed requests. Mock parity unchanged (the in-memory filter already matched nothing).
- **Depends on:** nothing.
- **Priority:** P1 (console noise + guaranteed 400s per render; no data corruption)
- **Next:** T-337 (REALTIME-105) — unchanged standing recommendation.

### T-374 — 69th session: the attendance punch wrong-key fallback guardrails (WORKFORCE-502) — the 409s in the owner's console (RENUMBERED from T-372 at merge; the interim mitigation for the WORKFORCE-501 symptom family — the linkage itself is the concurrent T-371)

- **Status:** COMPLETED (TESTED + the LIVE leg, 2026-09-14 — the wrong-key fallback (`me?.id ?? session.userId` / `me?.id ?? currentUserId`) removed in worker-dashboard.tsx AND staff-attendance-center.tsx; the punch + the leave submit are refused with explicit guidance BEFORE any server call when no personnel record is linked; latestFor never runs with a foreign key; the attendance center's silent repository-failure path now surfaces the error (WEAK-019-class swallow closed); the t-374 suite 6/6 GREEN; the live root-cause probe t-374-attendance-probe.py 7/7 GREEN — the 409 reproduced as 23503 FK ("Key is not present in table \"personnel\""), NOT a unique constraint, and the correct-key punch verified end-to-end with a run-unique probe personnel, zero-residue cleanup)
- **Problems:** WORKFORCE-502 (registered + CLOSED TESTED same session — the wrong-key fallback + the silent error path; the INTERIM mitigation of the WORKFORCE-501 symptom family: once the concurrent T-371 links accounts to personnel rows, `me` resolves and the guards become dormant belt-and-braces)
- **Scope:** the two surfaces' key derivation + guards. NOT in scope: the account↔employee LINKAGE itself (the concurrent T-371 owns it) and the tasks.assignee_ids id-space split-brain (same family, T-371 scope f).
- **Depends on:** nothing.
- **Priority:** P1 (the punch button appeared broken to profile-less users)
- **Next:** T-337 (REALTIME-105) — unchanged standing recommendation.

### T-375 — 71st session (2026-09-15): fresh empty Supabase infrastructure verification (OPS-313) — prove the NEW project is structure-identical and data-empty, OLD project untouched

- **Status:** COMPLETED (VERIFIED — the census + registry docs landed with commit bc5a6c4 [T-375 register empty-DB verification + OPS-313 terminator note]; OPS-313 subsequently CLOSED by T-378 [72nd session, 2026-09-16] — status flipped at the 72nd-session closeout)
- **Problems:** OPS-313 (the 0096 terminator note — fresh-provision parse risk, no fix committed per append-only rule)
- **Scope:** NEW project `vebfehrpzajhstyhinnw` ONLY: migration-list parity (Local=Remote 0001–0098), public table/function/policy/bucket census, business-table emptiness (seed-only rows allowed), anon RLS probe, auth health. OLD project `hkvkefubghbbotgnteir` NEVER linked/applied/probed for writes. NOT in scope: EF redeploy matrix, secret rotation, admin-user creation, client `.env` changes, zip/push delivery.
- **Depends on:** none (read-only verification; no code change required for the verdict).
- **Priority:** P0 (owner mandate: exact structure, zero business data, old DB intact).
- **Next:** T-376 (OPS-314) — the RLS recursion blocker discovered on the NEW project while running this verification.

### T-376 — 71st session (2026-09-15): FIX the fresh-clone RLS recursion (`54001 stack depth limit exceeded`) — restore `SECURITY DEFINER` on the five RLS helpers + the `user_profiles_select_own` fast-path (OPS-314)

- **Status:** COMPLETE — FIXED + VERIFIED (migration `0099_rls_helper_security_definer_parity.sql` applied to the NEW project; docs updated; commit pending)
- **Problems:** OPS-314 (opened and CLOSED in this task)
- **Scope:** NEW project `vebfehrpzajhstyhinnw` ONLY. OLD project `hkvkefubghbbotgnteir` read-only (source-of-truth definition dumps via the Management SQL endpoint; no DDL, no writes, never linked).
- **What was wrong:** the fresh clone accepted authenticated logins but EVERY authenticated read returned `500 54001 stack depth limit exceeded` (or `401` with no token), so the desktop app rendered empty with a wall of 401s. Two chain-vs-live divergences: the five RLS helpers in `0003_rbac.sql` lacked `SECURITY DEFINER` + `search_path`, and `user_profiles_select_own` in `0019_rls_policies.sql` lacked the leading `auth_user_id = auth.uid()` disjunct. With `relforcerowsecurity=true` on the RBAC tables this produced unbounded recursion through the policy predicates of all 83 guarded tables.
- **What was changed:** (1) new append-only migration `0099_rls_helper_security_definer_parity.sql` recreating the five helpers exactly as LIVE (`security definer` + `set search_path to 'public'`) and recreating `user_profiles_select_own` with the LIVE predicate; (2) `docs/recovery/problem-registry.md` OPS-314; (3) this registry entry; (4) `docs/recovery/change-log.md`. `0003`/`0019` deliberately NOT edited (§15.9 append-only / ADR-001 — they remain forensic evidence).
- **Verified:** append-only guard OK (96 files, +1 new); `supabase migration list` NEW `0099` applied (Local=Remote through 0099); `pg_proc` helper `secdef`/`search_path` `MATCH_OLD: True` vs production; `user_profiles_select_own` predicate `POLICY_MATCH: True` vs production; **30/30 authenticated REST paths return 200** (the exact paths from the owner's failing console); anon still `[]` on protected probes (RLS strength unchanged).
- **Remaining (NOT part of this task):** OPS-313 (`0096` missing `;` terminator — fresh `db push --include-all` parse risk); `fn_finalize_class_placements` ACL (`=X/postgres` PUBLIC EXECUTE present on OLD, absent on NEW — NEW is the safer state, deliberately NOT widened, see change-log); Edge Functions deploy matrix on the NEW project; admin-user/bootstrap runbook; client connection switch. `auth.users` on NEW = 1 (the admin created for this test).
- **Depends on:** none.
- **Priority:** P0 (owner mandate: exact structural AND functional equivalence).
- **Next:** T-337 (REALTIME-105) — unchanged standing recommendation; then OPS-313 resolution.

### T-377 — 72nd session (2026-09-16): re-verify the T-376 RLS-parity fix on the NEW project with fresh evidence (12/12) — the session-opening proof the owner asked for

- **Status:** COMPLETE — VERIFIED (fresh `verify_t-376.sql` run against `vebfehrpzajhstyhinnw` on 2026-09-16, 12/12 PASS; evidence in change-log 72nd session)
- **Problems:** OPS-314 (already CLOSED by T-376 — this task re-proves it holds)
- **Scope:** NEW project ONLY (`vebfehrpzajhstyhinnw`), read-only. Run `elimtiyaz-desktop/scripts/verify_t-376.sql` via the Management SQL endpoint (`run376.sh` wrapper recreated at the session-sandbox scripts dir — token-carrying wrappers stay OUTSIDE the repos per the established convention). No DB writes (the script is BEGIN/ROLLBACK-wrapped).
- **What was verified:** A1 5/5 helpers `SECURITY DEFINER`; A2 5/5 `search_path=public`; A3 5/5 owner `BYPASSRLS`; B1 `user_profiles_select_own` fast-path disjunct present (qual 172 chars); B2 RLS still FORCEd on 4/4 RBAC tables; C1 `current_user_profile_id()` resolves with NO recursion (profile `42e369e9-…`, sub `a148fe34-…`); C2 own profile visible; C3 tenant resolves to `00000000-…-0001`; C4 `has_role('super_admin')=true` (the bootstrap admin's role assignment is LIVE on NEW); C5 tenant-scoped read `academic_levels_visible=14`; D1 unbound sub sees 0 profiles; D2 anon sees 0 parents.
- **Extra state census captured the same run (read-only):** migrations 96/96 through 0099; 83 public tables; 202 public + 24 storage policies; 100 public functions; extensions identical to OLD (btree_gist, pg_stat_statements, pg_trgm, pgcrypto, pgjwt, plpgsql, supabase_vault, uuid-ossp); 10 buckets byte-identical names/public flags; `auth.users` = 1 (the bootstrap admin, `status=active`, super_admin role_assignment present); business tables parents=1 / students=1 / payments=3 — ALL THREE are migration-0063 chain DML artefacts (the row-242 MAMER reconciliation inserts ship IN the migration; OLD carries the same rows among its real data), so the NEW DB is confirmed EMPTY of business data.
- **Depends on:** T-376 (completed).
- **Priority:** P0 (the owner's evidence requirement: do not mark verified without a fresh run).
- **Next:** T-378 (OPS-313 — the 0096 chain-file terminator fix).

### T-378 — 72nd session (2026-09-16): FIX OPS-313 — the 0096 `$function$` missing terminator (owner-sanctioned in-place chain-file fix, live parse-proven)

- **Status:** COMPLETE — FIXED + VERIFIED (the `;` added after the closing `$function$` of `fn_finalize_class_placements` in the chain file; pre-fix content live-proven to fail with 42601, post-fix content live-proven to parse + execute cleanly inside BEGIN/ROLLBACK on the NEW project)
- **Problems:** OPS-313 (CLOSED by this task)
- **Scope:** the committed chain file ONLY (`elimtiyaz-desktop/supabase/migrations/0096_class_placement_finalize.sql` L302 + a 7-line forensic comment). NO database was migrated, re-applied or touched persistently: the NEW project already carries 0096 (registered), the OLD project never had the file applied from the chain (live-applied by a concurrent agent before the file existed), and the parse probes were BEGIN/ROLLBACK-wrapped (zero residue, re-verified: the function's ACL on NEW is unchanged — `{postgres=X,anon=X,authenticated=X,service_role=X}`, the deliberately-narrower-than-OLD state per OPS-314).
- **Why in-place (not a 0100 re-declaration):** a follow-up migration cannot fix fresh provisioning — the runner dies AT 0096 before reaching 0100; and on already-parsed databases a re-declaration is a no-op. The only fix that makes `supabase db push --include-all` work from the chain is the terminator itself. The owner's 72nd-session mandate explicitly directed "Fix the chain file", satisfying the sign-off condition OPS-313 required.
- **Verified:** (1) pre-fix probe: the exact committed content (as of 865343d) wrapped in `BEGIN; … ROLLBACK;` sent via the Management SQL endpoint to `vebfehrpzajhstyhinnw` → HTTP 400 `42601: syntax error at or near "revoke"`; (2) post-fix probe: the fixed content, same wrapper → HTTP 201 (parsed + executed, rolled back); (3) post-probe ACL re-check → unchanged; (4) append-only guard `--base HEAD` post-commit → green; (5) t-058 vitest suite (the real-chain check) → green.
- **Depends on:** T-375 (discovery), T-376 (chain context).
- **Priority:** P0 (the owner's handover list item 2).
- **Next:** T-379 — the Edge-Function fleet deploy + secrets + curl matrix on the NEW project.

### T-379 — 72nd session (2026-09-16): deploy + verify the Edge-Function fleet on the NEW project (the 14 EFs, the secrets set, the live curl matrix)

- **Status:** COMPLETE — VERIFIED (14/14 EFs ACTIVE via the Management API; the 13-name secret set 1:1 with production; `t-379-ef-fleet-matrix.sh` 61/61 PASS — the full T-004 curl matrix incl. the live GROQ round-trip)
- **Problems:** none opened (the handover list item 3 closed)
- **Scope:** NEW project `vebfehrpzajhstyhinnw` ONLY. Deployed from the canonical hub source (`elimtiyaz-desktop/supabase/functions/`, 14 EFs + `_shared/`) with `supabase functions deploy --no-verify-jwt` (the documented §11.1 pattern — the EFs enforce their own auth). Secrets set: `CRON_SECRET` (freshly generated — the production value is a masked digest by design, and a secret VALUE is configuration-unique per instance, not business data), `ALLOWED_ORIGINS` (the canonical 4-origin set), `FIREBASE_PROJECT_ID=elimtiyaz-android`, `GROQ_API_KEY` (owner-supplied this session), `LOG_LEVEL=info` (no runtime consumer — allowlist-only key; production value unknown/masked), `PROJECT_REF=vebfehrpzajhstyhinnw` (the update-server-secret EF's own-project pointer). NOT set (parity with production): `RESEND_API_KEY`, `FIREBASE_SERVICE_ACCOUNT_JSON` (the standing owner residuals), `SUPABASE_ACCESS_TOKEN` (the update-server-secret EF's Management-API credential — a sbp_ owner token; owner-gated by class).
- **Verified:** the matrix (committed as `elimtiyaz-desktop/scripts/t-379-ef-fleet-matrix.sh`, output captured in change-log): P1–P3 anonymous-deny sweep 14×3 = 42×HTTP 401 (no-auth / garbage bearer / publishable-as-bearer); P4a the 5 cron EFs (expire-pending-approvals, purge-expired-backups, refresh-materialized-views, run-overdue-scan, workflow-resume-scheduler) with the fresh `CRON_SECRET` → 5×200 (no-op on the empty DB); P4b the 8 staff EFs with the admin JWT + minimal body → 4xx validation (auth+permission gates passed, nothing mutated); P4c send-push-notification with the legacy service JWT → 401 — the production-identical response (T-126: the injected `SUPABASE_SERVICE_ROLE_KEY` carries the sb_secret value, so the legacy JWT fails the EF's own compare; the sb_secret positive path → 500 FIREBASE residual is operator-gated, see the discovery below); P5a ALLOWED_ORIGINS echoes `https://elimtiyaz-website.vercel.app` for an allowlisted origin and falls back to the first canonical origin for a foreign one (no echo); P5b wrong CRON_SECRET → 401; P5c ai-proxy single-shot narrative with the admin JWT → **HTTP 200 with real French content** (the GROQ key works through the NEW project's egress — the sandbox cannot reach Groq directly, §11.1 #10).
- **Discovery (registered in AGENTS.md §11.1 as quirk #13):** the Management API can CREATE additional `sb_secret_` keys (`POST /v1/projects/{ref}/api-keys`, raw value returned ONCE), but the data/function gateways REJECT them ("Invalid API key") even 2+ minutes after creation — so minting a fresh key does NOT give a probe path into service-key-gated EFs; only the project's DEFAULT sb_secret (revealable in the dashboard UI, never through the API) can do that. The probe key was DELETED after the experiment — the key set is back to exact production parity (legacy anon + legacy service_role + default publishable + default secret).
- **CLI quirk re-confirmed:** `supabase secrets set` with 6 secrets TIMED OUT after 5 minutes with all secrets already applied (§11.1 quirk #5 — verify via the API list + behavior probes, never the exit code).
- **Depends on:** T-376 (the RLS fix that made authenticated EF calls possible), T-377 (the fresh admin session).
- **Priority:** P0 (the owner's handover list item 3).
- **Next:** T-380 — the auth-config parity + the credentials map for the app switch.

### T-380 — 72nd session (2026-09-16): the NEW-project handover completed — auth-config parity, the credentials map + switch runbook, and the deep-parity census (handover items 4–5)

- **Status:** COMPLETE — VERIFIED (auth config patched + GET-after-PATCH verified; every non-secret-gated field now matches production; credentials.md §9 = the full connection map; the final structural census: triggers 89/89, views 13/13, matviews 5/5, sequences 4/4, constraints 508/508, indexes 449/449, tables 83/83, buckets 10/10 byte-identical incl. size limits + MIME types)
- **Problems:** none opened (the two remaining auth-config diffs are the OWNER-GATED Google pair, registered in credentials.md §9.4 — `external_google_secret` is unrecoverable by API; enabling without it would break the provider)
- **Scope:** NEW project configuration ONLY (Management API PATCH on `/config/auth`: `site_url`, `uri_allow_list`, `external_google_client_id`, `external_google_skip_nonce_check` — copied from production). NO client repointed: per the owner's mandate ("so I can LATER connect the application"), production stays the live backend; the switch procedure is DOCUMENTED (credentials.md §9.4) for the owner's cutover decision, not executed. The bootstrap admin's "role approval" the 71st-session report listed as pending was found ALREADY DONE live (profile `status=active`, `super_admin` role_assignment present, `verify_t-376` C4 `has_role('super_admin')=true`, sign-in 200 with the owner-pinned credential) — verified, not re-done.
- **Verified:** (1) auth-config PATCH → GET-after-PATCH diff vs production = exactly the 2 Google-secret-gated fields (`external_google_enabled` False-vs-True, `external_google_secret` unset — both owner-gated by the secret's API-unrecoverability); (2) the final deep census (both projects, read-only): triggers 89/89 · views 13/13 · matviews 5/5 · enums 0/0 · sequences 4/4 · constraints 508/508 · indexes 449/449 · tables 83/83 · policies 202+24 vs 202+24 · functions 100 vs 100 · extensions identical · buckets 10 vs 10 with `file_size_limit` + `allowed_mime_types` byte-identical; (3) the desktop's exact connection values (URL + publishable key) proven live by every probe this session (the admin sign-in, the EF matrix, the RLS reads).
- **Docs:** `docs/operations/credentials.md` §9 (identity + keys + secrets parity + the per-platform switch procedure + the owner-gated residuals + the equivalence evidence index); `docs/recovery/current-state.md` +the 72nd-session snapshot.
- **Depends on:** T-377 (evidence base), T-379 (the EF fleet the switch depends on).
- **Priority:** P0 (the owner's handover list items 4–5).
- **Next:** the owner's cutover decision (point clients at `vebfehrpzajhstyhinnw` + populate fresh data per credentials.md §9.4), or on production: T-337 (REALTIME-105) — the standing P0.

### T-381 — 73rd session (2026-09-16): the users + students removal functionality (USER-500 / STUDENT-500) — the missing destructive surfaces on Settings → Comptes and CRM → Élèves

- **Status:** COMPLETED (TESTED, 2026-09-16 — gates: tsc 0 / eslint 0 errors / 167 files / 3435 tests of which 3 failed = the SAME pre-existing CALC-001 cross-platform failures attributed at session open (+16 new t-381 tests, 0 new failures); the LIVE leg (deploy the EF to BOTH projects + the create→verify→delete round-trip) is T-383)
- **Problems:** USER-500 + STUDENT-500 (both registered BEFORE the fix per §13 and CLOSED TESTED same-session — see problem-registry)
- **Scope:** (a) the `delete-user-account` Edge Function — the create mirror (T-079): super_admin gate, tenant-scoped resolution, self-deletion 409, owner-pinned-admin 403 (OPS-310 generalized), parents/students unbind, pending approval requests expired, profile delete (role_assignments cascade, personnel SET NULL), auth identity deleted LAST (the safe ordering: a failure leaves an inert auth user, never a unique-index-corrupting orphan profile), `user_account.delete` audit without credential material; (b) `UserAccountRepository.deleteAccount` contract + Supabase (functions.invoke passthrough, EF envelope mapping) + mock (personnel unbind, seedAccounts drop, owner-pinned guard, honest notFound) implementations; (c) AccountsTab — per-row Supprimer (data-testid delete-account-<id>) + ConfirmModal → deleteAccount → toast + overview refresh; (d) StudentsTab — per-row Supprimer gated by the NEW `Permission.DeleteStudent` (SuperAdmin via defaults; RBAC-matrix-grantable) + ConfirmModal → the EXISTING `deleteStudent` soft delete (deleted_at + is_active=false — financial history preserved); (e) audit actions `user_account.delete` + `student.delete` registered; (f) `DataTableAction.title` (a11y for icon-only destructive actions).
- **What was wrong:** the accounts workflow (T-079/T-371) had create/list/link with NO removal path (deprovisioning required the dashboard); `deleteStudent` shipped dark in both repository implementations with zero UI callers (only the import adapter's rollback used it); no DeleteStudent permission existed to gate any surface.
- **Depends on:** nothing (baseline gates at session OPEN attributed: the 3 CALC-001 cross-platform failures are pre-existing, files untouched).
- **Priority:** P0 (the owner's explicit mandate).
- **Next:** T-382 — the export destination + format workflow (Backups Sync/Export area + Backend/Settings Excel & Archive buttons).
- **Commit:** 3c20d2c (feat(desktop): T-381 — remove users and students).

### T-382 — 73rd session (2026-09-16): the export destination + format workflow (BKUP-500) — choose WHERE the export is saved + the export FORMAT (entire archive vs zipped Excel files) in the Backups Sync/Export area AND the Backend/Settings Excel & Archive buttons

- **Status:** COMPLETED (TESTED, 2026-09-16 — gates: tsc 0 / eslint 0 errors / 168 files / 3454 tests of which 3 failed = the SAME pre-existing CALC-001 cross-platform failures attributed at session open (+19 new t-382 tests, 0 new failures); the workflow is client-side — no DB change → no separate live leg; commit 5b0f2cf)
- **Problems:** BKUP-500 (to be registered BEFORE the fix per §13 — the Electron save bridge exists but was never wired; every export goes to the browser download folder; NO archive export exists at all; no destination/format choice anywhere)
- **Scope:** (a) the renderer-side save bridge (`window.elImtiyazDesktop.saveFile` — the REAL preload bridge, OS save dialog) with the browser downloadBlob fallback; (b) a dependency-free store-method ZIP writer (no zip lib in package.json); (c) the archive-export service: "entire archive" (manifest + every vault archive + per-archive metadata — the complete archive structure + associated files) and "zipped Excel files" (the generated workbook(s) inside a ZIP); (d) the shared ExportDialog (destination + format choice BEFORE the export starts); (e) the BackupTab "Export & synchronisation" card; (f) the ConfigurationTab (Backend) Excel + Archive export buttons.
- **Depends on:** T-381 (session sequencing only — disjoint files).
- **Priority:** P0 (the owner's explicit mandate).
- **Next:** T-383 — live verification of both tasks on OLD + NEW Supabase.

### T-383 — 73rd session (2026-09-16): the live verification legs — deploy delete-user-account to BOTH Supabase projects + the create→verify→delete round-trip on OLD and NEW

- **Status:** COMPLETED (VERIFIED, 2026-09-16 — the EF deployed to BOTH projects; scripts/t-383-remove-users-e2e.py: 28/28 PASS on OLD hkvkefubghbbotgnteir AND 28/28 PASS on NEW vebfehrpzajhstyhinnw; the role-gate probe 403-forbidden PASS on both; the 15-EF anonymous-deny sweep 15/15 on both; zero residue (auth.users back to 8 / 1); evidence: docs/recovery/t-383-live-verification.md)
- **Problems:** USER-500 (the live leg of T-381); the EF-fleet parity discipline (the 15th EF must land on BOTH projects — the 72nd session's census + t-379 matrix documented 14).
- **Scope:** (a) deploy the delete-user-account EF to production `hkvkefubghbbotgnteir` AND the fresh clone `vebfehrpzajhstyhinnw`; (b) the T-004 curl matrix for the new EF on both (401 anonymous-deny + the staff-JWT validation path + the super_admin happy path); (c) the live E2E: create a probe account (create-user-account EF) → verify profile/role/personnel link → delete it (delete-user-account EF) → verify auth.users + user_profiles + role_assignments gone, personnel unbound, the guard rails (self-deletion, owner-pinned admin) refuse correctly; (d) update scripts/t-379-ef-fleet-matrix.sh to the 15-EF fleet + re-run on NEW; (e) the zero-residue census.
- **Depends on:** T-381 (the EF), T-382 (session sequencing only).
- **Priority:** P0 (the owner's "make sure it works" + "ensure this works with new db too").
- **Next:** the session closeout (zip + push + handover).

### T-384 — 74th session (2026-09-16): the parent-removal functionality (PARENT-500) — the owner's clarified "users = students AND parents" — the missing destructive surface on CRM → Parents

- **Status:** COMPLETED (VERIFIED, 2026-09-16 — gates: tsc 0 / eslint 0 errors / 169 files / 3470 tests of which 3 failed = the SAME pre-existing CALC-001 cross-platform failures attributed at the 73rd-session open (+16 new t-384 tests, 0 new failures); LIVE: migration 0100 applied to BOTH projects atomically with registration + the t-384-parent-removal-e2e.py harness 17/17 PASS on production hkvkefubghbbotgnteir AND 17/17 PASS on the fresh clone vebfehrpzajhstyhinnw — the RLS-500 RED evidence captured [the plain-UPDATE 42501] + the RPC round-trip incl. the active-students guard, the audit entries, the operational filter, zero residue)
- **Problems:** PARENT-500 + RLS-500 (both registered BEFORE their fixes per §13 and CLOSED VERIFIED same-session — see problem-registry)
- **Scope:** (a) ParentsTab (CRM → Parents) — the per-row Supprimer action (icon-only, titled "Supprimer ce parent", data-testid-free per the StudentsTab precedent) gated by the ALREADY-REGISTERED `Permission.DeleteParent` ("Supprimer un parent" — SuperAdmin via the `Object.values(Permission)` defaults; RBAC-matrix-grantable) + the destructive ConfirmModal (the guard is explained IN the description) → `repos.parents.deleteParent` → success/error toast; (b) Supabase `deleteParent` hardened — resolve-first notFound (§15.30b zero-match honesty), the ACTIVE-students guard (`.eq("parent_id", id).is("deleted_at", null)` — soft-deleted students do NOT block, matching the mock store semantics), the French conflict userMessage instructing the operator to remove/reassign the students first; the soft-delete payload + reactive cache eviction preserved; (c) mock `deleteParent` hardened — the honest notFound + the same French userMessage; the guard + audit + hard store-removal preserved (behavioral parity with the soft delete); (d) the t-384 suite (14 tests: A mock semantics incl. the guard-clears-after-student-removal path + the audit entry; B the Supabase behavioral wiring through a chainable PostgREST mock pinning resolve→guard→update + the source-order guard; C the UI permission gating + ConfirmModal + the rejection path; D the registries).
- **What was wrong:** the owner's original "remove users and students" mandate was read literally by T-381 (accounts surface + students annuaire); the clarification ("when I mean users I mean the student and parents") identified the PARENT entity as the intended target — `deleteParent` shipped dark in both repository implementations (zero UI callers — the STUDENT-500 pattern one entity later), AND the two implementations diverged (Supabase: no notFound, no guard; mock: the guard but a default userMessage with no operator instruction).
- **Deliberately NOT changed:** the soft-delete semantics (financial history preserved — the STUDENT-500 precedent); the portal auth accounts (`parents.auth_user_id` untouched — full deprovisioning stays the separate Settings → Comptes surface); the Excel import-adapter rollback path (the other deleteParent caller); the parent-detail-drawer (the destructive surface stays on the annuaire row).
- **Depends on:** nothing (baseline gates at session OPEN attributed: the 3 CALC-001 cross-platform failures are pre-existing, files untouched).
- **Priority:** P0 (the owner's clarified mandate).
- **Next:** the standing P0 on production: T-337 (REALTIME-105) — the publication migration (next free number 0100); or the CALC-001 baseline repair (the 3 cross-platform mirror tests).
- **Commit:** (this session's feat commit — see change-log).

### T-506 — Windows x64 installer and portable packaging (2026-09-16)

- **Status:** IMPLEMENTED — both artifacts built successfully; real-Windows launch verification remains open. Registration added at closeout (the implementation preceded registration).
- **Problem:** PACK-100 — the checkout lacked the Windows packaging recipe and icon described in the owner's report.
- **Dependencies:** none; existing Electron 33 / electron-builder 25 infrastructure reused.
- **Change:** additive `dist:win` script, NSIS assisted installer and portable x64 targets, tracked resources/icon.png and icon.ico. Runtime, backend, business rules and existing scripts unchanged.
- **Evidence:** `npm run dist:win` exit 0; installer 106974114 bytes, portable 106747735 bytes; PE installer wrappers and app.asar present. Hashes and limitations recorded in change-log.md. Baseline gates re-run at closeout on the changed tree: typecheck 0 errors; lint 0 errors (616 pre-existing warnings); FULL vitest 169 files — 3461 passed / 4 failed / 5 skipped, of which 3 are the SAME pre-existing CALC-001 cross-platform failures attributed at the 73rd/74th-session open, and 1 (ai-311 payment-plan due-date, expects 2026-10-10 got 2026-10-09) is a newly-attributed pre-existing TIMEZONE-SENSITIVE date assertion — reproduced identically in isolation on a tree this task touched zero source files of (packaging config + icons + docs only). Neither failure class is caused by this change; both are registered for the standing baseline repair.
- **Left:** real Windows install/launch, login/dashboard/CRM and PDF-save smoke test; unsigned builds, no auto-update feed. Release binaries remain gitignored, not committed.
- **Next:** T-506 Windows smoke test; standing backend recommendation T-337 unchanged.

### T-385 — 75th session (2026-09-17): the full 3-language i18n coverage of the parent portal (I18N-500) — the owner's "translate the full app into 3 languages" mandate

- **Status:** COMPLETED (TESTED, 2026-09-17 — 75th session; gates: scanner 0 findings [baseline 55/20 files] + parity 555/555/555 + tsc 0 + eslint 0 + 49 files / 629 tests ALL PASS + strict build exit 0 + the LIVE 3-locale browser round-trip incl. RTL + the tri-lingual offline fallback; see I18N-500 for the full evidence; 5 code commits on i18n/full-coverage, each merged to main immediately — concurrent-agent-safe: the dictionary got ONE append-only commit, zero reflow)
- **Problems:** I18N-500 (registered BEFORE the fix per §13)
- **Owner mandate:** "translate the full app into 3 languages in i18n … make sure all visible text in the entire codebase is found and properly translated, and make sure you have a reliable way to track your progress … build or use some kind of tool that scans the entire codebase and identifies all user-visible text … work through the results systematically … in small, safe iterations."
- **Plan (the burn-down):** (1) TOOLING — scripts/i18n/scan-hardcoded-strings.js (TypeScript AST scanner: jsx-text, visible attrs, ternaries, fallbacks, toast calls; excludes console.*/dev-invariants/tests/dictionary) + scripts/i18n/check-parity.js (fr/ar/en key-set parity) + the frozen baseline report (55 findings / 53 unique pairs / 20 files, 2026-09-17) + the t-385 vitest guard (the ALLOWLIST burn-down: no finding may exist outside the list; the list empties as strings migrate; parity + duplicate-key gates); (2) PARITY — the missing ar/en `activation.code.error.network`; (3) shared components (banners/boundaries/splash/dialog Close); (4) feature views (absence dialog, academic, attendance, activation, financial incl. the canonical-label code→key render mapping, messages, notifications, profile, documents); (5) validation.ts zod messages → dictionary keys translated at the toast seam; (6) RTL (document dir/lang follow the locale) + offline.html tri-lingual; (7) hub registry closeout. Each iteration: lint + full vitest + strict build green, conventional commit with the 5 answers, push + merge (concurrent-agent-aware: additions-only to dictionary.ts, no reflow of existing keys).
- **Scope decisions (registered in I18N-500):** PDFs / app metadata / PWA manifest stay French (WinAnsi + desktop-parity + static-export constraints); format.ts untouched (parity-pinned); the canonical layer untouched (code→key mapping happens at the display layer, the UI-304 precedent).
- **Left:** nothing — task complete. The burn-down list in src/test/t-385-i18n-coverage.test.ts is EMPTY and machine-enforced (any new hardcoded user-visible string fails the suite; any fr/ar/en key drift fails the suite). Scope decisions recorded in I18N-500 stand (PDFs/metadata/manifest French; format.ts parity-pinned; canonical layer untouched).
- **Next:** the standing backend recommendation T-337 (realtime publication) is unchanged; the desktop's 3 pre-existing CALC-001 suite failures remain attributed for the standing baseline repair.
### T-387 — 76th session (2026-09-17): the student-import HTTP 400 — the live seed-state disproof + the SYNC-300 blank-string RPC-argument fix (the owner-supplied diagnosis verification)

> **RENUMBERED from T-385 at merge** — the concurrent repair-agent session registered its own T-385 (I18N-500, the portal i18n mandate) on the remote FIRST (commit 3171e6c, 2026-09-17 01:02 UTC); per the T-373/T-371 merge convention, this task takes the next free number. All artifacts (suite, scripts, live-verification doc, AGENTS.md §15.37) carry T-387.


- **Status:** COMPLETE — VERIFIED (2026-09-17 — gates: tsc 6 PRE-EXISTING errors [all in the concurrent dashboard-analytics files aa19a75/d87c7bf, zero new] / eslint 0 errors 629 pre-existing warnings / the new t-387 suite 14/14 / the infrastructure+integration sweep 73 files 743 tests PASS / verify_t-387.sql 7/7 live on NEW / t-387-rpc-blank-args-e2e.py 14/14 on NEW + 13/14 on OLD [the single FAIL is the OPS-316 discovery — G3 migration parity, NOT SYNC-300]; evidence: docs/recovery/t-387-live-verification.md)
- **Problems:** SYNC-300 (registered BEFORE the fix per §13, CLOSED VERIFIED same-session); OPS-316 (NEW DISCOVERY — registered OPEN, fixed by the follow-up T-386 in the same session)
- **Scope:** the owner's handed-over analysis claimed the student-import 400 came from MISSING 0023 seed data (empty tenants/roles/permissions, no default tenant) and prescribed re-running 0023_seed.sql in the SQL Editor. The live verification DISPROVED the hypothesis for the current state (both projects carry the full canonical census — tenants=1 roles=11 permissions=56 default-tenant-present super_admin=56/56; migration parity NEW 97/97 exact) and confirmed the actual 400 mechanism: the desktop sync push maps payload fields with `??`, which does NOT convert `""` to null, so `p_class_id: ""` reaches `upsert_student_from_import`'s `uuid` parameter and PostgREST rejects the cast (22P02) BEFORE the SECURITY DEFINER body runs. Fixed client-side: `blankToNull()` on every date/timestamptz-typed arg, `uuidOrNull()` (the exported isUuid guard, the line-1268 convention) on every optional uuid-typed arg, in default-push-handler.ts ONLY — optional (`DEFAULT NULL`) params guarded, required uuid params deliberately stay loud. types.ts re-aligned to the live pg_proc signature (the 0028 params + the 0031 out_* Returns — the generated types were behind the chain, exactly as the owner's report suspected).
- **Deliberately NOT changed:** the canonical RPCs (0027/0031/0037/0041 own the signatures — no server-side change was needed; the fix is the client seam, matching the ACAD-501 read-path precedent); 0023_seed.sql was NOT re-run (its trailing DO-asserts are calibrated to the 0023-era snapshot — `transport_destinations = 4` — and would RAISE on the canonical post-0089 state of 28; documented as a live-probe discovery); the mock-mode import path; createStudent's `p_class_id: input.classId ?? null` (its import caller passes explicit null — noted as a same-class surface in the registry entry).
- **What was verified (the full evidence):** see docs/recovery/t-387-live-verification.md — the RED/GREEN boundary contract reproduced on BOTH projects with the desktop's EXACT rpc() payload shapes ("" → 400 22P02 / null → 200 + out_student_id; the 22007 date sibling proven), the seed census, the signature census (18 IN + 3 OUT — pg_proc lists both), and the zero-residue cleanup convention.
- **Session-opening baseline attribution (§15.14):** 169 files / 3470 tests — 18 failed / 3447 passed / 5 skipped: 3 standing CALC-001 cross-platform failures + 15 dashboard-analytics render failures from the CONCURRENT AGENT's in-flight commits (aa19a75…d87c7bf — data-inspector/operational-query-console/analytics-tab, which also carry the 6 tsc errors). This task touched ZERO of those files; the sync-layer suites are green.
- **Depends on:** nothing.
- **Priority:** P0 (the owner's explicit handover task — "here is the full issue and fix… may or may not be the issue").
- **Next:** T-386 — the OPS-316 registration heal (the production 0099 history row, discovered by this task's both-projects probe; a 10-minute atomic fix).
- **Commit:** (this session's fix commit — see change-log.)

### T-386 — 76th session (2026-09-17): the OPS-316 registration heal — production's missing 0099 schema_migrations row, applied atomically (the both-projects migration parity restored to 97/97)

- **Status:** COMPLETE — VERIFIED (2026-09-17 — apply_0099_live.sh against production hkvkefubghbbotgnteir: HTTP 201; post-heal legs: migrations_applied 96→97 · verify_t-376.sql on OLD 12/12 [the five RLS helpers + the fast-path policy untouched by the idempotent re-apply] · verify_t-387.sql on OLD 7/7 [C3 parity = 97] · t-387-rpc-blank-args-e2e.py on OLD 14/14 [was 13/14 — the G3 parity check green]; NEW untouched — it already carried both the DDL and the registration)
- **Problems:** OPS-316 (registered OPEN during T-387's both-projects probe, CLOSED VERIFIED by this task)
- **Scope:** production's `supabase_migrations.schema_migrations` history row for 0099 ONLY. The 0099 DDL re-applied in the SAME atomic transaction is a VERIFIED no-op on production (verify_t-376 12/12 BEFORE the heal proved the helpers were already in the exact 0099 shape — T-376 transcribed them FROM production). The registration INSERT follows the 0100-in-file pattern (version, statements, name) with ON CONFLICT (version) DO NOTHING.
- **Deliberately NOT changed:** the NEW project (already 97/97 — untouched); the 0099 migration FILE (already committed — this task ships only the live-apply script); the helpers themselves (byte-identical CREATE OR REPLACE re-run).
- **Depends on:** T-387 (the discovery).
- **Priority:** P1 (history-integrity heal — the "migration history is misleading" class the owner's original report called out).
- **Next:** the standing T-337 (REALTIME-105, next free migration 0101); the CALC-001 baseline repair; the concurrent agent's T-385 i18n burn-down.
- **Commit:** (this session's heal commit — see change-log.)

### T-388 — 77th session (2026-09-17): the full 3-language i18n coverage of the DESKTOP terminal (I18N-501) — the owner's review finding: untranslated English, incomplete Arabic, and the Arabic font to replace

- **Status:** IN PROGRESS (registered 2026-09-17 — 77th session)
- **Problems:** I18N-501 (registered BEFORE the fix per §13)
- **Owner mandate:** "Are you sure you translated the entire desktop? I can still see a lot of English text, and in the Arabic version, many things are still not translated. Also, fix the Arabic font and choose a better one that looks clean and professional." (the T-385 mandate covered the portal; this is the desktop half)
- **Plan (the burn-down, 3,643 findings / 174 files / 2,924 unique texts):** (1) TOOLING — the desktop port of the T-385 scanner (scripts/i18n/scan-hardcoded-strings.mjs) + the unique-string collector (collect-unique-strings.mjs) + a codemod (apply-i18n.mjs) that rewrites findings to `t()` calls with interpolation params and injects `useTranslation` where missing; (2) TRANSLATIONS — the 2,924 unique texts get fr/ar/en values (fr = the source where French; fr authored where the source is English), authored in batches with a domain glossary (tranche=installment, bulletin=report card, …), merged append-only into fr.ts/ar.ts + the NEW en.ts; (3) THE en LOCALE — i18n.ts supportedLngs, AppLocale, user-preferences-provider validation, the language-switcher's third option (its own hardcoded labels migrated too); (4) THE FONT — Noto Sans Arabic (Google Fonts CDN, fails offline in Electron) replaced by IBM Plex Sans Arabic bundled locally via @font-face, wired through index.css + tailwind.config.cjs; (5) the burn-down guard (scanner 0 + parity fr/ar/en + no duplicate keys) in the vitest suite; (6) per-area iterations (auth/shell → dashboard → crm → financials → academics → personnel → workflow → routing → settings → profile → shared), each: typecheck + tests + scanner count shrinking + conventional commit + PUSH + MERGE (concurrent-agent-safe: dictionary edits append-only, feature files are i18n-only edits).
- **Scope decisions:** registered in I18N-501 (PDFs/Excel stay French; domain/core/infrastructure literals out of scope; particle-engine excluded; brand nouns untranslated).
- **Left:** the registered residuals (INSPECT-500's list): the enrollment-vs-KPI population unification [product decision], the aging 0_30 includes not-yet-due [mirrored metric semantics], the new UI strings joining the T-388 i18n burn-down, the owner's visual acceptance pass in Electron.
- **Next:** the standing T-388 (I18N-501, the concurrent agent's burn-down — this task's new UI strings join its backlog); then T-337 (REALTIME-105).

### T-389 — 78th session (2026-09-17): the data-lineage inspection repair (INSPECT-500) — make every dashboard metric traceable from the displayed number back to the live source records, with structured financial categories and the top-10 contributor color coding

- **Status:** COMPLETE — TESTED (2026-09-17, 78th session — the t-389 suite 34/34; tsc 0 errors [5 baseline errors fixed]; eslint 0 new warnings; full vitest run 18 failed / 3495 passed with the failure set IDENTICAL to baseline main [git stash + re-run proof — the failures are the T-388 i18n text-matcher fallout, pre-existing]; LIVE verification on BOTH projects read-only [scripts/verify_t-389_live.sh, docs/recovery/t-389-live-verification.md]: production C1 revenue 55 227 100 DZD/891 payments in the exclusive window, C2 58 354 700 vs C2b 58 602 700 — the 248 000 DZD live proof of the scope defect, C4 the 318-entry remise corpus, C6 the top-10 debtor ranking. The rendered-UI visual pass in Electron is the owner's acceptance step [registered residual].)
- **Problems:** INSPECT-500 (registered BEFORE the fix per §13)
- **Owner mandate (2026-09-17):** "The inspection feature is supposed to explain exactly what, who, how, and where every dashboard metric comes from… the tracing and calculation logic are incorrect… There should be no ambiguous amounts, unexplained prices, generic categories, missing contributors, or values that cannot be traced back to the actual data that produced them… the inspection should identify the top 10 contributors to that metric and assign each contributor a different, visually distinct color… Those colors should appear consistently on the contributor list, contribution amounts, percentages, charts/bars, and any other relevant visual representation."
- **Plan:** (1) SHARED DERIVATIONS — align `inRange` to the exclusive-upper-bound house convention (fixes the KPI↔inspector↔stat-strip boundary drift) + add `deriveOutstandingDebt` (the buildInstallmentsQuery mirror: status ≠ paid + academic-year window + INV-4 remaining) + `deriveDiscountTotal` (Σ |negative adjustment ledger entries|); (2) RESOLUTION ENGINE — rebuild `buildResolution` on the canonical primitives (`installmentRemaining`, `daysBetweenFloor`, `agingBucketFromDays`, `evaluateStudentRiskProfiles`, `normalizeTransportTier`), add structured per-record lineage (`category`/`categoryLabel`/`sourceTable`/`amountKind`/`sourceId`), apply the aging-bucket filter, add the debt `scope` (year vs all) and attendance `mode` (records vs absences) parameters, re-point discount at ledger adjustments and transport at transport installments (amounts + routes), support multi-select method/category filters; (3) UI — the 10-color `INSPECTOR_PALETTE` + `contributorColor(rank)` applied consistently (compact popup list/amounts/percentages/stacked bar, drawer contributor panel, per-record color dots), formula steps with intermediate values (N, Σ due, Σ paid, Σ pending, window, filters); (4) TRIGGERS — rewire every analytics-tab trigger so sourceValue and resolution share ONE definition (debt year-scoped, Pareto all-years, filtered revenue passes arrays, discount from ledger, attendance records-mode) + mount the tranche/transport/service triggers; (5) TESTS — the t-389 suite pinning each reconciliation (boundary, scoping, aging, attendance, GPA reuse, ledger discount, transport amounts, palette consistency, multi-filter); (6) DOCS — problem CLOSED, change-log, this entry.
- **Scope decisions:** registered in INSPECT-500 (SeeDetailsModal untouched; executive-card internals untouched; no backend/migration changes; the portal has no inspection surface).
- **Concurrent-agent safety (T-388 i18n agent active):** the engine/UI work is concentrated in data-inspector-core.tsx (the file created FOR this purpose); analytics-derivations.ts gets append-style additions plus the one-line boundary fix; analytics-tab.tsx edits are surgical trigger re-wirings; new user-visible strings kept minimal and centralized.
- **Left:** the registered residuals (INSPECT-500's list): the enrollment-vs-KPI population unification [product decision], the aging 0_30 includes not-yet-due [mirrored metric semantics], the new UI strings joining the T-388 i18n burn-down, the owner's visual acceptance pass in Electron.
- **Next:** the standing T-388 (I18N-501, the concurrent agent's burn-down — this task's new UI strings join its backlog); then T-337 (REALTIME-105).

### T-390 — 79th session (2026-09-18): the Supabase access-point audit + backend health proof (the owner's handed-over root-cause task list, part 1) — audit every Supabase access path and prove which layer actually fails

- **Status:** COMPLETE — VERIFIED (2026-09-18, 79th session — source census (createClient/from/rpc/auth/storage/channel/functions.invoke/fetch/env, TASK 1–5/16 of the handed-over list) + LIVE read-only probes on the NEW project: anon read `200 []` vs authenticated read `200 [row]` for the EXACT owner-reported request shape, sign-in 200, getUser 200, students read 200, SQL census (parents=7, students=3, tenants=1, profiles=1, auth users=1, migrations 97/97, super_admin role_assignment live). Evidence: docs/audits/supabase-access-audit-2026-09-18.md + docs/recovery/t-390-live-verification.md.)
- **Problems:** AUTH-302 (root cause DISCOVERED + registered), OPS-317, OPS-318 (registered BEFORE the fixes per §13)
- **Owner mandate (2026-09-17/18):** the handed-over "El-Imtiyaz Desktop — Supabase Root Cause & Remediation Task List" (17 September 2026): clone the repos, read the audit docs + AGENTS.md, audit every Supabase access point, verify the single canonical client/URL/key, prove auth/tenant/RLS, fix student loading + insertion, stop swallowing errors, build a deterministic diagnostics screen, produce the final root-cause report — with live tokens supplied for verification. The handed-over report's Root Problems 3–6 claimed missing data/parent; the live evidence DISPROVED the data hypothesis.
- **What was actually verified (the corrected diagnosis):** the backend is healthy end to end (network/URL/key/project/auth/tenant/RLS/read + historical INSERT evidence); the owner's `200 []` symptom is reproduced ONLY in the anon-session state → **AUTH-302** (the desktop keeps its domain session while the Supabase SDK session is gone → every REST call is anon → RLS filters → silent empty UI via the OPS-317 catch blocks). The parent `220e7f65-…` EXISTS (the handed-over Problem 6 is disproven). The `%20` URL bug class survives in exactly one path (OPS-318, `validateConnection`).
- **Left:** the fixes themselves (T-392 client session-state sync + error surfacing + validateConnection sanitization; T-393 the diagnostics screen; T-394 the final report + closeout).
- **Next:** T-392 (same session).

### T-391 — 79th session (2026-09-18): the live auth/tenant/RLS + write-path verification (handed-over list Tasks 6–9/22/23/24) — the deterministic probe script + the create→read→update round-trip as the real admin

- **Status:** COMPLETE — VERIFIED (2026-09-18, 79th session: `scripts/t-391-live-rls-e2e.py` run 1789665485 against `vebfehrpzajhstyhinnw` — **29/29 PASS, 0 FAIL, 0 NOT TESTED**, zero business-data residue (probe parent+student created and removed through the CANONICAL soft-delete RPCs; audit rows stay as the honest record). Full matrix: sign-in 200 / getUser 200 / anon `200 []` vs authenticated `200 [row]` (the AUTH-302 proof) / profile+tenant+roles RPCs green / RLS read matrix 9 tables + anon split green / write round-trip D1–D9 green (upsert_parent → upsert_student → PATCH update → SQL-verified persistence + tenant consistency + FK integrity → canonical cleanup). Evidence: docs/recovery/t-391-live-verification.md. Commit `ee2337c`.)
- **Problems:** AUTH-302 (verification half), the handed-over list's "NOT YET PROVEN" items (auth, tenant resolution, RLS CRUD, parent→student relationship, persistence across restart)
- **Plan:** (1) a re-usable probe script (`scripts/t-392-live-session-e2e.sh` family, following the t-384/t-387 conventions) that signs in as the documented admin, asserts getSession/getUser, resolves user→profile→tenant→role via BOTH the REST path and the SQL census, and exercises the RLS matrix on the representative tables (parents, students, classes, payments, payment_allocations, attendance, personnel, notes, transport — the handed-over Task 22 list) recording PASS/FAIL/NOT TESTED; (2) the SAFE write-path round-trip (Task 23): create a clearly-labelled probe parent+student via the SAME canonical RPCs the desktop uses (`upsert_parent_from_import` + `upsert_student_from_import`), read them back authenticated, UPDATE the student, re-read, verify row state in SQL, then soft-delete via `soft_delete_parent`/`soft_delete_student` (zero-residue cleanup per the t-384 convention — audit_logs rows are the honest record and stay); (3) document PASS/FAIL with exact status codes + error codes (never tokens).
- **Left:** none (the evidence doc + the probe script are committed; the renderer-level re-verification leg is covered by T-392's unit tests + T-393's live runner).
- **Next:** T-392 (the client fixes).

### T-392 — 79th session (2026-09-18): FIX AUTH-302 + OPS-317 + OPS-318 — the desktop session-state synchronization, the swallowed-error surfacing, and the validateConnection sanitization

- **Status:** COMPLETE — VERIFIED (2026-09-18, 79th session: `npx vitest run src/tests/infrastructure/t-392-session-surfacing.test.tsx` — **14/14 PASS** (evict-on-auth-class ×2, keep-on-network, keep-on-Ok-null, refresh-success, sign-in-after-eviction, parents/students seed recording, healthy-seed-no-record, URL-normalization-no-%20, 200-[]-note, 401 status, sanitized persistence, format gate); `npm run typecheck` — **0 errors** (the pre-existing cc317a6/f39eb17 TS18004 fixed in supabase-client.ts); eslint on all 7 touched files — 0 errors/0 new warnings; full vitest 3511 passed with the failing set IDENTICAL to the stash-verified baseline (the T-388 i18n fallout + CALC-001 mirror tests + vault/realtime/t-390-financial-realtime pre-existing file-level failures — none in this task's files). The LIVE re-verification leg runs with T-393's runner (same session). Commit `3e2642e`.)
- **Problems:** AUTH-302, OPS-317, OPS-318 (all registered BEFORE the fixes per §13)
- **Plan:** (1) **AUTH-302 (auth-provider.tsx)** — when the startup `refreshSession()` fails because the SDK has NO session / the refresh grant is rejected, the stale domain session must be EVICTED (sign-in screen), not kept while every REST call silently runs as anon; keep the existing behaviour only for transient NETWORK failures (offline start must not log the user out — the honest offline degradation). Classification: `unauthorized`/auth-missing errors evict; `network` errors keep the session (with a diagnostic record). (2) **OPS-317 (supabase-shared-repositories.ts)** — the `seed()`-family silent catches get a classified diagnostic record (logger.warn + a last-seed-error field surfaced through the diagnostics screen T-393); the honest-empty degradation stays (the UI contract does not change), but the REASON becomes observable — auth failures, RLS 42501, and network faults are distinguishable from "0 rows". (3) **OPS-318 (system-config.ts `validateConnection`)** — normalize the URL through the same `normalizeSupabaseUrl` seam the canonical client uses (kills the `%20` class at this path), send the anon key as apikey only, and classify the response honestly (200+[] = "reachable but not authorized/empty" ≠ "connected with data"; 401/4xx/5xx surfaced with the exact status). (4) regression tests pinning each behaviour (evict-on-auth-fail, keep-on-network-fail, seeded-error recording, URL normalization incl. the trailing-space `%20` case). (5) LIVE re-verification of the full path (T-391's probe suite re-run green).
- **Concurrent-agent safety (T-388 i18n agent active):** auth-provider.tsx, supabase-shared-repositories.ts, system-config.ts are NOT i18n surfaces; all new user-visible strings stay in the NEW diagnostics module (T-393) or existing error paths; no dictionary files touched.
- **Left:** none — the live leg ran with T-393's sequence (t-393-diagnostics-e2e.py: 20 PASS / 0 FAIL / 1 NOT TESTED, READ-ONLY).
- **Next:** T-393 (the diagnostics screen that makes AUTH-302-class states permanently diagnosable).

### T-393 — 79th session (2026-09-18): the deterministic Supabase diagnostics screen (handed-over Task 21) — Configuration / Network / Authentication / Tenant / RLS / Students / Parents / Payments / RPC each PASS|FAIL|NOT TESTED

- **Status:** COMPLETE — VERIFIED (2026-09-18, 79th session: the module `src/features/settings/supabase-diagnostics/` (types + deterministic 18-check runner + the view with the OPS-317 seed-degradation card + the safe clipboard export) mounted as the new « Diagnostic Supabase » Settings tab; `npx vitest run src/tests/features/t-393-supabase-diagnostics.test.tsx` — **12/12 PASS**; tsc 0 errors; eslint 0 errors/0 new warnings on the touched files; the LIVE leg `scripts/t-393-diagnostics-e2e.py` (READ-ONLY, run 1789673721) — **20 PASS / 0 FAIL / 1 NOT TESTED** (the websocket channel leg — unit-tested, the live leg belongs to the EXE matrix). The live run is simultaneously T-392's live re-verification leg: the full healthy path re-proven AFTER the fixes. Evidence: docs/recovery/t-393-live-verification.md.)
- **Problems:** AUTH-302 (the observability half — the owner must be able to SEE the anon-session state instead of an empty app), OPS-317 (the surfaced seed-error records feed this screen)
- **Plan:** ONE new module under `src/features/settings/supabase-diagnostics/` (self-contained — no edits to shared components): a deterministic check runner that executes the ordered probe sequence (config singleton describe → REST reachability → auth getSession/getUser → profile → tenant resolution → RLS read matrix (parents, students, classes, payments, payment_allocations, attendance, personnel) → RPC probe (current_user_roles) → storage/realtime configuration presence) and renders PASS/FAIL/NOT TESTED with SAFE messages (HTTP status + Supabase error code + operation + table; NEVER keys/tokens — the describeSupabaseConnection() convention). Mount point: Settings (near the configuration tab). The runner reuses `getSupabaseClient()` + the existing `describeSupabaseConnection()` — no second client (TASK 2 invariant).
- **Left:** none (the AUTH-302 detector (auth.domain-vs-sdk) + the OPS-317 explainer card make both defect classes permanently visible from inside the app).
- **Next:** T-394 (final report + closeout).

### T-394 — 79th session (2026-09-18): the final root-cause report (handed-over Task 30) + registry/closeout + the delivery zip

- **Status:** COMPLETE — VERIFIED (2026-09-18, 79th session: `docs/audits/supabase-root-cause-report-2026-09-18.md` — the 15-row PASS/FAIL table (14 PASS incl. the three fixed this session, 0 FAIL, 1 honest NOT PROVEN for the EXE install/launch matrix with the §4 owner runbook), the pasted-audit verdict table (RP3–RP6 disproven/disambiguated), the commit ledger, the 30-task mapping, and the remaining-open register (REALTIME-105, the EXE matrix, the pre-existing failing set). The EXE build legs WERE proven in-sandbox: the production renderer bundle (VITE_DESKTOP_PRODUCTION=true → exit 0; canonical URL ×2, 0 old-project refs, 0 secrets, the diagnostics screen included) + the Electron main compile (tsc exit 0). The delivery zip built + pushed per the owner mandate.)
- **Problems:** the handed-over list's final-report contract (PASS/FAIL per area with exact error/file/object/root cause/fix/verification for every FAIL)
- **Plan:** `docs/audits/supabase-root-cause-report-2026-09-18.md` — the 14-row PASS/FAIL table (Configuration, Network, Authentication, Tenant resolution, RLS, Parents, Students read, Students insert, Students update, RPCs, Schema, Data migration, Realtime, Storage, Production EXE) with evidence links; honest NOT-PROVEN rows where this sandbox cannot execute the leg (the Windows EXE install/launch matrix — documented with the exact runbook for the owner); registry + change-log + current-state + next-task updates; zip + push per the owner mandate.
- **Left:** none (the report + the runbook are the deliverables; the zip + push follow this commit).
- **Next:** the standing T-337 (REALTIME-105) / T-388 (the concurrent i18n burn-down).

### T-395 — 80th session (2026-09-21): the owner's "Famille SIDI — 0554288142 exists in Supabase but cannot be seen in the desktop" report — diagnose the invisibility, restore the family (migration 0101), and register the systemic gaps (OPS-319 + BUSINESS-105)

- **Status:** COMPLETE — VERIFIED (2026-09-21, 80th session: migration **0101** applied live ATOMICALLY with registration to **BOTH** projects (NEW `vebfehrpzajhstyhinnw` — the actual restore; OLD `hkvkefubghbbotgnteir` — guarded data no-op + chain parity **98/98**); `t-395-restore-e2e.py --phase red` **6/6** (the owner's symptom captured with the AUTH-302 disproof control) → `--phase green` **15/15** (the family PRESENT in the desktop's exact parents/students/payments REST shapes + the `verify_t-395.sql` C1–C10 matrix **10/10** server-side: visible + coherent + audited (parent.restore=1/student.restore=1/payment.restore=3) + registered) → `--phase old` **3/3** + the verify matrix on OLD **10/10** (the honest nothing-to-restore disjunct); the migration dry-run (BEGIN/ROLLBACK) HTTP 201 zero errors BEFORE the apply; the append-only guard OK (98 files, +1, 0 edited) + t-058 6/6; full vitest 3522 passed / 21 failed / 5 skipped with the failing set attributable BY CONSTRUCTION to the pre-existing classes (the concurrent layout-editor `editing`-prop fixture drift + the T-388 i18n fallout + CALC-001 mirrors + vault/source-scan) — none of this task's files, zero application source changed. Evidence: `docs/recovery/t-395-live-verification.md`. Commits: e6b9f65 (registration) → dbb735d (the fix) → the closeout commit.)
- **Problems:** OPS-319 (the soft-delete invisibility/restore gap — the owner could not tell why a live-DB row was invisible) + BUSINESS-105 (the half-refund no-op in `revert_payment_allocation` on bulk_import-sourced ledger entries — discovered during this diagnosis) + the DATA-011 status-note update (the family's full lifecycle)
- **Owner report:** "i just went to supabase and found a row that exists in the database but cannot be seen in the desktop version under 'Famille SIDI' — 0554288142"
- **Diagnosis (live-audit-proven, 2026-09-21):** the row EXISTS (parent `d50ecbfc-…` / PAR-2026-8F4B97, tenant 00000000-…-0001, created 2026-09-15 17:48 by the fresh-clone chain's 0063 DATA-011 reconciliation) but carries `deleted_at = 2026-09-16 17:23:36` + `is_active = false` — the desktop annuaire streams (`.is("deleted_at", null)` + the 0019 RLS `deleted_at IS NULL` policies) correctly filter it. The deletion trail: `student.delete` 17:23:32 (audit 041b1ced) then `parent.delete` 17:23:36 (audit 228fa17e) — the guard-clears-after-student-removal sequence of a MANUAL walk of the new T-384 Supprimer buttons in the desktop UI against a REAL family (the t-384 e2e used its own run-unique probe rows; the OLD project's copy of the family was never deleted — the desktop is hard-locked to the NEW project). Additionally the family's 3 payments were flipped to `refunded` at 23:17 the same day via `revert_payment_allocation` (audit notes "idk"/"test"/"errr") — and the refunds HALF-EXECUTED: no reversal ledger entries, no LIFO waterfall reversion (BUSINESS-105), leaving payments.status contradicting the ledger/tranches/allocations which all still say fully paid (Σ 255,000 / créance 0 — the DATA-011 workbook truth).
- **NOT the AUTH-302 class:** the RED e2e leg (t-395-restore-e2e.py --phase red, 6/6) proves the authenticated desktop-shape read returns 4 control parents while the family is absent — this is the soft-delete filter, not an anon-session read (the 2026-09-18 root-cause report's class is fixed and does not explain this row).
- **Scope:** (a) migration `0101_restore_sidi_family.sql` — guarded, idempotent restore of the parent + student (clear deleted_at, is_active=true) and return of the 3 half-refunded payments to canonical `paid` (guard: refunded AND no reversal ledger entry — a financially-executed refund is left alone), with `parent.restore` / `student.restore` / `payment.restore` audit rows (the 0063 system-actor convention); the OLD project is a data no-op + registration parity (98/98); (b) `scripts/apply_0101_live.sh` + `scripts/verify_t-395.sql` (C1–C10, BEGIN/ROLLBACK) + `scripts/t-395-restore-e2e.py` (red/green/old phases); (c) the registry closeout (OPS-319 instance-fixed/gap-open, BUSINESS-105 OPEN, DATA-011 lifecycle note) + the AGENTS.md §15.38 rule (never run destructive-surface testing against REAL rows).
- **Deliberately NOT changed:** the soft-delete semantics themselves (T-384's design is correct); the RLS policies; `revert_payment_allocation` (BUSINESS-105 needs its own task + the financial equivalence suites); the other soft-deleted test rows (DIAG TEST/probe rows stay deleted); the restore SURFACE (a Corbeille/restore UI is the recommended follow-up — OPS-319's open half).
- **Depends on:** nothing (the RED baseline is captured; the invariants C4–C8 already PASS pre-restore).
- **Priority:** P0 (the owner's explicit report).
- **Left:** nothing — task complete. The REGISTERED follow-ups (deliberately out of scope per §15.8): OPS-319's restore surface (the recommended next task: `restore_parent`/`restore_student` RPCs + the Corbeille section) and BUSINESS-105's RPC fix (needs the financial equivalence suites).
- **Next:** OPS-319's restore-surface task (the deletion buttons stay a one-way door until it exists — the exact gap this report exposed) / the standing T-337 (REALTIME-105).
- **Commit:** e6b9f65 (registration) → dbb735d (the fix: migration 0101 + apply/verify/e2e) → the closeout commit (this one).

### T-396 — 81st session (2026-09-21): the owner's backend CRUD verification mandate (OPS-320) — a full write-path integration test suite in Settings (insert / update / delete / fetch / relationships / validation errors / server errors / bulk / UI-vs-DB consistency), each operation PASS|FAIL with the actual error

- **Status:** COMPLETE — VERIFIED (2026-09-21, 81st session: unit 12/12; LIVE 27/27 ALL GREEN — `scripts/t-396-crud-live-e2e.ts` — incl. the IMPORT-110 discovery on the first run (24/27 → fix → 27/27); the full-suite gate 3542/21/5 with the failing set identical to the 80th-session baseline. Evidence: `docs/recovery/t-396-live-verification.md`)
- **Problems:** OPS-320 (CLOSED), IMPORT-110 (discovered + CLOSED same session)
- **Owner mandate (2026-09-21, verbatim scope):** "in the settings, add a testing capability that allows me to test the entire CRUD flow and verify that every operation works correctly with the backend... the testing should cover: inserting students and parents; updating existing records; deleting records; viewing and fetching records; relationships between related records; handling validation errors; handling server/database errors; testing bulk inserts/imports; verifying that the UI state stays consistent with the database after every operation... clearly see whether each operation succeeds or fails, including the actual error when something goes wrong."
- **Plan:** (1) extend the T-393 diagnostics module family (`src/features/settings/supabase-diagnostics/`) — NOT a parallel implementation (§6): a new `crud-test-runner.ts` executing the deterministic ordered suite through the canonical singleton client (injected seam, the t-393 pattern), using the EXACT repository write/read shapes (createParent's `upsert_parent_from_import` + full-row fetch; createStudent's `upsert_student_from_import`; updateParent/updateStudent PATCH; the seed list shapes with `.is(deleted_at, null)`; `bulkAppend`'s ignore-duplicates upsert; `bulkImportInstallments`'s identity upsert; `soft_delete_student`/`soft_delete_parent`); run-unique probe codes (t-391 convention); validation-error legs (blank-string uuid → 22P02; invalid category → 23514 — the codes SURFACED, proving error handling); server-error leg (FK violation → 23503 with code); idempotency leg (re-upsert → out_was_inserted=false, no duplicate); consistency legs (re-read after EVERY mutation through the UI's exact list shapes); (2) a new Settings tab (« Tests CRUD ») rendering the PASS/FAIL/NON TESTÉ matrix + durations + the exact error text + safe clipboard export (the T-393 conventions); (3) unit suite pinning the runner's logic on a mock client (the t-393 test pattern) + the view; (4) a live e2e verification run (zero-residue, soft-delete cleanup, §15.26); (5) evidence doc `docs/recovery/t-396-live-verification.md`.
- **Deliverables this task already produced:** `scripts/t-396-insert-latency-probe.py` (the PERF-501 live evidence — 21 sequential round-trips measured 6,984 ms vs 2 bulk round-trips 507 ms).
- **Scope decisions:** the runner tests the BACKEND CONTRACT through the same client singleton (not the repositories themselves — no cache/state coupling); the T-393 read-only tab stays untouched; French labels live in the module (the T-388 i18n burn-down owns the dictionaries — concurrent-agent safety); probe rows are run-unique + soft-deleted (accumulation is invisible in the UI — OPS-319's deleted-set gap — and the audit rows stay per §15.26).
- **Depends on:** nothing.
- **Priority:** P0 (the owner's explicit mandate).

### T-397 — 81st session (2026-09-21): PERF-501 + DATA-019 — rewire `batchRegister`'s billing leg onto the EXISTING bulk write paths (21+ sequential round-trips → ~7) + surface the billing-persistence failure honestly + the idempotent-retry absorber for the transient class

- **Status:** COMPLETE — VERIFIED (2026-09-21, 81st session: unit 5/5 (the call-count contract) + the 88-test regression sweep + LIVE end-to-end — the REAL batchRegister 3,189 ms wall clock (was 6,984 ms; round-trips 21+ → ~11, +2 per additional student not +12) with the billing content verified (4 ledger + 3 installments through the bulk paths, no warning). Evidence: `docs/recovery/t-397-live-verification.md`)
- **Problems:** PERF-501 (CLOSED), DATA-019 (CLOSED)
- **Owner report (2026-09-21, verbatim):** "how long it takes to insert a student or parent. sometimes it takes around 10–20 seconds for a single insert, which is a serious problem if i need to import hundreds of records. also, sometimes when i try to insert a student or parent, i get a server error."
- **Plan:** (1) keep the identity legs (parent upsert + fetch, student upsert ×N + fetch — they return the ids the billing rows need, and they are already idempotent via the deterministic codes); (2) build ALL billing rows first, then ONE `bulkAppend` (ledger) + ONE `bulkImportInstallments` (tranches) call — both EXISTING methods (IMPORT-107/T-063-era, Excel-importer-proven) — no new server surface, no new migration; (3) the DATA-019 fix: the billing catch returns an honest `billingWarning` surfaced by the wizard (a visible toast — "Inscription réussie MAIS échec de persistance de la facturation : <raison>") or fails when NOTHING persisted for a promised-charge student; (4) a single network-class retry on the two idempotent upsert RPCs (the deterministic-code convergence contract makes re-runs safe); (5) unit tests pinning the new call-count contract (the mock client counts round-trips — the t-393 mock pattern) + the warning surfacing + the retry; (6) before/after latency evidence via the T-396 probe re-run + the live e2e.
- **Expected result:** 1-student default registration: 21 → ~7 round-trips (measured projection ≈ 7.0 s → ≈ 1.9 s from the sandbox; the owner's route ≈ 10–20 s → ≈ 3–7 s); each additional student +2 (identity) instead of +12 (identity + per-tranche loops); the bulk legs stay 1 call regardless of student count.
- **Deliberately NOT changed:** the per-row `append`/`importInstallment` methods (their own semantics are correct — other callers rely on them); the canonical RPC signatures; the mock repository's behavior contract (aligned where the warning field is added); the wizard UI steps.
- **Depends on:** T-396's runner (the verification instrument — same session, ordered).
- **Priority:** P0 (the owner's explicit report).

### T-398 — 82nd session (2026-09-21): PERF-502 — collapse the ENTIRE registration write into ONE round-trip (a `register_family_batch` SECURITY DEFINER RPC, migration 0102) + the pricing-config passthrough (the wizard's loaded config through the input contract — the registered T-397 follow-up)

- **Status:** COMPLETE — VERIFIED (2026-09-21, 82nd session: migrations 0102+0103 applied live to BOTH projects (chain 100/100) with verify_t-398 **12/12 × 2** (happy path + idempotency C7 + atomicity C8 + the ref guard C9 + the CROSS-PATH convergence C12); the REAL `batchRegister` end-to-end against production **17/17 — 368 ms** (was 6,984 ms original / 3,189 ms post-T-397; the owner's route projects ≈ 0.6–1.2 s, was 10–20 s); t-397 updated 8/8 + t-398 NEW 4/4; tsc = the 6-error pre-existing baseline; full vitest 3549/21/5 (+7 passing, the failing set identical). Evidence: `docs/recovery/t-398-live-verification.md`)
- **Problems:** PERF-502 (the residual-latency follow-up to PERF-501), plus the T-397-registered pricing-read leg (5 of the ~11 remaining round-trips) and the preview-vs-persisted correctness concern.
- **Owner report (2026-09-21, verbatim):** "is there no way to make it faster????" — after T-397 the projection for the owner's route is still ~5–10 s per registration; the owner wants it FAST, and hundreds of sequential registrations at year-start remain impractical at that latency.
- **Plan:** (1) migration 0102: `register_family_batch(p_tenant_id, p_parent, p_students, p_ledger_entries, p_installments)` — ONE SECURITY DEFINER transaction that REUSES the canonical idempotent upserts internally (`upsert_parent_from_import` + `upsert_student_from_import` — zero reimplementation of the identity/fallback logic), fills the server-generated uuids + the `deriveAccountId` string server-side (the client cannot know them before the call — the billing rows carry a 0-based `student_ref` index the RPC resolves), writes the billing legs with `ON CONFLICT DO NOTHING` (the exact IMPORT-107/IMPORT-110 wire semantics already live-proven by `bulkAppend`/`bulkImportInstallments`), and RETURNS the full parent + student rows so the client needs ZERO follow-up fetches; (2) the client `batchRegister` builds ALL rows locally (the SAME `createChargeEntry` factory + the SAME installment shapes — the canonical TS calc engine stays the ONLY derivation of billing amounts, no financial logic moves to SQL), passes the wizard's already-loaded pricing config through the new optional `BatchRegistrationInput.pricingConfig` (kills the 5-6 sequential `readDbPricingConfig` reads AND makes the persisted charges always match the step-3 preview — same config source), and issues ONE `rpcWithIdempotentRetry` call (the deterministic codes + ON CONFLICT make the whole composite idempotent — a retry can never duplicate); (3) ATOMICITY UPGRADE (registered change to the DATA-019 scope decision): the whole registration is now ONE transaction — any leg failing rolls back EVERYTHING (the mock repository has been fully atomic since birth via its snapshot-rollback; the Supabase path's partial-success semantics existed only because the writes were split across calls). The `billingWarning` field stays in the contract (the mock path + the wizard's warning branch remain); the Supabase path now returns either full success or a clean Err with "rien n'a été écrit"; (4) tests: the t-397 call-count contract updated to the new pin (1 RPC, 0 reads, 0 upserts when the config is passed) + the t-398 suite (payload content, error mapping, retry, fallback path); (5) live evidence: the latency probe re-run (before: ~11 round-trips / 3,189 ms; expected after: 1 round-trip / ~500-700 ms sandbox — the owner's route ~0.7–1.2 s), the T-396 CRUD suite re-run (27/27), and a live atomicity probe (a poisoned billing row must roll back the WHOLE registration).
- **Expected result:** a 1-student default registration: ~11 → **1** round-trip (sandbox ~3.2 s → ~0.5-0.7 s; the owner's route ~5–10 s → ~0.7–1.2 s); N students stay ONE round-trip (the per-student identity +2s are gone); the persisted charges always match the wizard's step-3 preview (same config object); a failed registration leaves ZERO rows (atomic).
- **Deliberately changed:** the DATA-019 scope decision (billing failure no longer keeps the family records — one transaction, everything-or-nothing; strictly better for the owner's "100% certain" requirement: no half-registered families, no zero-balance-until-regeneration state). **Deliberately NOT changed:** `createParent`/`createStudent`/`bulkAppend`/`bulkImportInstallments` (their own callers — the importer, the CRUD suite, the sync paths — keep them untouched); the canonical upsert RPCs (called, not modified); the mock repository; the wizard UI steps; the source_id identity conventions (only the uuid→code substitution: `reg-<studentCode>-t<n>` / `<studentCode>:<category>:T<n>` — the client cannot know the uuids before the single call; idempotency is preserved because the codes are deterministic).
- **Depends on:** T-397 (the bulk-row builders this reuses), IMPORT-110 (the installments ON CONFLICT wire form), T-396 (the live verification instrument).
- **Priority:** P0 (the owner's explicit follow-up report).

### T-399 — 83rd session (2026-09-21): the owner's test-data autofill mandate (OPS-321) — Ctrl+O fills ANY open form with realistic, validation-respecting fake data (names, phones, dates, selects/enums, references), ready to submit against the real backend

- **Status:** COMPLETE — VERIFIED (2026-09-21, 83rd session: unit 23/23 — the generators pinned against the REAL validators (PHONE_RE/EMAIL_RE imported from edit-parent-modal), the classifier vocabulary incl. Arabic, the full parent-form Ctrl+O e2e in jsdom with REAL Radix-select fills + the safety rails; tsc = the 6-error pre-existing baseline; lint 0 errors; i18n parity OK; FULL vitest 3572/21/5 — the +23 new passing, the failing set IDENTICAL (the concurrent agent's fixture drift); LIVE e2e `scripts/t-399-autofill-data-live-e2e.ts` ALL PASS (22 checks): the SAME generators' data pushed through the REAL one-round-trip batchRegister in 447 ms, every generated value verified against the PERSISTED rows (parents: first/last/phone/whatsapp/email/occupation; students: name/family name/ISO date/FK), the billing landed (4 ledger + 3 installments, Σ equality), zero residue. Evidence: `docs/recovery/t-399-live-verification.md`)
- **Problems:** OPS-321 (the no-autofill gap this closes)
- **Owner mandate (2026-09-21, verbatim scope):** "when i press Ctrl+O while i am on any form, it should automatically fill all fields with realistic, fake, but valid test data. the generated data must respect the actual validation rules and expected formats of each field so that the form can be submitted successfully and the data can actually be inserted into the database... names should be realistic fake names; phone numbers should have the correct format; dates should be valid; required fields should always be populated; numbers should be within valid ranges; emails should have valid formats; relationships/select fields should use valid existing values; IDs and references should be generated or selected in a way that satisfies the backend constraints; fields with specific enums or allowed values should use valid options... this should work consistently across all forms in the application and should be designed specifically for testing database insertion and CRUD operations."
- **Plan:** (1) a new cross-cutting module `src/shared/devtools/test-data/` (NOT a parallel data layer — the VALUE GENERATORS reuse the existing seeded-RNG + Algerian name pools from `src/infrastructure/mock/fixtures/`, additively exported): `generators.ts` (a coherent per-press identity: gender-consistent first/last names, unique-run phone `05XX XX XX XX` matching the placeholder format, derived e-mail, address, DZD amounts, birth dates, `buildCode`-format identity codes PAR-/ELV-/ACT-, passwords, times), `classify.ts` (field → semantic kind via input type + label text + placeholder + name/id, French-first with Arabic/English synonyms — the app's actual label vocabulary: Prénom/Nom/Genre/Téléphone/WhatsApp/E-mail/Profession/Adresse/Ville/Date de naissance/Montant/Notes/Code/Classe/Niveau...), `autofill-engine.ts` (the DOM engine: scope detection = activeElement → enclosing form → enclosing `[role="dialog"]` → largest visible form; React-native-value-setter + input/change dispatch for controlled inputs; min/max/step/minLength/maxLength/pattern/required honored; placeholder-derived phone formats; Radix comboboxes filled by the open→pick-a-valid-option→click dance with semantic matching where possible (gender-consistent), sentinel/empty options avoided; native selects/radios via valid option pick; run-unique values per press — never collides with real rows), `use-test-data-autofill.ts` (the global Ctrl+O/Cmd+O listener — the topbar Ctrl+K pattern — + the toast feedback, i18n keys in all three dictionaries); (2) SAFETY (the §15.38-class guard): the autofill NEVER submits, NEVER flips switches/toggles (destructive-option risk), NEVER touches file inputs, NEVER overflows a field's declared constraints, skips disabled/readonly fields; (3) unit suite `src/tests/features/t-399-test-data-autofill.test.tsx` (generator formats vs the app's actual validators — PHONE_RE/EMAIL_RE from edit-parent-modal, date validity, range respect, Radix select fill through the REAL Radix components, the Ctrl+O keydown path, the toast, the no-form case); (4) LIVE evidence `scripts/t-399-autofill-data-live-e2e.ts`: the SAME generators feed a REAL `batchRegister` call against production (the T-398 one-round-trip path) proving autofill-shaped data passes the full backend constraint chain, run-unique + zero-residue (the t-396/t-398 conventions); (5) evidence doc + registry flips + closeout.
- **Expected result:** on any form (wizard, modals, auto-forms, handwritten): Ctrl+O → every fillable field populated with realistic valid data → the operator reviews and submits immediately; the toast reports what was filled/skipped and why.
- **Deliberately NOT changed:** any form component (zero per-form registration — the engine is generic over the DOM); the fixture builders' existing behavior (only ADDITIVE exports of the name pools); validation logic (the engine RESPECTS it, never redefines it); switches/toggles (left untouched by design).
- **Depends on:** nothing (uses the T-398 one-round-trip path for the live evidence leg only).
- **Priority:** P0 (the owner's explicit mandate).

### T-400 — 84th session (2026-09-21): the Personnel workforce live parity — connect/verify the PR-9 branch against the REAL backend (0104 completed + applied, 0105 worker-chat fix, 0106 Personnel realtime) + the owner's full live test matrix

- **Status:** COMPLETE — VERIFIED (2026-09-21, 84th session: migrations 0104/0105/0106 applied LIVE atomically with registrations (chain head 0106); the owner's matrix through the app's own repository/RPC shapes — `scripts/t-400-personnel-e2e.py` **63/63 GREEN** (auth+identity chain, request flow incl. the clarification RPC's state/ownership guards + RLS-rejected direct updates, task lifecycle + non-assignee scoping, attendance with profile-uuid actors, payroll history + own-rows-only, worker↔manager chat incl. impersonation 403, fresh-session persistence) + `scripts/t-400-realtime-probe.mjs` **20/20 GREEN** (two separate authenticated sessions; the manager receives the worker's chat + leave-request events with zero reloads; a dead control — `tasks`, not a member — receives zero events); gates at the documented baseline (tsc 6 = the concurrent agent's fixtures, FULL vitest 3572/21/5 with the failing set byte-identical — the branch's 3 pre-existing Personnel failures FIXED); vite build GREEN; zero residue (5 archived probe personnel with salary history = the t-369 honest record). Evidence: `docs/recovery/t-400-live-verification.md`)
- **Problems:** WORKFORCE-500 (the registered worker-clarification residual — CLOSED by 0104 live), REALTIME-105 (ADVANCED: the desktop Personnel surfaces live via 0106; the portal set remains T-337's), OPS-321 (Ctrl+O re-verified on-branch 23/23), WORKFORCE-503 (NEW, registered: the attendance-insert tenant-only check)
- **Owner mandate (2026-09-21, verbatim scope):** "Connect the existing Personnel UI/workflows to the real Supabase backend and verify the complete end-to-end behavior. Do not redesign the feature or create parallel logic… Test persistence + authorization + realtime… Verify unauthorized actions are rejected by backend/RLS, not just hidden in the UI."
- **What the session actually found (the handed-over report was partially FALSE):** the live §15.11 census showed 0104 NOT applied (chain head 0103, the RPC nonexistent) despite the report's "already applied — do not re-run" claim; the worker-side direct chat was DEAD live (0061's staff gate omitted the workforce employee roles → 403); the Personnel realtime subscriptions were dead (REALTIME-105: chat_channels/chat_messages/leave_requests not in the publication); 3 Personnel tests were red on the pristine branch tip (the contract rewires shipped without updating the pinning suites).
- **Deliverables:** migrations 0104 (conventions completed: T-091 registration + `search_path = public`) / 0105 (the staff-gate widening) / 0106 (the publication membership); `SupabaseLeaveRequestRepository.startRealtime()` (the chat-repository pattern); the C2a + payroll test realignments; the two live evidence scripts (re-runnable, zero-residue, service-role cleanup with row-COUNT assertions per the §15.41b discovery); this registry closeout.
- **Deliberately NOT changed:** the 0104 policy design (financial_officer visibility + the ownership-checked RPC — semantics preserved byte-for-byte); parents' exclusion from channel creation (0067 path untouched); RLS posture (no policy weakened anywhere — 0104's select subquery is STRICTER than 0019's: + tenant + deleted_at guards); the concurrent agent's failing subtree; tasks/workforce_attendance_events publication membership (no subscriber yet — dead weight).
- **Depends on:** T-369/T-371 (the workforce backend + account linkage this verifies), T-099/T-100 (the chat repository this revives).
- **Priority:** P0 (the owner's explicit mandate). **Next free migration: 0107.**
---

## T-401 — Full Filière / Spécialité Integration Across the System

**Status:** Verified (2026-09-22, 85th session) — COMPLETE: migration 0107 (the `filieres` catalog + classification columns + `fn_track_compatible` + finalize/import/promotion integration, applied live, verify_t-401.sql 17/17); desktop domain/UI/forms/filters/export + website parity (3589/21/5 desktop with the identical pre-existing failing set; website 629/629). Residuals registered in ACAD-502 + ADR-019 (no FK, no class_id trigger, gestion spécialités unseeded, subject_configurations.direction not yet wired, staff-JWT filières probe pending). Evidence: docs/recovery/t-401-live-verification.md  
**Priority:** P1  
**Scope:** Desktop + canonical Supabase backend + cross-platform consumers where the academic classification is exposed.

### Objective

Treat **Niveau → Filière → Spécialité → Classe/Section** as one canonical academic classification model and integrate it end-to-end. This is not an insertion-form enhancement. The field must work consistently anywhere academic classification affects data, filtering, placement, search, statistics, import/export, history, or validation.

### Required implementation

- Establish the canonical domain representation first; do not create page-specific filière enums, labels, or mapping logic.
- Add the required database column/relationship, constraints, indexes, migration, RLS implications, and typed client representation.
- Define valid Algerian secondary-school combinations and applicability rules by level.
- Integrate creation/editing, retrieval, detail views, tables, cards, filters, search, statistics, dashboards, imports/exports, and academic workflows.
- Integrate class formation so a student can only enter a compatible class/section for the student's academic classification.
- Keep classe/section distinct from filière; a filière describes the academic stream, while a class/section is the concrete group.
- Preserve academic-year context where classification changes between years.
- Verify every consumer of the changed schema across Desktop, Android, and Website before changing the contract.
- Remove or reuse any existing duplicate classification models rather than adding another one.
- Add regression tests for valid/invalid level → filière → spécialité → class combinations and end-to-end persistence.

### Definition of done

The field is not considered implemented until a value can be created, persisted, retrieved, searched, filtered, displayed, used by class formation, included in relevant statistics, imported/exported, and preserved in the correct academic-year context without any page maintaining a parallel interpretation.

### DBA/backend work is mandatory

The DBA/backend owner must implement and verify the canonical database representation, migration, constraints, indexes, RLS impact, queries/RPC contracts, and live round-trip verification. Frontend-only state is explicitly insufficient.

---

## T-402 — Full Batch Promotion Integration and Unified Academic Model

**Status:** Verified (2026-09-22, 85th session) — COMPLETE: the full promotion-path audit recorded in docs/recovery/t-402-live-verification.md (12 surfaces; ONE canonical RPC path confirmed + source-guarded; the desktop history-read gap CLOSED via embedAcademicHistories in SupabaseStudentRepository.seed()). Live verify_t-402.sql 9/9 (write→read round-trip incl. the classification stamp, repeater distinguishability, the shared fail-closed validation, idempotent re-run) + verify_t-041 regression 10/10. Desktop 3597/21/5 (failing set byte-identical to baseline). Residuals: Android p_filiere_code push (follow-up candidate, out of scope — repo not cloned); the promotion UI entry points restructure with T-403.  
**Priority:** P0  
**Scope:** All promotion entry points and all downstream academic consumers across Desktop, Android, Website, and the canonical database.

### Objective

Make **batch promotion fully functional end-to-end across the entire system**. Promotion must use the same canonical academic model as class formation and must not have duplicated forms, duplicated promotion rules, duplicated data transformations, or page-specific interpretations.

### Required implementation

- Audit every promotion UI, repository, domain function, RPC, migration, history writer, grade-level updater, class-formation consumer, and cross-platform mirror.
- Use students.grade_level_code + student_academic_histories as the canonical promotion model; do not reconnect the dead legacy academic_history / promote_students path.
- Make batch promotion atomic per batch, with explicit handling for promoted, repeating, deferred/override cases where the established academic rules permit them.
- Preserve prior academic history while moving the student's current grade/class context forward.
- Ensure the resulting grade level is consumed consistently by CRM, Pédagogie, class formation, student details, academic records, statistics, search/filtering, imports/exports, and any other dependent workflow.
- Ensure the next class-formation step can consume the promotion result without manual data repair.
- Ensure repeaters are represented consistently and remain distinguishable from promoted students.
- Reuse one promotion domain model and one write path. Do not create page-specific promotion forms or business logic.
- Audit and remove/retire duplicate implementations only after proving all consumers have moved to the canonical path.
- Implement equivalent behavior on Android where promotion is exposed; fix the known sync gap where the grade change is currently dropped.
- Verify the canonical database path, RLS, history append, grade-level update, and audit trail live.
- Add cross-platform equivalence tests and end-to-end regression tests.

### Definition of done

Batch promotion must be executable from the intended UI, persist atomically, create the correct academic-history records, update the student's current academic level, preserve historical data, propagate correctly into class formation and all relevant pages, survive refresh/reload, and produce equivalent results across supported platforms.

### No duplicate model / logic rule

If two pages currently collect or calculate the same promotion information differently, consolidate them onto the canonical model. A second form is acceptable only when it is a different presentation of the same domain contract; it must not define a second business rule.

### DBA/backend work is mandatory

The DBA/backend owner must own the canonical schema/RPC/RLS/transaction side of this task. Do not solve a database defect with frontend state or a client-only workaround.

---

## T-403 — Batch Promotion Cycles: Human-in-the-Loop Academic-Year Workflow

**Status:** Verified (2026-09-22, 85th session) — COMPLETE: migration 0108 (promotion_cycles + promotion_cycle_classes + fn_create/get/confirm/reopen/complete/cancel — the confirm executes through the SAME execute_batch_promotion RPC, ONE business path); the desktop Cycles de promotion tab + the cycle detail worklist + the per-class review modal (the canonical buildPromotionReviewQueue engine, per-student overrides, the [NOTES_INCOMPLETES] two-phase ack, the reopen path); the one-shot BatchPromotionModal + use-batch-promotion RETIRED (the class-detail contextual button opens the cycle); the mock parity; buildPromotionDecisionPayload extracted as the ONE wire format. Live verify_t-403.sql 16/16 (the full C1..C10 matrix). Desktop 3608/21/5 (failing set byte-identical). Residuals: skip/exception marking from the UI, the studio deep-link — registered in t-403-live-verification.md.  
**Priority:** P0  
**Scope:** Promotion UI, academic workflow, database/domain contract, class-level review, and all downstream consumers.

### Core rule

Batch promotion is a **batch operation in scope, but not a blind one-click operation**. The system must manage a complete **promotion cycle** for one academic year at a time, while requiring human review/confirmation for each class/group before that class is finalized.

The unit of workflow is:

**Academic Year → Promotion Cycle → Level/Grade → Class/Group → Student decisions → Review → Confirm**

Do not treat “promote this class” as the complete promotion feature.

### New dedicated area: Batch Promotion Cycles

Create a dedicated **Batch Promotion Cycles** section/table instead of scattering promotion actions across unrelated pages.

The table must show promotion cycles, primarily the upcoming academic year, with at least:

- Source academic year
- Target academic year
- Cycle status: Draft / In Review / Partially Processed / Completed / Cancelled
- Levels/classes included
- Number of students awaiting decision
- Number promoted
- Number repeating
- Number deferred/exception cases where supported
- Notes/completion warnings
- Last updated / audit information
- Actions to open, continue, review, or inspect the cycle

The cycle page must allow the authorized user to work through the complete year's promotion process.

### One cycle at a time

The workflow must operate on **one source → target academic-year cycle at a time**. The system should normally surface the next academic year as the primary cycle.

Within that cycle, users process the relevant levels/classes **one group at a time** so that a human remains in the loop.

The system may prepare a batch of students for a class, but it must never silently finalize every class in the school from one global button.

### Remove scattered promotion entry points

Audit all existing promotion buttons/actions.

Remove or replace UI buttons that directly execute promotion outside the Batch Promotion Cycles workflow.

Existing pages may provide a contextual link such as **“Open Promotion Cycle”**, but they must not maintain independent promotion workflows or duplicate promotion business logic.

### Class/group review workflow

For each class/group:

1. Open the class/group within the active promotion cycle.
2. Load all students and their academic information.
3. Show the proposed destination level/class and promotion decision.
4. Allow the authorized user to edit individual decisions.
5. Allow the user to identify repeaters and other supported exception cases.
6. Show relevant notes, grades/results, attendance and other established academic evidence.
7. Warn when required academic information is incomplete.
8. Require explicit human confirmation for the class/group.
9. Persist that class/group's decisions atomically.
10. Mark the class/group as processed.
11. Move to the next class/group.

A processed class must remain auditable and reopenable according to the established authorization rules.

### Incomplete grades/notes warning

Before confirming a class/group, detect whether required grades/notes are missing or incomplete.

Display a clear blocking or confirmation warning according to the existing academic rules, for example:

> **Les notes ne sont pas encore toutes renseignées. Êtes-vous sûr de vouloir continuer ?**

The warning must identify what is incomplete where practical. The user must explicitly confirm before continuing when the established rules allow continuation.

Do not silently treat missing grades as zero or fabricate academic data.

### Whole-cycle completion

The cycle must have an explicit completion state.

Completing a cycle means:

- every required class/group has been reviewed or has an explicitly documented exception;
- every student's promotion/repetition/deferment decision is resolved;
- all required validations have passed or have an authorized override;
- all class/group operations have been committed;
- academic history is preserved;
- the target-year state is internally consistent;
- downstream class formation can consume the resulting promotion state;
- an audit record exists for the cycle and its class/group decisions.

The user should not be able to mark the whole cycle **Completed** merely because one class was processed.

### Relationship to T-402

T-402 remains the canonical batch-promotion implementation task. T-403 defines its required **human-in-the-loop cycle workflow** and UI structure.

T-402/T-403 must share the same canonical promotion model, repository/RPC/domain logic, database transaction rules, and academic-history model. The cycle UI is a presentation/workflow layer, not a second promotion engine.

### No duplicated logic

Do not create:

- a second promotion algorithm for the cycle page;
- a second student-decision model;
- separate class-level and cycle-level persistence models for the same decision;
- page-specific promotion rules;
- direct client-side database mutations that bypass the canonical promotion transaction.

The cycle, class review, and any contextual entry point must all call the same domain/backend contract.

### Definition of done

The feature is complete only when an authorized user can create/open the next academic-year promotion cycle, review every relevant class one at a time, modify individual student decisions, receive incomplete-notes warnings, confirm each class, monitor cycle progress, and finally complete the entire cycle with consistent database state, preserved history, auditability, and downstream compatibility.



## T-404 — Automatic Timetable Generation & Constraint Scheduling

**Status:** TESTED (2026-09-22 — all six stages landed: migrations 0109/0110 live-verified 27/27; canonical TS domain + native solver 25/25; TimetableRepository Supabase+mock 9/9; the dedicated Emploi du temps UI 7/7; packaging gates PASS incl. the Windows x64 portable .exe with the solver verified inside the packaged ASAR + clean-environment generation under `env -i`. Full evidence: docs/recovery/t-404-live-verification.md. Remaining to VERIFIED: executing the built .exe on a real Windows machine (owner action, same residual as T-506) + the NSIS setup variant on a wine-equipped host.) **SCHED-103 follow-up (same day, live-reported):** the shipped problem assembly 400'd live (PGRST200 — class_subjects→personnel had NO FK; the `personnel!left` embed cannot resolve without one). App fixed (embed removed, names resolved from the existing personnel fetch; live-verified 10/10 by `scripts/t404-postgrest-smoke.sh`; .exe rebuilt SHA256 `9330a6a9…`); canonical FK migration **0112** + `apply_0112_live.sh` ready — apply owner-gated on the sbp_ token (runbook: docs/operations/credentials.md + SCHED-103 in the problem registry).  
**Priority:** P0  
**Scope:** Desktop/Electron + canonical backend contract + timetable domain/solver integration + generated timetable viewing.

### Objective

Build a real school-wide automatic timetable generator for all academic years, levels, filières/specialties, classes, teachers, subjects/modules, rooms, days, and time periods. The generator must create valid schedules from curriculum requirements and configurable constraints rather than requiring staff to manually construct the timetable.

### Mandatory capabilities

- Configure academic year, school days, periods, lesson durations, breaks, and available scheduling windows.
- Configure classes/groups, teachers, subjects/modules, rooms, capacities, room types, and teacher assignments.
- Define how many sessions/hours each subject requires per week for each relevant level/class.
- Support lesson duration/session length and consecutive periods for laboratory or double-period lessons.
- Support hard constraints that must never be violated: teacher/class/room double-booking, incompatible rooms, unavailable teacher/class periods, required weekly hours, capacity limits, and other established scheduling invariants.
- Support soft constraints/preferences with visible violation reporting: preferred periods, avoiding gaps, maximum daily lessons, preferred morning/afternoon placement, consecutive-lesson limits, and similar preferences.
- Support class-specific free days/unavailable days. A free day may be configured as a preferred soft constraint or, where explicitly required, as a hard constraint.
- Support teacher availability/unavailability and room availability.
- Support an Algerian school configuration as a first-class configuration profile, while keeping the solver generic and data-driven. The profile must cover the school's configured academic levels/streams, school week, periods, breaks, subject-hour requirements, room types, and other local scheduling rules without hardcoding them into the solver.
- Generate timetables for the whole school/year while preserving human review and adjustment.
- Explain unsatisfied constraints and impossible schedules instead of silently producing an invalid timetable.
- Allow manual post-generation adjustments with immediate conflict validation.
- Keep generated schedules as versioned draft/trial runs; never overwrite the active timetable implicitly.
- Publish/activate an explicitly reviewed timetable version.
- Preserve audit information for generation, manual changes, review, and publication.

### Solver architecture and Node.js/TypeScript requirement

Node.js + TypeScript is mandatory for the El-Imtiyaz integration layer. The timetable feature must not require end users to install Node.js, Python, C++, Java, or a separate solver.

Use a stable TypeScript solver-adapter contract such as TimetableSolver. Prefer a native Node/TypeScript-compatible solver when sufficiently capable and reliable. If an established external solver such as FET is selected, bundle the required platform-specific executable/runtime with Electron and invoke it through the adapter; do not expose solver installation/configuration to the end user.

Never make business logic depend directly on solver-specific APIs or file paths. The canonical El-Imtiyaz model remains TypeScript/domain-owned and the adapter translates to/from the solver representation.

### Packaging and reliability requirements

Development success alone is not sufficient.

The exact packaged Electron application must be tested with the bundled solver on clean target environments. No solver executable may be resolved from the developer PATH or from hardcoded development paths.

Required validation:
1. Development generation on the developer PC.
2. Production build/package with every required solver binary/resource bundled.
3. Packaged-app generation with no development runtime installed.
4. Target-platform smoke testing, including Windows x64 for the distributable EXE.
5. Known-good deterministic fixture generation test.
6. Failure diagnostics when the solver cannot start or returns an invalid result.
7. Reopen/reload test proving the generated timetable persists correctly.
8. Version/solver-build identification for reproducibility.

The final acceptance criterion is the packaged application successfully generating, validating, saving, reopening, and displaying a timetable on a clean target environment without developer-only dependencies.

### New dedicated timetable viewing area

Create a dedicated Timetable / Emploi du temps table/view where staff can see the generated timetable after generation.

The view must support at minimum:
- academic year;
- class/group;
- level/filière/specialty;
- day and period;
- subject/module;
- teacher;
- room;
- generated version/status;
- conflict/constraint status where relevant.

Provide class-oriented timetable viewing as the primary staff view, with useful room/teacher views where the same canonical generated schedule can be inspected without creating duplicate timetable data.

### Definition of done

An authorized user can configure timetable inputs and constraints, generate a school-wide timetable, receive an honest valid/invalid result with conflict explanations, review it in the dedicated Timetable/Emploi du temps area, manually adjust it with live conflict checks, save/version it, and explicitly publish an approved version. The same packaged Electron application must perform generation on the target environment without requiring external runtime installation.

### No duplicate model / logic rule

There must be one canonical timetable domain model and one constraint contract. UI pages, room views, teacher views, class views, exports, and future Android/Website consumers must read the same generated schedule rather than maintaining independent timetable representations or algorithms.

### Dependencies

- T-401 for canonical Niveau → Filière → Spécialité → Classe/Section classification.
- T-402/T-403 where promotion/class formation determines the academic-year class population.
- Existing timetable discovery/problem registry entries, including SCHED-100 / UNKNOWN-011, must be read before implementation.


## T-405 — Cross-Year Debt Aging & Payment-Behavior Tracking

**Status:** COMPLETE — **VERIFIED** (2026-09-22, 86th session: rules documented FIRST in financial-rules §15 → TS reference engine 32/32 → migration 0111 applied live → verify_t-405.sql **29/29 PASS** zero-residue on vebfehrpzajhstyhinnw → repository layer (Supabase RPC client + reactive mock + realtime recompute) 5/5 → the « Suivi des Dettes » desktop tab 5/5 → the website portal parity port 8/8 + build green. Evidence: `docs/recovery/t-405-live-verification.md`. The two archetype parents — the SAME 100 000 DZD debt from 2024-2025 — pin GREEN/active_payer (kept paying through 2025-2026, 10 subsequent-year payments) vs RED/critical_delinquency (silent since 2024-11) on BOTH the TS engine and the SQL mirror at the same pinned clock. The Android mirror remains future work (the engine + SQL contract are the porting surface).
**Priority:** P0 — Critical  
**Scope:** Financial domain, database/backend, statistics, search/filtering, dashboards, student/parent financial pages, academic-year history, audit, and all platform consumers.

### Objective

Build a real financial debt-aging and payment-behavior system for outstanding balances carried from previous school years. The system must distinguish between a person who has an old outstanding debt but continued paying current/subsequent school fees and a person who has remained inactive or stopped paying altogether.

This is not a visual color feature. Green/Yellow/Orange/Red are representations of an underlying canonical financial-status calculation.

### Canonical analysis

The calculation must use the existing financial/business rules and canonical payment/allocation model. It must consider, where applicable:

- outstanding amount;
- original due date;
- debt age/duration;
- payment activity;
- payment history;
- payments made in subsequent academic years;
- last payment date;
- periods of inactivity;
- current-year obligations versus carried-forward obligations;
- payment allocation/history needed to determine what was actually settled.

Do not invent arbitrary thresholds in UI code. Status thresholds, eligibility, transitions, and exceptions must be derived from or formally added to the authoritative financial/business rules and documented before implementation.

### Debt-status levels

The system must expose a canonical status level such as:

- **Green:** debt resolved or payment behavior is currently controlled/active according to the financial rules.
- **Yellow/Orange:** sustained delinquency or inactivity requiring attention but not yet at the critical threshold.
- **Red:** serious long-duration delinquency according to the authoritative financial rules.

These labels are presentation. The database/domain must retain the underlying calculated factors and status reason(s), so users can understand why a person reached a level.

### Critical distinction

An old debt must not automatically mean severe delinquency.

Example:
- A parent has an unpaid balance originating 365+ days ago.
- The parent nevertheless continued making payments for children during the following academic year.

The system must preserve both facts and distinguish this from:
- an equally old debt where the person stopped paying and has had prolonged inactivity.

The status calculation must therefore evaluate debt age together with subsequent payment behavior and current activity.

### Cross-year tracking

Track financial continuity across academic years so staff can inspect:

Academic Year → Original obligation → Due date → Payments/allocations → Remaining balance → Subsequent-year payment activity → Current debt age/status

Historical obligations must remain attributable to their original year/due date while subsequent payments remain part of the person's actual payment history. Do not rewrite historical debt dates merely because a later payment occurred.

### Integration requirements

The feature must be consumed consistently by:

- financial pages and debt/receivables views;
- student/parent/person details;
- payment history;
- dashboards and operational statistics;
- debt aging reports;
- search and filtering;
- alerts/attention workflows where applicable;
- academic-year financial views;
- exports/reports;
- Android/Desktop/Website consumers where financial data is exposed.

Users must be able to filter and inspect debt by age/status, amount, academic year, activity, and other supported financial dimensions without each page implementing its own calculation.

### Dedicated debt tracking view

Create a dedicated **Debt Aging / Suivi des Dettes** table/view showing, at minimum:

- person/household;
- affected student(s);
- originating academic year;
- original due date;
- outstanding amount;
- debt age;
- last payment date;
- subsequent-year payment activity;
- inactivity duration;
- canonical status level;
- status reason/explanation;
- last recalculation/update.

The view must allow staff to open the underlying financial history rather than treating the status as a black box.

### Calculation and data integrity

- Use one canonical debt-status calculation/service.
- No page-local color/status rules.
- Do not treat missing payments as zero without an established financial meaning.
- Do not reset debt age when a partial payment occurs.
- Preserve original due dates and allocation history.
- Separate current-year obligations from carried-forward historical debt while still analyzing the person's overall payment behavior.
- Recalculate consistently when payments, allocations, due dates, academic-year context, or relevant financial rules change.
- Preserve auditability of status-relevant changes.

### No Duplication + Finance Tab Parity

This feature MUST NOT duplicate any existing financial logic, calculation, data model, workflow, or feature.

Before implementation, agents MUST inspect the existing **Finance / Financial tab** and identify what is already implemented and authoritative. Debt Aging / Suivi des Dettes must extend those existing financial capabilities rather than recreate them.

- Reuse the existing canonical financial calculations, payment logic, allocation logic, debt/receivable logic, academic-year logic, and financial data model.
- Do not create a second debt calculation engine, payment-history implementation, payment/allocation model, or parallel debt ledger.
- Do not create page-specific financial calculations or duplicate an existing Finance-tab feature under another name.
- If an existing function, service, query, component, table, view, or calculation already provides the required information, extend/reuse it instead of implementing another version.

### UI Must Match the Existing Finance Tab

The Debt Aging / Suivi des Dettes UI must match and extend the **actual Finance tab** already built. Agents MUST first inspect how the Finance tab calculates and displays outstanding amounts, payments, allocations, academic years, debts/receivables, workflows, components, tables, filters, and details.

Where the Finance tab already has a concept, calculation, component, terminology, or workflow, T-405 MUST use the same implementation and semantics. The new UI may add debt-aging-specific information such as originating academic year, original due date, debt age, subsequent-year payment activity, last payment, inactivity duration, canonical status, and status explanation, but these must be additional views of the existing financial data and logic.

If the Finance tab says a person owes a particular amount, Debt Aging MUST NOT independently calculate a different amount. If an existing financial workflow determines payment allocation, Debt Aging MUST consume that result rather than reproduce the allocation logic.

**Core rule: extend the existing Finance system; do not recreate it.**

### Database/backend requirements

The database/backend must own persisted financial facts, payment allocations, historical obligations, and the query contract needed to calculate/report debt aging. Any derived status must have a documented source-of-truth strategy and must not drift between Desktop, Android, Website, statistics, and reports.

Before implementation, audit the existing financial schema, payment allocation logic, receivables/debt calculations, academic-year boundaries, and authoritative financial documents. Do not create a parallel debt ledger if the existing canonical financial model can support this feature.

### Definition of done

An authorized user can inspect a person's historical debt, see exactly when the obligation originated, how old it is, what remains outstanding, whether the person continued paying in later school years, how long they have been inactive, and the resulting rule-based status with an understandable explanation. The same calculation is used across financial pages, statistics, search/filtering, reports, and platform consumers.

The feature is not complete until the distinction between "old debt but continued paying" and "old debt with prolonged non-payment" is demonstrably correct against real payment-history fixtures and the authoritative financial rules.


## T-406 — Manager Worker Group Chat & Automatic Client Contact Channels

**Status:** Ready  
**Priority:** P1  
**Scope:** Manager workspace, worker communication, client communication, permissions, client portal activation, channel/conversation lifecycle, UI/core integration, testing.

### Objective

Build a fully integrated communication workflow in the Manager for both worker-to-worker group communication and client communication. The feature must use the existing authentication, authorization, Manager communication, and client-portal models rather than creating parallel permission or messaging logic.

### Worker group chat

Provide group channels for workers inside the Manager. Authorized workers must be able to create/open channels, participate in conversations, send messages, and reply according to the existing permission model.

Fix the current permission-flow issue where creating a channel can incorrectly display a message such as **“You have permission to make this action too”** even though the user is already authorized. Channel creation, messaging, replies, and channel management must use consistent existing permission checks and must not introduce a second RBAC system.

### Client communication / reply section

Provide a Manager communication/reply area for contacting clients through their available client communication channel. It must support conversation history, sending replies, receiving/viewing messages where supported by the existing architecture, read/unread state, clear client identification, and permission-aware access.

### Automatic channel creation when a client portal is activated

Whenever a client's portal is activated, automatically create or open the corresponding client contact conversation in the Manager.

The workflow is:

**Activate Client Portal → Create/open the client's communication channel → Make the conversation immediately available in Manager**

If the client already has a communication channel, reuse/open that existing channel. Never create duplicate client conversations for the same client.

### No duplicated logic

Reuse the existing permission/RBAC model, authentication identity, client identity, portal state, communication primitives, and channel/conversation data model wherever they already exist.

Do not create a second permission system, duplicate client identity model, parallel conversation model, or page-specific authorization rules. If an existing function/service/query/component already provides the required capability, extend and reuse it.

### Full UI and core integration testing

This task must be tested as a real end-to-end workflow, not as disconnected UI mocks. Perform extensive UI and mouse-interaction testing covering:

- creating worker group channels;
- opening and switching channels;
- sending messages;
- replying to messages;
- permission boundaries for authorized and unauthorized users;
- activating a client portal;
- automatic creation/opening of the client contact channel;
- sending the first client message;
- reopening an existing client conversation;
- preventing duplicate client channels;
- unread/read behavior where supported;
- refresh/reload persistence;
- navigation between Manager and client-related views;
- verifying that UI state matches the underlying core/data state.

The final implementation must prove that the Manager UI, permission system, client portal activation state, and communication logic are fully integrated and remain synchronized.

### Definition of done

An authorized worker can communicate with other workers through Manager group channels and communicate with clients through their Manager conversation. Creating a client portal automatically makes the correct client communication channel available without manual channel creation, existing channels are reused rather than duplicated, permissions behave consistently, and the complete workflow passes comprehensive UI, mouse-interaction, persistence, and core-integration tests.
