/**
 * MockUserAccountRepository — in-memory admin account provisioning (T-079).
 *
 * Mirrors the create-user-account Edge Function contract for dev/demo mode:
 *   - validates email + plan §12.04 password policy (same rules as
 *     changePassword — deliberately duplicated across implementations, the
 *     established pattern in this layer),
 *   - rejects duplicate emails (account squatting),
 *   - generates a policy-compliant password when none is provided,
 *   - mints the account into the SHARED seedAccounts array so the new user
 *     can immediately sign in through MockAuthRepository (mock semantics
 *     after T-001: known email + non-empty password),
 *   - appends a `user_account.create` audit entry WITHOUT the password.
 *
 * Unlike the Supabase layer there is no role-escalation concern here — the
 * mock layer is a dev/demo fallback that is bypassed entirely when Supabase
 * is configured (see repository-provider.tsx).
 */
import type {
  AccountOverviewEntry,
  CreateAccountInput,
  CreatedAccount,
  UserAccountRepository,
} from "../../../domain/repository/repository";
import type { Result } from "../../../core/result";
import { Ok, Err } from "../../../core/result";
import { Errors } from "../../../core/app-error";
import { Role } from "../../../core/rbac/roles";
import { delay, store } from "./mock-store";
import {
  seedAccounts,
  TENANT_ID,
  AuditActions,
  appendAudit,
} from "./mock-store";

/** All wire roles accepted by createAccount (the 11-role matrix, §02.07 + §09). */
const VALID_ROLES: ReadonlySet<string> = new Set(Object.values(Role));

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/** Plan §12.04 policy — identical rules to changePassword in both repos. */
function meetsPasswordPolicy(pw: string): boolean {
  return (
    pw.length >= 8 && /[a-z]/.test(pw) && /[A-Z]/.test(pw) && /\d/.test(pw)
  );
}

/**
 * Generates a 12-char password guaranteed to satisfy the §12.04 policy.
 * Mirrors the generator inside the create-user-account Edge Function (the
 * EF runs on Deno and cannot import from src/ — accepted duplication).
 */
function generatePassword(): string {
  const lower = "abcdefghijkmnopqrstuvwxyz";
  const upper = "ABCDEFGHJKLMNPQRSTUVWXYZ";
  const digits = "23456789";
  const all = lower + upper + digits;
  const pick = (alphabet: string): string => {
    const buf = new Uint32Array(1);
    crypto.getRandomValues(buf);
    return alphabet[buf[0] % alphabet.length];
  };
  // Guarantee one of each class, then fill the rest, then shuffle.
  const chars = [
    pick(lower),
    pick(upper),
    pick(digits),
    ...Array.from({ length: 9 }, () => pick(all)),
  ];
  for (let i = chars.length - 1; i > 0; i--) {
    const buf = new Uint32Array(1);
    crypto.getRandomValues(buf);
    const j = buf[0] % (i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join("");
}

/** Mints sequential mock user ids (usr-gen-001, …) distinct from the seeds. */
function nextMockUserId(): string {
  const count =
    seedAccounts.filter((a) => a.userId.startsWith("usr-gen-")).length + 1;
  return `usr-gen-${String(count).padStart(3, "0")}`;
}

export class MockUserAccountRepository implements UserAccountRepository {
  async createAccount(input: CreateAccountInput): Promise<Result<CreatedAccount>> {
    await delay(200);

    const email = input.email.trim().toLowerCase();
    if (!EMAIL_RE.test(email)) {
      return Err(Errors.validation("Adresse email invalide"));
    }
    if (!VALID_ROLES.has(input.role)) {
      return Err(Errors.validation(`Rôle inconnu : ${String(input.role)}`));
    }
    if (
      seedAccounts.some(
        (a) => a.email.toLowerCase() === email,
      )
    ) {
      return Err(
        Errors.conflict(`Un compte existe déjà pour ${email}`),
      );
    }

    // T-371 — resolve + validate the employee BEFORE minting anything, so
    // a rejected link never leaves a half-created account behind (the
    // Supabase path gets the same atomicity from the RPC transaction).
    let personnelIdx = -1;
    if (input.personnelId && input.personnelId.trim().length > 0) {
      personnelIdx = store.personnel.findIndex(
        (p) => p.id === input.personnelId!.trim(),
      );
      if (personnelIdx < 0) {
        return Err(Errors.validation("Fiche employé introuvable"));
      }
      const bound = store.personnel[personnelIdx];
      if (bound.userId) {
        return Err(
          Errors.conflict(
            `Cet employé (${bound.id}) est déjà lié à un autre compte`,
          ),
        );
      }
    }

    const initialPassword =
      input.initialPassword && input.initialPassword.length > 0
        ? input.initialPassword
        : generatePassword();
    if (!meetsPasswordPolicy(initialPassword)) {
      return Err(
        Errors.validation(
          "Le mot de passe doit contenir au moins 8 caractères, une majuscule, une minuscule et un chiffre",
        ),
      );
    }

    const userId = nextMockUserId();
    // Mint into the SHARED seedAccounts — MockAuthRepository.signIn reads
    // this array, so the created user can sign in immediately (the whole
    // point of T-079).
    seedAccounts.push({
      email,
      userId,
      displayName: input.fullName?.trim() || email,
      role: input.role,
      // Mock sign-in semantics (T-001) check only email + non-empty
      // password, so no secret is stored here.
    });

    // T-371 — bind the employee record to the fresh account id and notify
    // the shared personnel stream, so every observeByUserId consumer (the
    // employee dashboards, the task table, the requests center, the
    // ProfilePage dossier) resolves "me" for the new user immediately.
    let personnelCode: string | null = null;
    let personnelName: string | null = null;
    if (personnelIdx >= 0) {
      const bound = store.personnel[personnelIdx];
      personnelCode = bound.id; // mock ids stand in for personnel_code
      personnelName = `${bound.firstName} ${bound.lastName}`.trim();
      store.personnel[personnelIdx] = {
        ...bound,
        userId,
        email: bound.email ?? email,
      };
      store.notifyPersonnel();
    }

    appendAudit({
      action: AuditActions.UserAccountCreate,
      entityType: "user_account",
      entityId: email,
      actorId: "admin",
      actorName: "Administrateur (mock)",
      diff: {
        before: null,
        // NEVER include the initial password (SEC-100).
        after: {
          email,
          role: input.role,
          displayName: input.fullName ?? null,
          // T-371 — the linkage is part of the audit record.
          personnelId: input.personnelId?.trim() || null,
        },
      },
      note: `Compte créé par l'administrateur (${TENANT_ID})`,
    });

    return Ok({
      email,
      role: input.role,
      initialPassword,
      personnelCode,
      personnelName,
    });
  }

  /**
   * T-381 — the accounts overview over the shared mock stores: every seeded
   * + minted account, joined with the personnel rows bound to it. Mock ids
   * stand in for personnel_code (same convention as createAccount).
   */
  async listAccounts(): Promise<Result<AccountOverviewEntry[]>> {
    await delay(120);
    const byUserId = new Map<string, (typeof store.personnel)[number]>();
    for (const p of store.personnel) {
      if (p.userId && !byUserId.has(p.userId)) byUserId.set(p.userId, p);
    }
    const entries: AccountOverviewEntry[] = seedAccounts.map((a) => {
      const bound = byUserId.get(a.userId) ?? null;
      return {
        profileId: a.userId,
        email: a.email,
        displayName: a.displayName,
        status: "active",
        role: a.role,
        personnelId: bound?.id ?? null,
        personnelCode: bound?.id ?? null,
        personnelName: bound ? `${bound.firstName} ${bound.lastName}`.trim() : null,
      };
    });
    return Ok(entries);
  }

  /**
   * T-381 — remove a mock account: unbind the employee row (the service
   * mirror of the live EF's ON DELETE SET NULL cascade), drop the
   * seedAccounts entry, audit WITHOUT any credential material. The dev/demo
   * equivalent of the delete-user-account Edge Function's semantics.
   */
  async deleteAccount(profileId: string): Promise<Result<void>> {
    await delay(150);
    const id = profileId.trim();
    const idx = seedAccounts.findIndex((a) => a.userId === id);
    if (idx < 0) {
      return Err(Errors.notFound("UserAccount", id));
    }
    const account = seedAccounts[idx];

    // The owner-pinned admin is untouchable (the live EF's OPS-310 guard,
    // mirrored — the owner's identity belongs to the owner).
    if (account.email.toLowerCase() === "admin@elimtiyaz.dz") {
      return Err(
        Errors.validation(
          "Le compte administrateur propriétaire ne peut pas être supprimé",
        ),
      );
    }

    // Unbind the employee row (the live FK is ON DELETE SET NULL — 0009).
    let unboundPersonnelId: string | null = null;
    for (let i = 0; i < store.personnel.length; i++) {
      if (store.personnel[i].userId === id) {
        unboundPersonnelId = store.personnel[i].id;
        store.personnel[i] = { ...store.personnel[i], userId: null };
      }
    }
    if (unboundPersonnelId) store.notifyPersonnel();

    seedAccounts.splice(idx, 1);

    appendAudit({
      action: AuditActions.UserAccountDelete,
      entityType: "user_account",
      entityId: account.email,
      actorId: "admin",
      actorName: "Administrateur (mock)",
      diff: {
        before: {
          email: account.email,
          role: account.role,
          displayName: account.displayName,
        },
        after: null,
      },
      note: `Compte supprimé par l'administrateur${
        unboundPersonnelId ? ` (employé ${unboundPersonnelId} détaché)` : ""
      }`,
    });

    return Ok(undefined);
  }
}

/** Singleton instance — exported for the barrel re-export in `mock-repositories.ts`. */
export const mockUserAccountRepository: UserAccountRepository =
  new MockUserAccountRepository();
