import type { SupabaseClient } from "@supabase/supabase-js";
import type { Result } from "../../../core/result";
import { Ok, Err } from "../../../core/result";
import { Errors } from "../../../core/app-error";
import { AuditActions } from "../../../core/audit-actions";
import { supabaseErrorToAppError } from "../supabase-client";
import { SubjectBehavior } from "../../mock/subject-behavior";
import { getTenantId, isUuid } from "./supabase-shared-repositories";
import type {
  PromotionCycle,
  PromotionCycleClass,
  PromotionClassConfirmResult,
  PromotionCycleStatus,
  PromotionCycleClassStatus,
} from "../../../domain/model/promotion-cycle";
import type {
  PromotionCycleRepository,
  CreatePromotionCycleInput,
  ConfirmPromotionCycleClassInput,
} from "../../../domain/repository/academic-repository";
import { normalizeTrackCode } from "../../../domain/model/filiere";
import type { SupabaseStudentRepository } from "./supabase-shared-repositories";
import type { Observable } from "../../../domain/repository/repository";
import type {
  AcademicClass,
  Subject,
  SubjectConfiguration,
  ClassSubject,
  Assessment,
  AttendanceRecord,
  AttendanceSession,
  AttendanceStatus,
  Homework,
  AcademicYear,
  AcademicLevelModel,
  AcademicTerm,
} from "../../../domain/model/academic";
import { computeSubjectAverage } from "../../../domain/model/academic";
import { computeSubjectAverageFromRecipe } from "../../../domain/calc/academics/subject-config";
import type {
  Student,
  AcademicLevel,
  GradeLevel,
} from "../../../domain/model/student";
import {
  academicLevelFromGradeLevel,
  gradeYearFromGradeLevel,
} from "../../../domain/model/student";
import type {
  AcademicYearRepository,
  AcademicLevelRepository,
  ClassRepository,
  SubjectRepository,
  GradeRepository,
  AttendanceRepository,
  HomeworkRepository,
  PromotionRepository,
  GradeEntryInput,
  ClassPlacementRepository,
  FinalizeClassPlacementsInput,
  FinalizeClassPlacementsResult,
} from "../../../domain/repository/academic-repository";
import type { PromotionCandidate } from "../../../domain/calc/academics/promotion";
import { createAcademicHistoryEntry,
  buildPromotionDecisionPayload,
} from "../../../domain/calc/academics/promotion";
import { currentTermWindow } from "../../../domain/calc/academics/terms";
import { dispatchWorkflowTriggerSafe } from "./workflow-dispatch";
import type {
  CreateSchoolYearInput,
  UpdateSchoolYearInput,
} from "../../../domain/calc/academics/school-year";

// ============================================================================
// 1. ACADEMIC YEAR REPOSITORY
// ============================================================================
export class SupabaseAcademicYearRepository implements AcademicYearRepository {
  private readonly subject = new SubjectBehavior<AcademicYear[]>([]);

  constructor(private readonly client: SupabaseClient) {
    this.refresh();
  }

  private async refresh(): Promise<void> {
    const { data } = await this.client
      .from("academic_years")
      .select("*")
      .order("start_date", { ascending: false });

    if (data) {
      this.subject.set(data.map(mapAcademicYearRow));
    }
  }

  observeAll(): Observable<AcademicYear[]> {
    return this.subject;
  }

  observeById(id: string): Observable<AcademicYear | null> {
    const sub = new SubjectBehavior<AcademicYear | null>(null);
    this.subject.subscribe((years) => {
      sub.set(years.find((y) => y.id === id) ?? null);
    });
    return sub;
  }

  async getCurrentYear(): Promise<Result<AcademicYear>> {
    const { data, error } = await this.client
      .from("academic_years")
      .select("*")
      .eq("is_current", true)
      .single();

    if (error) return Err(supabaseErrorToAppError(error));
    return Ok(mapAcademicYearRow(data));
  }

  async getYearByCode(code: string): Promise<Result<AcademicYear | null>> {
    const { data, error } = await this.client
      .from("academic_years")
      .select("*")
      .eq("code", code)
      .maybeSingle();

    if (error) return Err(supabaseErrorToAppError(error));
    return Ok(data ? mapAcademicYearRow(data) : null);
  }

  async setCurrentYear(id: string, actorId: string, actorName: string): Promise<Result<AcademicYear>> {
    // T-041 (ACAD-101): single atomic RPC (migration 0059) — ONE UPDATE
    // statement flips is_current for every year of the tenant, so there is
    // no failure window leaving the tenant with zero current years (the old
    // two-step client UPDATE could unset every year then fail on the second
    // call). The RPC also writes the audit entry the old path never wrote.
    const { data, error } = await this.client.rpc("set_current_academic_year", {
      p_academic_year_id: id,
      p_actor_profile_id: isUuid(actorId) ? actorId : null,
      p_actor_name: actorName || null,
      p_tenant_id: getTenantId(),
    });

    if (error) return Err(supabaseErrorToAppError(error));
    await this.refresh();
    return Ok(mapAcademicYearRow(data as Record<string, any>));
  }

  async createAcademicYear(
    input: CreateSchoolYearInput,
    _actorId: string,
    _actorName: string,
  ): Promise<Result<AcademicYear>> {
    // T-313 (ACAD-104): tenant_id is NOT NULL with NO column default and
    // the academic_years_admin WITH CHECK is
    // `(tenant_id = current_tenant_id() AND has_any_role(...))` — an
    // insert without tenant_id evaluates NULL = ... → 42501 → ERR_FORBIDDEN
    // (the owner's SuperAdmin denial). Same fix as the T-023 ATT-100/
    // HOMEWORK-100 precedent in this file: supply the session's working
    // tenant explicitly, and fail loud (Result) when there is none — a
    // global admin who has not picked a tenant cannot create a year.
    const tenantId = getTenantId();
    if (!tenantId) {
      return Err(
        Errors.validation(
          "createAcademicYear: no active tenant context",
          "Aucun établissement actif — sélectionnez un établissement ou reconnectez-vous.",
        ),
      );
    }
    // T-041 (ACAD-101): INSERT with is_current = false, then (when the new
    // year must be current) flip via the ATOMIC set_current_academic_year
    // RPC — one UPDATE statement, no zero-current-year window. Failure
    // modes are safe: if the INSERT fails nothing changed; if the RPC fails
    // the new year exists but is NOT current (the previous current year
    // keeps its flag — strictly better than the old unset-first pattern,
    // which un-set the previous year BEFORE the INSERT could fail).
    const { data, error } = await this.client
      .from("academic_years")
      .insert({
        tenant_id: tenantId,
        code: input.code,
        label: input.label,
        start_date: input.startDate,
        end_date: input.endDate,
        term_structure: input.termStructure,
        is_current: false,
        is_archived: false,
      })
      .select()
      .single();

    if (error) return Err(supabaseErrorToAppError(error));
    const created = mapAcademicYearRow(data);

    if (input.isCurrent) {
      const flip = await this.setCurrentYear(
        created.id,
        _actorId,
        _actorName,
      );
      if (!flip.ok) return flip;
      await this.refresh();
      return flip;
    }

    await this.refresh();
    return Ok(created);
  }

  async updateAcademicYear(
    id: string,
    input: UpdateSchoolYearInput,
    _actorId: string,
    _actorName: string,
  ): Promise<Result<AcademicYear>> {
    const patch: Record<string, unknown> = { updated_at: new Date().toISOString() };
    if (input.label !== undefined) patch.label = input.label;
    if (input.startDate !== undefined) patch.start_date = input.startDate;
    if (input.endDate !== undefined) patch.end_date = input.endDate;
    if (input.termStructure !== undefined) patch.term_structure = input.termStructure;

    const { data, error } = await this.client
      .from("academic_years")
      .update(patch)
      .eq("id", id)
      .select()
      .single();

    if (error) return Err(supabaseErrorToAppError(error));
    await this.refresh();
    return Ok(mapAcademicYearRow(data));
  }

  async archiveAcademicYear(id: string, _actorId: string, _actorName: string): Promise<Result<AcademicYear>> {
    const { data, error } = await this.client
      .from("academic_years")
      .update({ is_archived: true, updated_at: new Date().toISOString() })
      .eq("id", id)
      .select()
      .single();

    if (error) return Err(supabaseErrorToAppError(error));
    await this.refresh();
    return Ok(mapAcademicYearRow(data));
  }

  async restoreAcademicYear(id: string, _actorId: string, _actorName: string): Promise<Result<AcademicYear>> {
    const { data, error } = await this.client
      .from("academic_years")
      .update({ is_archived: false, updated_at: new Date().toISOString() })
      .eq("id", id)
      .select()
      .single();

    if (error) return Err(supabaseErrorToAppError(error));
    await this.refresh();
    return Ok(mapAcademicYearRow(data));
  }

  async deleteAcademicYear(id: string, _actorId: string, _actorName: string): Promise<Result<void>> {
    const { error } = await this.client
      .from("academic_years")
      .delete()
      .eq("id", id);

    if (error) return Err(supabaseErrorToAppError(error));
    await this.refresh();
    return Ok(undefined);
  }
}

// ============================================================================
// 2. ACADEMIC LEVEL REPOSITORY
// ============================================================================
export class SupabaseAcademicLevelRepository implements AcademicLevelRepository {
  private readonly subject = new SubjectBehavior<AcademicLevelModel[]>([]);

  constructor(private readonly client: SupabaseClient) {
    this.refresh();
  }

  private async refresh(): Promise<void> {
    const { data } = await this.client
      .from("academic_levels")
      .select("*")
      .eq("is_active", true)
      .order("sort_order", { ascending: true });

    if (data) {
      this.subject.set(data.map(mapAcademicLevelRow));
    }
  }

  observeAll(): Observable<AcademicLevelModel[]> {
    return this.subject;
  }

  async getByGradeCode(
    gradeCode: GradeLevel,
  ): Promise<Result<AcademicLevelModel | null>> {
    const { data, error } = await this.client
      .from("academic_levels")
      .select("*")
      .eq("grade_code", gradeCode)
      .maybeSingle();

    if (error) return Err(supabaseErrorToAppError(error));
    return Ok(data ? mapAcademicLevelRow(data) : null);
  }
}

// ============================================================================
// 3. CLASS REPOSITORY
// ============================================================================
export class SupabaseClassRepository implements ClassRepository {
  private readonly subject = new SubjectBehavior<AcademicClass[]>([]);
  /** Per-class enrolled-student counts (students.class_id histogram). */
  private enrolledByClass = new Map<string, number>();

  constructor(private readonly client: SupabaseClient) {
    this.refresh();
  }

  /**
   * T-370 (ACAD-500): this is now PUBLIC — the class-placement finalize RPC
   * mutates classes server-side, and `SupabaseClassPlacementRepository`
   * triggers this refresh after a successful batch so the studio's parent
   * view (Niveaux & Classes) reflects the created sections immediately,
   * instead of waiting for the CROSS-104 TTL/focus policy.
   */
  async refresh(): Promise<void> {
    try {
      const [{ data, error }, enrolled] = await Promise.all([
        this.client
          .from("classes")
          .select(
            `
            *,
            academic_years!inner(code, label)
          `,
          )
          .eq("is_active", true)
          .order("code", { ascending: true }),
        // enrolledCount is derived from the students table (the classes table
        // has no enrolled_count column) — one histogram query per refresh.
        this.client
          .from("students")
          .select("class_id")
          .not("class_id", "is", null),
      ] as const);

      if (error) throw error;

      this.enrolledByClass = new Map<string, number>();
      for (const row of (enrolled.data ?? []) as { class_id: string | null }[]) {
        if (row.class_id) {
          this.enrolledByClass.set(
            row.class_id,
            (this.enrolledByClass.get(row.class_id) ?? 0) + 1,
          );
        }
      }

      if (data) {
        this.subject.set(
          data.map((row) => mapClassRow(row, this.enrolledByClass.get(row.id) ?? 0)),
        );
      }
    } catch {
      // Silently degrade to the current cache — the UI shows "no classes".
    }
  }

  observe(): Observable<AcademicClass[]> {
    return this.subject;
  }

  observeByLevel(level: AcademicLevel): Observable<AcademicClass[]> {
    const sub = new SubjectBehavior<AcademicClass[]>([]);
    this.subject.subscribe((classes) => {
      sub.set(classes.filter((c) => c.level === level));
    });
    return sub;
  }

  observeById(id: string): Observable<AcademicClass | null> {
    const sub = new SubjectBehavior<AcademicClass | null>(null);
    this.subject.subscribe((classes) => {
      sub.set(classes.find((c) => c.id === id) ?? null);
    });
    return sub;
  }

  async createClass(
    input: Omit<
      AcademicClass,
      "id" | "tenantId" | "enrolledCount" | "isActive"
    >,
  ): Promise<Result<AcademicClass>> {
    // T-313 (ACAD-104): tenant_id is NOT NULL, no default, no set-tenant
    // trigger on `classes` — the insert MUST carry the session's working
    // tenant or the classes_admin WITH CHECK rejects it (42501). Same
    // T-023 in-file precedent (attendance L934 / homework L1135).
    const tenantId = getTenantId();
    if (!tenantId) {
      return Err(
        Errors.validation(
          "createClass: no active tenant context",
          "Aucun établissement actif — sélectionnez un établissement ou reconnectez-vous.",
        ),
      );
    }
    const { data, error } = await this.client
      .from("classes")
      .insert({
        tenant_id: tenantId,
        academic_year_id: input.academicYearId,
        academic_level_id: input.academicLevelId,
        code: input.code,
        name: input.name,
        grade_code: input.gradeCode,
        section: input.section || "A",
        // T-401 (0107): the class's academic classification (validated
        // client-side by the catalog; NULL = untagged).
        filiere_code: normalizeTrackCode(input.filiereCode),
        specialite_code: normalizeTrackCode(input.specialiteCode),
        room: input.room,
        capacity: input.capacity ?? 30,
        // Mock-era ids ("per-001") are not UUIDs — never send them to the
        // uuid column.
        homeroom_teacher_id: isUuid(input.homeroomTeacherId)
          ? input.homeroomTeacherId
          : null,
        homeroom_teacher_name: input.homeroomTeacherName,
      })
      .select(`*, academic_years!inner(code, label)`)
      .single();

    if (error) return Err(supabaseErrorToAppError(error));
    await this.refresh();
    return Ok(mapClassRow(data, this.enrolledByClass.get(data.id) ?? 0));
  }

  async updateClass(
    id: string,
    updates: Partial<AcademicClass>,
  ): Promise<Result<AcademicClass>> {
    const patch: Record<string, unknown> = {};
    if (updates.name !== undefined) patch.name = updates.name;
    if (updates.code !== undefined) patch.code = updates.code;
    if (updates.room !== undefined) patch.room = updates.room;
    if (updates.capacity !== undefined)
      patch.capacity = updates.capacity ?? 30;
    if (updates.homeroomTeacherId !== undefined)
      patch.homeroom_teacher_id = isUuid(updates.homeroomTeacherId)
        ? updates.homeroomTeacherId
        : null;
    if (updates.homeroomTeacherName !== undefined)
      patch.homeroom_teacher_name = updates.homeroomTeacherName;
    patch.updated_at = new Date().toISOString();

    const { data, error } = await this.client
      .from("classes")
      .update(patch)
      .eq("id", id)
      .select(`*, academic_years!inner(code, label)`)
      .single();

    if (error) return Err(supabaseErrorToAppError(error));
    await this.refresh();
    return Ok(mapClassRow(data, this.enrolledByClass.get(data.id) ?? 0));
  }

  async deleteClass(id: string): Promise<Result<void>> {
    const { error } = await this.client
      .from("classes")
      .update({ is_active: false, updated_at: new Date().toISOString() })
      .eq("id", id);

    if (error) return Err(supabaseErrorToAppError(error));
    await this.refresh();
    return Ok(undefined);
  }
}

// ============================================================================
// 4. SUBJECT REPOSITORY
// ============================================================================
export class SupabaseSubjectRepository implements SubjectRepository {
  private readonly subject = new SubjectBehavior<Subject[]>([]);
  /** All class-subject assignments — kept reactive for `observeByClass`. */
  private readonly classSubjects = new SubjectBehavior<ClassSubject[]>([]);
  /** T-345 (MATIERE-500/ADR-018): the context configurations cache. */
  private readonly configurations = new SubjectBehavior<SubjectConfiguration[]>([]);

  constructor(private readonly client: SupabaseClient) {
    this.refresh();
    this.refreshClassSubjects();
    this.refreshConfigurations();
  }

  private async refresh(): Promise<void> {
    const { data } = await this.client
      .from("subjects")
      .select("*")
      .eq("is_active", true)
      .order("code", { ascending: true });

    if (data) {
      this.subject.set(data.map(mapSubjectRow));
    }
  }

  private async refreshClassSubjects(): Promise<void> {
    const { data } = await this.client
      .from("class_subjects")
      .select("*")
      .order("created_at", { ascending: true });

    if (data) {
      this.classSubjects.set(data.map(mapClassSubjectRow));
    }
  }

  /** T-345: the context-specific subject configurations (0094 table). */
  private async refreshConfigurations(): Promise<void> {
    const { data } = await this.client
      .from("subject_configurations")
      .select("*")
      .eq("is_active", true)
      .order("created_at", { ascending: true });

    if (data) {
      this.configurations.set(data.map(mapSubjectConfigurationRow));
    }
  }

  observeConfigurations(): Observable<SubjectConfiguration[]> {
    return this.configurations;
  }

  async upsertSubjectConfiguration(
    input: Omit<SubjectConfiguration, "id" | "tenantId"> & { id?: string },
  ): Promise<Result<SubjectConfiguration>> {
    const tenantId = getTenantId();
    if (!tenantId) {
      return Err(
        Errors.validation(
          "upsertSubjectConfiguration: no active tenant context",
          "Aucun établissement actif — sélectionnez un établissement ou reconnectez-vous.",
        ),
      );
    }
    if (
      !isUuid(input.subjectId) ||
      !isUuid(input.academicYearId) ||
      !isUuid(input.academicLevelId)
    ) {
      return Err(
        Errors.validation(
          "La configuration matière nécessite des identifiants Supabase valides (matière, année, niveau).",
        ),
      );
    }
    // Grading-recipe shape guard (mirrors the SQL CHECK constraint).
    const r = input.gradingRecipe;
    const weights = [r.devoir1, r.devoir2, r.examen, r.cc];
    if (weights.some((w) => !Number.isFinite(w) || w < 0) || weights.reduce((a, b) => a + b, 0) <= 0) {
      return Err(
        Errors.validation(
          "Recette de notation invalide — chaque poids doit être ≥ 0 et leur somme > 0.",
        ),
      );
    }

    const payload = {
      tenant_id: tenantId,
      subject_id: input.subjectId,
      academic_year_id: input.academicYearId,
      academic_level_id: input.academicLevelId,
      direction: input.direction || "general",
      coefficient: input.coefficient,
      subject_code: input.subjectCode,
      passing_grade: input.passingGrade,
      is_extracurricular: input.isExtracurricular,
      grading_recipe: {
        devoir1: r.devoir1,
        devoir2: r.devoir2,
        examen: r.examen,
        cc: r.cc,
      },
      weekly_hours: input.weeklyHours,
      is_active: input.isActive,
      updated_at: new Date().toISOString(),
    };

    const { data, error } = await this.client
      .from("subject_configurations")
      .upsert(payload, {
        onConflict:
          "tenant_id,subject_id,academic_year_id,academic_level_id,direction",
      })
      .select()
      .single();

    if (error) return Err(supabaseErrorToAppError(error));
    await this.refreshConfigurations();
    return Ok(mapSubjectConfigurationRow(data));
  }

  observe(): Observable<Subject[]> {
    return this.subject;
  }

  observeByLevel(level: AcademicLevel): Observable<Subject[]> {
    const sub = new SubjectBehavior<Subject[]>([]);
    this.subject.subscribe((subjects) => {
      sub.set(subjects.filter((s) => s.level === level));
    });
    return sub;
  }

  observeByClass(classId: string): Observable<ClassSubject[]> {
    // Derived from the shared assignments cache so assign/remove mutations
    // propagate to every open class-subjects tab.
    const sub = new SubjectBehavior<ClassSubject[]>([]);
    this.classSubjects.subscribe((all) => {
      sub.set(all.filter((cs) => cs.classId === classId));
    });
    return sub;
  }

  async assignSubjectToClass(
    input: Omit<ClassSubject, "id">,
  ): Promise<Result<ClassSubject>> {
    if (!isUuid(input.classId) || !isUuid(input.subjectId)) {
      return Err(
        Errors.validation(
          "L'assignation matière-classe nécessite des identifiants Supabase valides.",
        ),
      );
    }

    // T-313 (ACAD-104): this is the EXACT insert the owner's SuperAdmin
    // denial report was about. class_subjects.tenant_id is NOT NULL, no
    // default, no set-tenant trigger; the class_subjects_admin WITH CHECK
    // `(tenant_id = current_tenant_id() AND has_any_role(...))` evaluates
    // NULL on a tenant-less payload → 42501 → ERR_FORBIDDEN. The 9e70078
    // "fix" wrapped this failure into a fake-success client-side row
    // (REG-006) instead of fixing the payload. Verified live: the table
    // had ZERO rows — the flow never once persisted.
    const tenantId = getTenantId();
    if (!tenantId) {
      return Err(
        Errors.validation(
          "assignSubjectToClass: no active tenant context",
          "Aucun établissement actif — sélectionnez un établissement ou reconnectez-vous.",
        ),
      );
    }

    const { data, error } = await this.client
      .from("class_subjects")
      .insert({
        tenant_id: tenantId,
        class_id: input.classId,
        subject_id: input.subjectId,
        // Mock-era personnel ids ("per-001") are not UUIDs.
        teacher_id: isUuid(input.teacherId) ? input.teacherId : null,
        teacher_name: input.teacherName,
        weekly_hours: input.weeklyHours,
        coefficient: input.coefficient,
        // T-404 (0109 §6): consecutive blocks + required room type.
        consecutive_periods: input.consecutivePeriods ?? 1,
        required_room_type: input.requiredRoomType ?? null,
      })
      .select()
      .single();

    if (error) return Err(supabaseErrorToAppError(error));
    await this.refreshClassSubjects();
    return Ok(mapClassSubjectRow(data));
  }

  async removeSubjectFromClass(id: string): Promise<Result<void>> {
    const { error } = await this.client
      .from("class_subjects")
      .delete()
      .eq("id", id);
    if (error) return Err(supabaseErrorToAppError(error));
    await this.refreshClassSubjects();
    return Ok(undefined);
  }

  async createSubject(
    input: Omit<Subject, "id" | "tenantId">,
  ): Promise<Result<Subject>> {
    // T-313 (ACAD-104): tenant_id is NOT NULL, no default, no set-tenant
    // trigger on `subjects` — the subjects_admin WITH CHECK rejects a
    // tenant-less insert (42501). T-023 in-file precedent.
    const tenantId = getTenantId();
    if (!tenantId) {
      return Err(
        Errors.validation(
          "createSubject: no active tenant context",
          "Aucun établissement actif — sélectionnez un établissement ou reconnectez-vous.",
        ),
      );
    }
    const { data, error } = await this.client
      .from("subjects")
      .insert({
        tenant_id: tenantId,
        code: input.code,
        name_fr: input.name,
        name_ar: input.nameAr,
        cycle: input.cycle,
        default_coefficient: input.coefficient,
        passing_grade: input.passingGrade,
        is_extracurricular: input.isExtracurricular,
      })
      .select()
      .single();

    if (error) return Err(supabaseErrorToAppError(error));
    await this.refresh();
    return Ok(mapSubjectRow(data));
  }

  async updateSubject(
    id: string,
    updates: Partial<Omit<Subject, "id" | "tenantId">>,
  ): Promise<Result<Subject>> {
    const patch: Record<string, unknown> = {};
    if (updates.name !== undefined) patch.name_fr = updates.name;
    if (updates.nameAr !== undefined) patch.name_ar = updates.nameAr;
    if (updates.code !== undefined) patch.code = updates.code;
    if (updates.coefficient !== undefined)
      patch.default_coefficient = updates.coefficient;
    if (updates.passingGrade !== undefined)
      patch.passing_grade = updates.passingGrade;
    if (updates.isExtracurricular !== undefined)
      patch.is_extracurricular = updates.isExtracurricular;
    patch.updated_at = new Date().toISOString();

    const { data, error } = await this.client
      .from("subjects")
      .update(patch)
      .eq("id", id)
      .select()
      .single();

    if (error) return Err(supabaseErrorToAppError(error));

    // FIX (vault §05.06 — coefficient edits trigger an automatic GPA
    // recompute): the canonical GPA (SQL `fn_calculate_student_term_gpa`,
    // Android engine, desktop drawers) reads the coefficient SNAPSHOT stored
    // on each assessment row. When the subject's default coefficient changes,
    // re-weight the stored snapshots for NON-ARCHIVED academic years so every
    // affected student's GPA recomputes. Archived years stay untouched
    // (append-only history, §04.07). This keeps desktop / mobile / backend
    // bit-identical because all three read `assessments.coefficient`.
    if (updates.coefficient !== undefined) {
      const archivedCodes = await this.archivedYearCodes();
      let query = this.client
        .from("assessments")
        .update({ coefficient: updates.coefficient })
        .eq("subject_id", id);
      if (archivedCodes.length > 0) {
        // Exclude archived years from the re-weight (append-only history).
        // PostgREST `in` filter takes a parenthesized, quoted list.
        query = query.not(
          "academic_year",
          "in",
          `(${archivedCodes.map((c) => `"${c}"`).join(",")})`,
        );
      }
      const { error: reweightError } = await query;
      if (reweightError) {
        // Non-fatal: the subject row itself was updated successfully. Surface
        // the re-weight failure so operators know GPAs may be stale.
        console.warn(
          "[supabase-subject-repo] coefficient re-weight failed:",
          reweightError.message,
        );
      }
    }

    await this.refresh();
    return Ok(mapSubjectRow(data));
  }

  /**
   * Codes of all archived academic years — used to keep archived-year
   * assessments untouched when re-weighting coefficients (append-only rule).
   */
  private async archivedYearCodes(): Promise<string[]> {
    const { data } = await this.client
      .from("academic_years")
      .select("code")
      .eq("is_archived", true);
    return (data ?? []).map((r: { code: string }) => r.code);
  }

  async archiveSubject(id: string): Promise<Result<void>> {
    const { error } = await this.client
      .from("subjects")
      .update({ is_active: false, updated_at: new Date().toISOString() })
      .eq("id", id);

    if (error) return Err(supabaseErrorToAppError(error));
    await this.refresh();
    return Ok(undefined);
  }
}

// ============================================================================
// 5. GRADE REPOSITORY
// ============================================================================
export class SupabaseGradeRepository implements GradeRepository {
  constructor(private readonly client: SupabaseClient) {}

  observeForStudent(studentId: string): Observable<Assessment[]> {
    const sub = new SubjectBehavior<Assessment[]>([]);
    const fetchGrades = async () => {
      const { data } = await this.client
        .from("assessments")
        .select("*")
        .eq("student_id", studentId)
        .order("entered_at", { ascending: false });

      if (data) sub.set(data.map(mapAssessmentRow));
    };
    fetchGrades();
    return sub;
  }

  observeForClass(
    classId: string,
    academicYear?: string,
    term?: string,
  ): Observable<Assessment[]> {
    const sub = new SubjectBehavior<Assessment[]>([]);
    const fetchClassGrades = async () => {
      let query = this.client
        .from("assessments")
        .select("*")
        .eq("class_id", classId);
      if (academicYear) query = query.eq("academic_year", academicYear);
      if (term) query = query.eq("term", term);

      const { data } = await query.order("entered_at", { ascending: false });
      if (data) sub.set(data.map(mapAssessmentRow));
    };
    fetchClassGrades();
    return sub;
  }

  /**
   * T-352 (DASH-402): the school-wide assessment stream. The Analytics
   * tab's risk engine previously queried `observeForClass("")` — a
   * literal empty-UUID filter matching ZERO rows, so every GPA rendered
   * "—" and every risk category collapsed to "healthy". This method
   * returns EVERY tenant assessment (optionally narrowed by year/term —
   * same optional filters as observeForClass).
   */
  observeAll(
    academicYear?: string,
    term?: string,
  ): Observable<Assessment[]> {
    const sub = new SubjectBehavior<Assessment[]>([]);
    const fetchAllGrades = async () => {
      let query = this.client
        .from("assessments")
        .select("*")
        .eq("tenant_id", getTenantId() ?? "");
      if (academicYear) query = query.eq("academic_year", academicYear);
      if (term) query = query.eq("term", term);

      const { data } = await query.order("entered_at", { ascending: false });
      if (data) sub.set(data.map(mapAssessmentRow));
    };
    fetchAllGrades();
    return sub;
  }

  async enterGrade(input: GradeEntryInput): Promise<Result<Assessment>> {
    // FIX (vault §04.07 — append-only history): refuse writes to archived
    // academic years, mirroring the mock repository and the backend rule.
    const archived = await this.isArchivedYear(input.academicYear);
    if (archived) {
      const msg =
        `Année scolaire ${input.academicYear} archivée — lecture seule ` +
        `(append-only, plan §04.07).`;
      return Err(Errors.validation(msg, msg));
    }
    const { data, error } = await this.client
      .from("assessments")
      .upsert(
        {
          student_id: input.studentId,
          class_id: input.classId,
          subject_id: input.subjectId,
          // WIRE FIX (A-0041): the DB column is INTEGER 1|2|3 (migration
          // 0004); the domain model uses "T1"|"T2"|"T3". The unmapped value
          // previously broke every live upsert with a type error.
          term: termToWire(input.term),
          academic_year: input.academicYear,
          devoir1: input.devoir1,
          devoir2: input.devoir2,
          examen: input.examen,
          // T-345 (ADR-018): the contrôle-continu mark + the entry-time
          // snapshots (coefficient + component weights) — history is never
          // re-resolved when the configuration later changes.
          cc: input.cc ?? null,
          coefficient: input.coefficient,
          coefficient_devoir1: input.coefficientDevoir1 ?? 1,
          coefficient_devoir2: input.coefficientDevoir2 ?? 1,
          coefficient_examen: input.coefficientExamen ?? 2,
          coefficient_cc: input.coefficientCc ?? 0,
          // CANONICAL (INV §13.03): persist the subject average computed by
          // the canonical engine — identical to the backend trigger
          // (migrations 0041/0094) and the Android Room write path.
          subject_average: computeSubjectAverageFromRecipe(
            input.devoir1 ?? null,
            input.devoir2 ?? null,
            input.examen ?? null,
            input.cc ?? null,
            {
              devoir1: input.coefficientDevoir1 ?? 1,
              devoir2: input.coefficientDevoir2 ?? 1,
              examen: input.coefficientExamen ?? 2,
              cc: input.coefficientCc ?? 0,
            },
          ),
          entered_by: input.enteredBy,
          entered_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
        { onConflict: "student_id,subject_id,term,academic_year" },
      )
      .select()
      .single();

    if (error) return Err(supabaseErrorToAppError(error));
    return Ok(mapAssessmentRow(data));
  }

  async enterGradesBatch(
    inputs: ReadonlyArray<GradeEntryInput>,
  ): Promise<Result<Assessment[]>> {
    // FIX (vault §04.07 — append-only history): all-or-nothing rejection of
    // batches targeting archived years (mirrors the mock repository).
    const yearSet = new Set(inputs.map((i) => i.academicYear));
    for (const year of yearSet) {
      const archived = await this.isArchivedYear(year);
      if (archived) {
        const msg =
          `Année scolaire ${year} archivée — lecture seule ` +
          `(append-only, plan §04.07).`;
        return Err(Errors.validation(msg, msg));
      }
    }
    const payload = inputs.map((input) => ({
      student_id: input.studentId,
      class_id: input.classId,
      subject_id: input.subjectId,
      // WIRE FIX (A-0041): map "T1"|"T2"|"T3" → 1|2|3 for the INTEGER column.
      term: termToWire(input.term),
      academic_year: input.academicYear,
      devoir1: input.devoir1,
      devoir2: input.devoir2,
      examen: input.examen,
      // T-345 (ADR-018): the contrôle-continu mark + the entry-time
      // snapshots (coefficient + component weights) — history is never
      // re-resolved when the configuration later changes.
      cc: input.cc ?? null,
      coefficient: input.coefficient,
      coefficient_devoir1: input.coefficientDevoir1 ?? 1,
      coefficient_devoir2: input.coefficientDevoir2 ?? 1,
      coefficient_examen: input.coefficientExamen ?? 2,
      coefficient_cc: input.coefficientCc ?? 0,
      // CANONICAL subject average (see single-row path).
      subject_average: computeSubjectAverageFromRecipe(
        input.devoir1 ?? null,
        input.devoir2 ?? null,
        input.examen ?? null,
        input.cc ?? null,
        {
          devoir1: input.coefficientDevoir1 ?? 1,
          devoir2: input.coefficientDevoir2 ?? 1,
          examen: input.coefficientExamen ?? 2,
          cc: input.coefficientCc ?? 0,
        },
      ),
      entered_by: input.enteredBy,
      entered_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }));

    const { data, error } = await this.client
      .from("assessments")
      .upsert(payload, {
        onConflict: "student_id,subject_id,term,academic_year",
      })
      .select();

    if (error) return Err(supabaseErrorToAppError(error));
    return Ok(data.map(mapAssessmentRow));
  }

  /** True when `academicYear` maps to an archived academic_years row. */
  private async isArchivedYear(academicYear: string): Promise<boolean> {
    const { data } = await this.client
      .from("academic_years")
      .select("is_archived")
      .eq("code", academicYear)
      .maybeSingle();
    return data?.is_archived === true;
  }
}

// ============================================================================
// 6. ATTENDANCE REPOSITORY
// ============================================================================
export class SupabaseAttendanceRepository implements AttendanceRepository {
  constructor(private readonly client: SupabaseClient) {}

  observeByClass(
    classId: string,
    date: string,
  ): Observable<AttendanceRecord[]> {
    const sub = new SubjectBehavior<AttendanceRecord[]>([]);
    const fetchAttendance = async () => {
      const { data } = await this.client
        .from("attendance_records")
        .select("*")
        .eq("class_id", classId)
        .eq("record_date", date);

      if (data) sub.set(data.map(mapAttendanceRow));
    };
    fetchAttendance();
    return sub;
  }

  observeByClassRange(
    classId: string,
    from: string,
    to: string,
  ): Observable<AttendanceRecord[]> {
    // FIX (7-day claim): range query used by the class attendance tab —
    // previously the tab claimed "7 derniers jours" but only queried today.
    const sub = new SubjectBehavior<AttendanceRecord[]>([]);
    const fetchRange = async () => {
      const { data } = await this.client
        .from("attendance_records")
        .select("*")
        .eq("class_id", classId)
        .gte("record_date", from)
        .lte("record_date", to)
        .order("record_date", { ascending: false });

      if (data) sub.set(data.map(mapAttendanceRow));
    };
    fetchRange();
    return sub;
  }

  observeByStudent(
    studentId: string,
    fromDate: string,
    toDate: string,
  ): Observable<AttendanceRecord[]> {
    const sub = new SubjectBehavior<AttendanceRecord[]>([]);
    const fetchStudentAttendance = async () => {
      const { data } = await this.client
        .from("attendance_records")
        .select("*")
        .eq("student_id", studentId)
        .gte("record_date", fromDate)
        .lte("record_date", toDate)
        .order("record_date", { ascending: false });

      if (data) sub.set(data.map(mapAttendanceRow));
    };
    fetchStudentAttendance();
    return sub;
  }

  /**
   * T-352 (DASH-402): the school-wide attendance stream over [from, to].
   * The Analytics tab's risk engine previously queried
   * `observeByStudent("", …)` — an empty-UUID filter matching ZERO rows,
   * so `calculateAttendanceRate([])` defaulted every student to 100%
   * (missing data rendered as PERFECT attendance — the WEAK-019 family
   * inversion). Tenant-scoped; ordered newest-first like the sibling
   * methods.
   */
  observeAll(from: string, to: string): Observable<AttendanceRecord[]> {
    const sub = new SubjectBehavior<AttendanceRecord[]>([]);
    const fetchAllAttendance = async () => {
      const { data } = await this.client
        .from("attendance_records")
        .select("*")
        .eq("tenant_id", getTenantId() ?? "")
        .gte("record_date", from)
        .lte("record_date", to)
        .order("record_date", { ascending: false });

      if (data) sub.set(data.map(mapAttendanceRow));
    };
    fetchAllAttendance();
    return sub;
  }

  /**
   * T-040 (ATT-101): the staff review queue — attendance records with a
   * justification in the given state, newest first. Tenant-scoped (RLS
   * enforces read access; the explicit tenant filter keeps the payload
   * minimal).
   */
  observeJustifications(
    status: "submitted" | "accepted" | "rejected" = "submitted",
  ): Observable<AttendanceRecord[]> {
    const sub = new SubjectBehavior<AttendanceRecord[]>([]);
    const fetchJustifications = async () => {
      const { data } = await this.client
        .from("attendance_records")
        .select("*")
        .eq("tenant_id", getTenantId() ?? "")
        .eq("justification_status", status)
        .order("record_date", { ascending: false })
        .limit(200);
      if (data) sub.set(data.map(mapAttendanceRow));
    };
    fetchJustifications();
    return sub;
  }

  /**
   * T-040 (ATT-101): staff decision on a justification — UPDATEs
   * justification_status + reviewer + timestamp atomically, guarded by
   * `justification_status <> 'none'` (a record with NO justification cannot
   * be reviewed). A previous decision may be overturned (correction path).
   */
  async reviewJustification(input: {
    recordId: string;
    decision: "accepted" | "rejected";
    reviewedBy: string;
  }): Promise<Result<AttendanceRecord>> {
    if (!isUuid(input.recordId)) {
      return Err(Errors.validation("Identifiant de pointage invalide."));
    }
    try {
      const { data, error } = await this.client
        .from("attendance_records")
        .update({
          justification_status: input.decision,
          justification_reviewed_by: input.reviewedBy,
          justification_reviewed_at: new Date().toISOString(),
        })
        .eq("id", input.recordId)
        .neq("justification_status", "none")
        .select("*")
        .maybeSingle();
      if (error) throw error;
      if (!data) {
        return Err(
          Errors.notFound(
            "AttendanceRecord (justification 'none' ou introuvable)",
            input.recordId,
          ),
        );
      }
      return Ok(mapAttendanceRow(data));
    } catch (e) {
      return Err(Errors.unknown(e as Error));
    }
  }

  async recordRollCall(input: {
    classId: string;
    date: string;
    session: AttendanceSession;
    statuses: ReadonlyMap<string, AttendanceStatus>;
    arrivalTimes?: ReadonlyMap<string, string>;
    recordedBy: string;
  }): Promise<Result<AttendanceRecord[]>> {
    if (!isUuid(input.classId)) {
      return Err(
        Errors.validation(
          "L'appel nécessite une classe Supabase valide (identifiant non-UUID reçu).",
        ),
      );
    }

    const payload = Array.from(input.statuses.entries())
      .filter(([studentId]) => isUuid(studentId))
      .map(([studentId, status]) => ({
        // T-023 (ATT-100): tenant_id is NOT NULL (migration 0004) and the
        // RLS INSERT policy `attendance_teacher_write` is tenant-scoped —
        // the payload previously omitted it so every roll call failed with
        // a NOT NULL violation and NOTHING ever persisted.
        tenant_id: getTenantId(),
        student_id: studentId,
        class_id: input.classId,
        // T-023 (ATT-100): the legacy `date` column is still NOT NULL
        // (0004; never relaxed by 0029, which added the nullable
        // `record_date` beside it). Both columns are written with the same
        // value so the legacy index and the canonical
        // `uq_attendance_canonical (tenant_id, student_id, record_date,
        // session)` index both stay satisfied.
        date: input.date,
        record_date: input.date,
        session: input.session,
        status,
        // VAULT §09.01 — arrival time for LATE students (migration 0004
        // column `arrival_time`, "required when status='late'").
        arrival_time:
          status === "late"
            ? (input.arrivalTimes?.get(studentId) ?? null)
            : null,
        recorded_by: isUuid(input.recordedBy) ? input.recordedBy : null,
        recorded_at: new Date().toISOString(),
        synced_at: new Date().toISOString(),
      }));

    if (payload.length === 0) return Ok([]);

    const { data, error } = await this.client
      .from("attendance_records")
      // T-023 (ATT-100): the onConflict target MUST match a real unique
      // index. The canonical index (migration 0041) is on (tenant_id,
      // student_id, record_date, session) — the old 3-column target matched
      // neither it nor the legacy 5-column index, so PostgREST rejected the
      // upsert with "there is no unique or exclusion constraint matching".
      .upsert(payload, { onConflict: "tenant_id,student_id,record_date,session" })
      .select();

    if (error) return Err(supabaseErrorToAppError(error));

    // T-314 (event bridge): when a student JUST crossed the 3-unexcused-
    // absence threshold in the current term, fire the DEPLOYED
    // `absence_limit_exceeded` workflows through the canonical
    // workflow-execute EF (real entity context + REAL side effects
    // server-side). Fail-safe: never breaks the roll-call save.
    void this.dispatchAbsenceWorkflows(data);

    return Ok(data.map(mapAttendanceRow));
  }

  /**
   * T-314: threshold re-check + workflow dispatch for the students that
   * just became absent. PRIVATE — called after a successful roll-call
   * upsert; every failure is swallowed (audit-logged server-side).
   */
  private async dispatchAbsenceWorkflows(
    rows: readonly { student_id: string; status: string }[],
  ): Promise<void> {
    try {
      const THRESHOLD = 3;
      const absentStudentIds = rows
        .filter((r) => r.status === "absent" || r.status === "absent_unexcused" || r.status === "absent_excused")
        .map((r) => r.student_id);
      if (absentStudentIds.length === 0) return;
      const now = new Date();
      const window = currentTermWindow(now);
      const windowStart = window.start.toISOString().slice(0, 10);
      const { data: countRows } = await this.client
        .from("attendance_records")
        .select("student_id, status")
        .in("student_id", absentStudentIds)
        .in("status", ["absent_unexcused", "absent"])
        .gte("record_date", windowStart)
        .lte("record_date", now.toISOString().slice(0, 10));
      if (!countRows) return;
      const counts = new Map<string, number>();
      for (const row of countRows as { student_id: string }[]) {
        counts.set(row.student_id, (counts.get(row.student_id) ?? 0) + 1);
      }
      const flagged = [...counts.entries()].filter(([, c]) => c >= THRESHOLD);
      if (flagged.length === 0) return;
      // Resolve each student's parent for the entity-targeted dispatch.
      const { data: studentRows } = await this.client
        .from("students")
        .select("id, parent_id")
        .in("id", flagged.map(([id]) => id));
      const parentByStudent = new Map<string, string>();
      for (const row of (studentRows ?? []) as { id: string; parent_id: string | null }[]) {
        if (row.parent_id) parentByStudent.set(row.id, row.parent_id);
      }
      for (const [studentId, count] of flagged) {
        await dispatchWorkflowTriggerSafe({
          triggerSubtype: "absence_limit_exceeded",
          studentId,
          parentId: parentByStudent.get(studentId) ?? null,
          context: { student: { absence_count: count } },
          actorId: "system",
          actorName: "Système (appel — seuil absences)",
        });
      }
    } catch {
      /* fail-safe by contract — the roll call is already saved */
    }
  }

  /**
   * VAULT §09.04 — absence alert dispatch (parents notified at 3+ absences
   * for the CURRENT TERM).
   *
   * The threshold re-check happens server-side via a count query so no
   * premature alert is ever sent ("the threshold is 3 — not 1, not 2").
   * Because the `dispatch-absence-alerts` Edge Function is not deployed in
   * this project, the parent notification is written to the `notifications`
   * table directly (read by the web portal) and the alert intent is traced
   * via the `write_audit_log` RPC (migration 0014).
   */
  async alertAbsences(studentIds: string[]): Promise<Result<void>> {
    try {
      const THRESHOLD = 3;
      const now = new Date();
      const window = currentTermWindow(now);
      const windowStart = window.start.toISOString().slice(0, 10);
      // Count current-term absences per candidate student (LATE excluded).
      const { data, error } = await this.client
        .from("attendance_records")
        .select("student_id, status")
        .in("student_id", studentIds.filter(isUuid))
        .in("status", ["absent_excused", "absent_unexcused"])
        .gte("record_date", windowStart)
        .lte("record_date", now.toISOString().slice(0, 10));
      if (!error && data) {
        const counts = new Map<string, number>();
        for (const row of data as { student_id: string }[]) {
          counts.set(row.student_id, (counts.get(row.student_id) ?? 0) + 1);
        }
        const flagged = [...counts.entries()]
          .filter(([, c]) => c >= THRESHOLD)
          .map(([studentId, c]) => ({ studentId, count: c }));
        // Parent notifications for flagged students only.
        for (const { studentId, count } of flagged) {
          await this.client.from("notifications").insert({
            tenant_id: getTenantId(),
            title: "Alerte absences",
            body: `Votre enfant a accumulé ${count} absences ce trimestre (${window.label}). Merci de contacter l'administration.`,
            type: "attendance_alert",
            priority: "high",
            source: "system",
            source_label: "Module Présences",
            entity_type: "student",
            entity_id: studentId,
            created_by: "system",
            created_at: new Date().toISOString(),
          });
        }
        await this.client.rpc("write_audit_log", {
          p_tenant_id: getTenantId(),
          p_action: "attendance.alert_absences",
          p_entity_type: "student",
          p_entity_id: flagged.map((f) => f.studentId).join(",") || null,
          p_actor_id: null,
          p_actor_name: "Système",
          p_note:
            flagged.length > 0
              ? `Seuil ${THRESHOLD}+ absences (${window.label}) atteint pour ${flagged.length} élève(s) — alertes parents envoyées.`
              : `Évaluation du seuil d'absences (${window.label}) — aucun élève n'a atteint ${THRESHOLD} absences.`,
        });
        return Ok(undefined);
      }
      // Count query failed — fall back to the audited-intent-only path.
      await this.client.rpc("write_audit_log", {
        p_tenant_id: getTenantId(),
        p_action: "attendance.alert_absences",
        p_entity_type: "student",
        p_entity_id: null,
        p_actor_id: null,
        p_actor_name: "Système",
        p_note: `Évaluation du seuil d'absences (${window.label}) — ${studentIds.length} élève(s) évalué(s).`,
      });
    } catch {
      // The audit entry is best-effort — never fail the alert call on it.
    }
    return Ok(undefined);
  }
}

// ============================================================================
// 7. HOMEWORK REPOSITORY
// ============================================================================
export class SupabaseHomeworkRepository implements HomeworkRepository {
  constructor(private readonly client: SupabaseClient) {}

  observeForClass(classId: string): Observable<Homework[]> {
    const sub = new SubjectBehavior<Homework[]>([]);
    // T-373 (ACAD-501): the "no class selected yet" state passes ""
    // (homework-history-tab.tsx `classId || ""`). A literal
    // `.eq("class_id", "")` against the UUID column is a guaranteed HTTP 400
    // (22P02 — live console evidence 2026-09-14). Stable empty stream instead.
    if (!classId) return sub;
    const fetchHomework = async () => {
      const { data } = await this.client
        .from("homework")
        .select("*")
        .eq("class_id", classId)
        .order("created_at", { ascending: false });

      if (data) sub.set(data.map(mapHomeworkRow));
    };
    fetchHomework();
    return sub;
  }

  observeByTeacher(teacherId: string): Observable<Homework[]> {
    const sub = new SubjectBehavior<Homework[]>([]);
    // T-373 (ACAD-501): teacher_id is a UUID column — the same empty-id
    // guard as observeForClass (no server round-trip, stable empty stream).
    if (!teacherId) return sub;
    const fetchTeacherHomework = async () => {
      const { data } = await this.client
        .from("homework")
        .select("*")
        .eq("teacher_id", teacherId)
        .order("created_at", { ascending: false });

      if (data) sub.set(data.map(mapHomeworkRow));
    };
    fetchTeacherHomework();
    return sub;
  }

  async push(input: {
    classId: string;
    subjectId: string;
    teacherId: string;
    teacherName: string;
    title: string;
    description: string;
    dueDate: string;
    attachments: readonly string[];
  }): Promise<Result<Homework>> {
    if (!isUuid(input.classId) || !isUuid(input.subjectId) || !isUuid(input.teacherId)) {
      return Err(
        Errors.validation(
          "La publication de devoirs nécessite des identifiants Supabase valides (classe / matière / enseignant).",
        ),
      );
    }

    // Resolve the subject display name and the current academic year code
    // (previously both were hardcoded — "Matière" / "2025-2026").
    const [subjectRes, yearRes] = await Promise.all([
      this.client
        .from("subjects")
        .select("name_fr")
        .eq("id", input.subjectId)
        .maybeSingle(),
      this.client
        .from("academic_years")
        .select("code, label")
        .eq("is_current", true)
        .maybeSingle(),
    ]);
    const subjectName =
      (subjectRes.data as { name_fr?: string } | null)?.name_fr ?? "Matière";
    const yearRow = yearRes.data as { code?: string | null; label?: string | null } | null;
    const academicYear = yearRow?.code ?? yearRow?.label ?? "2025-2026";

    const { data, error } = await this.client
      .from("homework")
      .insert({
        // T-023 (HOMEWORK-100): tenant_id is NOT NULL on the canonical
        // `homework` table (migration 0029) and the RLS write policy
        // `homework_canonical_write` is tenant-scoped — the payload
        // previously omitted it, so every desktop homework push failed
        // with a NOT NULL violation and zero rows were ever persisted.
        tenant_id: getTenantId(),
        class_id: input.classId,
        subject_id: input.subjectId,
        subject_name: subjectName,
        teacher_id: input.teacherId,
        teacher_name: input.teacherName,
        title: input.title,
        description: input.description,
        due_date: input.dueDate,
        attachments: input.attachments,
        academic_year: academicYear,
        pushed_at: new Date().toISOString(),
      })
      .select()
      .single();

    if (error) return Err(supabaseErrorToAppError(error));

    // T-023 (HOMEWORK-100): the dead `push-homework-notification` Edge
    // Function invocation was REMOVED. The EF has never existed in
    // supabase/functions/, so the call failed on every push and the
    // `.catch(() => undefined)` swallowed it — a fake side-effect. The
    // homework row itself is the source of truth; the parent-notification
    // fan-out now lives server-side — migration 0078 (T-193/MSG-201, 30th
    // session) triggers one notification per distinct parent of the class
    // roster on every homework INSERT, so the modal's "notifié aux parents"
    // promise is delivered for ALL writers (desktop, Android, future).

    return Ok(mapHomeworkRow(data));
  }
}

// ============================================================================
// 8. PROMOTION REPOSITORY (Decoupled Batch Execution)
// ============================================================================
/**
 * Derive the academic year label that just completed, given the target year
 * of the promotion (e.g. "2026-2027" → "2025-2026"). Mirrors the mock
 * implementation so the history entry records the COMPLETED year.
 */
function derivePreviousAcademicYear(targetAcademicYear: string): string {
  const m = /^(\d{4})-(\d{4})$/.exec(targetAcademicYear.trim());
  if (m) {
    const start = Number(m[1]) - 1;
    return `${start}-${start + 1}`;
  }
  return targetAcademicYear;
}

export class SupabasePromotionRepository implements PromotionRepository {
  constructor(private readonly client: SupabaseClient) {}

  /**
   * Batch promotion — ATOMIC via the `execute_batch_promotion` RPC
   * (migration 0059, T-041 / ACAD-100 / BUSINESS-004):
   *
   *   1. The DECISION COMPUTATION stays here (the canonical TS engine
   *      `src/domain/calc/academics/promotion.ts` is the reference — GPA,
   *      ranking, suggestion, override); the FINAL decisions are shipped to
   *      the RPC as one JSON array.
   *   2. Server-side (single transaction): append-only history upsert into
   *      `student_academic_histories`, `grade_level_code` advance + class
   *      clear for 'promoted', `enrollment_status='graduated'` for
   *      'graduated', ONE `student.promote` audit entry. Any invalid or
   *      foreign-tenant decision RAISES and rolls back the WHOLE batch —
   *      the previous direct-table loop could advance students 1..N then
   *      fail on N+1, leaving partial state.
   *
   * HISTORY: the original implementation called an `execute_batch_promotion`
   * RPC that did NOT exist in any migration and would have failed with
   * PGRST202 — so it was rewritten to direct table operations (the comment
   * below said so). Migration 0059 now provides the real RPC; the
   * client-side fallback loop is retired.
   */
  async executeBatchPromotion(input: {
    candidates: readonly {
      candidate: PromotionCandidate;
      finalDecision: import("../../../domain/model/academic").PromotionDecision;
    }[];
    targetAcademicYear: string;
    performedBy: string;
    performedByName: string;
  }): Promise<Result<{ promotedStudents: Student[]; updatedCount: number }>> {
    const completedYear = derivePreviousAcademicYear(input.targetAcademicYear);

    // T-403: the payload construction moved to the canonical domain builder
    // (ONE wire format — the cycle workflow's fn_confirm_promotion_cycle_class
    // consumes the exact same array). Mock-era ids are filtered inside (they
    // cannot execute server-side; the RPC would reject the whole batch).
    const decisions = buildPromotionDecisionPayload(input.candidates, completedYear);
    const updatedIds = input.candidates
      .filter(
        (item) =>
          isUuid(item.candidate.student.id) &&
          (item.finalDecision === "promoted" || item.finalDecision === "graduated"),
      )
      .map((item) => item.candidate.student.id);

    if (decisions.length === 0) {
      return Ok({ promotedStudents: [], updatedCount: 0 });
    }

    // ONE RPC call — the whole batch commits or rolls back together.
    const { error: rpcErr } = await this.client.rpc("execute_batch_promotion", {
      p_decisions: decisions,
      p_actor_profile_id: isUuid(input.performedBy) ? input.performedBy : null,
      p_actor_name: input.performedByName || null,
      p_tenant_id: getTenantId(),
    });
    if (rpcErr) return Err(supabaseErrorToAppError(rpcErr));

    // Re-read the updated students for the return payload.
    const { data: rows, error: fetchErr } = await this.client
      .from("students")
      .select("*")
      .in("id", updatedIds);
    if (fetchErr) return Err(supabaseErrorToAppError(fetchErr));

    return Ok({
      promotedStudents: (rows ?? []).map(mapStudentRow),
      updatedCount: updatedIds.length,
    });
  }
}

// ============================================================================
// 7. CLASS PLACEMENT REPOSITORY (T-370 / ACAD-500 — the 9ddde68 workflow)
//
// ONE atomic RPC call — `fn_finalize_class_placements` (migration 0096):
// creates the drafted sections, maps client draft ids to the created UUIDs,
// applies the existing-class patches, assigns the students (grade-integrity
// checked server-side), and writes ONE `class.placement_finalize` audit
// entry. The whole batch commits or rolls back together. This replaces the
// 08f7f13 non-atomic classes+students loop (the ACAD-500 defect family:
// draft-ID pointer corruption, silent Result swallowing, dropped patches).
// ============================================================================
export class SupabaseClassPlacementRepository implements ClassPlacementRepository {
  constructor(
    private readonly client: SupabaseClient,
    /** Refreshed after a successful batch (the created sections appear). */
    private readonly classes: SupabaseClassRepository,
    /** Refreshed after a successful batch (the moved students appear). */
    private readonly students: SupabaseStudentRepository,
  ) {}

  async finalizePlacements(
    input: FinalizeClassPlacementsInput,
  ): Promise<Result<FinalizeClassPlacementsResult>> {
    // ── Client-side pre-validation (honest failures with named entities —
    // the server's uuid-cast errors are cryptic). Mock-era ids cannot be
    // finalized server-side; naming the student is honest, silently
    // skipping it is the exact defect this task repairs.
    for (const assignment of input.studentAssignments) {
      if (!isUuid(assignment.studentId)) {
        return Err(Errors.validation(
          `classPlacement.finalizePlacements requires student UUIDs (got "${assignment.studentId}")`,
          "Données d'élève incohérentes (identifiant local) — resynchronisez ou vérifiez la fiche de l'élève.",
        ));
      }
    }
    for (const patch of input.classesToUpdate) {
      if (!isUuid(patch.id)) {
        return Err(Errors.validation(
          `classPlacement.finalizePlacements: existing-class patch id must be a UUID (got "${patch.id}")`,
          "Classe ciblée introuvable — resynchronisez les classes et réessayez.",
        ));
      }
    }

    const { data, error } = await this.client.rpc("fn_finalize_class_placements", {
      p_target_year_id: input.targetAcademicYearId,
      p_target_year_code: input.targetAcademicYearCode,
      p_new_classes: input.newClasses.map((d) => ({
        clientDraftId: d.clientDraftId,
        code: d.code,
        name: d.name,
        gradeCode: d.gradeCode,
        section: d.section,
        // T-401 (0107): the drafted section's classification (catalog-validated
        // server-side; NULL = untagged).
        filiereCode: normalizeTrackCode(d.filiereCode),
        specialiteCode: normalizeTrackCode(d.specialiteCode),
        room: d.room,
        capacity: d.capacity,
        homeroomTeacherId: isUuid(d.homeroomTeacherId) ? d.homeroomTeacherId : null,
        homeroomTeacherName: d.homeroomTeacherName,
      })),
      p_updated_classes: input.classesToUpdate.map((p) => ({
        id: p.id,
        ...(p.room !== undefined ? { room: p.room } : {}),
        ...(p.capacity !== undefined ? { capacity: p.capacity } : {}),
        ...(p.homeroomTeacherId !== undefined
          ? { homeroomTeacherId: isUuid(p.homeroomTeacherId) ? p.homeroomTeacherId : null }
          : {}),
        ...(p.homeroomTeacherName !== undefined
          ? { homeroomTeacherName: p.homeroomTeacherName }
          : {}),
      })),
      p_student_assignments: input.studentAssignments.map((a) => ({
        studentId: a.studentId,
        targetClassId: a.targetClassId,
        gradeLevel: a.gradeLevel,
        level: a.level,
        gradeYear: a.gradeYear,
      })),
      p_actor_profile_id: isUuid(input.performedBy) ? input.performedBy : null,
      p_actor_name: input.performedByName || null,
      p_tenant_id: getTenantId(),
    });
    if (error) return Err(supabaseErrorToAppError(error));

    const row = (data ?? {}) as {
      ok?: boolean;
      targetYearId?: string;
      createdClassesCount?: number;
      updatedClassesCount?: number;
      assignedStudentsCount?: number;
    };
    if (!row.ok) {
      return Err(Errors.server(
        "fn_finalize_class_placements returned no confirmation payload",
      ));
    }

    // The batch committed — refresh BOTH affected caches so the studio's
    // parent views reflect the new sections and moved students immediately.
    await this.classes.refresh();
    await this.students.refresh();

    return Ok({
      targetYearId: row.targetYearId ?? "",
      createdClassesCount: row.createdClassesCount ?? input.newClasses.length,
      updatedClassesCount: row.updatedClassesCount ?? input.classesToUpdate.length,
      assignedStudentsCount:
        row.assignedStudentsCount ?? input.studentAssignments.length,
    });
  }
}

// ============================================================================
// DB ROW MAPPERS (Snake_case DB -> CamelCase Domain)
// ============================================================================
function mapAcademicYearRow(row: Record<string, any>): AcademicYear {
  return {
    id: row.id,
    tenantId: row.tenant_id,
    // The `code` column (migration 0029) is NULL on the live seeded year —
    // fall back to the label ("2026-2027") so the domain contract
    // (`code: string`) and the UI never see null.
    code: row.code ?? row.label,
    label: row.label,
    startDate: row.start_date,
    endDate: row.end_date,
    termStructure: row.term_structure,
    isCurrent: row.is_current,
    isArchived: row.is_archived,
  };
}

function mapAcademicLevelRow(row: Record<string, any>): AcademicLevelModel {
  return {
    id: row.id,
    tenantId: row.tenant_id,
    cycle: row.cycle,
    gradeCode: row.grade_code,
    labelFr: row.label_fr,
    labelAr: row.label_ar,
    yearNumber: row.year_number,
    sortOrder: row.sort_order,
    isActive: row.is_active,
  };
}

function mapClassRow(
  row: Record<string, any>,
  enrolledCount?: number,
): AcademicClass {
  const cycleMap: Record<string, AcademicLevel> = {
    prescolaire_1: "primaire",
    prescolaire_2: "primaire",
    "1ap": "primaire",
    "2ap": "primaire",
    "3ap": "primaire",
    "4ap": "primaire",
    "5ap": "primaire",
    "1am": "cem",
    "2am": "cem",
    "3am": "cem",
    "4am": "cem",
    "1ere_annee": "lycee",
    "2eme_annee": "lycee",
    "3eme_annee": "lycee",
  };

  return {
    id: row.id,
    tenantId: row.tenant_id,
    academicYearId: row.academic_year_id,
    academicLevelId: row.academic_level_id,
    code: row.code,
    name: row.name,
    gradeCode: row.grade_code as GradeLevel,
    // T-401 (0107): the class's academic classification (NULL = untagged).
    filiereCode: row.filiere_code ?? null,
    specialiteCode: row.specialite_code ?? null,
    level: cycleMap[row.grade_code] ?? "primaire",
    gradeYear: row.grade_code?.includes("ap") ? parseInt(row.grade_code) : 1,
    section: row.section,
    room: row.room,
    capacity: row.capacity ?? null,
    enrolledCount: enrolledCount ?? row.enrolled_count ?? 0,
    homeroomTeacherId: row.homeroom_teacher_id,
    homeroomTeacherName: row.homeroom_teacher_name,
    notes: row.notes ?? null,
    // The joined year's `code` is NULL on the live seeded year (0029 column) —
    // fall back to its label before the static mock default.
    academicYear:
      row.academic_years?.code ??
      row.academic_years?.label ??
      "2025-2026",
    isActive: row.is_active,
  };
}

/** T-345 (MATIERE-500/ADR-018): the context-specific subject configuration. */
function mapSubjectConfigurationRow(row: Record<string, any>): SubjectConfiguration {
  const recipe = row.grading_recipe ?? {};
  return {
    id: row.id,
    tenantId: row.tenant_id,
    subjectId: row.subject_id,
    academicYearId: row.academic_year_id,
    academicLevelId: row.academic_level_id,
    direction: row.direction ?? "general",
    coefficient: Number(row.coefficient),
    subjectCode: row.subject_code ?? null,
    passingGrade: Number(row.passing_grade),
    isExtracurricular: Boolean(row.is_extracurricular),
    gradingRecipe: {
      devoir1: Number(recipe.devoir1 ?? 1),
      devoir2: Number(recipe.devoir2 ?? 1),
      examen: Number(recipe.examen ?? 2),
      cc: Number(recipe.cc ?? 0),
    },
    weeklyHours: row.weekly_hours != null ? Number(row.weekly_hours) : null,
    isActive: row.is_active,
  };
}

function mapSubjectRow(row: Record<string, any>): Subject {
  const cycleToLevel: Record<string, AcademicLevel> = {
    prescolaire: "primaire",
    primaire: "primaire",
    cem: "cem",
    lycee: "lycee",
  };

  return {
    id: row.id,
    tenantId: row.tenant_id,
    code: row.code,
    name: row.name_fr,
    nameAr: row.name_ar,
    cycle: row.cycle,
    level: cycleToLevel[row.cycle] ?? "primaire",
    coefficient: Number(row.default_coefficient),
    passingGrade: Number(row.passing_grade),
    isExtracurricular: row.is_extracurricular,
    isActive: row.is_active,
    teacherId: row.teacher_id ?? null,
    teacherName: row.teacher_name ?? null,
    academicYearId: row.academic_year_id ?? "ay-2025-2026",
    academicYearCode: row.academic_year_code ?? "2025-2026",
  };
}

function mapClassSubjectRow(row: Record<string, any>): ClassSubject {
  return {
    id: row.id,
    classId: row.class_id,
    subjectId: row.subject_id,
    teacherId: row.teacher_id,
    teacherName: row.teacher_name,
    weeklyHours: Number(row.weekly_hours),
    coefficient: Number(row.coefficient),
    // T-404 (0109 §6): the two generator curriculum fields.
    consecutivePeriods:
      row.consecutive_periods != null ? Number(row.consecutive_periods) : 1,
    requiredRoomType: row.required_room_type ?? null,
  };
}

/**
 * Term wire mappers — the DB column `assessments.term` is INTEGER (1|2|3,
 * migration 0004) while the domain model uses "T1"|"T2"|"T3".
 */
function termToWire(term: string): number {
  const n = /^T?(\d+)$/.exec(String(term ?? ""));
  const v = n ? Number(n[1]) : NaN;
  if (v === 1 || v === 2 || v === 3) return v;
  return 1;
}
function termFromWire(term: number | string): AcademicTerm {
  const n = /^T?(\d+)$/.exec(String(term ?? ""));
  const v = n ? Number(n[1]) : 1;
  return v === 2 ? "T2" : v === 3 ? "T3" : "T1";
}

function mapAssessmentRow(row: Record<string, any>): Assessment {
  return {
    id: row.id,
    studentId: row.student_id,
    classId: row.class_id,
    subjectId: row.subject_id,
    // WIRE FIX (A-0041): the DB stores INTEGER 1|2|3 — map back to the
    // canonical domain enum "T1"|"T2"|"T3".
    term: termFromWire(row.term),
    academicYear: row.academic_year,
    devoir1: row.devoir1 != null ? Number(row.devoir1) : null,
    devoir2: row.devoir2 != null ? Number(row.devoir2) : null,
    examen: row.examen != null ? Number(row.examen) : null,
    // T-345 (ADR-018): the contrôle-continu mark + the snapshots. Legacy
    // rows (pre-0094) read as cc=null / weight 0 — bit-identical behavior.
    cc: row.cc != null ? Number(row.cc) : null,
    subjectAverage:
      row.subject_average != null ? Number(row.subject_average) : null,
    coefficient: Number(row.coefficient),
    coefficientDevoir1: Number(row.coefficient_devoir1 ?? 1),
    coefficientDevoir2: Number(row.coefficient_devoir2 ?? 1),
    coefficientExamen: Number(row.coefficient_examen ?? 2),
    coefficientCc: Number(row.coefficient_cc ?? 0),
    enteredBy: row.entered_by,
    enteredAt: row.entered_at,
  };
}

function mapAttendanceRow(row: Record<string, any>): AttendanceRecord {
  return {
    id: row.id,
    studentId: row.student_id,
    classId: row.class_id,
    date: row.record_date,
    session: row.session,
    status: row.status,
    // VAULT §09.01 — arrival time read-back for LATE records.
    arrivalTime: row.arrival_time ?? null,
    note: row.note,
    recordedBy: row.recorded_by,
    recordedAt: row.recorded_at,
    syncedAt: row.synced_at,
    // T-040 (ATT-101): the justification workflow columns (migration 0043).
    justificationStatus: row.justification_status ?? "none",
    justificationNote: row.justification_note ?? null,
    justificationPath: row.justification_path ?? null,
    justificationDriveLink: row.justification_drive_link ?? null,
    justificationReviewedBy: row.justification_reviewed_by ?? null,
    justificationReviewedAt: row.justification_reviewed_at ?? null,
  };
}

function mapHomeworkRow(row: Record<string, any>): Homework {
  return {
    id: row.id,
    classId: row.class_id,
    subjectId: row.subject_id,
    subjectName: row.subject_name,
    teacherId: row.teacher_id,
    teacherName: row.teacher_name,
    title: row.title,
    description: row.description,
    dueDate: row.due_date,
    attachments: row.attachments ?? [],
    academicYear: row.academic_year,
    createdAt: row.created_at,
    pushedAt: row.pushed_at,
    acknowledgedCount: row.acknowledged_count ?? 0,
  };
}

function mapStudentRow(row: Record<string, any>): Student {
  // students table has no level / grade_year / grade_level columns — the
  // canonical source is `grade_level_code` (migration 0028), from which
  // level + gradeYear are derived via the domain helpers (same routine as
  // the shared SupabaseStudentRepository).
  const gradeLevel = (row.grade_level_code ?? "1ap") as GradeLevel;
  return {
    id: row.id,
    tenantId: row.tenant_id,
    code: row.student_code,
    parentId: row.parent_id,
    firstName: row.first_name,
    lastName: row.last_name,
    displayName: row.display_name ?? null,
    gender: row.gender ?? "unspecified",
    birthDate: row.date_of_birth,
    enrollmentDate: row.enrollment_date,
    level: academicLevelFromGradeLevel(gradeLevel),
    gradeYear: gradeYearFromGradeLevel(gradeLevel),
    gradeLevel,
    classId: row.class_id,
    photoUrl: null,
    medicalNotes: row.medical_notes,
    transportTier: null,
    status: (row.enrollment_status === "withdrawn"
      ? "withdrawn"
      : row.enrollment_status === "graduated"
        ? "graduated"
        : row.is_active
          ? "active"
          : "suspended") as Student["status"],
    paymentPlan: (row.payment_plan as Student["paymentPlan"]) ?? "tranches",
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

// ============================================================================
// SupabasePromotionCycleRepository — T-403 (migration 0108)
// ============================================================================

interface CycleListRow {
  id: string;
  source_academic_year: string;
  target_academic_year: string;
  status: PromotionCycleStatus;
  notes: string | null;
  created_by_name: string | null;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
  completed_by_name: string | null;
  classes_total: number;
  classes_processed: number;
  students_awaiting: number;
  promoted_count: number;
  repeating_count: number;
  deferred_count: number;
}

interface CycleClassRow {
  id: string;
  cycle_id: string;
  class_id: string;
  class_code: string;
  class_name: string;
  grade_code: string;
  status: PromotionCycleClassStatus;
  students_awaiting: number;
  promoted_count: number;
  repeating_count: number;
  deferred_count: number;
  exception_note: string | null;
  processed_by_name: string | null;
  processed_at: string | null;
}

function mapCycleRow(r: CycleListRow): PromotionCycle {
  return {
    id: r.id,
    sourceAcademicYear: r.source_academic_year,
    targetAcademicYear: r.target_academic_year,
    status: r.status,
    notes: r.notes,
    createdByName: r.created_by_name,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
    completedAt: r.completed_at,
    completedByName: r.completed_by_name,
    classesTotal: r.classes_total,
    classesProcessed: r.classes_processed,
    studentsAwaiting: r.students_awaiting,
    promotedCount: r.promoted_count,
    repeatingCount: r.repeating_count,
    deferredCount: r.deferred_count,
  };
}

function mapCycleClassRow(r: CycleClassRow): PromotionCycleClass {
  return {
    id: r.id,
    cycleId: r.cycle_id,
    classId: r.class_id,
    classCode: r.class_code,
    className: r.class_name,
    gradeCode: r.grade_code,
    status: r.status,
    studentsAwaiting: r.students_awaiting,
    promotedCount: r.promoted_count,
    repeatingCount: r.repeating_count,
    deferredCount: r.deferred_count,
    exceptionNote: r.exception_note,
    processedByName: r.processed_by_name,
    processedAt: r.processed_at,
  };
}

export class SupabasePromotionCycleRepository implements PromotionCycleRepository {
  constructor(private readonly client: SupabaseClient) {}

  async listCycles(): Promise<Result<readonly PromotionCycle[]>> {
    try {
      const { data, error } = await this.client.rpc("fn_get_promotion_cycles", {
        p_tenant_id: getTenantId(),
      });
      if (error) return Err(supabaseErrorToAppError(error));
      const rows = (data ?? []) as unknown as CycleListRow[];
      return Ok(rows.map(mapCycleRow));
    } catch (e) {
      return Err(Errors.unknown(e as Error));
    }
  }

  async getCycleClasses(cycleId: string): Promise<Result<readonly PromotionCycleClass[]>> {
    if (!isUuid(cycleId)) return Err(Errors.validation("cycleId must be a UUID"));
    try {
      const { data, error } = await this.client.rpc("fn_get_promotion_cycle_classes", {
        p_cycle_id: cycleId,
        p_tenant_id: getTenantId(),
      });
      if (error) return Err(supabaseErrorToAppError(error));
      const rows = (data ?? []) as unknown as CycleClassRow[];
      return Ok(rows.map(mapCycleClassRow));
    } catch (e) {
      return Err(Errors.unknown(e as Error));
    }
  }

  async openOrCreateCycle(input: CreatePromotionCycleInput): Promise<Result<PromotionCycle>> {
    // The 0108 RPC refuses a second ACTIVE cycle for a source year — the
    // contextual entry points converge here (open the existing one when it
    // exists, create it otherwise).
    const existing = await this.listCycles();
    if (existing.ok) {
      const found = existing.value.find(
        (c) =>
          c.sourceAcademicYear === input.sourceAcademicYear && c.status !== "cancelled",
      );
      if (found) return Ok(found);
    }
    try {
      const { data, error } = await this.client.rpc("fn_create_promotion_cycle", {
        p_source_academic_year: input.sourceAcademicYear,
        p_target_academic_year: input.targetAcademicYear ?? null,
        p_actor_profile_id: isUuid(input.performedBy) ? input.performedBy : null,
        p_actor_name: input.performedByName || null,
        p_tenant_id: getTenantId(),
      });
      if (error) return Err(supabaseErrorToAppError(error));
      const created = (data ?? {}) as { cycle_id?: string };
      if (!created.cycle_id) return Err(Errors.server("fn_create_promotion_cycle returned no cycle id"));
      const list = await this.listCycles();
      if (!list.ok) return Err(list.error);
      const cycle = list.value.find((c) => c.id === created.cycle_id);
      if (!cycle) return Err(Errors.server("created promotion cycle not readable"));
      return Ok(cycle);
    } catch (e) {
      return Err(Errors.unknown(e as Error));
    }
  }

  async confirmClass(input: ConfirmPromotionCycleClassInput): Promise<Result<PromotionClassConfirmResult>> {
    if (!isUuid(input.cycleId) || !isUuid(input.classId)) {
      return Err(Errors.validation("cycleId and classId must be UUIDs"));
    }
    try {
      const { data, error } = await this.client.rpc("fn_confirm_promotion_cycle_class", {
        p_cycle_id: input.cycleId,
        p_class_id: input.classId,
        p_decisions: input.decisions,
        p_ack_incomplete_notes: input.acknowledgeIncompleteNotes ?? false,
        p_actor_profile_id: isUuid(input.performedBy) ? input.performedBy : null,
        p_actor_name: input.performedByName || null,
        p_tenant_id: getTenantId(),
      });
      if (error) {
        // The two-phase incomplete-notes ack: the server raises the
        // [NOTES_INCOMPLETES] marker — surface it verbatim so the UI can
        // offer the explicit confirmation.
        return Err(supabaseErrorToAppError(error));
      }
      const row = (data ?? {}) as Record<string, unknown>;
      return Ok({
        cycleId: String(row.cycle_id ?? input.cycleId),
        classId: String(row.class_id ?? input.classId),
        className: String(row.class_name ?? ""),
        promoted: Number(row.promoted ?? 0),
        repeated: Number(row.repeated ?? 0),
        deferred: Number(row.deferred ?? 0),
        incompleteNotesCount: Number(row.incomplete_notes_count ?? 0),
        incompleteNotesAcked: Boolean(row.incomplete_notes_acked),
      });
    } catch (e) {
      return Err(Errors.unknown(e as Error));
    }
  }

  async reopenClass(
    cycleId: string,
    classId: string,
    reason: string | null,
    performedBy: string,
    performedByName: string,
  ): Promise<Result<void>> {
    try {
      const { error } = await this.client.rpc("fn_reopen_promotion_cycle_class", {
        p_cycle_id: cycleId,
        p_class_id: classId,
        p_reason: reason,
        p_actor_profile_id: isUuid(performedBy) ? performedBy : null,
        p_actor_name: performedByName || null,
        p_tenant_id: getTenantId(),
      });
      if (error) return Err(supabaseErrorToAppError(error));
      return Ok(undefined);
    } catch (e) {
      return Err(Errors.unknown(e as Error));
    }
  }

  async completeCycle(cycleId: string, performedBy: string, performedByName: string): Promise<Result<void>> {
    try {
      const { error } = await this.client.rpc("fn_complete_promotion_cycle", {
        p_cycle_id: cycleId,
        p_actor_profile_id: isUuid(performedBy) ? performedBy : null,
        p_actor_name: performedByName || null,
        p_tenant_id: getTenantId(),
      });
      if (error) return Err(supabaseErrorToAppError(error));
      return Ok(undefined);
    } catch (e) {
      return Err(Errors.unknown(e as Error));
    }
  }

  async cancelCycle(cycleId: string, reason: string | null, performedBy: string, performedByName: string): Promise<Result<void>> {
    try {
      const { error } = await this.client.rpc("fn_cancel_promotion_cycle", {
        p_cycle_id: cycleId,
        p_reason: reason,
        p_actor_profile_id: isUuid(performedBy) ? performedBy : null,
        p_actor_name: performedByName || null,
        p_tenant_id: getTenantId(),
      });
      if (error) return Err(supabaseErrorToAppError(error));
      return Ok(undefined);
    } catch (e) {
      return Err(Errors.unknown(e as Error));
    }
  }
}
