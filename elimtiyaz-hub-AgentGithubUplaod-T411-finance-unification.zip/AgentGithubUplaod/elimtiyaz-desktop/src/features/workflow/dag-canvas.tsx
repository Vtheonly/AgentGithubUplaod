/**
 * DagCanvas — SVG-based workflow DAG editor (plan §10.03-04).
 *
 * Real-time drag & drop with window-level pointer tracking,
 * topological auto-layout, edge drawing, and live synchronization.
 */
import {
  useCallback,
  useMemo,
  useRef,
  useState,
  useEffect,
  type MouseEvent as ReactMouseEvent,
  type WheelEvent as ReactWheelEvent,
} from "react";
import {
  Webhook,
  Filter,
  Send,
  Clock,
  GitBranch,
  Save,
  Rocket,
  Trash2,
  AlertCircle,
  Plus,
  ZoomIn,
  ZoomOut,
  Maximize,
  Wand2,
  Play,
  XCircle,
  Settings2,
  Map as MapIcon,
  Cloud,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { cn } from "../../shared/ui/cn";
import { Button } from "../../shared/ui/button";
import { Card, CardContent } from "../../shared/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "../../shared/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../shared/ui/select";
import { ConfirmModal } from "../../shared/ui/unified-modal";
import { detectCycle } from "../../domain/kahn";
import { dryRunWorkflow } from "../../domain/calc/workflow/dry-run";
import {
  defaultConditionContext,
  type ConditionContext,
} from "../../domain/calc/workflow/condition-evaluator";
import { autoLayout } from "../../domain/calc/workflow/auto-layout";
import type { DryRunResult } from "../../domain/calc/workflow/dry-run";
import {
  NODE_SUBTYPE_TO_TYPE,
  WORKFLOW_NODE_TYPE_LABELS_FR,
  WORKFLOW_NODE_SUBTYPE_LABELS_FR,
  type Workflow,
  type WorkflowNode,
  type WorkflowNodeSubtype,
  type WorkflowEdge,
  type WorkflowNodeType,
} from "../../domain/model/workflow";
import {
  TestStudioDrawer,
  type TestStudioEntity,
} from "./test-studio-drawer";

const NODE_W = 160;
const NODE_H = 60;
const GRID = 20;
const MIN_ZOOM = 0.25;
const MAX_ZOOM = 2.5;

/** T-314: output-port Y offsets for condition nodes (VRAI top / FAUX bottom). */
const TRUE_PORT_Y = 15;
const FALSE_PORT_Y = 45;

const ICON_FOR_TYPE: Record<WorkflowNodeType, LucideIcon> = {
  trigger: Webhook,
  condition: Filter,
  action: Send,
  delay: Clock,
  transform: GitBranch,
};

const COLOR_FOR_TYPE: Record<
  WorkflowNodeType,
  { border: string; bg: string; text: string }
> = {
  trigger: {
    border: "stroke-primary",
    bg: "fill-primary/10",
    text: "text-primary",
  },
  condition: {
    border: "stroke-status-warning",
    bg: "fill-status-warning/10",
    text: "text-status-warning",
  },
  action: {
    border: "stroke-status-success",
    bg: "fill-status-success/10",
    text: "text-status-success",
  },
  delay: {
    border: "stroke-status-info",
    bg: "fill-status-info/10",
    text: "text-status-info",
  },
  transform: {
    border: "stroke-status-neutral",
    bg: "fill-status-neutral/10",
    text: "text-status-neutral",
  },
};

export interface DagCanvasProps {
  workflow: Workflow;
  onChange: (nodes: WorkflowNode[], edges: WorkflowEdge[]) => void;
  onSave: (nodes: WorkflowNode[], edges: WorkflowEdge[]) => Promise<void>;
  onDeploy: () => Promise<void>;
  canEdit: boolean;
  onInspectNode: (node: WorkflowNode) => void;
  onExecute?: () => Promise<void>;
  onServerDryRun?: (
    parentId: string | null,
  ) => Promise<ServerDryRunOutcome | null>;
  serverDryRunEntities?: readonly { id: string; label: string }[];
  /** T-314 (Test Studio): real entities (parents) selectable in the drawer. */
  testEntities?: readonly TestStudioEntity[];
  /** T-314: REAL execution for a specific parent (side effects applied). */
  onTestExecute?: (parentId: string, context: ConditionContext) => Promise<void>;
  /** Whether the real-execution button is enabled (deployed + permitted). */
  canTestExecute?: boolean;
}

export interface ServerDryRunOutcome {
  status: "succeeded" | "failed" | "timeout";
  nodeOutcomes: readonly {
    nodeId: string;
    status: "succeeded" | "failed" | "skipped";
    output?: string;
    error?: string;
  }[];
  takenEdgeKeys: readonly string[];
  warnings: readonly string[];
  error?: string;
}

interface DragState {
  kind: "node" | "pan";
  nodeId: string;
  offsetX: number;
  offsetY: number;
  startX: number;
  startY: number;
}

interface EdgeDraft {
  fromId: string;
  /** T-314: the output port the draft leaves from ("out" for non-conditions). */
  fromHandle: "out" | "true" | "false";
  cursorX: number;
  cursorY: number;
}

interface ViewState {
  zoom: number;
  panX: number;
  panY: number;
}

function clientToSvg(
  svg: SVGSVGElement | null,
  view: ViewState,
  clientX: number,
  clientY: number,
): { x: number; y: number } {
  if (!svg) return { x: 0, y: 0 };
  const ctm = svg.getScreenCTM();
  if (ctm) {
    const pt = svg.createSVGPoint();
    pt.x = clientX;
    pt.y = clientY;
    const svgP = pt.matrixTransform(ctm.inverse());
    return {
      x: (svgP.x - view.panX) / view.zoom,
      y: (svgP.y - view.panY) / view.zoom,
    };
  }
  const rect = svg.getBoundingClientRect();
  const baseX = (clientX - rect.left) * (1000 / rect.width);
  const baseY = (clientY - rect.top) * (600 / rect.height);
  return {
    x: (baseX - view.panX) / view.zoom,
    y: (baseY - view.panY) / view.zoom,
  };
}

function snap(value: number): number {
  return Math.round(value / GRID) * GRID;
}

/** T-314: the Y coordinate an edge leaves from, by output port. */
function outputPortY(
  from: WorkflowNode,
  handle: "out" | "true" | "false" | undefined,
): number {
  if (from.type === "condition" && handle === "true") return from.position.y + TRUE_PORT_Y;
  if (from.type === "condition" && handle === "false") return from.position.y + FALSE_PORT_Y;
  return from.position.y + NODE_H / 2;
}

export function DagCanvas({
  workflow,
  onChange,
  onSave,
  onDeploy,
  canEdit,
  onInspectNode,
  onExecute,
  onServerDryRun,
  serverDryRunEntities,
  testEntities,
  onTestExecute,
  canTestExecute,
}: DagCanvasProps) {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [nodes, setNodes] = useState<WorkflowNode[]>([...workflow.nodes]);
  const [edges, setEdges] = useState<WorkflowEdge[]>([...workflow.edges]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [drag, setDrag] = useState<DragState | null>(null);
  const [edgeDraft, setEdgeDraft] = useState<EdgeDraft | null>(null);
  const [cycleError, setCycleError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [deployOpen, setDeployOpen] = useState(false);
  const [deploying, setDeploying] = useState(false);
  const [view, setView] = useState<ViewState>({ zoom: 1, panX: 0, panY: 0 });
  const [dryRun, setDryRun] = useState<DryRunResult | null>(null);
  const [serverTesting, setServerTesting] = useState(false);
  const [serverEntityId, setServerEntityId] = useState<string>("");
  const [executing, setExecuting] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);
  const [showMinimap, setShowMinimap] = useState(true);
  // T-314 (Test Studio): drawer open state + the inspected step node.
  const [studioOpen, setStudioOpen] = useState(false);
  const [testSelectedId, setTestSelectedId] = useState<string | null>(null);
  const [testExecuting, setTestExecuting] = useState(false);

  // Sync internal state when the workflow prop updates (switched, node added/configured externally)
  const dragRef = useRef(drag);
  dragRef.current = drag;
  const nodesRef = useRef(nodes);
  nodesRef.current = nodes;
  const edgesRef = useRef(edges);
  edgesRef.current = edges;
  const viewRef = useRef(view);
  viewRef.current = view;

  const lastWfIdRef = useRef<string>(workflow.id);
  useEffect(() => {
    if (lastWfIdRef.current !== workflow.id) {
      lastWfIdRef.current = workflow.id;
      setNodes([...workflow.nodes]);
      setEdges([...workflow.edges]);
      setSelectedId(null);
      setCycleError(null);
      setDryRun(null);
      setView({ zoom: 1, panX: 0, panY: 0 });
    } else if (!dragRef.current) {
      setNodes([...workflow.nodes]);
      setEdges([...workflow.edges]);
    }
  }, [workflow]);

  const emit = useCallback(
    (nextNodes: WorkflowNode[], nextEdges: WorkflowEdge[]) => {
      setNodes(nextNodes);
      setEdges(nextEdges);
      onChange(nextNodes, nextEdges);
    },
    [onChange],
  );

  /* --------------------- Window-level drag & drop --------------------- */
  useEffect(() => {
    if (!drag && !edgeDraft) return;

    function onMouseMove(e: MouseEvent) {
      if (drag?.kind === "pan") {
        const rect = svgRef.current?.getBoundingClientRect();
        if (!rect) return;
        const dx = (e.clientX - drag.offsetX) * (1000 / rect.width);
        const dy = (e.clientY - drag.offsetY) * (600 / rect.height);
        setDrag((prev) =>
          prev ? { ...prev, offsetX: e.clientX, offsetY: e.clientY } : null,
        );
        setView((v) => ({ ...v, panX: v.panX + dx, panY: v.panY + dy }));
        return;
      }

      if (drag && drag.kind === "node") {
        const { x, y } = clientToSvg(
          svgRef.current,
          viewRef.current,
          e.clientX,
          e.clientY,
        );
        const nextX = snap(Math.max(0, x - drag.offsetX));
        const nextY = snap(Math.max(0, y - drag.offsetY));
        setNodes((curr) =>
          curr.map((n) =>
            n.id === drag.nodeId
              ? { ...n, position: { x: nextX, y: nextY } }
              : n,
          ),
        );
      } else if (edgeDraft) {
        const { x, y } = clientToSvg(
          svgRef.current,
          viewRef.current,
          e.clientX,
          e.clientY,
        );
        setEdgeDraft((prev) =>
          prev ? { ...prev, cursorX: x, cursorY: y } : null,
        );
      }
    }

    function onMouseUp() {
      if (drag?.kind === "node") {
        const currentNodes = nodesRef.current;
        const currentEdges = edgesRef.current;
        emit(currentNodes, currentEdges);
        // Persist the moved position automatically
        void onSave(currentNodes, currentEdges);
      }
      setDrag(null);
      setEdgeDraft(null);
    }

    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
    return () => {
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
    };
  }, [drag, edgeDraft, emit, onSave]);

  function handleNodeMouseDown(e: ReactMouseEvent, node: WorkflowNode) {
    if (!canEdit) return;
    e.preventDefault();
    e.stopPropagation();
    setSelectedId(node.id);
    const { x, y } = clientToSvg(svgRef.current, view, e.clientX, e.clientY);
    setDrag({
      kind: "node",
      nodeId: node.id,
      offsetX: x - node.position.x,
      offsetY: y - node.position.y,
      startX: node.position.x,
      startY: node.position.y,
    });
  }

  function handleCanvasMouseDown(e: ReactMouseEvent<SVGSVGElement>) {
    if (
      e.target === e.currentTarget ||
      (e.target as Element).getAttribute("data-canvas-bg") === "true"
    ) {
      e.preventDefault();
      setDrag({
        kind: "pan",
        nodeId: "",
        offsetX: e.clientX,
        offsetY: e.clientY,
        startX: view.panX,
        startY: view.panY,
      });
    }
  }

  function handleCanvasClick(e: ReactMouseEvent<SVGSVGElement>) {
    if (
      e.target === e.currentTarget ||
      (e.target as Element).getAttribute("data-canvas-bg") === "true"
    ) {
      setSelectedId(null);
    }
  }

  /* --------------------- Zoom & fit --------------------- */
  function zoomBy(factor: number, anchorClient?: { x: number; y: number }) {
    setView((v) => {
      const next = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, v.zoom * factor));
      if (Math.abs(next - v.zoom) < 0.0001) return v;
      if (anchorClient && svgRef.current) {
        const rect = svgRef.current.getBoundingClientRect();
        const svgX = (anchorClient.x - rect.left) * (1000 / rect.width);
        const svgY = (anchorClient.y - rect.top) * (600 / rect.height);
        const viewX = (svgX - v.panX) / v.zoom;
        const viewY = (svgY - v.panY) / v.zoom;
        return {
          zoom: next,
          panX: svgX - viewX * next,
          panY: svgY - viewY * next,
        };
      }
      return { ...v, zoom: next };
    });
  }

  function handleWheel(e: ReactWheelEvent<SVGSVGElement>) {
    if (!e.ctrlKey && !e.metaKey) return;
    try {
      e.preventDefault();
    } catch {
      // Passive listener fallback
    }
    zoomBy(e.deltaY < 0 ? 1.1 : 0.9, { x: e.clientX, y: e.clientY });
  }

  const contentBounds = useMemo(() => {
    if (nodes.length === 0) return { minX: 0, minY: 0, maxX: 1000, maxY: 600 };
    let minX = Infinity,
      minY = Infinity,
      maxX = -Infinity,
      maxY = -Infinity;
    for (const n of nodes) {
      minX = Math.min(minX, n.position.x);
      minY = Math.min(minY, n.position.y);
      maxX = Math.max(maxX, n.position.x + NODE_W);
      maxY = Math.max(maxY, n.position.y + NODE_H);
    }
    const m = 60;
    return { minX: minX - m, minY: minY - m, maxX: maxX + m, maxY: maxY + m };
  }, [nodes]);

  function fitView() {
    const w = Math.max(1, contentBounds.maxX - contentBounds.minX);
    const h = Math.max(1, contentBounds.maxY - contentBounds.minY);
    const zoom = Math.min(
      MAX_ZOOM,
      Math.max(0.25, Math.min(1000 / w, 600 / h)),
    );
    setView({
      zoom,
      panX: (1000 - (contentBounds.minX + contentBounds.maxX) * zoom) / 2,
      panY: (600 - (contentBounds.minY + contentBounds.maxY) * zoom) / 2,
    });
  }

  /* --------------------- Edge connection --------------------- */
  function handleOutputPortMouseDown(
    e: ReactMouseEvent<SVGCircleElement>,
    node: WorkflowNode,
    handle: "out" | "true" | "false",
  ) {
    if (!canEdit) return;
    e.stopPropagation();
    e.preventDefault();
    const { x, y } = clientToSvg(svgRef.current, view, e.clientX, e.clientY);
    setEdgeDraft({ fromId: node.id, fromHandle: handle, cursorX: x, cursorY: y });
  }

  function handleInputPortMouseUp(
    e: ReactMouseEvent<SVGCircleElement>,
    node: WorkflowNode,
  ) {
    if (!edgeDraft || !canEdit) return;
    e.stopPropagation();
    if (edgeDraft.fromId === node.id) {
      setEdgeDraft(null);
      return;
    }
    const exists = edges.some(
      (ed) => ed.from === edgeDraft.fromId && ed.to === node.id,
    );
    if (!exists) {
      const fromNode = nodes.find((n) => n.id === edgeDraft.fromId) ?? null;
      // T-314: edges drawn from a condition's VRAI/FAUX port carry the
      // sourceHandle — the engines route TRUE/FALSE through it.
      const sourceHandle =
        fromNode && fromNode.type === "condition" && edgeDraft.fromHandle !== "out"
          ? (edgeDraft.fromHandle as "true" | "false")
          : undefined;
      const newEdge: WorkflowEdge = {
        id: `e-${edgeDraft.fromId}-${node.id}-${Date.now().toString(36)}`,
        from: edgeDraft.fromId,
        to: node.id,
        ...(sourceHandle ? { sourceHandle } : {}),
      };
      const nextEdges = [...edges, newEdge];
      emit(nodes, nextEdges);
      void onSave(nodes, nextEdges);

      const cycle = detectCycle(nodes, nextEdges);
      if (cycle.hasCycle) {
        setCycleError(
          `Cycle détecté — ${cycle.cycleNodeIds.size} nœud(s) en boucle. Cette connexion crée une boucle : supprimez-la.`,
        );
      } else {
        setCycleError(null);
      }
    }
    setEdgeDraft(null);
  }

  function deleteNode(id: string) {
    const nextNodes = nodes.filter((n) => n.id !== id);
    const nextEdges = edges.filter((e) => e.from !== id && e.to !== id);
    emit(nextNodes, nextEdges);
    void onSave(nextNodes, nextEdges);
    if (selectedId === id) setSelectedId(null);
    const cycle = detectCycle(nextNodes, nextEdges);
    setCycleError(
      cycle.hasCycle
        ? `Cycle détecté — ${cycle.cycleNodeIds.size} nœud(s) en boucle.`
        : null,
    );
  }

  function handleAutoLayout() {
    const result = autoLayout(nodes, edges);
    if (!result.ok) {
      setCycleError(result.error ?? "Réorganisation impossible.");
      return;
    }
    setCycleError(null);
    emit([...result.nodes], edges);
    void onSave([...result.nodes], edges);
    fitView();
  }

  /**
   * T-314: the Tester button opens the REAL-ENTITY Test Studio (replaces
   * the old invisible dummy payload). The studio builds a context (real
   * parent / preset / sliders) and calls back into handleStudioSimulation.
   */
  function handleOpenStudio() {
    setServerError(null);
    setStudioOpen(true);
  }

  /** Studio → canvas: run the simulation against the studio's context. */
  function handleStudioSimulation(context: ConditionContext, _entityLabel: string) {
    setServerError(null);
    setTestSelectedId(null);
    const result = dryRunWorkflow(nodes, edges, context);
    setDryRun(result);
  }

  /** Studio → canvas: REAL execution for a parent (side effects applied). */
  async function handleStudioExecute(parentId: string, context: ConditionContext) {
    if (!onTestExecute) return;
    setTestExecuting(true);
    setServerError(null);
    try {
      await onTestExecute(parentId, context);
    } finally {
      setTestExecuting(false);
    }
  }

  async function handleServerDryRun() {
    if (!onServerDryRun) return;
    setServerTesting(true);
    setServerError(null);
    try {
      const outcome = await onServerDryRun(serverEntityId || null);
      if (!outcome) {
        setServerError("La simulation serveur a échoué.");
        return;
      }
      const nodeById = new Map(nodes.map((n) => [n.id, n] as const));
      setDryRun({
        ok: true,
        results: outcome.nodeOutcomes.map((o) => {
          const node = nodeById.get(o.nodeId);
          return {
            nodeId: o.nodeId,
            nodeLabel: node?.label ?? o.nodeId,
            subtype: node?.subtype ?? "manual_run",
            type: node?.type ?? "action",
            status: o.status,
            output: [
              o.error ? `ERREUR : ${o.error}` : (o.output ?? ""),
              "(serveur)",
            ]
              .filter(Boolean)
              .join(" "),
            warnings: [],
          };
        }),
        takenEdgeKeys: outcome.takenEdgeKeys,
        context: defaultConditionContext(),
      });
      if (outcome.error) setServerError(outcome.error);
    } finally {
      setServerTesting(false);
    }
  }

  async function handleExecute() {
    if (!onExecute) return;
    setExecuting(true);
    setServerError(null);
    try {
      await onExecute();
    } finally {
      setExecuting(false);
    }
  }

  const dryRunNodeStatus = useMemo(() => {
    const map = new Map<string, "succeeded" | "skipped" | "failed">();
    if (dryRun) for (const r of dryRun.results) map.set(r.nodeId, r.status);
    return map;
  }, [dryRun]);

  const dryRunTakenEdges = useMemo(
    () => new Set(dryRun?.takenEdgeKeys ?? []),
    [dryRun],
  );
  const dryRunWarningCount = useMemo(
    () => dryRun?.results.reduce((s, r) => s + r.warnings.length, 0) ?? 0,
    [dryRun],
  );

  async function handleSave() {
    setSaving(true);
    setCycleError(null);
    const cycle = detectCycle(nodes, edges);
    if (cycle.hasCycle) {
      setCycleError(
        `Cycle détecté — ${cycle.cycleNodeIds.size} nœud(s) en boucle. Sauvegarde impossible.`,
      );
      setSaving(false);
      return;
    }
    try {
      await onSave(nodes, edges);
    } finally {
      setSaving(false);
    }
  }

  async function handleDeployConfirm() {
    setDeploying(true);
    try {
      await onDeploy();
    } finally {
      setDeploying(false);
    }
  }

  const cycle = cycleError ? detectCycle(nodes, edges) : null;
  const cycleEdgeKeys = new Set(cycle?.cycleEdgeKeys ?? []);
  const cycleNodeIds = new Set(cycle?.cycleNodeIds ?? []);

  const minimap = useMemo(() => {
    const w = Math.max(1, contentBounds.maxX - contentBounds.minX);
    const h = Math.max(1, contentBounds.maxY - contentBounds.minY);
    const scale = Math.min(180 / w, 108 / h);
    const mapW = w * scale;
    const mapH = h * scale;
    const toMap = (x: number, y: number) => ({
      x: (x - contentBounds.minX) * scale,
      y: (y - contentBounds.minY) * scale,
    });
    const visX = -view.panX / view.zoom;
    const visY = -view.panY / view.zoom;
    const visW = 1000 / view.zoom;
    const visH = 600 / view.zoom;
    const vis = toMap(visX, visY);
    return {
      mapW,
      mapH,
      scale,
      toMap,
      viewport: { x: vis.x, y: vis.y, w: visW * scale, h: visH * scale },
    };
  }, [contentBounds, view]);

  function handleMinimapJump(e: ReactMouseEvent<SVGSVGElement>) {
    const rect = e.currentTarget.getBoundingClientRect();
    const mapX = ((e.clientX - rect.left) / rect.width) * minimap.mapW;
    const mapY = ((e.clientY - rect.top) / rect.height) * minimap.mapH;
    const viewX = mapX / minimap.scale + contentBounds.minX;
    const viewY = mapY / minimap.scale + contentBounds.minY;
    setView((v) => ({
      ...v,
      panX: 500 - viewX * v.zoom,
      panY: 300 - viewY * v.zoom,
    }));
  }

  const zoomPct = Math.round(view.zoom * 100);

  return (
    <Card className="flex flex-col h-full min-h-0">
      {/* ---------- Toolbar ---------- */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border px-3 py-2">
        <div className="flex items-center gap-2 min-w-0">
          <span className="text-sm font-medium text-foreground truncate">
            {workflow.name}
          </span>
          <span className="text-xs text-muted-foreground whitespace-nowrap">
            · {nodes.length} nœud(s), {edges.length} lien(s)
          </span>
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          <Button
            size="sm"
            variant="ghost"
            className="h-8 w-8 p-0"
            onClick={() => zoomBy(1.2)}
            title="Zoom avant (Ctrl+molette)"
          >
            <ZoomIn className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-8 w-8 p-0"
            onClick={() => zoomBy(1 / 1.2)}
            title="Zoom arrière (Ctrl+molette)"
          >
            <ZoomOut className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-8 w-8 p-0"
            onClick={fitView}
            title="Ajuster à l'écran"
          >
            <Maximize className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-8 w-8 p-0"
            onClick={() => setShowMinimap((s) => !s)}
            title={
              showMinimap ? "Masquer la mini-carte" : "Afficher la mini-carte"
            }
          >
            <MapIcon className="h-4 w-4" />
          </Button>
          <span className="text-[10px] font-mono text-muted-foreground w-9 text-center">
            {zoomPct}%
          </span>
          <span className="w-px h-5 bg-border mx-0.5" />
          <Button
            size="sm"
            variant="outline"
            onClick={handleAutoLayout}
            disabled={!canEdit}
            title="Réorganiser selon la topologie"
          >
            <Wand2 className="h-4 w-4" /> Réorganiser
          </Button>
          <Button
            size="sm"
            variant={dryRun ? "default" : "outline"}
            onClick={handleOpenStudio}
            disabled={nodes.length === 0}
            title="Studio de test — entités réelles, presets et curseurs (T-314)"
          >
            <Play className="h-4 w-4" /> Tester
          </Button>
          {dryRun && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setDryRun(null)}
              title="Effacer la simulation"
            >
              <XCircle className="h-4 w-4" />
            </Button>
          )}
          {onServerDryRun && (
            <>
              <span className="w-px h-5 bg-border mx-0.5" />
              <Select value={serverEntityId} onValueChange={setServerEntityId}>
                <SelectTrigger
                  className="h-8 w-44"
                  title="Entité de test (données réelles)"
                >
                  <SelectValue placeholder="Entité de test" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Sans entité</SelectItem>
                  {(serverDryRunEntities ?? []).map((e) => (
                    <SelectItem key={e.id} value={e.id}>
                      {e.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                size="sm"
                variant="outline"
                onClick={handleServerDryRun}
                disabled={serverTesting || nodes.length === 0}
                title="Test serveur avec données réelles"
              >
                <Cloud className="h-4 w-4" />{" "}
                {serverTesting ? "Test serveur…" : "Test serveur"}
              </Button>
            </>
          )}
          <span className="w-px h-5 bg-border mx-0.5" />
          <Button
            size="sm"
            variant="outline"
            onClick={handleSave}
            disabled={!canEdit || saving}
          >
            <Save className="h-4 w-4" />{" "}
            {saving ? "Sauvegarde…" : "Enregistrer"}
          </Button>
          <Button
            size="sm"
            onClick={() => setDeployOpen(true)}
            disabled={!canEdit || deploying}
          >
            <Rocket className="h-4 w-4" /> Déployer
          </Button>
          {onExecute && (
            <Button
              size="sm"
              variant="outline"
              onClick={handleExecute}
              disabled={executing}
              title="Exécuter maintenant (serveur)"
            >
              <Zap className="h-4 w-4" />{" "}
              {executing ? "Exécution…" : "Exécuter"}
            </Button>
          )}
        </div>
      </div>

      {cycleError && (
        <div className="flex items-start gap-2 border-b border-status-danger/30 bg-status-danger/10 px-3 py-2 text-sm text-status-danger">
          <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
          <span className="leading-snug">{cycleError}</span>
        </div>
      )}
      {serverError && (
        <div className="flex items-start gap-2 border-b border-status-warning/30 bg-status-warning/10 px-3 py-2 text-sm text-status-warning">
          <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
          <span className="leading-snug">{serverError}</span>
        </div>
      )}

      {dryRun && (
        <div
          className={cn(
            "border-b px-3 py-2 text-xs",
            dryRun.ok
              ? "border-status-success/30 bg-status-success/10 text-status-success"
              : "border-status-danger/30 bg-status-danger/10 text-status-danger",
          )}
        >
          <p className="font-semibold flex items-center gap-1.5">
            <Play className="h-3.5 w-3.5" />
            {dryRun.ok
              ? `Simulation : ${dryRun.results.filter((r) => r.status === "succeeded").length} nœud(s) exécuté(s), ${dryRun.results.filter((r) => r.status === "skipped").length} ignoré(s) — ${dryRun.takenEdgeKeys.length} lien(s) emprunté(s)${dryRunWarningCount > 0 ? ` · ${dryRunWarningCount} avertissement(s)` : ""}`
              : dryRun.error}
          </p>
          {dryRun.ok && dryRunWarningCount > 0 && (
            <ul className="mt-1 space-y-0.5 pl-5 list-disc">
              {dryRun.results
                .flatMap((r) => r.warnings.map((w) => `${r.nodeLabel}: ${w}`))
                .slice(0, 4)
                .map((w, i) => (
                  <li key={i} className="leading-snug">
                    {w}
                  </li>
                ))}
            </ul>
          )}
        </div>
      )}

      <CardContent className="relative flex-1 p-0 overflow-hidden">
        <svg
          ref={svgRef}
          viewBox="0 0 1000 600"
          className="w-full h-full bg-surface-background select-none"
          style={{ cursor: drag?.kind === "pan" ? "grabbing" : "default" }}
          onMouseDown={handleCanvasMouseDown}
          onClick={handleCanvasClick}
          onWheel={handleWheel}
        >
          <defs>
            <pattern
              id="dag-grid"
              width={40}
              height={40}
              patternUnits="userSpaceOnUse"
            >
              <circle cx="0" cy="0" r="1" fill="rgba(255,255,255,0.08)" />
            </pattern>
            <marker
              id="dag-arrow"
              viewBox="0 0 10 10"
              refX="9"
              refY="5"
              markerWidth="6"
              markerHeight="6"
              orient="auto-start-reverse"
            >
              <path d="M 0 0 L 10 5 L 0 10 z" className="fill-border" />
            </marker>
            <marker
              id="dag-arrow-cycle"
              viewBox="0 0 10 10"
              refX="9"
              refY="5"
              markerWidth="6"
              markerHeight="6"
              orient="auto-start-reverse"
            >
              <path d="M 0 0 L 10 5 L 0 10 z" className="fill-status-danger" />
            </marker>
            <marker
              id="dag-arrow-taken"
              viewBox="0 0 10 10"
              refX="9"
              refY="5"
              markerWidth="7"
              markerHeight="7"
              orient="auto-start-reverse"
            >
              <path d="M 0 0 L 10 5 L 0 10 z" className="fill-status-success" />
            </marker>
          </defs>
          <rect
            width="1000"
            height="600"
            fill="url(#dag-grid)"
            data-canvas-bg="true"
          />

          {/* Viewport transform */}
          <g
            transform={`translate(${view.panX}, ${view.panY}) scale(${view.zoom})`}
          >
            {/* Edges */}
            {edges.map((edge) => {
              const from = nodes.find((n) => n.id === edge.from);
              const to = nodes.find((n) => n.id === edge.to);
              if (!from || !to) return null;
              // T-314: the edge leaves from the VRAI/FAUX port when labeled.
              const x1 = from.position.x + NODE_W;
              const y1 = outputPortY(from, edge.sourceHandle);
              const x2 = to.position.x;
              const y2 = to.position.y + NODE_H / 2;
              const mx = (x1 + x2) / 2;
              const key = `${edge.from}->${edge.to}`;
              const isCycle = cycleEdgeKeys.has(key);
              const isTaken = dryRunTakenEdges.has(key);
              // T-314: untaken branches dim to 30% while a simulation runs.
              const isDimmed = !!dryRun && !isTaken && !isCycle;
              const path = `M ${x1} ${y1} C ${mx} ${y1}, ${mx} ${y2}, ${x2} ${y2}`;
              return (
                <g key={edge.id} className={isDimmed ? "opacity-30" : undefined}>
                  <path
                    d={path}
                    className={cn(
                      isCycle
                        ? "stroke-status-danger"
                        : isTaken
                          ? "stroke-status-success"
                          : edge.sourceHandle === "false"
                            ? "stroke-status-danger/70"
                            : edge.sourceHandle === "true"
                              ? "stroke-status-success/70"
                              : "stroke-border",
                      isTaken && dryRun && "animate-pulse",
                    )}
                    strokeWidth={isCycle || isTaken ? 2.5 : 1.8}
                    strokeDasharray={
                      !isTaken && !isCycle && edge.sourceHandle === "false" ? "7 4" : undefined
                    }
                    fill="none"
                    markerEnd={
                      isCycle
                        ? "url(#dag-arrow-cycle)"
                        : isTaken
                          ? "url(#dag-arrow-taken)"
                          : "url(#dag-arrow)"
                    }
                  />
                  {(edge.sourceHandle === "true" || edge.sourceHandle === "false") && !dryRun && (
                    <text
                      x={mx}
                      y={edge.sourceHandle === "true" ? Math.min(y1, y2) - 6 : Math.max(y1, y2) + 14}
                      textAnchor="middle"
                      className={cn(
                        "text-[9px] font-semibold select-none pointer-events-none",
                        edge.sourceHandle === "true" ? "fill-status-success" : "fill-status-danger",
                      )}
                    >
                      {edge.sourceHandle === "true" ? "VRAI / OUI" : "FAUX / NON"}
                    </text>
                  )}
                </g>
              );
            })}

            {/* Edge draft during port drag */}
            {edgeDraft &&
              (() => {
                const from = nodes.find((n) => n.id === edgeDraft.fromId);
                if (!from) return null;
                const x1 = from.position.x + NODE_W;
                const y1 = outputPortY(from, edgeDraft.fromHandle);
                const x2 = edgeDraft.cursorX;
                const y2 = edgeDraft.cursorY;
                const mx = (x1 + x2) / 2;
                return (
                  <path
                    d={`M ${x1} ${y1} C ${mx} ${y1}, ${mx} ${y2}, ${x2} ${y2}`}
                    className={cn(
                      edgeDraft.fromHandle === "true"
                        ? "stroke-status-success/70"
                        : edgeDraft.fromHandle === "false"
                          ? "stroke-status-danger/70"
                          : "stroke-primary/60",
                    )}
                    strokeWidth={1.8}
                    strokeDasharray="6 4"
                    fill="none"
                  />
                );
              })()}

            {/* Nodes */}
            {nodes.map((node) => {
              const Icon = ICON_FOR_TYPE[node.type];
              const colors = COLOR_FOR_TYPE[node.type];
              const isSelected = selectedId === node.id;
              const isCycle = cycleNodeIds.has(node.id);
              const runStatus = dryRunNodeStatus.get(node.id);
              return (
                <g
                  key={node.id}
                  transform={`translate(${node.position.x}, ${node.position.y})`}
                  className={cn(
                    "cursor-grab active:cursor-grabbing select-none",
                    !canEdit && "cursor-default",
                  )}
                  onMouseDown={(e) => handleNodeMouseDown(e, node)}
                  onDoubleClick={() => onInspectNode(node)}
                  // T-314 (Test Studio): single-click a node while a
                  // simulation is showing → inspect that step in the studio.
                  onClick={() => {
                    if (dryRun && testSelectedId !== node.id) setTestSelectedId(node.id);
                  }}
                >
                  <rect
                    width={NODE_W}
                    height={NODE_H}
                    rx={10}
                    ry={10}
                    className={cn(
                      colors.bg,
                      colors.border,
                      isCycle && "stroke-status-danger",
                      runStatus === "skipped" && "opacity-50",
                    )}
                    strokeWidth={isSelected ? 2.5 : isCycle ? 2.5 : 1.5}
                    strokeDasharray={
                      runStatus === "skipped" ? "6 3" : undefined
                    }
                  />

                  {/* T-314: Test Studio inspected-step ring (info blue) */}
                  {dryRun && testSelectedId === node.id && (
                    <rect
                      x={-6}
                      y={-6}
                      width={NODE_W + 12}
                      height={NODE_H + 12}
                      rx={14}
                      ry={14}
                      className="fill-none stroke-primary"
                      strokeWidth={2}
                      strokeDasharray="5 4"
                      pointerEvents="none"
                    />
                  )}

                  {/* Dry-run status rings */}
                  {runStatus === "failed" && (
                    <rect
                      x={-3}
                      y={-3}
                      width={NODE_W + 6}
                      height={NODE_H + 6}
                      rx={13}
                      ry={13}
                      className="fill-none stroke-status-danger"
                      strokeWidth={2}
                      strokeDasharray="4 3"
                      pointerEvents="none"
                    />
                  )}
                  {runStatus === "succeeded" && (
                    <rect
                      width={NODE_W}
                      height={NODE_H}
                      rx={10}
                      ry={10}
                      className="fill-none stroke-status-success"
                      strokeWidth={3}
                      pointerEvents="none"
                    />
                  )}

                  {/* Type tag at top */}
                  <text
                    x={10}
                    y={16}
                    className={cn(
                      "text-[10px] font-medium pointer-events-none select-none",
                      colors.text,
                    )}
                    fill="currentColor"
                  >
                    {WORKFLOW_NODE_TYPE_LABELS_FR[node.type]}
                  </text>

                  {/* Node label */}
                  <text
                    x={10}
                    y={36}
                    className="text-xs font-semibold text-foreground pointer-events-none select-none"
                    fill="currentColor"
                  >
                    {node.label}
                  </text>

                  {/* Subtype description */}
                  <text
                    x={10}
                    y={52}
                    className="text-[10px] text-muted-foreground pointer-events-none select-none"
                    fill="currentColor"
                  >
                    {WORKFLOW_NODE_SUBTYPE_LABELS_FR[node.subtype] ??
                      node.subtype}
                  </text>

                  {/* Top-right Icon */}
                  <foreignObject
                    x={NODE_W - 28}
                    y={6}
                    width={22}
                    height={22}
                    className="pointer-events-none select-none"
                  >
                    <Icon className={cn("h-5 w-5", colors.text)} />
                  </foreignObject>

                  {/* Input port (left) */}
                  <circle
                    cx={0}
                    cy={NODE_H / 2}
                    r={6}
                    className="fill-popover stroke-border hover:stroke-primary hover:scale-125 transition-transform"
                    strokeWidth={2}
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      e.preventDefault();
                    }}
                    onMouseUp={(e) => handleInputPortMouseUp(e, node)}
                  />

                  {/* T-314: output ports — conditions carry the VRAI/FAUX
                      binary pair (green top / red bottom); every other node
                      keeps its single right-side port. */}
                  {node.type === "condition" ? (
                    <>
                      <circle
                        cx={NODE_W}
                        cy={TRUE_PORT_Y}
                        r={6}
                        className="fill-popover stroke-status-success hover:scale-125 transition-transform cursor-crosshair"
                        strokeWidth={2.5}
                        onMouseDown={(e) => handleOutputPortMouseDown(e, node, "true")}
                      >
                        <title>Port VRAI / OUI — la condition est remplie</title>
                      </circle>
                      <circle
                        cx={NODE_W}
                        cy={FALSE_PORT_Y}
                        r={6}
                        className="fill-popover stroke-status-danger hover:scale-125 transition-transform cursor-crosshair"
                        strokeWidth={2.5}
                        onMouseDown={(e) => handleOutputPortMouseDown(e, node, "false")}
                      >
                        <title>Port FAUX / NON — la condition n'est pas remplie</title>
                      </circle>
                      <text
                        x={NODE_W - 34}
                        y={TRUE_PORT_Y + 3.5}
                        textAnchor="end"
                        className="text-[9px] font-semibold fill-status-success pointer-events-none select-none"
                      >
                        VRAI
                      </text>
                      <text
                        x={NODE_W - 34}
                        y={FALSE_PORT_Y + 3.5}
                        textAnchor="end"
                        className="text-[9px] font-semibold fill-status-danger pointer-events-none select-none"
                      >
                        FAUX
                      </text>
                    </>
                  ) : (
                    <circle
                      cx={NODE_W}
                      cy={NODE_H / 2}
                      r={6}
                      className="fill-popover stroke-primary hover:scale-125 transition-transform cursor-crosshair"
                      strokeWidth={2}
                      onMouseDown={(e) => handleOutputPortMouseDown(e, node, "out")}
                    />
                  )}

                  {/* Context menu trigger */}
                  {canEdit && (
                    <foreignObject
                      x={NODE_W - 22}
                      y={NODE_H - 22}
                      width={20}
                      height={20}
                    >
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <button
                            type="button"
                            className="flex items-center justify-center h-5 w-5 rounded text-muted-foreground hover:bg-accent/20 hover:text-foreground transition-colors"
                            aria-label="Actions du nœud"
                            onMouseDown={(ev) => ev.stopPropagation()}
                            onClick={(ev) => ev.stopPropagation()}
                          >
                            <svg
                              width="14"
                              height="14"
                              viewBox="0 0 14 14"
                              fill="currentColor"
                            >
                              <circle cx="3" cy="7" r="1.2" />
                              <circle cx="7" cy="7" r="1.2" />
                              <circle cx="11" cy="7" r="1.2" />
                            </svg>
                          </button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onInspectNode(node)}>
                            <Settings2 className="h-3.5 w-3.5" /> Configurer
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => deleteNode(node.id)}>
                            <Trash2 className="h-3.5 w-3.5" /> Supprimer
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </foreignObject>
                  )}
                </g>
              );
            })}

            {nodes.length === 0 && (
              <text
                x={500}
                y={300}
                textAnchor="middle"
                className="text-xs text-muted-foreground"
                fill="currentColor"
              >
                Cliquez sur un type de nœud dans la palette pour commencer
              </text>
            )}
          </g>
        </svg>

        {/* ---------- Minimap ---------- */}
        {showMinimap && nodes.length > 0 && (
          <div className="absolute bottom-3 right-3 rounded-md border border-border bg-popover/95 shadow-lg p-1.5">
            <svg
              width={180}
              height={108}
              viewBox={`0 0 ${minimap.mapW} ${minimap.mapH}`}
              className="cursor-pointer"
              onClick={handleMinimapJump}
            >
              <rect
                x={0}
                y={0}
                width={minimap.mapW}
                height={minimap.mapH}
                className="fill-muted/40"
              />
              {nodes.map((n) => {
                const p = minimap.toMap(n.position.x, n.position.y);
                return (
                  <rect
                    key={n.id}
                    x={p.x}
                    y={p.y}
                    width={Math.max(4, NODE_W * minimap.scale)}
                    height={Math.max(3, NODE_H * minimap.scale)}
                    rx={2}
                    className={cn(
                      n.type === "trigger"
                        ? "fill-primary"
                        : n.type === "condition"
                          ? "fill-status-warning"
                          : n.type === "action"
                            ? "fill-status-success"
                            : "fill-muted-foreground",
                      dryRunNodeStatus.get(n.id) === "skipped" && "opacity-40",
                    )}
                  />
                );
              })}
              <rect
                x={minimap.viewport.x}
                y={minimap.viewport.y}
                width={Math.max(6, minimap.viewport.w)}
                height={Math.max(4, minimap.viewport.h)}
                className="fill-none stroke-foreground/70"
                strokeWidth={1.5}
              />
            </svg>
          </div>
        )}
      </CardContent>

      <ConfirmModal
        open={deployOpen}
        onOpenChange={setDeployOpen}
        title="Déployer ce workflow"
        description="Le workflow sera figé et exécutable en production."
        confirmLabel="Déployer"
        onConfirm={handleDeployConfirm}
      />

      {/* ---------- T-314: the Test Studio (real entities + live path) ---------- */}
      <TestStudioDrawer
        open={studioOpen}
        onOpenChange={setStudioOpen}
        entities={testEntities ?? []}
        nodes={nodes}
        dryRun={dryRun}
        onRunSimulation={handleStudioSimulation}
        onClearSimulation={() => {
          setDryRun(null);
          setTestSelectedId(null);
        }}
        onRealExecute={onTestExecute ?? (async () => undefined)}
        executing={testExecuting}
        canExecute={!!onTestExecute && (canTestExecute ?? false)}
        selectedNodeId={testSelectedId}
        onSelectNode={setTestSelectedId}
      />
    </Card>
  );
}

export function makeNode(
  subtype: WorkflowNodeSubtype,
  type: WorkflowNodeType,
  existing: readonly WorkflowNode[],
): WorkflowNode {
  const idx = existing.length + 1;
  return {
    id: `n-${idx}-${Date.now().toString(36)}`,
    type,
    subtype,
    label: WORKFLOW_NODE_SUBTYPE_LABELS_FR[subtype] ?? subtype,
    position: { x: snap(100), y: snap(100 + ((idx * 70) % 400)) },
    config: {},
  };
}

export const PlusIcon = Plus;
export { NODE_SUBTYPE_TO_TYPE };
