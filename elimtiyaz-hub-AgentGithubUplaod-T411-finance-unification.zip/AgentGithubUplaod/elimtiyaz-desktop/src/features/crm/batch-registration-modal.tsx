/**
 * BatchRegistrationModal — 4-step atomic registration wizard.
 *
 * Plan §04.03: "4-step atomic flow: Parent → N children → billing config → BEGIN…COMMIT"
 *
 * Phase 4B refactor: now built on the shared `<Wizard>` primitive
 * (`src/shared/ui/wizard/`). The custom stepper JSX, step-state index,
 * and custom next/back buttons have been removed — the wizard primitive
 * handles all of that. Each step's `render` delegates to the existing
 * sub-step components in `./batch-registration/`, and each step's
 * `validate` runs the corresponding validator + surfaces errors via
 * the wizard's built-in error slot.
 *
 * Steps:
 *   1. Parent info — step1-parent.tsx
 *   2. N children (unlimited — "Add Another Child" button, no upper bound per §04.02) — step2-students.tsx
 *   3. Billing config (reads from PricingConfig — tuition per level + transport tier + registration fee) — step3-billing.tsx
 *   4. Review + atomic submit — step4-review.tsx
 *
 * On submit, calls StudentRepository.batchRegister(input) which is the
 * atomic operation. If any step fails, the whole transaction rolls back.
 */
import { useEffect, useMemo, useState } from "react";
import {
  User,
  Users,
  Wallet,
  ClipboardCheck,
  UserPlus,
} from "lucide-react";
import { useRepositories } from "../../app/providers/repository-provider";
import { useToast } from "../../app/providers/toast-provider";
import { useAuth } from "../../app/providers/auth-provider";
import { useObservable } from "../../shared/hooks/use-observable";
import { Wizard, type WizardStep } from "../../shared/ui/wizard";
import type { CreateStudentInput, Student } from "../../domain/model/student";
import type { CreateParentInput, TransportDestination } from "../../domain/model/parent";

import { Step1 } from "./batch-registration/step1-parent";
import { Step2 } from "./batch-registration/step2-students";
import { Step3 } from "./batch-registration/step3-billing";
import { Step4 } from "./batch-registration/step4-review";
import { computeBilling } from "./batch-registration/compute-billing";
import { ActivationCodeModal } from "./activation-code-modal";
import { deterministicActivationCode } from "../../core/format/id";
import type { Billing } from "./batch-registration/types";
import {
  EMPTY_PARENT,
  EMPTY_STUDENT,
  PHONE_RE,
  EMAIL_RE,
  type Step1Parent,
  type Step2Student,
} from "./batch-registration/types";
import type { Parent } from "../../domain/model/parent";

export function BatchRegistrationModal({
  open,
  onOpenChange,
  onSubmitted,
  presetParent,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  onSubmitted?: (parentId: string) => void;
  /**
   * FIX (add-child duplication): when provided, children are attached to
   * THIS existing parent instead of creating a duplicate parent record.
   * Previously the parent drawer's "Ajouter un enfant" button opened a
   * blank wizard that always created a NEW parent.
   */
  presetParent?: Parent | null;
}) {
  const repos = useRepositories();
  const toast = useToast();
  const { session } = useAuth();
  const pricing = useObservable(() => repos.pricing.observe(), []);

  const [parent, setParent] = useState<Step1Parent>(EMPTY_PARENT);
  const [students, setStudents] = useState<Step2Student[]>([{ ...EMPTY_STUDENT }]);
  const [includeRegistration, setIncludeRegistration] = useState(true);
  const [includeTransport, setIncludeTransport] = useState(true);
  // CALC-001 — prior balances at intake (REMBOURSEMENT / DETTES): the Devis
  // sheet's Montant Total = Sous-total − Réduction − Remboursement.
  const [priorCredit, setPriorCredit] = useState("");
  const [priorDebt, setPriorDebt] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  // VAULT §02.08 — the activation code issued at enrollment time (Step 1 of
  // the Account Activation Protocol: "Office staff registers family AND
  // issues 6-7 digit activation code or QR"). Rendered after a successful
  // registration so staff hands the code to the parent before they leave.
  const [issuedActivation, setIssuedActivation] = useState<{
    code: string;
    parentName: string;
    whatsapp: string | null;
    phone: string | null;
  } | null>(null);

  // Reset on close
  useEffect(() => {
    if (!open) {
      setTimeout(() => {
        setParent(EMPTY_PARENT);
        setStudents([{ ...EMPTY_STUDENT }]);
        setIncludeRegistration(true);
        setIncludeTransport(true);
        setPriorCredit("");
        setPriorDebt("");
        setErrors({});
        setIssuedActivation(null);
      }, 200);
    }
  }, [open]);

  // FIX (add-child duplication): when re-opening with a preset parent,
  // prefill step 1 from the existing record so children attach to it.
  useEffect(() => {
    if (open && presetParent) {
      setParent({
        firstName: presetParent.firstName,
        lastName: presetParent.lastName,
        gender: presetParent.gender,
        phone: presetParent.phone,
        whatsapp: presetParent.whatsapp ?? "",
        email: presetParent.email ?? "",
        occupation: presetParent.occupation ?? "",
        address: presetParent.address ?? "",
        transportDestination: presetParent.transportDestination ?? "",
        preferredLanguage: presetParent.preferredLanguage === "ar" ? "ar" : "fr",
      });
    }
  }, [open, presetParent]);

  // === Billing computation (step 3) ===
  // Now delegates to the pure `computeBilling` helper which evaluates all 5
  // official `Prices.md` discounts ONCE on the gross annual tuition, then
  // splits the net across tranches (or 1 entry for `full_annual`). This
  // eliminates the double-discounting bug documented in the architectural
  // blueprint (discounts were previously applied per-tranche inside
  // `buildTuitionChargeEntries`).
  const billing = useMemo<Billing>(() => {
    return computeBilling({
      students,
      pricing,
      includeRegistration,
      includeTransport,
      priorCredit: Math.max(0, Number(priorCredit) || 0),
      priorDebt: Math.max(0, Number(priorDebt) || 0),
    });
  }, [students, pricing, includeRegistration, includeTransport, priorCredit, priorDebt]);


  // === Step validation (returns a human-readable error string or null) ===
  function validateStep1(): string | null {
    // When adding a child to an existing parent, the parent record is already validated and saved
    if (presetParent) {
      setErrors({});
      return null;
    }

    const e: Record<string, string> = {};
    if (!parent.firstName.trim() && !parent.lastName.trim()) {
      e.parent_lastName = "Nom requis";
    }
    if (!parent.phone.trim()) {
      e.parent_phone = "Téléphone requis";
    } else if (!PHONE_RE.test(parent.phone)) {
      e.parent_phone = "Format invalide (8-15 chiffres)";
    }
    if (parent.email && !EMAIL_RE.test(parent.email)) e.parent_email = "E-mail invalide";
    if (parent.whatsapp && !PHONE_RE.test(parent.whatsapp)) e.parent_whatsapp = "Format invalide";
    setErrors(e);
    return Object.keys(e).length === 0
      ? null
      : "Vérifiez les champs requis du parent (nom + téléphone valide).";
  }

  function validateStep2(): string | null {
    const e: Record<string, string> = {};
    students.forEach((s, i) => {
      if (!s.firstName.trim()) e[`stu_${i}_firstName`] = "Prénom requis";
      if (!s.lastName.trim()) e[`stu_${i}_lastName`] = "Nom requis";
      if (!s.birthDate) e[`stu_${i}_birthDate`] = "Date de naissance requise";
    });
    setErrors(e);
    return Object.keys(e).length === 0
      ? null
      : "Vérifiez les champs requis de chaque élève (nom + date de naissance).";
  }

  // === Atomic submit (called by Wizard onFinish on the last step) ===
  async function submit(): Promise<void> {
    if (!session) {
      throw new Error("Session expirée — reconnectez-vous puis réessayez.");
    }

    const studentInputs: CreateStudentInput[] = students.map((s) => ({
      firstName: s.firstName.trim(),
      // vault §04.03 — optional middle name from the child block.
      middleName: s.middleName.trim() || null,
      lastName: s.lastName.trim(),
      gender: s.gender,
      birthDate: s.birthDate,
      level: s.level,
      gradeYear: s.gradeYear,
      // T-401 — classification ("" → null = untagged).
      filiereCode: s.filiereCode || null,
      specialiteCode: s.specialiteCode || null,
      // vault §04.03 — optional class assignment ("" → null = unassigned).
      classId: s.classId || null,
      medicalNotes: s.medicalNotes.trim() || null,
      // Student.transportTier is a bare string — we store the canonical destination key in it.
      transportTier: (s.transportDestination || null) as string | null,
      paymentPlan: s.paymentPlan,
      // CALC-001 (2026-09-12): the ghost inputs (previousGradeLevel /
      // previousRank) are REMOVED — the rules they fed never existed at the
      // school. The negotiated remise + sticker-price flag live on the
      // billing input instead (buildRegistrationBilling reads them).
      remise: Math.max(0, Number(s.remise) || 0),
      chargeStickerPrice: s.chargeStickerPrice,
    }));

    // FIX (add-child duplication): attach children to the EXISTING parent
    // when one was provided — do NOT create a duplicate parent record.
    if (presetParent) {
      const created: Student[] = [];
      for (const input of studentInputs) {
        const r = await repos.students.createStudent(presetParent.id, input);
        if (!r.ok) throw new Error(r.error.userMessage);
        created.push(r.value);
      }
      toast.showSuccess(
        "Enfant(s) ajouté(s)",
        `${created.length} élève(s) rattaché(s) au dossier de ${presetParent.firstName} ${presetParent.lastName}.`,
      );
      onSubmitted?.(presetParent.id);
      return;
    }

    const parentInput: CreateParentInput = {
      firstName: parent.firstName.trim(),
      lastName: parent.lastName.trim(),
      gender: parent.gender,
      phone: parent.phone.trim(),
      whatsapp: parent.whatsapp.trim() || null,
      email: parent.email.trim() || null,
      occupation: parent.occupation.trim() || null,
      address: parent.address.trim() || null,
      transportDestination: (parent.transportDestination || null) as TransportDestination | null,
      preferredLanguage: parent.preferredLanguage,
    };

    const result = await repos.students.batchRegister({
      parent: parentInput,
      students: studentInputs,
      // FIX (billing persistence): forward the step-3 billing configuration
      // so the repository persists the promised charges + installment schedule.
      includeRegistration,
      includeTransport,
      // T-398 (PERF-502): the wizard's ALREADY-LOADED pricing config — the
      // same object the step-3 preview derived from. Kills the 5-6
      // sequential pricing reads inside the write path (the whole
      // registration is ONE round-trip now) AND guarantees the persisted
      // charges match the preview the parent agreed to.
      pricingConfig: pricing,
    });

    if (result.ok) {
      // DATA-019 (T-397): the billing-persistence failure is surfaced —
      // the family is created but the charges/tranches were NOT written;
      // the operator must know before promising a payment schedule to the
      // parent (previously a console.warn the UI never showed).
      if (result.value.billingWarning) {
        toast.showWarning(
          "Inscription réussie MAIS échec de la facturation",
          result.value.billingWarning,
        );
      } else {
        toast.showSuccess(
          "Inscription réussie",
          `Parent ${result.value.parent.code} + ${result.value.students.length} élève(s) créé(s) — facturation (charges + tranches) écrite.`,
        );
      }
      // VAULT §02.08 — issue the activation code at enrollment time. The
      // Supabase path already persisted the SAME deterministic code via
      // `upsert_parent_from_import(p_activation_code)` (migration 0037), so
      // here we surface it (code + QR) for hand-off to the parent.
      const createdParent = result.value.parent;
      setIssuedActivation({
        code: deterministicActivationCode(createdParent.code, createdParent.tenantId),
        parentName: `${createdParent.firstName} ${createdParent.lastName}`.trim(),
        whatsapp: createdParent.whatsapp ?? null,
        phone: createdParent.phone ?? null,
      });
      void repos.audit.log({
        action: "parent.activation_code_issued",
        entityType: "parent",
        entityId: createdParent.id,
        actorId: session.userId,
        actorName: session.displayName,
        tenantId: createdParent.tenantId,
        diff: { before: null, after: { parentCode: createdParent.code } },
        note: `Code d'activation portail émis à l'inscription de ${createdParent.firstName} ${createdParent.lastName} (usage unique, lié au profil maître)`,
      });
      onSubmitted?.(result.value.parent.id);
      return;
    }
    throw new Error(result.error.userMessage);
  }

  // === Wizard step definitions ===
  const steps: readonly WizardStep[] = [
    {
      id: "parent",
      label: "Parent",
      description: presetParent
        ? "Parent existant — les enfants seront rattachés à son dossier"
        : "Identité et coordonnées du parent",
      render: () => (
        <Step1
          parent={parent}
          setParent={setParent}
          errors={errors}
          lockedParent={presetParent}
        />
      ),
      validate: validateStep1,
    },
    {
      id: "students",
      label: "Élèves",
      description: "Ajoutez un nombre illimité d'enfants",
      render: () => (
        <Step2
          students={students}
          setStudents={setStudents}
          errors={errors}
          parentTransportDestination={parent.transportDestination}
        />
      ),
      validate: validateStep2,
    },
    {
      id: "billing",
      label: "Facturation",
      description: "Configuration des frais (scolarité + transport + inscription)",
      render: () => (
        <Step3
          billing={billing}
          includeRegistration={includeRegistration}
          setIncludeRegistration={setIncludeRegistration}
          includeTransport={includeTransport}
          setIncludeTransport={setIncludeTransport}
          priorCredit={priorCredit}
          setPriorCredit={setPriorCredit}
          priorDebt={priorDebt}
          setPriorDebt={setPriorDebt}
        />
      ),
    },
    {
      id: "review",
      label: "Validation",
      description: "Vérification atomique avant soumission",
      render: () => <Step4 parent={parent} students={students} billing={billing} />,
      isFinal: true,
    },
  ];

  return (
    <>
      <Wizard
        open={open}
        onOpenChange={onOpenChange}
        title={
          presetParent
            ? `Ajouter un enfant — ${presetParent.firstName} ${presetParent.lastName}`
            : "Inscription groupée (Parent + Élèves)"
        }
        steps={steps}
        onFinish={submit}
        widthClass="max-w-3xl"
      />
      {/* VAULT §02.08 — activation code + QR hand-off at enrollment time. */}
      <ActivationCodeModal
        open={issuedActivation !== null}
        onOpenChange={(o) => !o && setIssuedActivation(null)}
        code={issuedActivation?.code ?? null}
        parentName={issuedActivation?.parentName ?? ""}
        whatsapp={issuedActivation?.whatsapp}
        phone={issuedActivation?.phone}
      />
    </>
  );
}

// Re-export the step icons so callers (e.g. tests or future parent/pre-fill
// flows) can reuse the canonical icon mapping without re-importing from lucide.
export const STEP_ICONS = {
  parent: User,
  students: Users,
  billing: Wallet,
  review: ClipboardCheck,
  header: UserPlus,
} as const;
