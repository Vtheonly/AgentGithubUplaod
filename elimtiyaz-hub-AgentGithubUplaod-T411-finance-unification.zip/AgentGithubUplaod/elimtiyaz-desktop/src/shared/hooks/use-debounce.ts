/**
 * useDebounce — delays a value change until N ms of inactivity.
 *
 * Use for search inputs that hit a repository on every keystroke.
 */
import { useEffect, useState } from "react";

export function useDebounce<T>(value: T, delayMs = 250): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delayMs);
    return () => clearTimeout(t);
  }, [value, delayMs]);
  return debounced;
}
