# Tier 4 Cross-Platform Equivalence Report

**Generated:** 2026-09-30T01:02:01.775Z
**Desktop engine:** TypeScript (DZD `number`) — src/domain/calc/*
**Android mirror engine:** TypeScript (centimes Long) — android_mirror/kotlin_mirror_engine.ts
**Strict mode:** false

## Summary

- Total scenarios compared: 819
- Scenarios with full equivalence: 707
- Scenarios SKIPPED (op not implemented on one side — reported, never silent): 35
- Scenarios with discrepancies: 77
- Total discrepancies: 499
  - Errors (delta > 1 centime or non-numeric mismatch): 112
  - Warnings (delta ≤ 1 centime): 387

## Verdict

❌ **FAIL** — 112 material discrepancies detected. See details below.

## Discrepancies

| Scenario | Path | Desktop | Android Mirror | Delta | Severity |
|---|---|---|---|---|---|
| 007_discount_passage_palier | result.discountsApplied[0] | undefined | "passage_palier" | — | WARNING |
| 007_discount_passage_palier | result.evaluations[0] | undefined | {"amount":-1000000,"applied":true,"code":"passage_palier","l | — | WARNING |
| 007_discount_passage_palier | result.totalDiscount | 0 | -1000000 | 1000000 | ERROR |
| 008_discount_sibling_only | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Fratrie — enfant #2 (-5000 DA)" | — | WARNING |
| 009_discount_full_annual_early_payment | result.evaluations[0].amount | -1650000 | -3300000 | 1650000 | ERROR |
| 009_discount_full_annual_early_payment | result.evaluations[0].label | "Paiement annuel avant le 30 juin (-5% scolarité)" | "Paiement annuel avant le 30 juin (-10%)" | — | WARNING |
| 009_discount_full_annual_early_payment | result.totalDiscount | -1650000 | -3300000 | 1650000 | ERROR |
| 010_discount_highest_average | result.discountsApplied[0] | undefined | "highest_average" | — | WARNING |
| 010_discount_highest_average | result.evaluations[0] | undefined | {"amount":-3300000,"applied":true,"code":"highest_average"," | — | WARNING |
| 010_discount_highest_average | result.totalDiscount | 0 | -3300000 | 3300000 | ERROR |
| 011_discount_seniority_5y | result.discountsApplied[0] | undefined | "seniority_5y" | — | WARNING |
| 011_discount_seniority_5y | result.evaluations[0] | undefined | {"amount":-1650000,"applied":true,"code":"seniority_5y","lab | — | WARNING |
| 011_discount_seniority_5y | result.totalDiscount | 0 | -1650000 | 1650000 | ERROR |
| 012_discount_all_5_rules_combined | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| 012_discount_all_5_rules_combined | result.discountsApplied[1] | "full_annual" | "sibling_fixed" | — | WARNING |
| 012_discount_all_5_rules_combined | result.discountsApplied[2] | undefined | "full_annual" | — | WARNING |
| 012_discount_all_5_rules_combined | result.discountsApplied[3] | undefined | "highest_average" | — | WARNING |
| 012_discount_all_5_rules_combined | result.discountsApplied[4] | undefined | "seniority_5y" | — | WARNING |
| 012_discount_all_5_rules_combined | result.evaluations[0].amount | -500000 | -1000000 | 500000 | ERROR |
| 012_discount_all_5_rules_combined | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| 012_discount_all_5_rules_combined | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| 012_discount_all_5_rules_combined | result.evaluations[0].reason | "Enfant 2 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| 012_discount_all_5_rules_combined | result.evaluations[1].amount | -1650000 | -500000 | -1150000 | ERROR |
| 012_discount_all_5_rules_combined | result.evaluations[1].code | "full_annual" | "sibling_fixed" | — | WARNING |
| 012_discount_all_5_rules_combined | result.evaluations[1].label | "Paiement annuel avant le 30 juin (-5% scolarité)" | "Fratrie — enfant #2 (-5000 DA)" | — | WARNING |
| 012_discount_all_5_rules_combined | result.evaluations[1].reason | "Paiement intégral avant le 30 juin" | "Enfant 2 de la fratrie" | — | WARNING |
| 012_discount_all_5_rules_combined | result.evaluations[2] | undefined | {"amount":-3300000,"applied":true,"code":"full_annual","labe | — | WARNING |
| 012_discount_all_5_rules_combined | result.evaluations[3] | undefined | {"amount":-3300000,"applied":true,"code":"highest_average"," | — | WARNING |
| 012_discount_all_5_rules_combined | result.evaluations[4] | undefined | {"amount":-1650000,"applied":true,"code":"seniority_5y","lab | — | WARNING |
| 012_discount_all_5_rules_combined | result.totalDiscount | -2150000 | -9750000 | 7600000 | ERROR |
| 015_reconcile_detects_orphan_reversal | result.violations[0].details | {"reversesId":"led-999-does-not-exist"} | null | — | WARNING |
| 017_zero_payment | error (error-vs-success) | "Payment amount must be > 0 (got 0)" | "no error" | — | ERROR |
| gen_boundary_0014 | error (error-vs-success) | "Payment amount must be > 0 (got 0)" | "no error" | — | ERROR |
| gen_boundary_0254 | error (error-vs-success) | "Payment amount must be > 0 (got 0)" | "no error" | — | ERROR |
| gen_boundary_0270 | error (error-vs-success) | "Payment amount must be > 0 (got 0)" | "no error" | — | ERROR |
| gen_boundary_0350 | error (error-vs-success) | "Payment amount must be > 0 (got 0)" | "no error" | — | ERROR |
| gen_boundary_0358 | error (error-vs-success) | "Payment amount must be > 0 (got 0)" | "no error" | — | ERROR |
| gen_boundary_0390 | error (error-vs-success) | "Payment amount must be > 0 (got 0)" | "no error" | — | ERROR |
| gen_boundary_0422 | error (error-vs-success) | "Payment amount must be > 0 (got 0)" | "no error" | — | ERROR |
| gen_boundary_0454 | error (error-vs-success) | "Payment amount must be > 0 (got 0)" | "no error" | — | ERROR |
| gen_boundary_0470 | error (error-vs-success) | "Payment amount must be > 0 (got 0)" | "no error" | — | ERROR |
| gen_discount_0004 | result.discountsApplied[1] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0004 | result.evaluations[0].amount | -1000000 | -2000000 | 1000000 | ERROR |
| gen_discount_0004 | result.evaluations[0].label | "Paiement annuel avant le 30 juin (-5% scolarité)" | "Paiement annuel avant le 30 juin (-10%)" | — | WARNING |
| gen_discount_0004 | result.evaluations[1] | undefined | {"amount":-1000000,"applied":true,"code":"seniority_5y","lab | — | WARNING |
| gen_discount_0004 | result.totalDiscount | -1000000 | -3000000 | 2000000 | ERROR |
| gen_discount_0012 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0012 | result.discountsApplied[1] | "full_annual" | "sibling_fixed" | — | WARNING |
| gen_discount_0012 | result.discountsApplied[2] | undefined | "full_annual" | — | WARNING |
| gen_discount_0012 | result.discountsApplied[3] | undefined | "highest_average" | — | WARNING |
| gen_discount_0012 | result.evaluations[0].amount | -1500000 | -1000000 | -500000 | ERROR |
| gen_discount_0012 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0012 | result.evaluations[0].label | "Fratrie — enfant #4 (-15 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0012 | result.evaluations[0].reason | "Enfant 4 de la fratrie" | "Transition 4am → 1ere_annee" | — | WARNING |
| gen_discount_0012 | result.evaluations[1].amount | -2500000 | -1500000 | -1000000 | ERROR |
| gen_discount_0012 | result.evaluations[1].code | "full_annual" | "sibling_fixed" | — | WARNING |
| gen_discount_0012 | result.evaluations[1].label | "Paiement annuel avant le 30 juin (-5% scolarité)" | "Fratrie — enfant #4 (-15000 DA)" | — | WARNING |
| gen_discount_0012 | result.evaluations[1].reason | "Paiement intégral avant le 30 juin" | "Enfant 4 de la fratrie" | — | WARNING |
| gen_discount_0012 | result.evaluations[2] | undefined | {"amount":-5000000,"applied":true,"code":"full_annual","labe | — | WARNING |
| gen_discount_0012 | result.evaluations[3] | undefined | {"amount":-5000000,"applied":true,"code":"highest_average"," | — | WARNING |
| gen_discount_0012 | result.totalDiscount | -4000000 | -12500000 | 8500000 | ERROR |
| gen_discount_0020 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0020 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0020 | result.evaluations[0].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0020 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0020 | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0020 | result.evaluations[0].reason | "Enfant 2 de la fratrie" | "Transition 4am → 1ere_annee" | — | WARNING |
| gen_discount_0020 | result.evaluations[1] | undefined | {"amount":-500000,"applied":true,"code":"sibling_fixed","lab | — | WARNING |
| gen_discount_0020 | result.totalDiscount | -500000 | -1500000 | 1000000 | ERROR |
| gen_discount_0028 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0028 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0028 | result.discountsApplied[2] | undefined | "highest_average" | — | WARNING |
| gen_discount_0028 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0028 | result.evaluations[0].label | "Fratrie — enfant #3 (-10 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0028 | result.evaluations[0].reason | "Enfant 3 de la fratrie" | "Transition 4am → 1ere_annee" | — | WARNING |
| gen_discount_0028 | result.evaluations[1] | undefined | {"amount":-1000000,"applied":true,"code":"sibling_fixed","la | — | WARNING |
| gen_discount_0028 | result.evaluations[2] | undefined | {"amount":-2000000,"applied":true,"code":"highest_average"," | — | WARNING |
| gen_discount_0028 | result.totalDiscount | -1000000 | -4000000 | 3000000 | ERROR |
| gen_discount_0036 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0036 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0036 | result.discountsApplied[2] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0036 | result.evaluations[0].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0036 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0036 | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0036 | result.evaluations[0].reason | "Enfant 2 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0036 | result.evaluations[1] | undefined | {"amount":-500000,"applied":true,"code":"sibling_fixed","lab | — | WARNING |
| gen_discount_0036 | result.evaluations[2] | undefined | {"amount":-1650000,"applied":true,"code":"seniority_5y","lab | — | WARNING |
| gen_discount_0036 | result.totalDiscount | -500000 | -3150000 | 2650000 | ERROR |
| gen_discount_0044 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0044 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0044 | result.evaluations[0].amount | -1500000 | -1000000 | -500000 | ERROR |
| gen_discount_0044 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0044 | result.evaluations[0].label | "Fratrie — enfant #4 (-15 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0044 | result.evaluations[0].reason | "Enfant 4 de la fratrie" | "Transition 4am → 1ere_annee" | — | WARNING |
| gen_discount_0044 | result.evaluations[1] | undefined | {"amount":-1500000,"applied":true,"code":"sibling_fixed","la | — | WARNING |
| gen_discount_0044 | result.totalDiscount | -1500000 | -2500000 | 1000000 | ERROR |
| gen_discount_0052 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0052 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0052 | result.discountsApplied[2] | undefined | "highest_average" | — | WARNING |
| gen_discount_0052 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0052 | result.evaluations[0].label | "Fratrie — enfant #3 (-10 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0052 | result.evaluations[0].reason | "Enfant 3 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0052 | result.evaluations[1] | undefined | {"amount":-1000000,"applied":true,"code":"sibling_fixed","la | — | WARNING |
| gen_discount_0052 | result.evaluations[2] | undefined | {"amount":-10000000,"applied":true,"code":"highest_average", | — | WARNING |
| gen_discount_0052 | result.totalDiscount | -1000000 | -12000000 | 11000000 | ERROR |
| gen_discount_0060 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0060 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0060 | result.discountsApplied[2] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0060 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0060 | result.evaluations[0].label | "Fratrie — enfant #3 (-10 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0060 | result.evaluations[0].reason | "Enfant 3 de la fratrie" | "Transition 4am → 1ere_annee" | — | WARNING |
| gen_discount_0060 | result.evaluations[1] | undefined | {"amount":-1000000,"applied":true,"code":"sibling_fixed","la | — | WARNING |
| gen_discount_0060 | result.evaluations[2] | undefined | {"amount":-500000,"applied":true,"code":"seniority_5y","labe | — | WARNING |
| gen_discount_0060 | result.totalDiscount | -1000000 | -2500000 | 1500000 | ERROR |
| gen_discount_0076 | result.evaluations[0].label | "Fratrie — enfant #3 (-10 0 DA)" | "Fratrie — enfant #3 (-10000 DA)" | — | WARNING |
| gen_discount_0084 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0084 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0084 | result.discountsApplied[2] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0084 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0084 | result.evaluations[0].label | "Fratrie — enfant #3 (-10 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0084 | result.evaluations[0].reason | "Enfant 3 de la fratrie" | "Transition 4am → 1ere_annee" | — | WARNING |
| gen_discount_0084 | result.evaluations[1] | undefined | {"amount":-1000000,"applied":true,"code":"sibling_fixed","la | — | WARNING |
| gen_discount_0084 | result.evaluations[2] | undefined | {"amount":-2500000,"applied":true,"code":"seniority_5y","lab | — | WARNING |
| gen_discount_0084 | result.totalDiscount | -1000000 | -4500000 | 3500000 | ERROR |
| gen_discount_0092 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0092 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0092 | result.discountsApplied[2] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0092 | result.evaluations[0].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0092 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0092 | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0092 | result.evaluations[0].reason | "Enfant 2 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0092 | result.evaluations[1] | undefined | {"amount":-500000,"applied":true,"code":"sibling_fixed","lab | — | WARNING |
| gen_discount_0092 | result.evaluations[2] | undefined | {"amount":-5000000,"applied":true,"code":"seniority_5y","lab | — | WARNING |
| gen_discount_0092 | result.totalDiscount | -500000 | -6500000 | 6000000 | ERROR |
| gen_discount_0108 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0108 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0108 | result.discountsApplied[2] | undefined | "highest_average" | — | WARNING |
| gen_discount_0108 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0108 | result.evaluations[0].label | "Fratrie — enfant #3 (-10 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0108 | result.evaluations[0].reason | "Enfant 3 de la fratrie" | "Transition 4am → 1ere_annee" | — | WARNING |
| gen_discount_0108 | result.evaluations[1] | undefined | {"amount":-1000000,"applied":true,"code":"sibling_fixed","la | — | WARNING |
| gen_discount_0108 | result.evaluations[2] | undefined | {"amount":-2000000,"applied":true,"code":"highest_average"," | — | WARNING |
| gen_discount_0108 | result.totalDiscount | -1000000 | -4000000 | 3000000 | ERROR |
| gen_discount_0116 | result.discountsApplied[0] | undefined | "passage_palier" | — | WARNING |
| gen_discount_0116 | result.discountsApplied[1] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0116 | result.evaluations[0] | undefined | {"amount":-1000000,"applied":true,"code":"passage_palier","l | — | WARNING |
| gen_discount_0116 | result.evaluations[1] | undefined | {"amount":-1650000,"applied":true,"code":"seniority_5y","lab | — | WARNING |
| gen_discount_0116 | result.totalDiscount | 0 | -2650000 | 2650000 | ERROR |
| gen_discount_0124 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0124 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0124 | result.discountsApplied[2] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0124 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0124 | result.evaluations[0].label | "Fratrie — enfant #3 (-10 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0124 | result.evaluations[0].reason | "Enfant 3 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0124 | result.evaluations[1] | undefined | {"amount":-1000000,"applied":true,"code":"sibling_fixed","la | — | WARNING |
| gen_discount_0124 | result.evaluations[2] | undefined | {"amount":-500000,"applied":true,"code":"seniority_5y","labe | — | WARNING |
| gen_discount_0124 | result.totalDiscount | -1000000 | -2500000 | 1500000 | ERROR |
| gen_discount_0132 | result.evaluations[0].label | "Fratrie — enfant #4 (-15 0 DA)" | "Fratrie — enfant #4 (-15000 DA)" | — | WARNING |
| gen_discount_0140 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0140 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0140 | result.discountsApplied[2] | undefined | "highest_average" | — | WARNING |
| gen_discount_0140 | result.evaluations[0].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0140 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0140 | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0140 | result.evaluations[0].reason | "Enfant 2 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0140 | result.evaluations[1] | undefined | {"amount":-500000,"applied":true,"code":"sibling_fixed","lab | — | WARNING |
| gen_discount_0140 | result.evaluations[2] | undefined | {"amount":-5000000,"applied":true,"code":"highest_average"," | — | WARNING |
| gen_discount_0140 | result.totalDiscount | -500000 | -6500000 | 6000000 | ERROR |
| gen_discount_0148 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0148 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0148 | result.discountsApplied[2] | undefined | "highest_average" | — | WARNING |
| gen_discount_0148 | result.discountsApplied[3] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0148 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0148 | result.evaluations[0].label | "Fratrie — enfant #3 (-10 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0148 | result.evaluations[0].reason | "Enfant 3 de la fratrie" | "Transition 4am → 1ere_annee" | — | WARNING |
| gen_discount_0148 | result.evaluations[1] | undefined | {"amount":-1000000,"applied":true,"code":"sibling_fixed","la | — | WARNING |
| gen_discount_0148 | result.evaluations[2] | undefined | {"amount":-1000000,"applied":true,"code":"highest_average"," | — | WARNING |
| gen_discount_0148 | result.evaluations[3] | undefined | {"amount":-500000,"applied":true,"code":"seniority_5y","labe | — | WARNING |
| gen_discount_0148 | result.totalDiscount | -1000000 | -3500000 | 2500000 | ERROR |
| gen_discount_0156 | result.evaluations[0].label | "Fratrie — enfant #4 (-15 0 DA)" | "Fratrie — enfant #4 (-15000 DA)" | — | WARNING |
| gen_discount_0156 | result.evaluations[1].amount | -1000000 | -2000000 | 1000000 | ERROR |
| gen_discount_0156 | result.evaluations[1].label | "Paiement annuel avant le 30 juin (-5% scolarité)" | "Paiement annuel avant le 30 juin (-10%)" | — | WARNING |
| gen_discount_0156 | result.totalDiscount | -2500000 | -3500000 | 1000000 | ERROR |
| gen_discount_0164 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0164 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0164 | result.evaluations[0].amount | -1500000 | -1000000 | -500000 | ERROR |
| gen_discount_0164 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0164 | result.evaluations[0].label | "Fratrie — enfant #4 (-15 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0164 | result.evaluations[0].reason | "Enfant 4 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0164 | result.evaluations[1] | undefined | {"amount":-1500000,"applied":true,"code":"sibling_fixed","la | — | WARNING |
| gen_discount_0164 | result.totalDiscount | -1500000 | -2500000 | 1000000 | ERROR |
| gen_discount_0172 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0172 | result.discountsApplied[1] | "full_annual" | "sibling_fixed" | — | WARNING |
| gen_discount_0172 | result.discountsApplied[2] | undefined | "full_annual" | — | WARNING |
| gen_discount_0172 | result.evaluations[0].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0172 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0172 | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0172 | result.evaluations[0].reason | "Enfant 2 de la fratrie" | "Transition 4am → 1ere_annee" | — | WARNING |
| gen_discount_0172 | result.evaluations[1].amount | -2500000 | -500000 | -2000000 | ERROR |
| gen_discount_0172 | result.evaluations[1].code | "full_annual" | "sibling_fixed" | — | WARNING |
| gen_discount_0172 | result.evaluations[1].label | "Paiement annuel avant le 30 juin (-5% scolarité)" | "Fratrie — enfant #2 (-5000 DA)" | — | WARNING |
| gen_discount_0172 | result.evaluations[1].reason | "Paiement intégral avant le 30 juin" | "Enfant 2 de la fratrie" | — | WARNING |
| gen_discount_0172 | result.evaluations[2] | undefined | {"amount":-5000000,"applied":true,"code":"full_annual","labe | — | WARNING |
| gen_discount_0172 | result.totalDiscount | -3000000 | -6500000 | 3500000 | ERROR |
| gen_discount_0180 | result.discountsApplied[0] | undefined | "passage_palier" | — | WARNING |
| gen_discount_0180 | result.discountsApplied[1] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0180 | result.evaluations[0] | undefined | {"amount":-1000000,"applied":true,"code":"passage_palier","l | — | WARNING |
| gen_discount_0180 | result.evaluations[1] | undefined | {"amount":-500000,"applied":true,"code":"seniority_5y","labe | — | WARNING |
| gen_discount_0180 | result.totalDiscount | 0 | -1500000 | 1500000 | ERROR |
| gen_discount_0188 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0188 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0188 | result.discountsApplied[2] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0188 | result.evaluations[0].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0188 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0188 | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0188 | result.evaluations[0].reason | "Enfant 2 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0188 | result.evaluations[1] | undefined | {"amount":-500000,"applied":true,"code":"sibling_fixed","lab | — | WARNING |
| gen_discount_0188 | result.evaluations[2] | undefined | {"amount":-2500000,"applied":true,"code":"seniority_5y","lab | — | WARNING |
| gen_discount_0188 | result.totalDiscount | -500000 | -4000000 | 3500000 | ERROR |
| gen_discount_0196 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0196 | result.discountsApplied[1] | "full_annual" | "sibling_fixed" | — | WARNING |
| gen_discount_0196 | result.discountsApplied[2] | undefined | "full_annual" | — | WARNING |
| gen_discount_0196 | result.evaluations[0].amount | -1500000 | -1000000 | -500000 | ERROR |
| gen_discount_0196 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0196 | result.evaluations[0].label | "Fratrie — enfant #4 (-15 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0196 | result.evaluations[0].reason | "Enfant 4 de la fratrie" | "Transition 4am → 1ere_annee" | — | WARNING |
| gen_discount_0196 | result.evaluations[1].amount | -500000 | -1500000 | 1000000 | ERROR |
| gen_discount_0196 | result.evaluations[1].code | "full_annual" | "sibling_fixed" | — | WARNING |
| gen_discount_0196 | result.evaluations[1].label | "Paiement annuel avant le 30 juin (-5% scolarité)" | "Fratrie — enfant #4 (-15000 DA)" | — | WARNING |
| gen_discount_0196 | result.evaluations[1].reason | "Paiement intégral avant le 30 juin" | "Enfant 4 de la fratrie" | — | WARNING |
| gen_discount_0196 | result.evaluations[2] | undefined | {"amount":-1000000,"applied":true,"code":"full_annual","labe | — | WARNING |
| gen_discount_0196 | result.totalDiscount | -2000000 | -3500000 | 1500000 | ERROR |
| gen_discount_0204 | result.discountsApplied[2] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0204 | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Fratrie — enfant #2 (-5000 DA)" | — | WARNING |
| gen_discount_0204 | result.evaluations[1].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0204 | result.evaluations[1].label | "Paiement annuel avant le 30 juin (-5% scolarité)" | "Paiement annuel avant le 30 juin (-10%)" | — | WARNING |
| gen_discount_0204 | result.evaluations[2] | undefined | {"amount":-500000,"applied":true,"code":"seniority_5y","labe | — | WARNING |
| gen_discount_0204 | result.totalDiscount | -1000000 | -2000000 | 1000000 | ERROR |
| gen_discount_0212 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0212 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0212 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0212 | result.evaluations[0].label | "Fratrie — enfant #3 (-10 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0212 | result.evaluations[0].reason | "Enfant 3 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0212 | result.evaluations[1] | undefined | {"amount":-1000000,"applied":true,"code":"sibling_fixed","la | — | WARNING |
| gen_discount_0212 | result.totalDiscount | -1000000 | -2000000 | 1000000 | ERROR |
| gen_discount_0220 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0220 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0220 | result.discountsApplied[2] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0220 | result.evaluations[0].amount | -1500000 | -1000000 | -500000 | ERROR |
| gen_discount_0220 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0220 | result.evaluations[0].label | "Fratrie — enfant #4 (-15 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0220 | result.evaluations[0].reason | "Enfant 4 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0220 | result.evaluations[1] | undefined | {"amount":-1500000,"applied":true,"code":"sibling_fixed","la | — | WARNING |
| gen_discount_0220 | result.evaluations[2] | undefined | {"amount":-1650000,"applied":true,"code":"seniority_5y","lab | — | WARNING |
| gen_discount_0220 | result.totalDiscount | -1500000 | -4150000 | 2650000 | ERROR |
| gen_discount_0228 | result.discountsApplied[1] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0228 | result.evaluations[0].label | "Fratrie — enfant #4 (-15 0 DA)" | "Fratrie — enfant #4 (-15000 DA)" | — | WARNING |
| gen_discount_0228 | result.evaluations[1] | undefined | {"amount":-2500000,"applied":true,"code":"seniority_5y","lab | — | WARNING |
| gen_discount_0228 | result.totalDiscount | -1500000 | -4000000 | 2500000 | ERROR |
| gen_discount_0236 | result.discountsApplied[1] | undefined | "highest_average" | — | WARNING |
| gen_discount_0236 | result.discountsApplied[2] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0236 | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Fratrie — enfant #2 (-5000 DA)" | — | WARNING |
| gen_discount_0236 | result.evaluations[1] | undefined | {"amount":-10000000,"applied":true,"code":"highest_average", | — | WARNING |
| gen_discount_0236 | result.evaluations[2] | undefined | {"amount":-5000000,"applied":true,"code":"seniority_5y","lab | — | WARNING |
| gen_discount_0236 | result.totalDiscount | -500000 | -15500000 | 15000000 | ERROR |
| gen_discount_0244 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0244 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0244 | result.discountsApplied[2] | undefined | "highest_average" | — | WARNING |
| gen_discount_0244 | result.discountsApplied[3] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0244 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0244 | result.evaluations[0].label | "Fratrie — enfant #3 (-10 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0244 | result.evaluations[0].reason | "Enfant 3 de la fratrie" | "Transition 4am → 1ere_annee" | — | WARNING |
| gen_discount_0244 | result.evaluations[1] | undefined | {"amount":-1000000,"applied":true,"code":"sibling_fixed","la | — | WARNING |
| gen_discount_0244 | result.evaluations[2] | undefined | {"amount":-2000000,"applied":true,"code":"highest_average"," | — | WARNING |
| gen_discount_0244 | result.evaluations[3] | undefined | {"amount":-1000000,"applied":true,"code":"seniority_5y","lab | — | WARNING |
| gen_discount_0244 | result.totalDiscount | -1000000 | -5000000 | 4000000 | ERROR |
| gen_discount_0252 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0252 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0252 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0252 | result.evaluations[0].label | "Fratrie — enfant #3 (-10 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0252 | result.evaluations[0].reason | "Enfant 3 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0252 | result.evaluations[1] | undefined | {"amount":-1000000,"applied":true,"code":"sibling_fixed","la | — | WARNING |
| gen_discount_0252 | result.totalDiscount | -1000000 | -2000000 | 1000000 | ERROR |
| gen_discount_0260 | result.discountsApplied[2] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0260 | result.evaluations[0].label | "Fratrie — enfant #4 (-15 0 DA)" | "Fratrie — enfant #4 (-15000 DA)" | — | WARNING |
| gen_discount_0260 | result.evaluations[1].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0260 | result.evaluations[1].label | "Paiement annuel avant le 30 juin (-5% scolarité)" | "Paiement annuel avant le 30 juin (-10%)" | — | WARNING |
| gen_discount_0260 | result.evaluations[2] | undefined | {"amount":-500000,"applied":true,"code":"seniority_5y","labe | — | WARNING |
| gen_discount_0260 | result.totalDiscount | -2000000 | -3000000 | 1000000 | ERROR |
| gen_discount_0268 | result.discountsApplied[0] | undefined | "passage_palier" | — | WARNING |
| gen_discount_0268 | result.evaluations[0] | undefined | {"amount":-1000000,"applied":true,"code":"passage_palier","l | — | WARNING |
| gen_discount_0268 | result.totalDiscount | 0 | -1000000 | 1000000 | ERROR |
| gen_discount_0276 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0276 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0276 | result.evaluations[0].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0276 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0276 | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0276 | result.evaluations[0].reason | "Enfant 2 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0276 | result.evaluations[1] | undefined | {"amount":-500000,"applied":true,"code":"sibling_fixed","lab | — | WARNING |
| gen_discount_0276 | result.totalDiscount | -500000 | -1500000 | 1000000 | ERROR |
| gen_discount_0284 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0284 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0284 | result.discountsApplied[2] | undefined | "highest_average" | — | WARNING |
| gen_discount_0284 | result.discountsApplied[3] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0284 | result.evaluations[0].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0284 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0284 | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0284 | result.evaluations[0].reason | "Enfant 2 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0284 | result.evaluations[1] | undefined | {"amount":-500000,"applied":true,"code":"sibling_fixed","lab | — | WARNING |
| gen_discount_0284 | result.evaluations[2] | undefined | {"amount":-5000000,"applied":true,"code":"highest_average"," | — | WARNING |
| gen_discount_0284 | result.evaluations[3] | undefined | {"amount":-2500000,"applied":true,"code":"seniority_5y","lab | — | WARNING |
| gen_discount_0284 | result.totalDiscount | -500000 | -9000000 | 8500000 | ERROR |
| gen_discount_0292 | result.discountsApplied[1] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0292 | result.evaluations[0].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0292 | result.evaluations[0].label | "Paiement annuel avant le 30 juin (-5% scolarité)" | "Paiement annuel avant le 30 juin (-10%)" | — | WARNING |
| gen_discount_0292 | result.evaluations[1] | undefined | {"amount":-500000,"applied":true,"code":"seniority_5y","labe | — | WARNING |
| gen_discount_0292 | result.totalDiscount | -500000 | -1500000 | 1000000 | ERROR |
| gen_discount_0300 | result.discountsApplied[1] | undefined | "highest_average" | — | WARNING |
| gen_discount_0300 | result.discountsApplied[2] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0300 | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Fratrie — enfant #2 (-5000 DA)" | — | WARNING |
| gen_discount_0300 | result.evaluations[1] | undefined | {"amount":-5000000,"applied":true,"code":"highest_average"," | — | WARNING |
| gen_discount_0300 | result.evaluations[2] | undefined | {"amount":-2500000,"applied":true,"code":"seniority_5y","lab | — | WARNING |
| gen_discount_0300 | result.totalDiscount | -500000 | -8000000 | 7500000 | ERROR |
| gen_discount_0308 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0308 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0308 | result.evaluations[0].amount | -1500000 | -1000000 | -500000 | ERROR |
| gen_discount_0308 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0308 | result.evaluations[0].label | "Fratrie — enfant #4 (-15 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0308 | result.evaluations[0].reason | "Enfant 4 de la fratrie" | "Transition 4am → 1ere_annee" | — | WARNING |
| gen_discount_0308 | result.evaluations[1] | undefined | {"amount":-1500000,"applied":true,"code":"sibling_fixed","la | — | WARNING |
| gen_discount_0308 | result.totalDiscount | -1500000 | -2500000 | 1000000 | ERROR |
| gen_discount_0316 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0316 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0316 | result.discountsApplied[2] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0316 | result.evaluations[0].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0316 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0316 | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0316 | result.evaluations[0].reason | "Enfant 2 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0316 | result.evaluations[1] | undefined | {"amount":-500000,"applied":true,"code":"sibling_fixed","lab | — | WARNING |
| gen_discount_0316 | result.evaluations[2] | undefined | {"amount":-500000,"applied":true,"code":"seniority_5y","labe | — | WARNING |
| gen_discount_0316 | result.totalDiscount | -500000 | -2000000 | 1500000 | ERROR |
| gen_discount_0324 | result.discountsApplied[0] | undefined | "passage_palier" | — | WARNING |
| gen_discount_0324 | result.discountsApplied[1] | undefined | "highest_average" | — | WARNING |
| gen_discount_0324 | result.evaluations[0] | undefined | {"amount":-1000000,"applied":true,"code":"passage_palier","l | — | WARNING |
| gen_discount_0324 | result.evaluations[1] | undefined | {"amount":-1000000,"applied":true,"code":"highest_average"," | — | WARNING |
| gen_discount_0324 | result.totalDiscount | 0 | -2000000 | 2000000 | ERROR |
| gen_discount_0332 | result.discountsApplied[0] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0332 | result.evaluations[0] | undefined | {"amount":-500000,"applied":true,"code":"seniority_5y","labe | — | WARNING |
| gen_discount_0332 | result.totalDiscount | 0 | -500000 | 500000 | ERROR |
| gen_discount_0340 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0340 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0340 | result.discountsApplied[2] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0340 | result.evaluations[0].amount | -1500000 | -1000000 | -500000 | ERROR |
| gen_discount_0340 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0340 | result.evaluations[0].label | "Fratrie — enfant #4 (-15 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0340 | result.evaluations[0].reason | "Enfant 4 de la fratrie" | "Transition 4am → 1ere_annee" | — | WARNING |
| gen_discount_0340 | result.evaluations[1] | undefined | {"amount":-1500000,"applied":true,"code":"sibling_fixed","la | — | WARNING |
| gen_discount_0340 | result.evaluations[2] | undefined | {"amount":-500000,"applied":true,"code":"seniority_5y","labe | — | WARNING |
| gen_discount_0340 | result.totalDiscount | -1500000 | -3000000 | 1500000 | ERROR |
| gen_discount_0348 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0348 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0348 | result.discountsApplied[2] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0348 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0348 | result.evaluations[0].label | "Fratrie — enfant #3 (-10 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0348 | result.evaluations[0].reason | "Enfant 3 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0348 | result.evaluations[1] | undefined | {"amount":-1000000,"applied":true,"code":"sibling_fixed","la | — | WARNING |
| gen_discount_0348 | result.evaluations[2] | undefined | {"amount":-500000,"applied":true,"code":"seniority_5y","labe | — | WARNING |
| gen_discount_0348 | result.totalDiscount | -1000000 | -2500000 | 1500000 | ERROR |
| gen_discount_0356 | result.evaluations[0].label | "Fratrie — enfant #4 (-15 0 DA)" | "Fratrie — enfant #4 (-15000 DA)" | — | WARNING |
| gen_discount_0356 | result.evaluations[1].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0356 | result.evaluations[1].label | "Paiement annuel avant le 30 juin (-5% scolarité)" | "Paiement annuel avant le 30 juin (-10%)" | — | WARNING |
| gen_discount_0356 | result.totalDiscount | -2000000 | -2500000 | 500000 | ERROR |
| gen_discount_0364 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0364 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0364 | result.evaluations[0].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0364 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0364 | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0364 | result.evaluations[0].reason | "Enfant 2 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0364 | result.evaluations[1] | undefined | {"amount":-500000,"applied":true,"code":"sibling_fixed","lab | — | WARNING |
| gen_discount_0364 | result.totalDiscount | -500000 | -1500000 | 1000000 | ERROR |
| gen_discount_0372 | result.evaluations[0].label | "Fratrie — enfant #3 (-10 0 DA)" | "Fratrie — enfant #3 (-10000 DA)" | — | WARNING |
| gen_discount_0372 | result.evaluations[1].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0372 | result.evaluations[1].label | "Paiement annuel avant le 30 juin (-5% scolarité)" | "Paiement annuel avant le 30 juin (-10%)" | — | WARNING |
| gen_discount_0372 | result.totalDiscount | -1500000 | -2000000 | 500000 | ERROR |
| gen_discount_0380 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0380 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0380 | result.discountsApplied[2] | undefined | "highest_average" | — | WARNING |
| gen_discount_0380 | result.evaluations[0].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0380 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0380 | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0380 | result.evaluations[0].reason | "Enfant 2 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0380 | result.evaluations[1] | undefined | {"amount":-500000,"applied":true,"code":"sibling_fixed","lab | — | WARNING |
| gen_discount_0380 | result.evaluations[2] | undefined | {"amount":-2000000,"applied":true,"code":"highest_average"," | — | WARNING |
| gen_discount_0380 | result.totalDiscount | -500000 | -3500000 | 3000000 | ERROR |
| gen_discount_0388 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0388 | result.discountsApplied[1] | "full_annual" | "sibling_fixed" | — | WARNING |
| gen_discount_0388 | result.discountsApplied[2] | undefined | "full_annual" | — | WARNING |
| gen_discount_0388 | result.discountsApplied[3] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0388 | result.evaluations[0].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0388 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0388 | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0388 | result.evaluations[0].reason | "Enfant 2 de la fratrie" | "Transition 4am → 1ere_annee" | — | WARNING |
| gen_discount_0388 | result.evaluations[1].amount | -2500000 | -500000 | -2000000 | ERROR |
| gen_discount_0388 | result.evaluations[1].code | "full_annual" | "sibling_fixed" | — | WARNING |
| gen_discount_0388 | result.evaluations[1].label | "Paiement annuel avant le 30 juin (-5% scolarité)" | "Fratrie — enfant #2 (-5000 DA)" | — | WARNING |
| gen_discount_0388 | result.evaluations[1].reason | "Paiement intégral avant le 30 juin" | "Enfant 2 de la fratrie" | — | WARNING |
| gen_discount_0388 | result.evaluations[2] | undefined | {"amount":-5000000,"applied":true,"code":"full_annual","labe | — | WARNING |
| gen_discount_0388 | result.evaluations[3] | undefined | {"amount":-2500000,"applied":true,"code":"seniority_5y","lab | — | WARNING |
| gen_discount_0388 | result.totalDiscount | -3000000 | -9000000 | 6000000 | ERROR |
| gen_discount_0396 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0396 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0396 | result.discountsApplied[2] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0396 | result.evaluations[0].amount | -1500000 | -1000000 | -500000 | ERROR |
| gen_discount_0396 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0396 | result.evaluations[0].label | "Fratrie — enfant #4 (-15 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0396 | result.evaluations[0].reason | "Enfant 4 de la fratrie" | "Transition 4am → 1ere_annee" | — | WARNING |
| gen_discount_0396 | result.evaluations[1] | undefined | {"amount":-1500000,"applied":true,"code":"sibling_fixed","la | — | WARNING |
| gen_discount_0396 | result.evaluations[2] | undefined | {"amount":-500000,"applied":true,"code":"seniority_5y","labe | — | WARNING |
| gen_discount_0396 | result.totalDiscount | -1500000 | -3000000 | 1500000 | ERROR |
| gen_discount_0404 | result.discountsApplied[0] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0404 | result.evaluations[0] | undefined | {"amount":-2500000,"applied":true,"code":"seniority_5y","lab | — | WARNING |
| gen_discount_0404 | result.totalDiscount | 0 | -2500000 | 2500000 | ERROR |
| gen_discount_0412 | result.discountsApplied[0] | undefined | "passage_palier" | — | WARNING |
| gen_discount_0412 | result.discountsApplied[1] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0412 | result.evaluations[0] | undefined | {"amount":-1000000,"applied":true,"code":"passage_palier","l | — | WARNING |
| gen_discount_0412 | result.evaluations[1] | undefined | {"amount":-5000000,"applied":true,"code":"seniority_5y","lab | — | WARNING |
| gen_discount_0412 | result.totalDiscount | 0 | -6000000 | 6000000 | ERROR |
| gen_discount_0420 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0420 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0420 | result.discountsApplied[2] | undefined | "highest_average" | — | WARNING |
| gen_discount_0420 | result.evaluations[0].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0420 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0420 | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0420 | result.evaluations[0].reason | "Enfant 2 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0420 | result.evaluations[1] | undefined | {"amount":-500000,"applied":true,"code":"sibling_fixed","lab | — | WARNING |
| gen_discount_0420 | result.evaluations[2] | undefined | {"amount":-10000000,"applied":true,"code":"highest_average", | — | WARNING |
| gen_discount_0420 | result.totalDiscount | -500000 | -11500000 | 11000000 | ERROR |
| gen_discount_0428 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0428 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0428 | result.discountsApplied[2] | undefined | "highest_average" | — | WARNING |
| gen_discount_0428 | result.evaluations[0].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0428 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0428 | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0428 | result.evaluations[0].reason | "Enfant 2 de la fratrie" | "Transition 4am → 1ere_annee" | — | WARNING |
| gen_discount_0428 | result.evaluations[1] | undefined | {"amount":-500000,"applied":true,"code":"sibling_fixed","lab | — | WARNING |
| gen_discount_0428 | result.evaluations[2] | undefined | {"amount":-2000000,"applied":true,"code":"highest_average"," | — | WARNING |
| gen_discount_0428 | result.totalDiscount | -500000 | -3500000 | 3000000 | ERROR |
| gen_discount_0436 | result.evaluations[0].label | "Fratrie — enfant #4 (-15 0 DA)" | "Fratrie — enfant #4 (-15000 DA)" | — | WARNING |
| gen_discount_0444 | result.discountsApplied[0] | undefined | "passage_palier" | — | WARNING |
| gen_discount_0444 | result.discountsApplied[1] | undefined | "highest_average" | — | WARNING |
| gen_discount_0444 | result.evaluations[0] | undefined | {"amount":-1000000,"applied":true,"code":"passage_palier","l | — | WARNING |
| gen_discount_0444 | result.evaluations[1] | undefined | {"amount":-2000000,"applied":true,"code":"highest_average"," | — | WARNING |
| gen_discount_0444 | result.totalDiscount | 0 | -3000000 | 3000000 | ERROR |
| gen_discount_0452 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0452 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0452 | result.discountsApplied[2] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0452 | result.evaluations[0].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0452 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0452 | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0452 | result.evaluations[0].reason | "Enfant 2 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0452 | result.evaluations[1] | undefined | {"amount":-500000,"applied":true,"code":"sibling_fixed","lab | — | WARNING |
| gen_discount_0452 | result.evaluations[2] | undefined | {"amount":-5000000,"applied":true,"code":"seniority_5y","lab | — | WARNING |
| gen_discount_0452 | result.totalDiscount | -500000 | -6500000 | 6000000 | ERROR |
| gen_discount_0460 | result.discountsApplied[0] | undefined | "passage_palier" | — | WARNING |
| gen_discount_0460 | result.evaluations[0] | undefined | {"amount":-1000000,"applied":true,"code":"passage_palier","l | — | WARNING |
| gen_discount_0460 | result.totalDiscount | 0 | -1000000 | 1000000 | ERROR |
| gen_discount_0468 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0468 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0468 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0468 | result.evaluations[0].label | "Fratrie — enfant #3 (-10 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0468 | result.evaluations[0].reason | "Enfant 3 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0468 | result.evaluations[1] | undefined | {"amount":-1000000,"applied":true,"code":"sibling_fixed","la | — | WARNING |
| gen_discount_0468 | result.totalDiscount | -1000000 | -2000000 | 1000000 | ERROR |
| gen_discount_0476 | result.discountsApplied[0] | "full_annual" | "passage_palier" | — | WARNING |
| gen_discount_0476 | result.discountsApplied[1] | undefined | "full_annual" | — | WARNING |
| gen_discount_0476 | result.evaluations[0].amount | -2500000 | -1000000 | -1500000 | ERROR |
| gen_discount_0476 | result.evaluations[0].code | "full_annual" | "passage_palier" | — | WARNING |
| gen_discount_0476 | result.evaluations[0].label | "Paiement annuel avant le 30 juin (-5% scolarité)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0476 | result.evaluations[0].reason | "Paiement intégral avant le 30 juin" | "Transition 4am → 1ere_annee" | — | WARNING |
| gen_discount_0476 | result.evaluations[1] | undefined | {"amount":-5000000,"applied":true,"code":"full_annual","labe | — | WARNING |
| gen_discount_0476 | result.totalDiscount | -2500000 | -6000000 | 3500000 | ERROR |
| gen_discount_0484 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0484 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0484 | result.evaluations[0].amount | -500000 | -1000000 | 500000 | ERROR |
| gen_discount_0484 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0484 | result.evaluations[0].label | "Fratrie — enfant #2 (-5 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0484 | result.evaluations[0].reason | "Enfant 2 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0484 | result.evaluations[1] | undefined | {"amount":-500000,"applied":true,"code":"sibling_fixed","lab | — | WARNING |
| gen_discount_0484 | result.totalDiscount | -500000 | -1500000 | 1000000 | ERROR |
| gen_discount_0492 | result.discountsApplied[0] | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0492 | result.discountsApplied[1] | undefined | "sibling_fixed" | — | WARNING |
| gen_discount_0492 | result.discountsApplied[2] | undefined | "seniority_5y" | — | WARNING |
| gen_discount_0492 | result.evaluations[0].amount | -1500000 | -1000000 | -500000 | ERROR |
| gen_discount_0492 | result.evaluations[0].code | "sibling_fixed" | "passage_palier" | — | WARNING |
| gen_discount_0492 | result.evaluations[0].label | "Fratrie — enfant #4 (-15 0 DA)" | "Passage de palier (-10 000 DA)" | — | WARNING |
| gen_discount_0492 | result.evaluations[0].reason | "Enfant 4 de la fratrie" | "Transition 5ap → 1am" | — | WARNING |
| gen_discount_0492 | result.evaluations[1] | undefined | {"amount":-1500000,"applied":true,"code":"sibling_fixed","la | — | WARNING |
| gen_discount_0492 | result.evaluations[2] | undefined | {"amount":-2500000,"applied":true,"code":"seniority_5y","lab | — | WARNING |
| gen_discount_0492 | result.totalDiscount | -1500000 | -5000000 | 3500000 | ERROR |

## Methodology

1. Both engines received the **exact same canonical JSON scenarios** from `scenarios/` (hand-crafted) and `generated/` (mulberry32 PRNG).
2. Each engine normalized its result to centimes (the canonical scenario format).
3. The comparator performs **deep equality** at centime-level precision.
4. The only normalization applied is for representational differences (date format → epoch millis, key ordering).
5. **No rounding or tolerance is applied to financial values.**
