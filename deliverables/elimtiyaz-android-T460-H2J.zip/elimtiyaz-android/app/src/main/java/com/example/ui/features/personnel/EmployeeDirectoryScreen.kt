package com.example.ui.features.personnel

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Text
import com.example.ui.designsystem.overlays.ElDialogShell
import com.example.ui.designsystem.overlays.LocalElToast
import com.example.ui.designsystem.theme.ElTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.core.Permission
import com.example.core.Session
import com.example.domain.model.Personnel
import com.example.domain.repository.CreatePersonnelInput
import com.example.ui.designsystem.components.button.ElButton
import com.example.ui.designsystem.components.button.ElButtonVariant
import com.example.ui.designsystem.components.card.ElCard
import com.example.ui.designsystem.components.card.ElCardSize
import com.example.ui.designsystem.components.display.ElAvatar
import com.example.ui.designsystem.components.display.ElAvatarSize
import com.example.ui.designsystem.components.display.ElChip
import com.example.ui.designsystem.components.display.ElChipVariant
import com.example.ui.designsystem.components.display.ElSectionHeader
import com.example.ui.designsystem.components.display.ElTag
import com.example.ui.designsystem.components.display.ElTagSize
import com.example.ui.designsystem.components.display.ElTagTone
import com.example.ui.designsystem.components.button.ElFab
import com.example.ui.designsystem.components.tabs.ElScrollableTabRow
import com.example.ui.designsystem.components.feedback.ElEmptyState
import com.example.ui.designsystem.components.input.ElSearchBar
import com.example.ui.designsystem.components.input.ElTextField
import com.example.ui.util.PhoneUtils
import kotlinx.datetime.Clock
import kotlinx.datetime.TimeZone
import kotlinx.datetime.todayIn

private fun roleDisplayLabel(code: String): String = when (code.lowercase()) {
    "teacher" -> "Enseignants"
    "super_admin" -> "Direction"
    "financial_officer" -> "Finances"
    "support_staff" -> "Support"
    "driver" -> "Chauffeurs"
    "buyer" -> "Achats"
    "warehouse_worker" -> "Magasin"
    "worker" -> "Services"
    else -> code.replace("_", " ").replaceFirstChar { it.uppercase() }
}

private val STAFF_ROLE_OPTIONS: List<Pair<String, String>> = listOf(
    "teacher" to "Enseignant",
    "super_admin" to "Direction",
    "financial_officer" to "Finances",
    "support_staff" to "Support",
    "manager" to "Management",
    "driver" to "Chauffeur",
    "buyer" to "Achats",
    "warehouse_worker" to "Magasin",
    "worker" to "Services",
)

/**
 * T-460 pass J (issue #3 F-13): the directory filter — category tab × text
 * search. Pure function so the parity behaviour is unit-testable without
 * composition (the Student/Parents directories' search contract).
 */
internal fun filterPersonnel(
    personnel: List<Personnel>,
    category: String?,
    query: String,
): List<Personnel> {
    val q = query.trim()
    return personnel
        .let { list -> if (category == null || category == "all") list else list.filter { it.staffCategory == category } }
        .let { list ->
            if (q.isBlank()) list
            else list.filter {
                it.fullName.contains(q, ignoreCase = true) ||
                    it.position.contains(q, ignoreCase = true) ||
                    it.phone.contains(q, ignoreCase = true) ||
                    it.email?.contains(q, ignoreCase = true) == true
            }
        }
}

@Composable
fun EmployeeDirectoryScreen(
    session: Session,
    onNavigateToPersonnelDetail: (String) -> Unit = {},
    viewModel: EmployeeDirectoryViewModel = hiltViewModel(),
) {
    val personnel by viewModel.personnel.collectAsState()
    val query by viewModel.query.collectAsState()
    val departments by viewModel.departments.collectAsState()
    val error by viewModel.error.collectAsState()
    val message by viewModel.message.collectAsState()
    val busy by viewModel.busy.collectAsState()
    val context = LocalContext.current
    val toast = LocalElToast.current
    val c = ElTheme.colors

    var selectedCategoryTab by remember { mutableIntStateOf(0) }
    var showCreateDialog by remember { mutableStateOf(false) }

    val rawCategories = remember(personnel) {
        val distinct = personnel.map { it.staffCategory }.distinct().sorted()
        listOf("all") + distinct
    }
    val tabLabels = remember(rawCategories) {
        rawCategories.map { if (it == "all") "Tous" else roleDisplayLabel(it) }
    }
    val filteredStaff = remember(selectedCategoryTab, personnel, query) {
        filterPersonnel(personnel, rawCategories.getOrNull(selectedCategoryTab), query)
    }

    val canManage = session.can(Permission.MANAGE_PERSONNEL) || viewModel.canManage

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            ElSectionHeader(title = "Registre du Personnel (${personnel.size})")

            message?.let {
                Text(it, color = c.primary, style = ElTheme.typography.bodySmall)
            }
            error?.let {
                Text(it, color = c.danger, style = ElTheme.typography.bodySmall)
            }

            if (tabLabels.size > 1) {
                // T-460 pass F: the LEGACY ui.components.ElScrollableTabRow
                // (old tokens) → the DS tabs one (same behaviour, DS pills).
                ElScrollableTabRow(
                    tabs = tabLabels,
                    selectedIndex = selectedCategoryTab,
                    onSelected = { selectedCategoryTab = it },
                )
            }

            // T-460 pass J (issue #3 F-13): text-search parity with the
            // Student/Parents directories (name, position, phone, email).
            ElSearchBar(
                query = query,
                onQueryChange = viewModel::setQuery,
                placeholder = "Nom, fonction, téléphone…",
                modifier = Modifier.fillMaxWidth(),
            )

            if (filteredStaff.isEmpty()) {
                ElEmptyState(
                    icon = Icons.Default.Phone,
                    title = "Aucun personnel",
                    subtitle = if (query.isBlank()) "Aucun employé dans cette catégorie." else "Aucun employé ne correspond à « $query ».",
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxSize()) {
                    items(filteredStaff) { staff ->
                        EmployeeCard(
                            staff = staff,
                            onClick = { onNavigateToPersonnelDetail(staff.id) },
                            context = context,
                            toast = toast,
                        )
                    }
                    item {
                        Spacer(Modifier.height(80.dp))
                    }
                }
            }
        }

        if (canManage) {
            ElFab(
                icon = Icons.Default.PersonAdd,
                onClick = { showCreateDialog = true },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp),
                contentDescription = "Ajouter un employé",
            )
        }
    }

    if (showCreateDialog) {
        CreateEmployeeDialog(
            departments = departments.map { it.id to it.name },
            busy = busy,
            onConfirm = { input ->
                viewModel.createPersonnel(input)
                showCreateDialog = false
            },
            onDismiss = {
                showCreateDialog = false
                viewModel.clearMessages()
            },
        )
    }
}

@Composable
private fun EmployeeCard(
    staff: Personnel,
    onClick: () -> Unit,
    context: android.content.Context,
    toast: com.example.ui.designsystem.overlays.ElToastHostState,
) {
    ElCard(modifier = Modifier.fillMaxWidth(), size = ElCardSize.STANDARD, onClick = onClick) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ElAvatar(initials = staff.fullName, size = ElAvatarSize.M)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            staff.fullName,
                            style = ElTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = ElTheme.colors.textPrimary,
                        )
                        Text(
                            staff.position,
                            style = ElTheme.typography.bodySmall,
                            color = ElTheme.colors.textSecondary,
                        )
                    }
                }
                ElTag(text = roleDisplayLabel(staff.staffCategory), tone = ElTagTone.INFO, size = ElTagSize.MD)
            }

            Spacer(Modifier.height(8.dp))
            Text(
                text = if (staff.phone.isNotBlank()) "Tél : ${staff.phone} • Embauché : ${staff.hireDate.take(10)}"
                       else "Embauché : ${staff.hireDate.take(10)}",
                style = ElTheme.typography.bodySmall,
                color = ElTheme.colors.textSecondary,
            )
            Spacer(Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ElButton(
                    text = "Appeler",
                    onClick = { PhoneUtils.dial(context, staff.phone, toast) },
                    variant = ElButtonVariant.SECONDARY,
                    icon = Icons.Default.Phone,
                    modifier = Modifier.weight(1f),
                    enabled = staff.phone.isNotBlank(),
                )
                ElButton(
                    text = "Email",
                    onClick = {
                        staff.email?.let { email ->
                            val intent = android.content.Intent(android.content.Intent.ACTION_SENDTO, android.net.Uri.parse("mailto:$email"))
                            runCatching { context.startActivity(intent) }
                        }
                    },
                    variant = ElButtonVariant.SECONDARY,
                    icon = Icons.Default.Email,
                    modifier = Modifier.weight(1f),
                    enabled = !staff.email.isNullOrBlank(),
                )
            }
        }
    }
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun CreateEmployeeDialog(
    departments: List<Pair<String, String>>,
    busy: Boolean,
    onConfirm: (CreatePersonnelInput) -> Unit,
    onDismiss: () -> Unit,
) {
    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var roleCode by remember { mutableStateOf(STAFF_ROLE_OPTIONS.first().first) }
    var position by remember { mutableStateOf(STAFF_ROLE_OPTIONS.first().second) }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var hireDate by remember {
        mutableStateOf(Clock.System.todayIn(TimeZone.currentSystemDefault()).toString())
    }
    var salaryDzd by remember { mutableStateOf("") }
    var departmentId by remember { mutableStateOf<String?>(null) }

    val salaryCentimes = salaryDzd.replace(" ", "").toLongOrNull()?.let { it * 100L }
    val valid = firstName.isNotBlank() && lastName.isNotBlank() && phone.isNotBlank() && hireDate.isNotBlank()

    // T-460 pass F: the DS dialog shell (same dialog language as the other
    // hubs' forms).
    ElDialogShell(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .verticalScroll(rememberScrollState())
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                "Ajouter un employé",
                style = ElTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = ElTheme.colors.textPrimary,
            )
                ElTextField(value = firstName, onValueChange = { firstName = it }, label = "Prénom *", singleLine = true, modifier = Modifier.fillMaxWidth())
                ElTextField(value = lastName, onValueChange = { lastName = it }, label = "Nom *", singleLine = true, modifier = Modifier.fillMaxWidth())

                Text("Rôle *", style = ElTheme.typography.labelMedium, color = ElTheme.colors.textPrimary)
                androidx.compose.foundation.layout.FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    STAFF_ROLE_OPTIONS.forEach { (code, label) ->
                        ElChip(
                            text = label,
                            variant = ElChipVariant.FILTER,
                            selected = roleCode == code,
                            onClick = {
                                roleCode = code
                                position = label
                            },
                        )
                    }
                }

                if (departments.isNotEmpty()) {
                    Text("Département", style = ElTheme.typography.labelMedium, color = ElTheme.colors.textPrimary)
                    androidx.compose.foundation.layout.FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        ElChip(
                            text = "Aucun",
                            variant = ElChipVariant.FILTER,
                            selected = departmentId == null,
                            onClick = { departmentId = null },
                        )
                        departments.forEach { (id, name) ->
                            ElChip(
                                text = name,
                                variant = ElChipVariant.FILTER,
                                selected = departmentId == id,
                                onClick = { departmentId = id },
                            )
                        }
                    }
                }

                ElTextField(value = position, onValueChange = { position = it }, label = "Poste", singleLine = true, modifier = Modifier.fillMaxWidth())
                ElTextField(value = phone, onValueChange = { phone = it }, label = "Téléphone *", singleLine = true, modifier = Modifier.fillMaxWidth())
                ElTextField(value = email, onValueChange = { email = it }, label = "Email", singleLine = true, modifier = Modifier.fillMaxWidth())
                ElTextField(value = hireDate, onValueChange = { hireDate = it }, label = "Date d'embauche (AAAA-MM-JJ) *", singleLine = true, modifier = Modifier.fillMaxWidth())
                ElTextField(
                    value = salaryDzd,
                    onValueChange = { raw -> salaryDzd = raw.filter { it.isDigit() }.take(12) },
                    label = "Salaire mensuel (DZD)",
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ElButton(
                    text = "Annuler",
                    onClick = onDismiss,
                    variant = ElButtonVariant.GHOST,
                    modifier = Modifier.weight(1f),
                )
                ElButton(
                    text = "Ajouter",
                    onClick = {
                        onConfirm(
                            CreatePersonnelInput(
                                firstName = firstName.trim(),
                                lastName = lastName.trim(),
                                staffCategory = roleCode,
                                roleId = roleCode,
                                departmentId = departmentId,
                                position = position.trim().ifBlank { roleCode },
                                phone = phone.trim(),
                                email = email.trim().ifBlank { null },
                                hireDate = hireDate.trim(),
                                salary = salaryCentimes,
                            ),
                        )
                    },
                    enabled = !busy && valid,
                    variant = ElButtonVariant.PRIMARY,
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}