/**
 * AI-review screens regression suite (T-247..T-252, 37th session, 2026-09-09).
 *
 * Guards the 37th-session AI-review adaptations (all REAL-data derivations,
 * §15.16 discipline):
 *   - T-247 `deriveTrancheProjection` — the échéancier théorique line math
 *     (40% Sep / 30% Déc / 30% Mar from the canonical rule; 0 elsewhere).
 *   - T-247 SeeDetailsModal render — the collection-rate summary trio, the
 *     donut's REAL center total (Σ gender counts), legend callouts, the
 *     per-bucket severity badges, honest "—" when kpis are absent.
 *   - T-248/T-354 `deriveTrancheWaves` — wave grouping by the CANONICAL
 *     `trancheNumber` column (the DASH-404 fix: the live BON labels
 *     "INSCRIPTION (FI)" / "2EME TRANCHE" / "3ème TRANCHE" never matched
 *     the retired label regex) + canonical sums + the next-target
 *     highlight + pending surfacing.
 *   - T-249 UnifiedPaymentModal render — quick-pay shortcut chips and the
 *     cashier change-return calculator (Montant remis → Monnaie à rendre).
 *   - T-250 TuitionCard render — the consolidated 14-level matrix (one row
 *     per GRADE_LEVEL, balance column present).
 *   - T-252 ParentDetailDrawer render — the family coverage stack and the
 *     per-tranche 1-click collect button (real mock installment rows).
 *
 * Recharts is mocked (jsdom renders ResponsiveContainer at 0×0 — derivations
 * are tested as pure functions).
 */
import { describe, it, expect, vi, beforeAll } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { PersonNavigationProvider } from "../../shared/navigation/person-navigation-context";
import type { ReactNode } from "react";

// jsdom has no ResizeObserver — PageTabList (used by the SeeDetailsModal and
// the financials page chrome) needs one. Local stub (the global setup stays
// untouched — zero blast radius on the 2694-test baseline).
beforeAll(() => {
  class ResizeObserverStub {
    observe() {}
    unobserve() {}
    disconnect() {}
  }
  (globalThis as Record<string, unknown>).ResizeObserver = ResizeObserverStub;
});

// Initialize i18n FIRST — useTranslation() will otherwise throw.
import "../../i18n/i18n";
import { deriveTrancheProjection, SeeDetailsModal } from "../../features/dashboard/see-details-modal";
import { deriveTrancheWaves } from "../../features/financials/installment-schedule-tab";
import type { DashboardKpi, RevenuePoint } from "../../domain/model/operations";
import type { Installment } from "../../domain/model/payment";
import { GRADE_LEVELS, GRADE_LEVEL_LABELS_FR } from "../../domain/model/student";
import { seedInstallments } from "../../infrastructure/mock/seed-data";

// Mock recharts — jsdom gives ResponsiveContainer a 0×0 box; data derivations
// are covered by the pure-function suites.
vi.mock("recharts", () => ({
  ResponsiveContainer: ({ children }: { children?: ReactNode }) => (
    <div data-testid="recharts-stub">{children}</div>
  ),
  BarChart: ({ children }: { children?: ReactNode }) => <svg>{children}</svg>,
  ComposedChart: ({ children }: { children?: ReactNode }) => <svg>{children}</svg>,
  PieChart: ({ children }: { children?: ReactNode }) => <svg>{children}</svg>,
  AreaChart: ({ children }: { children?: ReactNode }) => <svg>{children}</svg>,
  Bar: () => <div data-testid="recharts-bar" />,
  Line: () => <div data-testid="recharts-line" />,
  Area: () => <div data-testid="recharts-area" />,
  Pie: ({ children }: { children?: ReactNode }) => <svg>{children}</svg>,
  Cell: () => <div />,
  XAxis: () => <div />,
  YAxis: () => <div />,
  Tooltip: () => <div />,
  CartesianGrid: () => <div />,
}));

// ============================================================
// T-247 — deriveTrancheProjection (pure)
// ============================================================

const REV: RevenuePoint[] = [
  { label: "Oct", amount: 100 },
  { label: "Nov", amount: 200 },
  { label: "Déc", amount: 300 },
  { label: "Jan", amount: 50 },
  { label: "Fév", amount: 60 },
  { label: "Mar", amount: 70 },
];

describe("T-247 — deriveTrancheProjection (échéancier théorique)", () => {
  it("allocates 40/30/30 on the canonical months and 0 elsewhere", () => {
    const out = deriveTrancheProjection(REV, 1_000_000);
    const byLabel = new Map(out.map((p) => [p.label, p.targetProjection]));
    expect(byLabel.get("Déc")).toBe(300_000);
    expect(byLabel.get("Mar")).toBe(300_000);
    expect(byLabel.get("Nov")).toBe(0);
    expect(byLabel.get("Jan")).toBe(0);
    expect(out.every((p) => p.amount === REV.find((r) => r.label === p.label)?.amount)).toBe(true);
  });

  it("projects 40% on Sep (the registration tranche month)", () => {
    const out = deriveTrancheProjection(
      [{ label: "Sep", amount: 400_000 }],
      1_000_000,
    );
    expect(out[0].targetProjection).toBe(400_000);
  });

  it("rounds to whole DZD (no fractional money)", () => {
    const out = deriveTrancheProjection([{ label: "Sep", amount: 0 }], 333);
    expect(out[0].targetProjection).toBe(133); // round(333 * 0.4)
  });

  it("keeps bar amounts untouched when totalExpected is 0", () => {
    const out = deriveTrancheProjection(REV, 0);
    expect(out.every((p) => p.targetProjection === 0)).toBe(true);
    expect(out[0].amount).toBe(100);
  });
});

// ============================================================
// T-248/T-354 — deriveTrancheWaves (pure; grouped by trancheNumber)
// ============================================================

function mkInstallment(over: Partial<Installment> & { label: string }): Installment {
  return {
    id: over.label,
    parentId: "par-001",
    studentId: null,
    category: "tuition",
    amountDue: 100,
    amountPaid: 0,
    amountPending: 0,
    dueDate: "2026-06-01T00:00:00.000Z",
    paidDate: null,
    status: "pending",
    ...over,
  } as Installment;
}

describe("T-354 — the wave grouping follows the CANONICAL trancheNumber column (DASH-404)", () => {
  it("the live BON labels group correctly (the exact rows the retired regex missed)", () => {
    const rows: Installment[] = [
      mkInstallment({ label: "INSCRIPTION (FI)", trancheNumber: 1, amountDue: 25_000, amountPaid: 25_000, status: "paid" }),
      mkInstallment({ label: "2EME TRANCHE (V2)", trancheNumber: 2, amountDue: 100_000, amountPaid: 40_000, status: "partial" }),
      mkInstallment({ label: "3ème TRANCHE (2V)", trancheNumber: 3, amountDue: 100_000, amountPaid: 0, status: "pending" }),
    ];
    const waves = deriveTrancheWaves(rows);
    // ALL THREE tuition waves are present — the retired label-regex
    // produced ZERO of them (transport-only header on live data).
    expect(waves[0].due).toBe(25_000);
    expect(waves[1].due).toBe(100_000);
    expect(waves[2].due).toBe(100_000);
    expect(waves[1].pct).toBe(40);
  });

  it("T-432 (DATA-049): the strip carries the TUITION-isolated rate — the Statistics card's number reconciles on the pooled strip", () => {
    // The owner's live pair: Statistics T1 (scolarité isolée) = 77 %,
    // Finance T1 (toutes catégories) = 75 %. Same canonical rows, different
    // bases — the strip now surfaces BOTH so the two surfaces reconcile.
    const rows: Installment[] = [
      // Tuition T1: 10,000 due / 7,700 paid → 77 %.
      mkInstallment({ label: "1EME TRANCHE (V1)", trancheNumber: 1, amountDue: 10_000, amountPaid: 7_700, status: "partial" }),
      // Transport T1: 2,000 due / 1_300 paid → 65 %.
      mkInstallment({ label: "Tranche 1 — Transport", trancheNumber: 1, category: "transport", amountDue: 2_000, amountPaid: 1_300, status: "partial" }),
    ];
    const waves = deriveTrancheWaves(rows);
    expect(waves[0].pct).toBe(75); // pooled: 9,000 / 12,000
    expect(waves[0].tuitionPct).toBe(77); // tuition-isolated: 7,700 / 10,000
    // No tuition rows in the wave → null (the line hides itself).
    const transportOnly: Installment[] = [
      mkInstallment({ label: "Tranche 2 — Transport", trancheNumber: 2, category: "transport", amountDue: 15_000, amountPaid: 5_000, status: "partial" }),
    ];
    expect(deriveTrancheWaves(transportOnly)[1].tuitionPct).toBeNull();
  });

  it("transport rows (label 'Tranche N — Transport') group by the same column", () => {
    const rows: Installment[] = [
      mkInstallment({ label: "Tranche 1 — Transport (Boumerdès)", trancheNumber: 1, category: "transport", amountDue: 30_000, amountPaid: 30_000, status: "paid" }),
      mkInstallment({ label: "Tranche 2 — Transport (Boumerdès)", trancheNumber: 2, category: "transport", amountDue: 15_000, amountPaid: 5_000, status: "partial" }),
    ];
    const waves = deriveTrancheWaves(rows);
    expect(waves[0].due).toBe(30_000);
    expect(waves[1].due).toBe(15_000);
    expect(waves[1].pct).toBe(33);
  });

  it("rows WITHOUT a tranche number are excluded (Année complète / custom lines)", () => {
    const rows: Installment[] = [
      mkInstallment({ label: "Année complète", amountDue: 999, trancheNumber: undefined }),
      mkInstallment({ label: "Tranche 2", trancheNumber: 2, amountDue: 100, amountPaid: 40, status: "partial" }),
    ];
    const waves = deriveTrancheWaves(rows);
    expect(waves[0].due).toBe(0);
    expect(waves[1].due).toBe(100);
    expect(waves[2].due).toBe(0);
    // The Année complète row never lands in a wave.
    expect(waves.every((w) => w.due <= 100)).toBe(true);
  });
});

describe("T-248 — deriveTrancheWaves (REAL row grouping)", () => {
  it("groups, sums and highlights the first wave with remaining balance", () => {
    const rows: Installment[] = [
      mkInstallment({ label: "Tranche 1", trancheNumber: 1, amountDue: 100, amountPaid: 100, status: "paid" }),
      mkInstallment({ label: "Tranche 2", trancheNumber: 2, amountDue: 100, amountPaid: 40, status: "partial" }),
      mkInstallment({ label: "Tranche 3", trancheNumber: 3, amountDue: 100, amountPaid: 0, status: "pending" }),
      mkInstallment({ label: "Année complète", trancheNumber: undefined, amountDue: 999, amountPaid: 0, status: "pending" }),
    ];
    const waves = deriveTrancheWaves(rows);
    // T-425 (the owner's confirmed official model): the strip renders
    // THREE cards — Registration (FI) + Tranches 1/2/3. There is NO 4th
    // tranche (the old "Tranche 4 (Juin)" card was the deleted BON
    // receipt template's phantom).
    expect(waves).toHaveLength(3);
    const t1 = waves[0];
    const t2 = waves[1];
    const t3 = waves[2];
    // T1 fully collected → 100%, NOT the next target.
    expect(t1.due).toBe(100);
    expect(t1.paid).toBe(100);
    expect(t1.pct).toBe(100);
    expect(t1.isNextTarget).toBe(false);
    // T2 is the next collection target (40% collected).
    expect(t2.isNextTarget).toBe(true);
    expect(t2.pct).toBe(40);
    expect(t2.due).toBe(100);
    expect(t2.paid).toBe(40);
    // T3 not targeted yet.
    expect(t3.isNextTarget).toBe(false);
    // "Année complète" is excluded from every wave.
    expect(waves.every((w) => w.due <= 100)).toBe(true);
  });

  it("surfaces uncleared pending funds as their own figure", () => {
    const waves = deriveTrancheWaves([
      mkInstallment({ label: "Tranche 2", trancheNumber: 2, amountDue: 100, amountPaid: 30, amountPending: 20, status: "partial" }),
    ]);
    expect(waves[1].pending).toBe(20);
    expect(waves[1].pct).toBe(30); // cleared-only rate
  });

  it("returns honest zero waves for non-tranche rows only", () => {
    const waves = deriveTrancheWaves([
      mkInstallment({ label: "Année complète", trancheNumber: undefined, amountDue: 500, amountPaid: 100, status: "partial" }),
    ]);
    expect(waves.every((w) => w.due === 0 && w.pct === 0)).toBe(true);
  });
});

// ============================================================
// T-247 — SeeDetailsModal render (mock charts, REAL fixture data)
// ============================================================

const KPIS: DashboardKpi = {
  totalStudents: 389,
  totalParents: 258,
  totalStaff: 14,
  monthlyRevenue: 300,
  outstandingDebt: 700,
  overdueAmount: 300,
  pendingExpenses: 0,
  attendanceRateToday: 0.94,
  overdueAlerts: 0,
};

const MODAL_DATA = {
  kpis: KPIS,
  revenue: REV,
  debtAging: [
    { bucket: "0_30" as const, amount: 100, debtorCount: 5 },
    { bucket: "31_60" as const, amount: 200, debtorCount: 8 },
    { bucket: "91_180" as const, amount: 300, debtorCount: 2 },
  ],
  demographics: {
    grade: [{ label: "1AP", count: 30, percent: 8 }],
    gender: [
      { label: "Garçons", count: 200, percent: 51 },
      { label: "Filles", count: 189, percent: 49 },
    ],
    age: [],
    capacity: [],
  },
  topDebtors: [],
};

describe("T-247 — SeeDetailsModal render", () => {
  it("shows the collection-rate summary trio from REAL totals", () => {
    render(
      <SeeDetailsModal open onOpenChange={() => {}} initialTab="revenue" data={MODAL_DATA} />,
    );
    // TEST-501 repair (T-469 verification, 2026-10-03): the owner's "okay"
    // rewrite renamed the trio — "Encaissé annuel" → "Encaissé effectif
    // (PAID)", "Taux de recouvrement" → "Taux d'Atteinte Annuel". The REAL
    // derivation assertions (53% from 780/1480) are unchanged.
    expect(screen.getByText("Encaissé effectif (PAID)")).toBeInTheDocument();
    expect(screen.getByText("Créances restantes")).toBeInTheDocument();
    expect(screen.getByText("Taux d'Atteinte Annuel")).toBeInTheDocument();
    // 780 collected / 1480 expected → 53%.
    expect(screen.getByText("53%")).toBeInTheDocument();
  });

  it("renders the échéancier théorique line when kpis exist, honest absence otherwise", () => {
    const { rerender } = render(
      <SeeDetailsModal open onOpenChange={() => {}} initialTab="revenue" data={MODAL_DATA} />,
    );
    expect(screen.getAllByTestId("recharts-line").length).toBeGreaterThan(0);

    rerender(
      <SeeDetailsModal
        open
        onOpenChange={() => {}}
        initialTab="revenue"
        data={{ ...MODAL_DATA, kpis: null }}
      />,
    );
    expect(screen.queryByTestId("recharts-line")).toBeNull();
    // The summary trio degrades to "—" without kpis.
    expect(screen.getAllByText("—").length).toBeGreaterThanOrEqual(2);
  });

  it("donut center shows the REAL Σ gender counts (not a synthesized total)", () => {
    render(
      <SeeDetailsModal open onOpenChange={() => {}} initialTab="demographics" data={MODAL_DATA} />,
    );
    // 200 + 189 = 389 — derived from the gender series itself.
    expect(screen.getByText("389")).toBeInTheDocument();
    // TEST-501: the legend label lost its pre-colon space in the "okay"
    // rewrite ("Garçons :" → "Garçons:").
    expect(screen.getByText("Garçons:")).toBeInTheDocument();
    expect(screen.getByText("Filles:")).toBeInTheDocument();
  });

  it("debt tab renders per-bucket severity badges", () => {
    render(
      <SeeDetailsModal open onOpenChange={() => {}} initialTab="debt" data={MODAL_DATA} />,
    );
    // TEST-501: "Normal"/"Avertissement" → "Courant"/"Relance" in the
    // "okay" rewrite (agingSeverity's current labels).
    expect(screen.getByText("Courant")).toBeInTheDocument();
    expect(screen.getByText("Relance")).toBeInTheDocument();
    expect(screen.getByText("Critique")).toBeInTheDocument();
  });
});

// ============================================================
// T-249 — UnifiedPaymentModal quick-pay + change calculator
// ============================================================

describe("T-249 — UnifiedPaymentModal (quick-pay chips + change calculator)", () => {
  async function renderModal() {
    const { RepositoryProvider, mockRepositories } = await import(
      "../../app/providers/repository-provider"
    );
    const { AuthProvider } = await import("../../app/providers/auth-provider");
    const { ToastProvider } = await import("../../app/providers/toast-provider");
    const { UnifiedPaymentModal } = await import(
      "../../features/financials/unified-payment-modal"
    );

    // par-001's seed T2: partial (half paid) → a real open tranche exists.
    const context = {
      parentId: "par-001",
      mode: "installment_tranche" as const,
      targetItemId: "ins-par-001-stu-001-t2",
      presetAmount: 32_000,
      lineItems: [
        {
          itemId: "ins-par-001-stu-001-t2",
          category: "tuition" as const,
          label: "Tranche 2",
          grossAmount: 64_000,
          discountAmount: 0,
          netAmount: 64_000,
          alreadyPaidAmount: 32_000,
          remainingAmount: 32_000,
        },
      ],
      allowPartial: true,
      originRoute: "test",
    };

    render(
      <ToastProvider>
        <AuthProvider>
          <RepositoryProvider repositories={mockRepositories}>
            <UnifiedPaymentModal open onOpenChange={() => {}} context={context} />
          </RepositoryProvider>
        </AuthProvider>
      </ToastProvider>,
    );
  }

  it("renders the quick-pay shortcut chips with the tranche label", async () => {
    await renderModal();
    await waitFor(() => {
      expect(screen.getByText(/Raccourcis d'encaissement direct/i)).toBeInTheDocument();
    });
    // The chip shows the open tranche amount derived from the context item.
    expect(screen.getByText(/Payer Tranche 2/i)).toBeInTheDocument();
  });

  it("change calculator: Montant remis → Monnaie à rendre (cash only)", async () => {
    await renderModal();
    await waitFor(() => {
      expect(screen.getByText(/Calculateur de monnaie/i)).toBeInTheDocument();
    });
    const input = screen.getByPlaceholderText(/70000/i);
    fireEvent.change(input, { target: { value: "40000" } });
    // 40000 handed − 32000 due → 8000 to return.
    await waitFor(() => {
      expect(screen.getByText(/8 000 DZD/i)).toBeInTheDocument();
    });
  });
});

// ============================================================
// T-250 — TuitionCard consolidated matrix
// ============================================================

describe("T-250 — TuitionCard (14-level consolidated matrix)", () => {
  it("renders ONE row per grade level with the balance column", async () => {
    const { RepositoryProvider, mockRepositories } = await import(
      "../../app/providers/repository-provider"
    );
    const { AuthProvider } = await import("../../app/providers/auth-provider");
    const { ToastProvider } = await import("../../app/providers/toast-provider");
    const { TuitionCard } = await import(
      "../../features/settings/pricing/tuition-card"
    );

    render(
      <ToastProvider>
        <AuthProvider>
          <RepositoryProvider repositories={mockRepositories}>
            <TuitionCard />
          </RepositoryProvider>
        </AuthProvider>
      </ToastProvider>,
    );

    // All 14 levels in a single table (the scroll-wall is gone).
    for (const g of GRADE_LEVELS) {
      expect(screen.getByText(GRADE_LEVEL_LABELS_FR[g])).toBeInTheDocument();
    }
    expect(screen.getByText(/Équilibre/i)).toBeInTheDocument();
    // The matrix header + the explicit-tool note (canEdit-independent).
    expect(screen.getByText(/Grille Tarifaire de Scolarité/i)).toBeInTheDocument();
    expect(screen.getByText(/OUTIL explicite/i)).toBeInTheDocument();
  });
});

// ============================================================
// T-252 — ParentDetailDrawer coverage stack + per-tranche collect
// ============================================================

describe("T-252 — ParentDetailDrawer (coverage + 1-click tranche collect)", () => {
  it("renders the coverage stack and per-tranche Encaisser buttons from REAL rows", async () => {
    const { RepositoryProvider, mockRepositories } = await import(
      "../../app/providers/repository-provider"
    );
    const { AuthProvider } = await import("../../app/providers/auth-provider");
    const { ToastProvider } = await import("../../app/providers/toast-provider");
    const { ParentDetailDrawer } = await import(
      "../../features/crm/parent-detail-drawer"
    );

    // par-002 (Amina Cherif): the seed's odd-index parents carry an OPEN
    // tranche (T3 unpaid — idx % 2 === 1). Sanity: real open rows exist.
    const openForPar002 = seedInstallments.filter(
      (i) => i.parentId === "par-002" && i.amountPaid < i.amountDue,
    );
    expect(openForPar002.length).toBeGreaterThan(0);

    // T-444/UI-324: the new-UI drawer consumes the PersonNavigation context
    // (which needs a Router); the harness mounts both inside the existing
    // provider stack.
    render(
      <ToastProvider>
        <AuthProvider>
          <RepositoryProvider repositories={mockRepositories}>
            <MemoryRouter>
              <PersonNavigationProvider>
                <ParentDetailDrawer parentId="par-002" open onOpenChange={() => {}} />
              </PersonNavigationProvider>
            </MemoryRouter>
          </RepositoryProvider>
        </AuthProvider>
      </ToastProvider>,
    );

    // Wait for the Finances tab content (the drawer renders tabs).
    await waitFor(
      () => {
        // The 1-click collect buttons exist on open tranches.
        expect(screen.getAllByText(/^Encaisser\s/i).length).toBeGreaterThan(0);
      },
      { timeout: 5000 },
    );
  });
});
