package com.example.ui.features.academics

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Class
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.core.Permission
import com.example.core.Session
import com.example.domain.model.AcademicClass
import com.example.ui.designsystem.components.button.ElButton
import com.example.ui.designsystem.components.button.ElButtonVariant
import com.example.ui.designsystem.components.button.ElIconButton
import com.example.ui.designsystem.components.card.ElCard
import com.example.ui.designsystem.components.card.ElCardSize
import com.example.ui.designsystem.components.display.ElAlertBanner
import com.example.ui.designsystem.components.display.ElAlertSeverity
import com.example.ui.designsystem.components.display.ElSectionHeader
import com.example.ui.designsystem.components.display.ElTag
import com.example.ui.designsystem.components.display.ElTagTone
import com.example.ui.designsystem.components.feedback.ElEmptyState
import com.example.ui.designsystem.components.input.ElSearchBar
import com.example.ui.designsystem.theme.ElTheme

/**
 * T-323 (55th session, UI-313) — classes directory on the canonical design
 * system, plus the REAL BUG FIX: `onNavigateToSubjectsDirectory` was declared
 * but NEVER referenced in the body, so the Matières directory was unreachable
 * from the Academics hub. The header now carries a "Matières" button.
 *
 * Preserved: the promotion entry point (Vault §06.04 — opens the REVIEW
 * QUEUE, never blind batch promotion), its busy gating, the permission
 * double-check, and the class-detail navigation.
 */
/**
 * T-460 pass J (issue #3 F-13): the classes filter — text search over the
 * class name, the homeroom teacher and the room. Pure so the parity
 * behaviour is unit-testable without composition.
 */
internal fun filterClasses(classes: List<AcademicClass>, query: String): List<AcademicClass> {
    val q = query.trim()
    if (q.isBlank()) return classes
    return classes.filter {
        it.name.contains(q, ignoreCase = true) ||
            it.homeroomTeacherName?.contains(q, ignoreCase = true) == true ||
            it.room?.contains(q, ignoreCase = true) == true
    }
}

@Composable
fun ClassesDirectoryScreen(
    session: Session,
    onNavigateToClassDetail: (String) -> Unit = {},
    onNavigateToSubjectsDirectory: () -> Unit = {},
    onNavigateToPromotionReview: (String) -> Unit = {},
    viewModel: ClassesDirectoryViewModel = hiltViewModel(),
) {
    val c = ElTheme.colors
    val classes by viewModel.classes.collectAsState()
    val query by viewModel.query.collectAsState()
    val error by viewModel.error.collectAsState()
    val message by viewModel.message.collectAsState()
    val busy by viewModel.busy.collectAsState()

    val canPromote = session.can(Permission.PROMOTE_STUDENT) || viewModel.canPromote

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(ElTheme.spacing.sm)) {
        ElSectionHeader(
            title = "Annuaire des classes",
            subtitle = "${classes.size} division${if (classes.size > 1) "s" else ""} active${if (classes.size > 1) "s" else ""}",
            trailing = {
                ElButton(
                    text = "Matières",
                    onClick = onNavigateToSubjectsDirectory,
                    variant = ElButtonVariant.SECONDARY,
                    icon = Icons.Default.MenuBook,
                )
            },
        )

        message?.let {
            ElAlertBanner(
                title = "Succès",
                message = it,
                severity = ElAlertSeverity.SUCCESS,
            )
        }
        error?.let {
            ElAlertBanner(
                title = "Erreur",
                message = it,
                severity = ElAlertSeverity.DANGER,
            )
        }

        // T-460 pass J (issue #3 F-13): text-search parity with the
        // Student/Parents directories (class name, teacher, room).
        ElSearchBar(
            query = query,
            onQueryChange = viewModel::setQuery,
            placeholder = "Classe, professeur, salle…",
            modifier = Modifier.fillMaxWidth(),
        )

        val filteredClasses = filterClasses(classes, query)

        if (classes.isEmpty()) {
            ElEmptyState(
                icon = Icons.Default.Class,
                title = "Aucune classe",
                subtitle = "Aucune classe n'est enregistrée pour cette année scolaire.",
            )
            return@Column
        }
        if (filteredClasses.isEmpty()) {
            ElEmptyState(
                icon = Icons.Default.Class,
                title = "Aucune classe trouvée",
                subtitle = "Aucune classe ne correspond à « $query ».",
            )
            return@Column
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(ElTheme.spacing.sm), modifier = Modifier.fillMaxSize()) {
            items(filteredClasses) { klass ->
                val fillRate = if (klass.capacity > 0) (klass.enrolledCount.toFloat() / klass.capacity * 100).toInt() else 0
                ElCard(
                    modifier = Modifier.fillMaxWidth(),
                    size = ElCardSize.COMPACT,
                    onClick = { onNavigateToClassDetail(klass.id) },
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(c.primaryContainer),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                Icons.Default.Class,
                                contentDescription = null,
                                tint = c.primary,
                                modifier = Modifier.size(20.dp),
                            )
                        }
                        Spacer(Modifier.width(ElTheme.spacing.md))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                klass.name,
                                style = ElTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Text(
                                "Professeur : ${klass.homeroomTeacherName ?: "Non assigné"} · Salle : ${klass.room ?: "—"}",
                                style = ElTheme.typography.bodySmall,
                                color = c.textSecondary,
                            )
                        }
                        ElTag(
                            text = "${klass.enrolledCount}/${klass.capacity} ($fillRate%)",
                            tone = if (fillRate >= 90) ElTagTone.WARNING else ElTagTone.INFO,
                        )
                        // Vault §06.04 — promotion entry point. Opens the
                        // GPA-driven REVIEW QUEUE (auto-flag + admin
                        // overrides) instead of blindly promoting every
                        // ACTIVE student. The vault explicitly forbids
                        // running batch promotion without first reviewing
                        // the queue.
                        if (canPromote) {
                            ElIconButton(
                                icon = Icons.Default.TrendingUp,
                                onClick = { onNavigateToPromotionReview(klass.id) },
                                enabled = !busy,
                                contentDescription = "File de promotion — ${klass.name}",
                                tint = c.primary,
                                background = androidx.compose.ui.graphics.Color.Transparent,
                            )
                        }
                    }
                }
            }
        }
    }
}
