"use client";

/**
 * AcademicView — grades + GPA view for the active student.
 *
 * Per platform matrix: portal = "View Grades" (read-only).
 * Teachers input marks from Desktop/Mobile; parents just see results.
 *
 * Layout (mobile-first):
 *   1. Student switcher (if multiple kids)
 *   2. GPA card (overall average, computed from subject_average)
 *   3. Tabs: by term (Trimestre 1 / 2 / 3)
 *   4. Per-subject grade list (coefficient, score, subject average)
 */

import { useAuth } from "@/app/providers/auth-provider";
import { useT } from "@/lib/i18n/use-t";
import { useAppStore } from "@/lib/store/app-store";
import { useGradesForStudent, useClass, useAttendanceForStudent, useAcademicLevels, type PortalAssessmentRow } from "@/lib/hooks/portal-queries";
import { resolveSubjectConfiguration } from "@/lib/canonical/subject-config";
import {
  subjectAverageFor,
  overallGpaFor,
  isPassing,
} from "@/lib/canonical/portal-derive";
import { KpiCard } from "@/features/shared/kpi-card";
import {
  SectionHeader,
  EmptyState,
  ListSkeleton,
  ErrorState,
} from "@/features/shared/state-views";
import { StudentSwitcherDropdown } from "@/features/students/student-switcher";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { GraduationCap, Award, TrendingUp, Download, Table2 } from "lucide-react";
import { formatFullName } from "@/lib/format";
import { useMemo, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { printBulletin } from "@/lib/bulletin";
import { toast } from "sonner";
import type { GradeRow } from "@/lib/types/database";

// T-049: Radix Tabs is string-keyed — onValueChange always delivers
// strings ("1" | "2" | "3"), so the filter state is a string union. The
// old numeric `Term = 1 | 2 | 3` described a state that never existed.
type TermFilter = "all" | "1" | "2" | "3";

/** T-212: full, unabbreviated term labels — the owner's mandate ("use the
 * full labels Trimester 1, Trimester 2, and Trimester 3 throughout the
 * portal"; the portal's UI language is French → "Trimestre N"). The
 * bulletin PDF already printed the full form; the tab triggers and the
 * per-assessment chips used the T1/T2/T3 abbreviations. */
const TERM_NUMBERS = ["1", "2", "3"] as const;

export function fullTermLabel(t: (key: string) => string, term: string | number): string {
  return `${t("student.term")} ${term}`;
}

export function AcademicView() {
  const { t } = useT();
  const { children: kids } = useAuth();
  const activeStudentId = useAppStore((s) => s.activeStudentId);
  const setActiveView = useAppStore((s) => s.setActiveView);
  const activeKid = kids.find((k) => k.id === activeStudentId);

  const grades = useGradesForStudent(activeKid?.id ?? null);
  const klass = useClass(activeKid?.class_id ?? null);
  const attendance = useAttendanceForStudent(activeKid?.id ?? null, { limit: 500 });
  const levels = useAcademicLevels();

  const [activeTerm, setActiveTerm] = useState<TermFilter>("all");

  const handleDownloadBulletin = () => {
    if (!activeKid) {
      toast.error(t("academic.noStudent"));
      return;
    }
    const level = levels.data?.find((l) => l.id === activeKid.grade_level_id) ?? null;
    printBulletin({
      student: activeKid,
      klass: klass.data ?? null,
      level,
      grades: (grades.data ?? []) as never,
      attendance: attendance.data ?? [],
    });
    toast.success(t("academic.bulletin.opened"));
  };

  // Group assessments by subject (canonical 0029 shape: one row per
  // student × subject × term × year, joined with its subject).
  const bySubject = useMemo(() => {
    if (!grades.data) return new Map<string, { subjectName: string; coefficient: number; isExtracurricular: boolean; rows: PortalAssessmentRow[] }>();
    const map = new Map<string, { subjectName: string; coefficient: number; isExtracurricular: boolean; rows: PortalAssessmentRow[] }>();
    for (const a of grades.data) {
      const key = a.subject_id ?? a.subject?.id ?? "unknown";
      // T-347 (ADR-018): the canonical resolution — the row SNAPSHOT first
      // (history is never re-resolved), then the legacy directory layer.
      // Never a bare inline `?? 1` chain again.
      const coefficient = resolveSubjectConfiguration({
        subject: a.subject
          ? {
              id: a.subject.id,
              code: undefined,
              coefficient: a.subject.default_coefficient,
              isExtracurricular: a.subject.is_extracurricular,
            }
          : undefined,
        configurations: [],
        snapshot: { coefficient: a.coefficient },
      }).coefficient;
      const existing = map.get(key);
      if (existing) {
        existing.rows.push(a);
      } else {
        map.set(key, {
          subjectName: a.subject?.name_fr ?? a.subject?.name_en ?? "—",
          coefficient,
          isExtracurricular: Boolean(a.subject?.is_extracurricular),
          rows: [a],
        });
      }
    }
    return map;
  }, [grades.data]);

  // Term filter — T-212: full "Trimestre N" labels (no T1/T2/T3
  // abbreviations) + the t-202 mobile pattern: the row scrolls below
  // sm (4 full labels need ~70–85px each — the bare grid clipped at
  // 320px) and restores the equal 4-cell grid at sm+.
  const filteredSubjects = useMemo(() => {
    if (activeTerm === "all") return bySubject;
    const m = new Map<string, { subjectName: string; coefficient: number; isExtracurricular: boolean; rows: PortalAssessmentRow[] }>();
    bySubject.forEach((s, key) => {
      const filtered = s.rows.filter((a) => String(a.term) === String(activeTerm));
      if (filtered.length > 0) m.set(key, { ...s, rows: filtered });
    });
    return m;
  }, [bySubject, activeTerm]);

  // Overall GPA — CANONICAL: coefficient-weighted over per-row canonical
  // subject averages ((D1 + D2 + 2×Ex)/4, all marks required), extracurricular
  // excluded — identical to desktop/Android engines and the SQL
  // fn_calculate_student_term_gpa function.
  //
  // T-336 (desktop-parity): the KPI follows the TERM FILTER — a
  // "Trimestre N" tab shows that term's canonical per-term GPA (the desktop
  // AcademicTab and SQL fn_calculate_student_term_gpa semantics; the
  // Android termGpas map), the all-terms tab shows the all-rows yearly GPA
  // (the Android yearlyGpa convention). Previously the KPI stayed at the
  // all-terms value while the subject list filtered — a behavior/
  // calculation divergence from the desktop the owner's parity mandate
  // calls out.
  const overall = useMemo(() => {
    if (filteredSubjects.size === 0) return null;
    const inputs: Array<{ devoir1: number | null; devoir2: number | null; examen: number | null; coefficient: number; isExtracurricular: boolean }> = [];
    const stored: Array<number | null> = [];
    filteredSubjects.forEach((s) => {
      for (const row of s.rows) {
        inputs.push({
          devoir1: row.devoir1 ?? null,
          devoir2: row.devoir2 ?? null,
          examen: row.examen ?? null,
          coefficient: s.coefficient,
          isExtracurricular: s.isExtracurricular,
        });
        stored.push(row.subject_average != null ? Number(row.subject_average) : null);
      }
    });
    return overallGpaFor(inputs, stored);
  }, [filteredSubjects]);

  return (
    <div className="mx-auto max-w-5xl space-y-6 px-4 py-5">
      {/* Header. T-201/UI-302: flex-wrap + gap-y so the action cluster stacks
          below the title on narrow screens (77px of document overflow at
          320px before the fix). */}
      <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-2">
        <h1 className="min-w-0 text-xl font-semibold">{t("nav.academic")}</h1>
        <div className="flex flex-wrap items-center gap-2">
          {/* T-407 (SCHED-106): mobile entry to the published timetable (the
              desktop rail has its own entry; the bottom nav is fixed at 5). */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setActiveView("timetable")}
          >
            <Table2 className="mr-1 h-3.5 w-3.5" />
            {t("nav.timetable")}
          </Button>
          {activeKid && (
            <Button variant="outline" size="sm" onClick={handleDownloadBulletin} disabled={grades.isLoading}>
              <Download className="mr-1 h-3.5 w-3.5" />
              {t("student.bulletin")}
            </Button>
          )}
          {kids.length > 1 && <StudentSwitcherDropdown />}
        </div>
      </div>

      {/* Active student banner */}
      {activeKid && (
        <Card className="border-border/60 bg-card/50">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/15 text-primary">
              <GraduationCap className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <p className="font-medium">{formatFullName(activeKid)}</p>
              <p className="text-xs text-muted-foreground">
                {klass.data?.name ?? klass.data?.code ?? activeKid.student_code}
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* GPA */}
      {grades.isLoading ? (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Card key={i} className="border-border/60">
              <CardContent className="p-4">
                <ListSkeleton count={1} />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          <KpiCard
            label={t("student.gpa")}
            value={overall !== null ? overall.toFixed(2) : "—"}
            tone={overall !== null && isPassing(overall) ? "success" : "warning"}
            icon={<Award className="h-5 w-5" />}
            hint={`/ 20`}
          />
          <KpiCard
            label={t("student.subject")}
            value={filteredSubjects.size}
            icon={<GraduationCap className="h-5 w-5" />}
          />
          <KpiCard
            label={t("student.term")}
            value={
              activeTerm === "all" ? t("academic.terms.all") : fullTermLabel(t, activeTerm)
            }
            icon={<TrendingUp className="h-5 w-5" />}
          />
        </div>
      )}

      {/* Term filter — T-212: full "Trimestre N" labels (no T1/T2/T3
          abbreviations) + the t-202 mobile pattern: the row scrolls below
          sm (4 full labels need ~70–85px each — the bare grid clipped at
          320px) and restores the equal 4-cell grid at sm+. */}
      <Tabs value={activeTerm} onValueChange={(v) => setActiveTerm(v as TermFilter)}>
        <TabsList className="flex w-full overflow-x-auto scrollbar-none sm:grid sm:grid-cols-4 [&_[data-slot=tabs-trigger]]:basis-auto [&_[data-slot=tabs-trigger]]:shrink-0">
          <TabsTrigger value="all">{t("academic.terms.all")}</TabsTrigger>
          {TERM_NUMBERS.map((n) => (
            <TabsTrigger key={n} value={n}>
              {fullTermLabel(t, n)}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value={activeTerm} className="mt-4">
          {grades.isLoading ? (
            <ListSkeleton count={4} />
          ) : grades.isError ? (
            <ErrorState title={t("common.error.title")} onRetry={() => grades.refetch()} />
          ) : filteredSubjects.size === 0 ? (
            <EmptyState title={t("academic.grades.empty")} icon={<GraduationCap className="h-6 w-6" />} />
          ) : (
            <div className="space-y-2">
              {Array.from(filteredSubjects.entries()).map(([subjectId, s]) => {
                // Canonical per-row subject average: (D1 + D2 + 2×Ex)/4, all
                // three marks required — recomputed from the component marks,
                // falling back to the stored subject_average for legacy rows.
                const rowAverages = s.rows.map((a) =>
                  subjectAverageFor({
                    devoir1: a.devoir1 ?? null,
                    devoir2: a.devoir2 ?? null,
                    examen: a.examen ?? null,
                    coefficient: s.coefficient,
                    isExtracurricular: s.isExtracurricular,
                  }) ?? (a.subject_average != null ? Number(a.subject_average) : null),
                );
                const valid = rowAverages.filter((v): v is number => v != null);
                const subjectAvg = valid.length ? valid.reduce((a, b) => a + b, 0) / valid.length : null;
                return (
                  <Card key={subjectId} className="border-border/50 bg-card">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0 flex-1">
                          <p className="font-medium">{s.subjectName}</p>
                          <p className="mt-0.5 text-xs text-muted-foreground">
                            {t("student.coefficient")}: {s.coefficient}
                            {s.isExtracurricular ? ` ${t("academic.cc.horsMoyenne")}` : ""}
                          </p>
                        </div>
                        {subjectAvg !== null && (
                          <div className="text-right">
                            <p className={`font-mono text-lg font-semibold ${subjectAvg >= 10 ? "text-success" : "text-warning"}`}>
                              {subjectAvg.toFixed(2)}
                            </p>
                            <p className="text-[10px] text-muted-foreground">{t("student.average")}</p>
                          </div>
                        )}
                      </div>

                      {/* Per-assessment marks (D1 / D2 / Examen per term) */}
                      <div className="mt-3 flex flex-wrap gap-2">
                        {s.rows.map((a) => (
                          <div
                            key={a.id}
                            className="flex items-center gap-2 rounded-md border border-border/40 bg-muted/30 px-2 py-1 text-xs"
                          >
                            <span className="text-muted-foreground">{fullTermLabel(t, a.term)}</span>
                            <span className="font-mono">
                              {a.devoir1 != null ? a.devoir1.toFixed(2) : "—"} · {a.devoir2 != null ? a.devoir2.toFixed(2) : "—"} · {a.examen != null ? a.examen.toFixed(2) : "—"}
                              {(a.coefficient_cc ?? 0) > 0 && (
                                <>
                                  {" · "}
                                  <span title={t("student.mark.cc")}>
                                    {a.cc != null ? a.cc.toFixed(2) : "—"}
                                  </span>
                                </>
                              )}
                            </span>
                          </div>
                        ))}
                      </div>

                      {/* T-336 (desktop-parity): partial marks are NEVER
                          silently hidden — the canonical average requires
                          all three marks, and the desktop's grade tables /
                          the Android's subject cards both explain a missing
                          average ("Moyenne à paraître — les 3 notes doivent
                          être saisies"). The portal showed "—" with no
                          explanation, which read as missing data. */}
                      {subjectAvg === null && (
                        <p className="mt-2 text-[11px] italic text-muted-foreground">
                          {t("student.average.pending")}
                        </p>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
