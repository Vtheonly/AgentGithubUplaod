"use client";

/**
 * AttendanceView — absence and tardiness history for the active student.
 *
 * DRIFT-010 accuracy note (T-065): the portal is NOT read-only for
 * justifications. It (a) DISPLAYS the 4-state justification status
 * (none / pending / submitted / rejected — staff uploads included), and
 * (b) SUBMITS justifications: for any non-present record with status
 * "none" the parent gets a "Justifier cette absence" button opening
 * AbsenceJustificationDialog, which uploads the file to the
 * `attendance-justifications` storage bucket and updates the
 * `attendance_records` justification fields directly.
 */

import { useAuth } from "@/app/providers/auth-provider";
import { useT } from "@/lib/i18n/use-t";
import { useAppStore } from "@/lib/store/app-store";
import { useAttendanceForStudent } from "@/lib/hooks/portal-queries";
import { useQueryClient } from "@tanstack/react-query";
import { KpiCard } from "@/features/shared/kpi-card";
import { attendanceRatePercent } from "@/lib/canonical/portal-derive";
import {
  StatusPill,
  attendanceStatusTone,
} from "@/features/shared/status-pill";
import {
  EmptyState,
  ListSkeleton,
  ErrorState,
  CardListItem,
} from "@/features/shared/state-views";
import { StudentSwitcherDropdown } from "@/features/students/student-switcher";
import { AbsenceJustificationDialog } from "@/features/attendance/absence-justification-dialog";
import { CheckCircle2, XCircle, Clock, AlertCircle, FileText } from "lucide-react";
import { formatDate, formatFullName } from "@/lib/format";
import { useMemo, useState } from "react";
import type { AttendanceRecordRow } from "@/lib/types/database";

const statusIcons: Record<string, typeof CheckCircle2> = {
  present: CheckCircle2,
  absent_excused: AlertCircle,
  absent_unexcused: XCircle,
  late: Clock,
};

const statusLabels: Record<string, string> = {
  present: "Présent",
  absent_excused: "Absence justifiée",
  absent_unexcused: "Absence non justifiée",
  late: "Retard",
};

function justificationTone(status: string): "info" | "success" | "warning" | "danger" | "muted" {
  switch (status) {
    case "accepted":
      return "success";
    case "submitted":
      return "info";
    case "rejected":
      return "danger";
    case "none":
    default:
      return "warning";
  }
}

export function AttendanceView() {
  const { t } = useT();
  const { children: kids } = useAuth();
  const activeStudentId = useAppStore((s) => s.activeStudentId);
  const activeKid = kids.find((k) => k.id === activeStudentId);

  const attendance = useAttendanceForStudent(activeKid?.id ?? null, { limit: 200 });
  const qc = useQueryClient();
  const [justifyRecord, setJustifyRecord] = useState<AttendanceRecordRow | null>(null);

  const stats = useMemo(() => {
    if (!attendance.data) return { present: 0, excused: 0, unexcused: 0, late: 0, total: 0, rate: null };
    const out = { present: 0, excused: 0, unexcused: 0, late: 0, total: attendance.data.length, rate: null as number | null };
    for (const a of attendance.data) {
      if (a.status === "present") out.present++;
      else if (a.status === "absent_excused") out.excused++;
      else if (a.status === "absent_unexcused") out.unexcused++;
      else if (a.status === "late") out.late++;
    }
    // T-027 / WEAK-019: use the canonical attendanceRatePercent
    // (present + late) / total — same formula as the dashboard KPI.
    // The previous inline `present / total` under-reported by counting
    // late arrivals as absent.
    // Preserve the null-on-empty semantics (no records → no rate) —
    // `attendanceRatePercent` returns 100 for empty since the canonical
    // `calculateAttendanceRate` returns 1.0 for empty, which is correct
    // for "no absences on record" semantics in the dashboard but not for
    // the attendance-view's "no data" UI.
    out.rate = out.total > 0 ? attendanceRatePercent(attendance.data) : null;
    return out;
  }, [attendance.data]);

  return (
    <div className="mx-auto max-w-5xl space-y-6 px-4 py-5">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-xl font-semibold">{t("attendance.title")}</h1>
        {kids.length > 1 && <StudentSwitcherDropdown />}
      </div>

      {/* KPI grid */}
      {attendance.isLoading ? (
        <ListSkeleton count={2} />
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <KpiCard
            label={t("attendance.summary.present")}
            value={stats.present}
            tone="success"
            icon={<CheckCircle2 className="h-5 w-5" />}
            hint={stats.rate !== null ? `${stats.rate}%` : undefined}
          />
          <KpiCard
            label={t("attendance.summary.excused")}
            value={stats.excused}
            tone="warning"
            icon={<AlertCircle className="h-5 w-5" />}
          />
          <KpiCard
            label={t("attendance.summary.unexcused")}
            value={stats.unexcused}
            tone="danger"
            icon={<XCircle className="h-5 w-5" />}
          />
          <KpiCard
            label={t("attendance.summary.late")}
            value={stats.late}
            tone="info"
            icon={<Clock className="h-5 w-5" />}
          />
        </div>
      )}

      {/* History */}
      {activeKid && (
        <p className="text-sm text-muted-foreground">
          {formatFullName(activeKid)}
        </p>
      )}

      {attendance.isLoading ? (
        <ListSkeleton count={6} />
      ) : attendance.isError ? (
        <ErrorState title={t("common.error.title")} onRetry={() => attendance.refetch()} />
      ) : attendance.data && attendance.data.length > 0 ? (
        <div className="space-y-2">
          {attendance.data.map((rec) => {
            const Icon = statusIcons[rec.status] ?? AlertCircle;
            const tone = attendanceStatusTone(rec.status);
            const hasJustification = Boolean(rec.justification_note || rec.justification_path || rec.justification_drive_link);
            const justStatus = rec.justification_status ?? "none";
            const canJustify = rec.status !== "present" && justStatus === "none";
            return (
              <div key={rec.id} className="space-y-1">
                <CardListItem
                  leading={
                    <div className={`flex h-10 w-10 items-center justify-center rounded-lg bg-muted/40 ${tone === "success" ? "text-success" : tone === "warning" ? "text-warning" : tone === "danger" ? "text-destructive" : "text-info"}`}>
                      <Icon className="h-4 w-4" />
                    </div>
                  }
                  title={`${formatDate(rec.date)} • ${statusLabels[rec.status] ?? rec.status}`}
                  subtitle={rec.justification_note ?? (hasJustification ? t("attendance.justification.uploaded") : rec.status !== "present" ? t("attendance.justification.pending") : undefined)}
                  trailing={
                    rec.status !== "present" && (
                      <StatusPill tone={justificationTone(justStatus)}>
                        {t(`attendance.justification.status.${justStatus}`)}
                      </StatusPill>
                    )
                  }
                />
                {canJustify && (
                  <button
                    onClick={() => setJustifyRecord(rec)}
                    className="ml-13 flex items-center gap-1 px-2 py-1 text-xs text-primary hover:underline"
                  >
                    <FileText className="h-3 w-3" />
                    {t("attendance.justifier")}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        <EmptyState title={t("attendance.empty")} icon={<CheckCircle2 className="h-6 w-6" />} />
      )}

      <AbsenceJustificationDialog
        record={justifyRecord}
        open={justifyRecord !== null}
        onOpenChange={(v) => !v && setJustifyRecord(null)}
        onSubmitted={() => {
          qc.invalidateQueries({ queryKey: ["attendance", activeKid?.id] });
        }}
      />
    </div>
  );
}
