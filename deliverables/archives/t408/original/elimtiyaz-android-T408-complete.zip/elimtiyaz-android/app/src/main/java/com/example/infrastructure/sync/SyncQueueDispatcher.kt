package com.example.infrastructure.sync

import com.example.infrastructure.room.SyncQueueEntity
import com.example.infrastructure.supabase.NetworkTimeouts
import com.example.infrastructure.supabase.SupabaseClientProvider
import com.example.session.SessionManager
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Dispatcher that processes a single [SyncQueueEntity] by pushing it to
 * Supabase via the shared `upsert_*_from_import` RPCs declared in
 * migration `0027_shared_unification.sql`.
 *
 * SHARED-UNIFICATION (migration 0027):
 *   - Both Desktop and Android call the SAME RPCs.
 *   - The RPCs are SECURITY DEFINER + idempotent (matched by stable
 *     identifiers: parent_code / phone / student_code / payment_number /
 *     (source_type, source_id) for ledger entries).
 *   - Re-pushing the same queue entry is safe — it never creates duplicates.
 *
 * When Supabase is NOT configured (placeholder URL), the dispatcher
 * silently no-ops and the SyncService marks the entry as "synced" so the
 * local cache stays consistent.
 *
 * ERROR SURFACING (T-019 / CROSS-200): every push runs through
 * [NetworkTimeouts.guardSyncPush], which propagates failures instead of
 * converting them to `null`. The supabase-kt SDK (3.1.1) throws
 * `PostgrestRestException` on every 4xx/5xx response (FK violation, NOT
 * NULL, RLS denial, trigger exception, …), so a rejected write now keeps
 * its queue entry pending with `lastError` and retries with backoff —
 * previously every push was wrapped in the read-oriented guard overload
 * (the one that catches Throwable and returns null), so server-rejected
 * writes were marked "synced" and Room drifted from the server silently.
 */
@Singleton
class SyncQueueDispatcher @Inject constructor(
    private val supabaseProvider: SupabaseClientProvider,
    private val sessionManager: SessionManager,
) {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = false
        isLenient = true
    }

    /**
     * Process a single queue entry — push it to Supabase via the appropriate
     * upsert RPC. Throws on failure; the SyncService catches and records the
     * error, then re-tries with exponential backoff.
     */
    suspend fun pushEntry(entry: SyncQueueEntity) {
        // Defense in depth: never push mock data.
        if (entry.isMock) return

        // Skip silently when Supabase isn't configured (offline / demo mode).
        if (!NetworkTimeouts.isSupabaseConfigured) return

        val payload = try {
            json.parseToJsonElement(entry.payload).jsonObject
        } catch (e: Exception) {
            // Malformed payload — can't push. Mark as synced to avoid
            // endless retries; the audit log entry in the queue is enough.
            return
        }

        val actorId = sessionManager.currentUserId() ?: entry.actorId

        when (entry.entity) {
            "parent" -> pushParent(entry, payload, actorId)
            "student" -> pushStudent(entry, payload, actorId)
            "payment" -> pushPayment(entry, payload, actorId)
            "ledger_entry" -> pushLedgerEntry(entry, payload, actorId)
            // TIER 4 FIX (migration 0037) — installment mutations now push to
            // the new idempotent `upsert_installment_from_import` RPC.
            "installment" -> pushInstallment(entry, payload, actorId)
            // Vault §06.06 — Homework Assignment Engine: the teacher's
            // assignment must reach the Student Web Portal. Direct idempotent
            // upsert into the shared `homework` table (matched by primary key
            // id — re-pushing the same queue entry never duplicates).
            "homework" -> pushHomework(entry, payload)
            // Vault §06.02 — Grade Entry: upsert into the canonical
            // `assessments` table (the same table the desktop grade-entry
            // flow and the web portal's Academic Hub read).
            "grade" -> pushGrade(entry, payload)
            // Vault §06.03 — Attendance Roll Call: upsert into
            // `attendance_records` on the canonical key (migration 0041) so
            // the portal's Absence Justification feature sees every record.
            "attendance" -> pushAttendance(entry, payload)
            // Other entity kinds (expense, audit_log, notification,
            // calendar_event) are currently local-only. The shared schema
            // migration 0027 supports them via direct table upserts, but
            // those flows are out of scope for this iteration.
            else -> {
                // No-op — the SyncService will mark the entry as "synced".
            }
        }
    }

    // ── Per-entity push implementations ────────────────────────────────────

    /**
     * Vault §06.06 — homework push to the shared `homework` table so the
     * Student Web Portal shows the assignment. Uses the postgrest table
     * upsert (idempotent on the primary key) rather than an RPC — the
     * `homework` table is part of the shared schema (migration 0027) and has
     * no dedicated upsert RPC.
     */
    private suspend fun pushHomework(entry: SyncQueueEntity, p: JsonObject) {
        // T-024 / HOMEWORK-101: the server's `homework.id` column is a UUID
        // PRIMARY KEY (migration 0029). Idempotency is on that primary key, so
        // the SAME logical row must always push the SAME server id. New rows
        // (post-T-024) are created with a bare UUID local id; LEGACY Room rows
        // and queue entries still carry the "hwk-" prefix — strip it here so
        // they can finally reach the server, and so a re-pushed legacy row
        // lands on the same server id as the stripped form (never a duplicate).
        val rawId = p.str("id") ?: return
        val id = rawId.removePrefix("hwk-")
        val classId = p.str("classId") ?: p.str("class_id") ?: return
        val subjectId = p.str("subjectId") ?: p.str("subject_id") ?: return
        val row = buildJsonObject {
            put("id", id)
            put("tenant_id", entry.tenantId)
            put("class_id", classId)
            put("subject_id", subjectId)
            p.str("subjectName")?.let { put("subject_name", it) }
            p.str("teacherId")?.let { put("teacher_id", it) }
            p.str("teacherName")?.let { put("teacher_name", it) }
            put("title", p.str("title") ?: "Devoir")
            put("description", p.str("description") ?: "")
            put("due_date", p.str("dueDate") ?: p.str("due_date") ?: "")
            p.str("academicYear")?.takeIf { it.isNotBlank() }?.let { put("academic_year", it) }
            p.str("pushedAt")?.takeIf { it.isNotBlank() }?.let { put("pushed_at", it) }
            put("created_at", p.str("createdAt") ?: p.str("created_at"))
            // attachments — the local JSON string (["a.jpg"]) is passed
            // through verbatim as a jsonb-compatible JSON array.
            val attachmentsRaw = p.str("attachments")
            val attachmentsElement = attachmentsRaw?.let {
                runCatching { json.parseToJsonElement(it) }.getOrNull()
            }
            if (attachmentsElement != null) put("attachments", attachmentsElement)
        }
        NetworkTimeouts.guardSyncPush("sync.pushHomework", timeoutMs = 5_000L) {
            supabaseProvider.postgrest.from("homework").upsert(row)
        }
    }

    private suspend fun pushParent(
        entry: SyncQueueEntity,
        p: JsonObject,
        actorId: String,
    ) {
        val params = buildJsonObject {
            put("p_tenant_id", entry.tenantId)
            put("p_parent_code", p.str("code") ?: p.str("parent_code") ?: generateParentCode())
            put("p_first_name", p.str("firstName") ?: p.str("first_name") ?: "")
            put("p_last_name", p.str("lastName") ?: p.str("last_name") ?: "")
            put("p_display_name", p.str("displayName") ?: p.str("display_name"))
            put("p_primary_phone", p.str("phone") ?: p.str("primary_phone") ?: "(inconnu)")
            put("p_secondary_phone", p.str("whatsapp") ?: p.str("secondary_phone"))
            put("p_email", p.str("email"))
            put("p_occupation", p.str("occupation"))
            put("p_address", p.str("address"))
            put("p_preferred_language", p.str("preferredLanguage") ?: "fr")
            put("p_is_active", true)
            // 0037 — canonical deterministic activation code so the server
            // populates activation_codes (web-portal activation).
            (p.str("activationCode") ?: p.str("activation_code"))?.let { put("p_activation_code", it) }
        }
        NetworkTimeouts.guardSyncPush("sync.pushParent", timeoutMs = 5_000L) {
            supabaseProvider.postgrest.rpc("upsert_parent_from_import", params)
        }
    }

    private suspend fun pushStudent(
        entry: SyncQueueEntity,
        p: JsonObject,
        actorId: String,
    ) {
        val parentId = p.str("parentId") ?: p.str("parent_id") ?: return
        val params = buildJsonObject {
            put("p_tenant_id", entry.tenantId)
            put("p_student_code", p.str("code") ?: p.str("student_code") ?: generateStudentCode())
            put("p_parent_id", parentId)
            put("p_first_name", p.str("firstName") ?: p.str("first_name") ?: "")
            put("p_last_name", p.str("lastName") ?: p.str("last_name") ?: "")
            put("p_display_name", p.str("displayName") ?: p.str("display_name"))
            put("p_date_of_birth", p.str("birthDate") ?: p.str("date_of_birth"))
            val gender = p.str("gender")
            if (gender != null && gender != "unspecified") put("p_gender", gender)
            put("p_class_id", p.str("classId") ?: p.str("class_id"))
            put("p_enrollment_status", p.str("status") ?: "active")
            put("p_medical_notes", p.str("medicalNotes") ?: p.str("medical_notes"))
            put("p_is_active", true)
            // T-024 / STUDENT-100: the promotion flow (operation="promote")
            // updates the local gradeLevel and enqueues a student payload with
            // the NEW grade — but this push never forwarded it, and the server
            // column students.grade_level_code was silently left at the old
            // value (cross-platform state drift: Android shows the new grade,
            // desktop/website show the old one). The RPC has accepted
            // p_grade_level_code since migration 0037 (verified live
            // 2026-09-01 via pg_get_functiondef) — send it on every student
            // push so promotions propagate. The RPC's COALESCE keeps the
            // server value when the payload omits the field (null-safe).
            (p.str("gradeLevel") ?: p.str("grade_level") ?: p.str("gradeLevelCode"))
                ?.takeIf { it.isNotBlank() }
                ?.let { put("p_grade_level_code", it) }
            (p.str("transportTier") ?: p.str("transport_tier"))?.let { put("p_transport_tier", it) }
        }
        NetworkTimeouts.guardSyncPush("sync.pushStudent", timeoutMs = 5_000L) {
            supabaseProvider.postgrest.rpc("upsert_student_from_import", params)
        }
    }

    private suspend fun pushPayment(
        entry: SyncQueueEntity,
        p: JsonObject,
        actorId: String,
    ) {
        // TIER 4 FIX — canonical parent code preferred (server-side resolution).
        val parentId = p.str("parentCode") ?: p.str("parent_code")
            ?: p.str("parentId") ?: p.str("parent_id") ?: return
        // CANONICAL-FINANCIAL-LOGIC.md §8.3 — Android domain stores money as
        // Long CENTIMES; the Supabase `payments.amount` column is NUMERIC(12,2)
        // DZD. Without `/100.0` conversion, a 150,000 DZD payment (15,000,000
        // centimes) is pushed as 15,000,000.00 DZD — a 100× inflation.
        val amountCentimes = p.str("amount")?.toLongOrNull() ?: return
        val amountDzd = amountCentimes / 100.0
        val params = buildJsonObject {
            put("p_tenant_id", entry.tenantId)
            put("p_payment_number", p.str("receiptNumber") ?: p.str("payment_number") ?: generatePaymentNumber())
            put("p_parent_id", parentId)
            // p_student_id — nullable; send null for parent-scoped payments.
            val studentId = p.str("studentId") ?: p.str("student_id")
            if (studentId != null) put("p_student_id", studentId) else put("p_student_id", JsonNull)
            // CANONICAL-FINANCIAL-LOGIC.md §8.3 — centimes → DZD.
            put("p_amount", amountDzd)
            put("p_method", p.str("method") ?: "cash")
            put("p_category", p.str("category") ?: "other")
            put("p_status", p.str("status"))
            put("p_proof_path", p.str("proofUrl") ?: p.str("proof_path"))
            put("p_collected_at", p.str("collectedAt") ?: p.str("collected_at"))
            put("p_collected_by", p.str("collectedBy") ?: p.str("collected_by") ?: actorId)
            put("p_notes", p.str("notes"))
            // CANONICAL-FINANCIAL-LOGIC.md §8.5 — check / transfer metadata +
            // installment linkage.
            // TIER 4 FIX — the previous `p.str(k) ?: p.str(k2)?.let { … }` form
            // suffered from elvis-precedence: when the camelCase key was
            // present (Android's actual payload format), the right-hand `let`
            // was never evaluated, so these params were silently never sent.
            (p.str("installmentId") ?: p.str("installment_id"))?.let { put("p_installment_id", it) }
            (p.str("checkNumber") ?: p.str("check_number"))?.let { put("p_check_number", it) }
            (p.str("checkBankName") ?: p.str("check_bank_name"))?.let { put("p_check_bank_name", it) }
            (p.str("checkIssueDate") ?: p.str("check_issue_date"))?.let { put("p_check_issue_date", it) }
            (p.str("checkClearanceDate") ?: p.str("check_clearance_date"))?.let { put("p_check_clearance_date", it) }
            (p.str("transferReference") ?: p.str("transfer_reference"))?.let { put("p_transfer_reference", it) }
            (p.str("transferSourceBank") ?: p.str("transfer_source_bank"))?.let { put("p_transfer_source_bank", it) }
        }
        NetworkTimeouts.guardSyncPush("sync.pushPayment", timeoutMs = 5_000L) {
            supabaseProvider.postgrest.rpc("upsert_payment_from_import", params)
        }
    }

    private suspend fun pushLedgerEntry(
        entry: SyncQueueEntity,
        p: JsonObject,
        actorId: String,
    ) {
        // TIER 4 FIX — canonical parent code preferred (server-side resolution).
        val parentId = p.str("parentCode") ?: p.str("parent_code")
            ?: p.str("parentId") ?: p.str("parent_id") ?: return
        // CANONICAL-FINANCIAL-LOGIC.md §8.3 — centimes → DZD.
        val amountCentimes = p.str("amount")?.toLongOrNull() ?: return
        val amountDzd = amountCentimes / 100.0
        // CANONICAL-FINANCIAL-LOGIC.md §8.4 — `p_metadata` MUST be sent on every
        // ledger_entry push. Preserve verbatim from the source entity.
        val metadataJsonStr = p.str("metadataJson") ?: p.str("metadata_json") ?: "{}"
        val metadataElement = runCatching {
            json.parseToJsonElement(metadataJsonStr)
        }.getOrNull() ?: JsonNull
        val params = buildJsonObject {
            put("p_tenant_id", entry.tenantId)
            put("p_entry_number", p.str("id") ?: p.str("entry_number"))
            put("p_parent_id", parentId)
            // p_student_id — nullable (parent_credit entries have studentId=null).
            val studentId = p.str("studentId") ?: p.str("student_id")
            if (studentId != null) put("p_student_id", studentId) else put("p_student_id", JsonNull)
            put("p_account_id", p.str("accountId") ?: p.str("account_id"))
            put("p_entry_type", p.str("type") ?: p.str("entry_type") ?: "charge")
            // CANONICAL-FINANCIAL-LOGIC.md §8.3 — centimes → DZD.
            put("p_amount", amountDzd)
            put("p_category", p.str("category") ?: "other")
            put("p_description", p.str("description"))
            put("p_source_type", p.str("sourceType") ?: p.str("source_type") ?: "bulk_import")
            put("p_source_id", p.str("sourceId") ?: p.str("source_id"))
            put("p_method", p.str("method"))
            put("p_receipt_number", p.str("receiptNumber") ?: p.str("receipt_number"))
            put("p_payment_status", p.str("paymentStatus") ?: p.str("payment_status"))
            put("p_reverses_id", p.str("reversesId") ?: p.str("reverses_id"))
            put("p_actor_id", p.str("actorId") ?: p.str("actor_id") ?: actorId)
            put("p_actor_name", p.str("actorName") ?: p.str("actor_name") ?: "Android")
            put("p_at", p.str("at"))
            // CANONICAL-FINANCIAL-LOGIC.md §8.4 — send p_metadata as a JSON object.
            put("p_metadata", metadataElement)
        }
        NetworkTimeouts.guardSyncPush("sync.pushLedgerEntry", timeoutMs = 5_000L) {
            supabaseProvider.postgrest.rpc("upsert_ledger_entry_from_import", params)
        }
    }

    /**
     * TIER 4 FIX (migration 0037) — push installment mutations to the new
     * idempotent `upsert_installment_from_import` RPC so Android-side
     * waterfall allocation results reach the server. Amounts are converted
     * centimes → DZD.
     */
    private suspend fun pushInstallment(
        entry: SyncQueueEntity,
        p: JsonObject,
        actorId: String,
    ) {
        val parentId = p.str("parentCode") ?: p.str("parent_code")
            ?: p.str("parentId") ?: p.str("parent_id") ?: return
        val amountDueDzd = (p.str("amountDue") ?: p.str("amount_due"))?.toLongOrNull()?.let { it / 100.0 }
        val amountPaidDzd = (p.str("amountPaid") ?: p.str("amount_paid"))?.toLongOrNull()?.let { it / 100.0 }
        val amountPendingDzd = (p.str("amountPending") ?: p.str("amount_pending"))?.toLongOrNull()?.let { it / 100.0 }

        val params = buildJsonObject {
            put("p_tenant_id", entry.tenantId)
            put("p_installment_ref", p.str("id") ?: p.str("installment_ref"))
            put("p_parent_id", parentId)
            (p.str("studentId") ?: p.str("student_id"))?.let { put("p_student_id", it) }
            put("p_category", p.str("category") ?: "tuition")
            put("p_label", p.str("label"))
            amountDueDzd?.let { put("p_amount_due", it) }
            amountPaidDzd?.let { put("p_amount_paid", it) }
            amountPendingDzd?.let { put("p_amount_pending", it) }
            put("p_due_date", p.str("dueDate") ?: p.str("due_date"))
            put("p_paid_date", p.str("paidDate") ?: p.str("paid_date"))
            put("p_status", p.str("status") ?: "unpaid")
            put("p_academic_cycle", p.str("academicCycle") ?: p.str("academic_cycle"))
        }
        NetworkTimeouts.guardSyncPush("sync.pushInstallment", timeoutMs = 5_000L) {
            supabaseProvider.postgrest.rpc("upsert_installment_from_import", params)
        }
    }

    /**
     * Vault §06.02 — push a grade entry into the canonical `assessments`
     * table. Column shape mirrors migration 0029 + 0041 exactly:
     *   term INTEGER 1|2|3 (domain uses "T1"|"T2"|"T3"),
     *   subject_average NUMERIC(4,2) (canonical engine value),
     *   per-component coefficient snapshot (defaults 1/1/2).
     * The upsert conflicts on (student_id, subject_id, term, academic_year)
     * so re-pushing the same entry never duplicates — identical to the
     * desktop's grade-entry upsert.
     */
    private suspend fun pushGrade(entry: SyncQueueEntity, p: JsonObject) {
        val studentId = p.str("studentId") ?: p.str("student_id") ?: return
        val subjectId = p.str("subjectId") ?: p.str("subject_id") ?: return
        // WIRE: the DB column is INTEGER 1|2|3 (migration 0004); the local
        // domain uses "T1"|"T2"|"T3" strings.
        val termWire = p.str("term")?.let { t ->
            Regex("^T?(\\d+)$").find(t)?.groupValues?.get(1)?.toIntOrNull()
        } ?: 1
        val params = buildJsonObject {
            put("p_tenant_id", entry.tenantId)
            put("p_student_id", studentId)
            put("p_subject_id", subjectId)
            (p.str("classId") ?: p.str("class_id"))?.let { put("p_class_id", it) }
            put("p_term", termWire.coerceIn(1, 3))
            put("p_academic_year", p.str("academicYear") ?: p.str("academic_year") ?: "")
            // ARCH-007 fix (T-081): `Double? ?: JsonNull` infers `Any`, which
            // matches no `put` overload — wrap the number in JsonPrimitive so
            // the elvis branch yields a JsonElement (JSON null when absent).
            put("p_devoir1", p.str("devoir1")?.toDoubleOrNull()?.let(::JsonPrimitive) ?: JsonNull)
            put("p_devoir2", p.str("devoir2")?.toDoubleOrNull()?.let(::JsonPrimitive) ?: JsonNull)
            put("p_examen", p.str("examen")?.toDoubleOrNull()?.let(::JsonPrimitive) ?: JsonNull)
            // T-348 (ADR-018): the contrôle-continu mark + its weight
            // snapshot travel with the row (0094 RPC parameters).
            put("p_cc", p.str("cc")?.toDoubleOrNull()?.let(::JsonPrimitive) ?: JsonNull)
            put("p_coefficient", p.str("coefficient")?.toDoubleOrNull() ?: 1.0)
            put("p_coefficient_devoir1", p.str("coefficientDevoir1")?.toDoubleOrNull() ?: 1.0)
            put("p_coefficient_devoir2", p.str("coefficientDevoir2")?.toDoubleOrNull() ?: 1.0)
            put("p_coefficient_examen", p.str("coefficientExamen")?.toDoubleOrNull() ?: 2.0)
            put("p_coefficient_cc", p.str("coefficientCc")?.toDoubleOrNull() ?: 0.0)
            put("p_entered_by", p.str("enteredBy"))
            put("p_entered_at", p.str("enteredAt"))
        }
        NetworkTimeouts.guardSyncPush("sync.pushGrade", timeoutMs = 5_000L) {
            supabaseProvider.postgrest.rpc("upsert_assessment_from_import", params)
        }
    }

    /**
     * Vault §06.03 — push a roll-call record into `attendance_records`.
     * The canonical unique key (tenant_id, student_id, record_date, session)
     * from migration 0041 makes the upsert idempotent.
     */
    private suspend fun pushAttendance(entry: SyncQueueEntity, p: JsonObject) {
        val studentId = p.str("studentId") ?: p.str("student_id") ?: return
        val recordDate = p.str("recordDate") ?: p.str("record_date") ?: p.str("date") ?: return
        val params = buildJsonObject {
            put("p_tenant_id", entry.tenantId)
            put("p_student_id", studentId)
            (p.str("classId") ?: p.str("class_id"))?.let { put("p_class_id", it) }
            put("p_record_date", recordDate)
            put("p_session", p.str("session") ?: "morning")
            put("p_status", p.str("status") ?: "present")
            put("p_arrival_time", p.str("arrivalTime"))
            put("p_note", p.str("note"))
            put("p_recorded_by", p.str("recordedBy"))
            put("p_recorded_at", p.str("recordedAt"))
        }
        NetworkTimeouts.guardSyncPush("sync.pushAttendance", timeoutMs = 5_000L) {
            supabaseProvider.postgrest.rpc("upsert_attendance_from_import", params)
        }
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private fun generateParentCode(): String {
        val year = java.time.Year.now().value
        val chars = ('A'..'Z') + ('0'..'9')
        val suffix = (1..4).map { chars.random() }.joinToString("")
        return "PAR-$year-$suffix"
    }

    private fun generateStudentCode(): String {
        val year = java.time.Year.now().value
        val seq = (1..1_000_000).random()
        return "ELV-$year-${seq.toString().padStart(6, '0')}"
    }

    private fun generatePaymentNumber(): String {
        val year = java.time.Year.now().value
        val seq = (1..1_000_000).random()
        return "PAY-$year-${seq.toString().padStart(6, '0')}"
    }
}

/**
 * Helper: return the string content of a [JsonObject] field by key, or null
 * if the field is absent, null, or not a string primitive.
 *
 * Workaround for the Kotlin serialization API's verbose null handling —
 * handles `JsonNull`, missing keys, and non-string primitives uniformly.
 */
private fun JsonObject.str(key: String): String? {
    val el: JsonElement = this[key] ?: return null
    if (el is JsonNull) return null
    return try {
        el.jsonPrimitive.content.takeIf { it.isNotEmpty() }
    } catch (e: Exception) {
        null
    }
}
