package com.example.infrastructure.supabase

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement

/**
 * Shared DTOs for the canonical Supabase PostgreSQL tables.
 * Perfectly mirrors the schema definitions provided by the user.
 */

@Serializable
data class TenantDto(
    @SerialName("id") val id: String,
    @SerialName("slug") val slug: String,
    @SerialName("name") val name: String,
    @SerialName("legal_name") val legalName: String? = null,
    @SerialName("tax_id") val taxId: String? = null,
    @SerialName("address") val address: String? = null,
    @SerialName("city") val city: String? = null,
    @SerialName("postal_code") val postalCode: String? = null,
    @SerialName("country") val country: String = "DZ",
    @SerialName("phone") val phone: String? = null,
    @SerialName("email") val email: String? = null,
    @SerialName("website") val website: String? = null,
    @SerialName("logo_path") val logoPath: String? = null,
    @SerialName("default_locale") val defaultLocale: String = "fr",
    @SerialName("default_currency") val defaultCurrency: String = "DZD",
    @SerialName("timezone") val timezone: String = "Africa/Algiers",
    @SerialName("is_active") val isActive: Boolean = true,
    @SerialName("settings") val settings: JsonElement? = null,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
    @SerialName("deleted_at") val deletedAt: String? = null,
)

@Serializable
data class ParentDto(
    @SerialName("id") val id: String = "",
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("parent_code") val parentCode: String? = null,
    @SerialName("first_name") val firstName: String = "",
    @SerialName("last_name") val lastName: String = "",
    @SerialName("display_name") val displayName: String? = null,
    @SerialName("primary_phone") val primaryPhone: String = "",
    @SerialName("secondary_phone") val secondaryPhone: String? = null,
    @SerialName("email") val email: String? = null,
    @SerialName("national_id") val nationalId: String? = null,
    @SerialName("occupation") val occupation: String? = null,
    @SerialName("address") val address: String? = null,
    @SerialName("city") val city: String? = null,
    @SerialName("postal_code") val postalCode: String? = null,
    @SerialName("relationship") val relationship: String? = null,
    @SerialName("notes") val notes: String? = null,
    @SerialName("is_active") val isActive: Boolean = true,
    @SerialName("is_financially_restricted") val isFinanciallyRestricted: Boolean = false,
    @SerialName("auth_user_id") val authUserId: String? = null,
    @SerialName("transport_destination") val transportDestination: String? = null,
    @SerialName("city_tier") val cityTier: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
    @SerialName("deleted_at") val deletedAt: String? = null,
)

@Serializable
data class StudentDto(
    @SerialName("id") val id: String = "",
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("parent_id") val parentId: String? = null,
    @SerialName("student_code") val studentCode: String? = null,
    @SerialName("first_name") val firstName: String = "",
    @SerialName("middle_name") val middleName: String? = null,
    @SerialName("last_name") val lastName: String = "",
    @SerialName("display_name") val displayName: String? = null,
    @SerialName("date_of_birth") val dateOfBirth: String? = null,
    @SerialName("gender") val gender: String? = null,
    @SerialName("grade_level_id") val gradeLevelId: String? = null,
    @SerialName("grade_level_code") val gradeLevelCode: String? = null,
    @SerialName("class_id") val classId: String? = null,
    @SerialName("enrollment_date") val enrollmentDate: String? = null,
    @SerialName("enrollment_status") val enrollmentStatus: String? = "active",
    @SerialName("medical_notes") val medicalNotes: String? = null,
    @SerialName("is_active") val isActive: Boolean = true,
    @SerialName("auth_user_id") val authUserId: String? = null,
    @SerialName("transport_tier") val transportTier: String? = null,
    @SerialName("payment_plan") val paymentPlan: String? = "tranches",
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
    @SerialName("deleted_at") val deletedAt: String? = null,
)

@Serializable
data class AcademicYearDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("label") val label: String,
    @SerialName("start_date") val startDate: String,
    @SerialName("end_date") val endDate: String,
    @SerialName("term_structure") val termStructure: String = "trimester",
    @SerialName("is_current") val isCurrent: Boolean = false,
    @SerialName("is_archived") val isArchived: Boolean = false,
    @SerialName("code") val code: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
)

@Serializable
data class AcademicLevelDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("cycle") val cycle: String,
    @SerialName("year_label") val yearLabel: String,
    @SerialName("year_number") val yearNumber: Int = 1,
    @SerialName("grade_code") val gradeCode: String,
    @SerialName("sort_order") val sortOrder: Int = 1,
    @SerialName("is_active") val isActive: Boolean = true,
    @SerialName("label_fr") val labelFr: String? = null,
    @SerialName("label_ar") val labelAr: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
)

@Serializable
data class ClassDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("academic_year_id") val academicYearId: String? = null,
    @SerialName("academic_level_id") val academicLevelId: String? = null,
    @SerialName("section") val section: String = "A",
    @SerialName("code") val code: String,
    @SerialName("name") val name: String? = null,
    // TIER 4 FIX — nullable capacity (null = unlimited enrollment), matching
    // the desktop model + SQL. The previous non-null default of 30 fabricated
    // a limit the server never set.
    @SerialName("capacity") val capacity: Int? = null,
    @SerialName("homeroom_teacher_id") val homeroomTeacherId: String? = null,
    @SerialName("homeroom_teacher_name") val homeroomTeacherName: String? = null,
    @SerialName("room") val room: String? = null,
    @SerialName("grade_code") val gradeCode: String? = null,
    @SerialName("is_active") val isActive: Boolean = true,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
)

@Serializable
data class SubjectDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("code") val code: String,
    @SerialName("name_fr") val nameFr: String,
    @SerialName("name_ar") val nameAr: String? = null,
    @SerialName("name_en") val nameEn: String? = null,
    @SerialName("domain") val domain: String = "scolarite",
    @SerialName("default_coefficient") val defaultCoefficient: Int = 1,
    @SerialName("is_active") val isActive: Boolean = true,
    @SerialName("cycle") val cycle: String? = null,
    @SerialName("passing_grade") val passingGrade: Double? = 10.0,
    @SerialName("is_extracurricular") val isExtracurricular: Boolean = false,
    // Vault §06.02 (iteration 2) — per-COMPONENT coefficients on the shared
    // subject schema. Nullable so a backend that hasn't migrated to the
    // per-component recipe still parses (defaults apply downstream). When
    // the backend/desktop add the matching `coefficient_devoir_1` /
    // `coefficient_devoir_2` / `coefficient_examen` columns, the values
    // round-trip through the sync layer unchanged.
    @SerialName("coefficient_devoir_1") val coefficientDevoir1: Double? = null,
    @SerialName("coefficient_devoir_2") val coefficientDevoir2: Double? = null,
    @SerialName("coefficient_examen") val coefficientExamen: Double? = null,
    // T-348 (ADR-018): the cc weight snapshot (0 = excluded).
    @SerialName("coefficient_cc") val coefficientCc: Double? = null,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
)

@Serializable
data class AssessmentDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("class_subject_id") val classSubjectId: String? = null,
    @SerialName("class_id") val classId: String? = null,
    @SerialName("subject_id") val subjectId: String? = null,
    @SerialName("student_id") val studentId: String? = null,
    @SerialName("term") val term: Int = 1,
    @SerialName("kind") val kind: String = "devoir_1",
    @SerialName("label") val label: String? = null,
    @SerialName("max_score") val maxScore: Double = 20.0,
    @SerialName("weight") val weight: Double = 1.0,
    @SerialName("coefficient") val coefficient: Double = 1.0,
    @SerialName("scheduled_at") val scheduledAt: String? = null,
    // T-039 / HOMEWORK-103: the canonical pull shape (migration 0041) — the
    // per-student assessment row with the year + component scores.
    @SerialName("academic_year") val academicYear: String? = null,
    @SerialName("devoir1") val devoir1: Double? = null,
    @SerialName("devoir2") val devoir2: Double? = null,
    @SerialName("examen") val examen: Double? = null,
    // T-348 (MATIERE-500/ADR-018): the contrôle-continu mark + its weight.
    @SerialName("cc") val cc: Double? = null,
    @SerialName("subject_average") val subjectAverage: Double? = null,
    @SerialName("coefficient_devoir1") val coefficientDevoir1: Double? = null,
    @SerialName("coefficient_devoir2") val coefficientDevoir2: Double? = null,
    @SerialName("coefficient_examen") val coefficientExamen: Double? = null,
    // T-348 (ADR-018): the cc weight snapshot (0 = excluded).
    @SerialName("coefficient_cc") val coefficientCc: Double? = null,
    @SerialName("entered_by") val enteredBy: String? = null,
    @SerialName("entered_at") val enteredAt: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
)

@Serializable
data class GradeDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("student_id") val studentId: String,
    @SerialName("assessment_id") val assessmentId: String,
    @SerialName("class_subject_id") val classSubjectId: String? = null,
    @SerialName("score") val score: Double,
    @SerialName("subject_average") val subjectAverage: Double? = null,
    @SerialName("is_absent") val isAbsent: Boolean = false,
    @SerialName("entered_by") val enteredBy: String? = null,
    @SerialName("entered_at") val enteredAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
)

@Serializable
data class AttendanceRecordDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("student_id") val studentId: String,
    @SerialName("class_id") val classId: String,
    @SerialName("class_subject_id") val classSubjectId: String? = null,
    @SerialName("date") val date: String? = null,
    @SerialName("record_date") val recordDate: String? = null,
    @SerialName("session") val session: String = "morning",
    @SerialName("status") val status: String,
    @SerialName("arrival_time") val arrivalTime: String? = null,
    @SerialName("note") val note: String? = null,
    @SerialName("recorded_by") val recordedBy: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
)

@Serializable
data class HomeworkDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("class_id") val classId: String,
    @SerialName("subject_id") val subjectId: String,
    @SerialName("subject_name") val subjectName: String? = null,
    @SerialName("teacher_id") val teacherId: String? = null,
    @SerialName("teacher_name") val teacherName: String? = null,
    @SerialName("title") val title: String,
    @SerialName("description") val description: String,
    @SerialName("due_date") val dueDate: String,
    @SerialName("academic_year") val academicYear: String? = null,
    // T-039 / HOMEWORK-103: attachments (jsonb array) + pushed_at exist on
    // the canonical table (migration 0029) — decode so a pulled row round-
    // trips into the local entity without losing fields.
    @SerialName("attachments") val attachments: kotlinx.serialization.json.JsonElement? = null,
    @SerialName("pushed_at") val pushedAt: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
)

@Serializable
data class PaymentDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("payment_number") val paymentNumber: String,
    @SerialName("receipt_number") val receiptNumber: String? = null,
    @SerialName("parent_id") val parentId: String,
    @SerialName("student_id") val studentId: String? = null,
    @SerialName("invoice_id") val invoiceId: String? = null,
    @SerialName("installment_id") val installmentId: String? = null,
    @SerialName("amount") val amount: Double,
    @SerialName("method") val method: String,
    @SerialName("category") val category: String? = "other",
    @SerialName("status") val status: String,
    @SerialName("check_number") val checkNumber: String? = null,
    @SerialName("check_bank_name") val checkBankName: String? = null,
    @SerialName("check_issue_date") val checkIssueDate: String? = null,
    @SerialName("check_clearance_date") val checkClearanceDate: String? = null,
    @SerialName("transfer_reference") val transferReference: String? = null,
    @SerialName("transfer_source_bank") val transferSourceBank: String? = null,
    @SerialName("proof_path") val proofPath: String? = null,
    @SerialName("collected_at") val collectedAt: String? = null,
    @SerialName("collected_by") val collectedBy: String? = null,
    @SerialName("notes") val notes: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
)

@Serializable
data class InstallmentDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("parent_id") val parentId: String,
    @SerialName("student_id") val studentId: String,
    @SerialName("service_enrollment_id") val serviceEnrollmentId: String? = null,
    @SerialName("invoice_id") val invoiceId: String? = null,
    @SerialName("tranche_number") val trancheNumber: Int = 1,
    @SerialName("amount_due") val amountDue: Double,
    @SerialName("amount_paid") val amountPaid: Double = 0.0,
    @SerialName("amount_pending") val amountPending: Double = 0.0,
    @SerialName("due_date") val dueDate: String,
    @SerialName("paid_date") val paidDate: String? = null,
    @SerialName("status") val status: String = "unpaid",
    @SerialName("academic_cycle") val academicCycle: String? = null,
    @SerialName("label") val label: String? = null,
    @SerialName("category") val category: String = "tuition",
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
)

@Serializable
data class LedgerEntryDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("entry_number") val entryNumber: String? = null,
    @SerialName("parent_id") val parentId: String,
    @SerialName("student_id") val studentId: String? = null,
    @SerialName("account_id") val accountId: String,
    @SerialName("entry_type") val entryType: String,
    @SerialName("amount") val amount: Double,
    @SerialName("category") val category: String,
    @SerialName("description") val description: String? = null,
    @SerialName("entry_date") val entryDate: String? = null,
    @SerialName("source_type") val sourceType: String? = null,
    @SerialName("source_id") val sourceId: String? = null,
    @SerialName("method") val method: String? = null,
    @SerialName("receipt_number") val receiptNumber: String? = null,
    @SerialName("payment_status") val paymentStatus: String? = null,
    @SerialName("reverses_id") val reversesId: String? = null,
    @SerialName("actor_id") val actorId: String? = null,
    @SerialName("actor_name") val actorName: String? = null,
    @SerialName("at") val at: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
    // CANONICAL-FINANCIAL-LOGIC.md §7.5 + §8.4 — pull-side metadata.
    // The Supabase `ledger_entries.metadata` JSONB column is parsed as a
    // raw JsonElement to preserve any field the server stores; the entity
    // mapper stores the verbatim JSON string in `metadataJson`.
    @SerialName("metadata") val metadata: kotlinx.serialization.json.JsonElement? = null,
)

@Serializable
data class DepartmentDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("code") val code: String,
    @SerialName("name_fr") val nameFr: String,
    @SerialName("label_ar") val labelAr: String? = null,
    @SerialName("color_hex") val colorHex: String? = null,
    @SerialName("head_personnel_id") val headPersonnelId: String? = null,
    @SerialName("description") val description: String? = null,
    @SerialName("is_active") val isActive: Boolean = true,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
)

@Serializable
data class PersonnelDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("personnel_code") val personnelCode: String,
    @SerialName("user_id") val userId: String? = null,
    @SerialName("first_name") val firstName: String,
    @SerialName("last_name") val lastName: String,
    @SerialName("middle_name") val middleName: String? = null,
    @SerialName("staff_category") val staffCategory: String = "teaching",
    @SerialName("department_id") val departmentId: String? = null,
    @SerialName("position") val position: String? = null,
    @SerialName("hire_date") val hireDate: String? = null,
    @SerialName("is_active") val isActive: Boolean = true,
    @SerialName("base_salary") val baseSalary: Double? = null,
    @SerialName("primary_phone") val primaryPhone: String? = null,
    @SerialName("email") val email: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
)

@Serializable
data class ReleveEntryDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("personnel_id") val personnelId: String,
    @SerialName("activity_type") val activityType: String = "course",
    @SerialName("class_id") val classId: String? = null,
    @SerialName("class_subject_id") val classSubjectId: String? = null,
    @SerialName("description") val description: String? = null,
    @SerialName("clock_in_at") val clockInAt: String,
    @SerialName("clock_out_at") val clockOutAt: String? = null,
    @SerialName("duration_minutes") val durationMinutes: Int? = null,
    @SerialName("recorded_by") val recordedBy: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
)

@Serializable
data class ExpenseCategoryDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("code") val code: String,
    @SerialName("label_fr") val labelFr: String,
    @SerialName("label_ar") val labelAr: String? = null,
    @SerialName("is_active") val isActive: Boolean = true,
    @SerialName("created_at") val createdAt: String? = null,
)

@Serializable
data class ExpenseTicketDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("ticket_number") val ticketNumber: String,
    @SerialName("title") val title: String,
    @SerialName("description") val description: String,
    @SerialName("category_id") val categoryId: String,
    @SerialName("requested_amount") val requestedAmount: Double,
    @SerialName("final_spent_amount") val finalSpentAmount: Double? = null,
    @SerialName("justification") val justification: String? = null,
    @SerialName("urgency") val urgency: String = "medium",
    @SerialName("status") val status: String = "pending_approval",
    @SerialName("submitted_by") val submittedBy: String,
    @SerialName("submitted_at") val submittedAt: String? = null,
    @SerialName("approved_by") val approvedBy: String? = null,
    @SerialName("receipt_path") val receiptPath: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
)

@Serializable
data class NotificationDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("kind") val kind: String = "info",
    @SerialName("title") val title: String,
    @SerialName("body") val body: String? = null,
    @SerialName("priority") val priority: String = "medium",
    @SerialName("source") val source: String = "system",
    @SerialName("target_user_id") val targetUserId: String? = null,
    // T-039 / NOTIF-105: role broadcasts carry the role in target_role
    // (server column, migration 0013). Decoded so the local cache can evict
    // role-broadcasts that no longer match the signed-in user's role.
    @SerialName("target_role") val targetRole: String? = null,
    @SerialName("is_read") val isRead: Boolean = false,
    // T-181 (T-173b / NOTIF-200): the server's dismissal timestamp. Decoded
    // so the pull layer can (a) record it in Room (migration v14) and
    // (b) evict local rows the server has dismissed since the last pull —
    // the run-overdue-scan lifecycle resolves alerts (sets dismissed_at)
    // when the installment is paid; pre-T-181 those rows lingered in Room
    // forever because the T-172 pull filter only stops NEW dismissed rows.
    @SerialName("dismissed_at") val dismissedAt: String? = null,
    @SerialName("triggered_at") val triggeredAt: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
)

/**
 * Workflow-run row (read-only on mobile — the DAG editor is desktop-only per
 * plan §10.02). Pulled so the Workflow Monitor shows REAL server executions.
 */
/**
 * T-231 (34th session) — the REAL workflow_runs contract. The previous DTO
 * was written against a *planned* schema (trigger/started_by/finished_at/
 * result_json) that never existed: every pulled run decoded with null
 * trigger (→ "Manuel"), null timestamps and null results. The live columns
 * (migration 0012 + 0081) are trigger_type/actor_id/completed_at/
 * node_results; workflow_name resolves via the `workflows(name)` embed
 * (the pull selects "*, workflows(name)").
 */
@Serializable
data class WorkflowRunDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("workflow_id") val workflowId: String = "",
    @SerialName("workflows") val workflow: WorkflowEmbedDto? = null,
    @SerialName("trigger_type") val triggerType: String? = null,
    @SerialName("status") val status: String = "running",
    @SerialName("actor_id") val actorId: String? = null,
    @SerialName("started_at") val startedAt: String? = null,
    @SerialName("completed_at") val completedAt: String? = null,
    @SerialName("duration_ms") val durationMs: Long? = null,
    @SerialName("node_results") val nodeResults: List<WorkflowNodeResultDto>? = null,
    @SerialName("error_message") val errorMessage: String? = null,
)

/** The PostgREST many-to-one embed of workflows(name) on workflow_runs. */
@Serializable
data class WorkflowEmbedDto(
    @SerialName("name") val name: String? = null,
    @SerialName("code") val code: String? = null,
)

/**
 * One node outcome inside workflow_runs.node_results — the exact shape the
 * workflow-execute EF writes (node_id/node_type/node_subtype/node_label/
 * status/started_at/completed_at/output/error).
 */
@Serializable
data class WorkflowNodeResultDto(
    @SerialName("node_id") val nodeId: String = "",
    @SerialName("node_type") val nodeType: String? = null,
    @SerialName("node_subtype") val nodeSubtype: String? = null,
    @SerialName("node_label") val nodeLabel: String? = null,
    @SerialName("status") val status: String = "skipped",
    @SerialName("started_at") val startedAt: String? = null,
    @SerialName("completed_at") val completedAt: String? = null,
    @SerialName("output") val output: JsonElement? = null,
    @SerialName("error") val error: String? = null,
)

@Serializable
data class TaskDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("title") val title: String,
    @SerialName("description") val description: String? = null,
    @SerialName("status") val status: String = "pending",
    @SerialName("priority") val priority: String = "medium",
    @SerialName("department_id") val departmentId: String? = null,
    @SerialName("due_date") val dueDate: String? = null,
    @SerialName("progress") val progress: Int = 0,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
)

@Serializable
data class DeviceTokenDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("user_id") val userId: String,
    @SerialName("token") val token: String,
    @SerialName("platform") val platform: String = "android",
    @SerialName("app_version") val appVersion: String? = null,
    @SerialName("is_active") val isActive: Boolean = true,
    @SerialName("last_seen_at") val lastSeenAt: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
)

@Serializable
data class PricingConfigDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("academic_year_id") val academicYearId: String,
    @SerialName("label") val label: String,
    @SerialName("registration_fee") val registrationFee: Double = 5000.0,
    @SerialName("late_penalty_per_day") val latePenaltyPerDay: Double = 100.0,
    @SerialName("second_apron_fee") val secondApronFee: Double = 2000.0,
    @SerialName("early_payment_bonus_pct") val earlyPaymentBonusPct: Double = 5.0,
    @SerialName("early_payment_deadline") val earlyPaymentDeadline: String? = null,
    @SerialName("is_active") val isActive: Boolean = true,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
)

@Serializable
data class GradeLevelTuitionDto(
    @SerialName("id") val id: String,
    @SerialName("pricing_config_id") val pricingConfigId: String,
    @SerialName("academic_level_id") val academicLevelId: String,
    @SerialName("annual_amount") val annualAmount: Double,
    @SerialName("tranche_1_amount") val tranche1Amount: Double,
    @SerialName("tranche_2_amount") val tranche2Amount: Double,
    @SerialName("tranche_3_amount") val tranche3Amount: Double,
)

@Serializable
data class TransportDestinationDto(
    @SerialName("id") val id: String,
    @SerialName("pricing_config_id") val pricingConfigId: String,
    @SerialName("code") val code: String,
    @SerialName("label_fr") val labelFr: String,
    @SerialName("label_ar") val labelAr: String? = null,
    @SerialName("annual_amount") val annualAmount: Double,
    @SerialName("tranche_1_amount") val tranche1Amount: Double,
    @SerialName("tranche_2_amount") val tranche2Amount: Double,
    @SerialName("tranche_3_amount") val tranche3Amount: Double,
)

@Serializable
data class DiscountDto(
    @SerialName("id") val id: String,
    @SerialName("pricing_config_id") val pricingConfigId: String,
    @SerialName("code") val code: String,
    @SerialName("label_fr") val labelFr: String,
    @SerialName("discount_type") val discountType: String,
    @SerialName("amount") val amount: Double,
    @SerialName("applies_to") val appliesTo: String = "total",
    @SerialName("is_active") val isActive: Boolean = true,
)


/**
 * T-299 (OFFLINE-400): the audit_logs row (migration 0014) — the canonical
 * "every change" stream. Pulled into Room so the attributed audit feed
 * (AuditStreamScreen, T-297's red/green diff renderer) stays live, and
 * refreshed by the RealtimeSyncManager audit_logs route. RLS gates which
 * rows this device receives (admins/finance: the tenant stream; other
 * staff: their own) — same policy the desktop's subscription respects.
 *
 * T-310 (49th session, AUDIT-502) — TWO fixes baked into the types:
 *   1. before_json / after_json / diff are JsonElement, NOT String?:
 *      PostgREST returns jsonb columns as PARSED JSON objects. The old
 *      String? declarations made decodeList<AuditLogDto> throw the moment
 *      any pulled row carried a non-null snapshot (the 0086 trigger rows
 *      write full before/after objects) — the whole pull failed silently
 *      as a Result.Err. The entity keeps String (compact JSON text,
 *      stringified here in the mapper).
 *   2. `diff` is declared at all: the payment RPCs (0034, pre-0087) wrote
 *      their payload ONLY into that column with both snapshots NULL —
 *      declaring it lets the mapper recover the payment details (the
 *      owner's "payment details missing from the audit" report).
 */
@Serializable
data class AuditLogDto(
    @SerialName("id") val id: String,
    @SerialName("tenant_id") val tenantId: String? = null,
    @SerialName("action") val action: String = "",
    @SerialName("entity_type") val entityType: String = "",
    @SerialName("entity_id") val entityId: String? = null,
    @SerialName("actor_id") val actorId: String? = null,
    @SerialName("actor_name") val actorName: String? = null,
    @SerialName("actor_role") val actorRole: String? = null,
    @SerialName("before_json") val beforeJson: JsonElement? = null,
    @SerialName("after_json") val afterJson: JsonElement? = null,
    @SerialName("diff") val diff: JsonElement? = null,
    @SerialName("note") val note: String? = null,
    @SerialName("occurred_at") val occurredAt: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
)
