# Unknowns — Open Questions Registry

> Questions that cannot currently be answered with sufficient evidence. **No agent may silently turn an unknown into an assumption** — that is how this codebase accumulated much of its drift. Each unknown lists what is needed to resolve it and what it blocks. When an unknown is resolved, record the decision (as an ADR if architectural) and update the blocked problems/tasks.

## ~~UNKNOWN-001 — Does binding an activation code activate the user account?~~ RESOLVED 2026-09-03

- **Resolution (24th session, ADR-011 / T-146):** the owner's issue report ("entering an activation code … preventing users from **activating and accessing** their accounts") is the product decision: **binding an activation code ACTIVATES the account** (pending → active + parent role + approval link cleared; suspended/deleted hard-rejected). The semantics live in the ONE canonical hub EF; the website's drifted copy is deleted. Live round-trip 19/19: docs/recovery/t-147-live-verification.md. T-028's blocker is cleared (the consolidation is done).

- **Question:** The website's `bind-activation-code` EF sets `user_profiles.status='active'` + grants the parent role after binding; the desktop's canonical version does neither (activation is a separate admin step). Which is the intended contract?
- **Evidence:** Website EF `index.ts:174-205` activates; desktop EF `index.ts:78-133` does not; SQL RPC `bind_activation_code` (0005) only binds `parents.auth_user_id`. They cannot both be right. (Problems CROSS-009, BUSINESS-008, SEC-104.)
- **Why it matters:** whichever EF is deployed determines whether parents can self-activate or wait for staff; consolidating the two EFs is impossible until this is decided.
- **Affected components:** both bind-activation-code EFs, parent onboarding (Path A), `approve_account_request` flow.
- **Blocked:** T-028 (EF consolidation), part of SEC-110's activation side-effects.
- **Required to resolve:** business owner decision (product semantics), then an ADR.

## UNKNOWN-002 — What is the Android target write architecture?

- **Question:** Should Android mutate the server through the canonical RPCs (online direct, offline queued replay) as ADR-005 proposes, or keep the Room-first + `upsert_*_from_import` design with the import RPCs upgraded to parity?
- **Evidence:** current architecture bypasses all canonical financial RPCs (ARCH-003/CROSS-005) with silent server-side gaps (CROSS-102/103, BUSINESS-102). ADR-005 exists but is Proposed — not owner-confirmed.
- **Why it matters:** it is the single largest architectural decision left; it determines whether Android financial writes ever gain server-side validation/audit and which Room layer survives.
- **Affected components:** Android repository bindings, sync dispatcher, Room layers; canonical RPC contract.
- **Blocked:** T-045 (Room consolidation), T-059 (Android canonical writes), parts of T-038/T-069 scheduling.
- **Required to resolve:** owner sign-off on ADR-005 (or an explicit alternative decision + new ADR).

## UNKNOWN-003 — Are the payment Edge Functions the canonical gateway or dead code?

- **Question:** `collect-payment` and `refund-payment` EFs contain JWT/permission/validation/audit logic but no client ever calls them (DEAD-016). Gateway (wire clients to them) or remove (direct SQL RPC is the contract)?
- **Evidence:** zero invocation sites across all three repos; clients call SQL RPCs directly; the EFs' absorbed latent defects (WEAK-001/002, DRIFT-002/004) were never triggered.
- **Why it matters:** if they are the gateway, their defects become live and must be fixed; if removed, RLS+triggers alone carry the invariants and the security posture must be reviewed.
- **Affected components:** both EFs, desktop/Android payment write paths.
- **Blocked:** T-067.
- **Required to resolve:** owner decision; interacts with ADR-005.

## ~~UNKNOWN-004 — Do parents need server-stored downloadable receipts?~~ RESOLVED 2026-09-05 (30th session, ADR-014)

- **Question:** The `receipts` table + storage bucket are orphaned (no writer since migration 0034 dropped the old `collect_payment`); the website's Receipts tab is permanently empty. Restore server-side receipt persistence, or remove the table and keep desktop client-side PDFs?
- **Evidence:** CROSS-101 (table created 0007, written until 0034, empty since; website `useReceiptsForPayment` queries a table nothing writes).
- **Why it matters:** either parents get self-service receipt downloads (feature work) or a dead table + broken UI ships (current state).
- **Affected components:** `receipts` table, website Receipts tab, desktop generateReceipt.
- **Blocked:** T-066.
- **Required to resolve:** product decision (support/audit requirements for receipt re-download).
- **RESOLUTION:** **client-side deterministic generation** (ADR-014, `docs/decisions/ADR-014-client-side-receipt-generation.md`): receipt + statement PDFs generate client-side from the canonical payments/ledger rows on EVERY platform (desktop reference module; website pdf-lib ports — T-194/T-195). The outcome the question was really about — parents re-downloading receipts without staff intervention — is delivered with ZERO server state. The orphaned table + bucket + policies are dropped (migration 0079). Server-persisted immutable receipts stay a rejected alternative until a business need appears (revisit via a new ADR). T-066 unblocked (nothing to build).

## ~~UNKNOWN-005 — What is the chat product scope?~~ RESOLVED 2026-08-31

- **Question:** Is staff↔parent/staff↔staff chat a committed feature? No production code creates `chat_channels`; the desktop chat is an in-memory mock; the website MessagesView is permanently empty.
- **Evidence:** CHAT-103 (zero channel writers), CHAT-105 (mock chat), CHAT-104 (no last-message sorting).
- **Resolution (14th session):** the owner instructed "fix and test the chat in all platforms" —
  chat IS a committed feature. Channel creation is staff-only; the parent portal is read+reply.
  Recorded as **ADR-008** (accepted). Implementation: migration 0061 (backend completion +
  canonical `create_direct_channel` RPC), T-099 (desktop SupabaseChatRepository), T-100
  (staff↔parent entry point), T-101 (portal readiness). T-037's "if built" branch is operative.
- **Unblocked:** T-037 (implementation portion), CHAT-104. NEW scope gap documented: Android has
  no chat UI at all (task T-102 tracks it).

## UNKNOWN-006 — Is multi-tenancy a real production requirement?

- **Question:** Will more than one school (tenant) ever share a deployment? Today a single DEMO tenant (`00000000-…-0001`) is the production tenant for El-Imtiyaz Boumerdès.
- **Evidence:** the schema is multi-tenant by design (tenants, tenant_id everywhere, per-tenant roles), but the resolver/policy defects (TENANT-100/101/102) show the model was never exercised beyond one tenant.
- **Why it matters:** determines the real-world severity of all TENANT-* findings and how much hardening investment is justified.
- **Affected components:** RBAC resolver, RLS policies, tenant enumeration.
- **Blocked:** nothing hard-blocked; affects prioritisation of T-005/T-053 and acceptance criteria.
- **Required to resolve:** owner statement of deployment intent.

## UNKNOWN-007 — How should role-broadcast notification read-state work?

- **Question:** `notifications.is_read` is a single flag, but role-broadcasts target many recipients. Introduce a per-recipient read table (e.g. `notification_reads`), or accept broadcasts as read-only/undismissible?
- **Evidence:** NOTIF-100 (RLS blocks recipients from marking broadcasts read — bulk mark-read silently no-ops), NOTIF-104 (Android read-state is local-only).
- **Why it matters:** current behaviour makes the bell badge permanently non-zero and trains users to ignore notifications.
- **Affected components:** notifications table/RLS, all three bell implementations.
- **Blocked:** T-038; influences T-032's notifications filter portion.
- **Required to resolve:** product decision + schema design.

## UNKNOWN-008 — What activation-code format and rate-limit policy is acceptable?

- **Question:** Codes are 7 digits from non-crypto `random()` (10M space, brute-forceable, no rate limit). A stronger format (longer, alphanumeric, CSPRNG) trades off human readability (parents type these). What is the requirement?
- **Evidence:** WEAK-100; migration 0005 `generate_activation_code`; website activation screen without rate limiting.
- **Why it matters:** combined with SEC-110 (now fixed via T-006) brute-force enabled account takeover; even with caller verification, code enumeration remains possible.
- **Affected components:** activation code generation, binding endpoint.
- **Blocked:** T-072.
- **Required to resolve:** product/security decision (format, attempt limits, lockout).

## UNKNOWN-009 — Are demo accounts intended for production builds?

- **Question:** Desktop ships 9 quick-fill staff accounts; Android ships a divergent set with one shared password. Dev convenience or product feature (e.g. for sales demos)?
- **Evidence:** SEC-100, CROSS-100.
- **Why it matters:** determines the end-state of T-001 (delete vs dev-gate) and whether credentials must be rotated everywhere.
- **Affected components:** both login screens.
- **Blocked:** final policy of T-001 (the security fix itself is unblocked).
- **Required to resolve:** owner decision.

## UNKNOWN-010 — Is the multi-guardian family feature required?

- **Question:** `parent_student_links` exists (schema + RLS) with zero writers; every student has exactly one `parent_id`. Does the school need both parents / guardians to have portal access?
- **Evidence:** DEAD-200.
- **Why it matters:** divorced/shared-custody families currently cannot both see their child's data; sibling-discount logic may miss half-siblings.
- **Affected components:** parent-student linkage, portal auth, discount engine.
- **Blocked:** T-070.
- **Required to resolve:** product decision.

## UNKNOWN-011 — Timetable: complete the feature or remove it? — RESOLVED (BUILD)

- **Question:** The desktop has a full timetable domain model + mock CRUD + conflict detection and a UI KPI, but no table, no repository, no migration. Build it or delete the façade?
- **Resolution (2026-09-22):** BUILD — the owner's T-404 registration directed the full Automatic Timetable feature; implemented and TESTED (see docs/recovery/t-404-live-verification.md). The legacy façade's removal is the registered follow-up (SCHED-100 residual).
- **Evidence:** SCHED-100 (RESOLVED), SCHED-101 (RESOLVED at the canonical level), ADR-020, migrations 0109/0110.
- **Why it matters:** the "Couverture EDT" KPI permanently shows 0% in production mode; users may believe timetables are managed.
- **Affected components:** desktop academics module.
- **Blocked:** T-042 (now unblocked — can be closed as superseded by T-404 or repointed to the façade removal).

## UNKNOWN-020 — Overdue-alert volume: per-installment alerts or a digest?

- **Question:** After T-172 the overdue-alert feed is TRUTHFUL (alerts resolve when installments are paid), but a 691-overdue corpus still produces 691 concurrent unread `financial_officer` alerts — one per genuinely overdue installment. Should the scan instead emit ONE digest alert (e.g. "N tranches en retard — X DZD au total — Module Finances") plus a top-N detail, or keep per-installment alerts?
- **Evidence:** NOTIF-200 (live: 958 unread pre-fix, 691 truthful post-fix; the owner's "why are there 1,000 notifications?" report).
- **Why it matters:** the per-installment design is unbounded with the corpus size; the bell dropdown shows 8, the repo caps reads at 200 — the UX degrades long before the data does. A digest changes the alert→installment navigation contract consumed by the desktop alerts-tab / detail modal (link_entity_id) and Android.
- **Affected components:** `run-overdue-scan` EF + desktop `SupabaseOverdueAlertGenerator` (equivalence mandatory), Android notification rendering.
- **Blocked:** T-173 (also carries the Android Room `dismissedAt` migration).
- **Required to resolve:** product decision (digest shape + N cap), then an ADR before implementation.

---

## UNKNOWN-021 — Should parents see (some) calendar_events on the portal?

- **Question:** The website's CalendarView + dashboard query `calendar_events` (portal-queries.ts useUpcomingEvents/useEventsInRange), but the `calendar_events_select` RLS policy (migration 0019) lists STAFF roles only — every parent read silently returns an empty array. Now that the desktop writes real rows (T-175), which event kinds should parents see? (exams / meetings / school-wide events plausibly yes; follow-up calls about debt plausibly no.)
- **Evidence:** T-175 session: policy text re-read + the live table census (0 rows — the desktop was the missing writer, so the empty result was invisible); the website kind map (calendar-view.tsx) already anticipates parent-relevant kinds.
- **Why it matters:** the T-160 scoping called calendar "the only slot with a verified live cross-platform read" — but under RLS that read is staff-empty for every parent session. Fixing it requires a policy decision on audience per kind (a tightened policy or a parent-visible flag column), which is a product + security decision, not an agent guess.
- **Affected components:** migration 0019 policy; website calendar-view + dashboard-view; desktop follow-up-call creation path (should staff be warned the event may be parent-visible?).
- **Blocked:** nothing hard — but any parent-calendar task must resolve this first.
- **Required to resolve:** product decision (which kinds are parent-visible), then a policy migration.

---

## UNKNOWN-022 — The 4 UPLOAD-104-era orphaned binaries in the `student-documents` bucket: recover, delete, or leave as forensic residue?

- **Question:** The bucket carries 4 objects with NO `student_documents` row and NO `documents_json` entry (their row-insert 403'd while the storage upload succeeded — the UPLOAD-104 era). Should they become document rows now that the metadata layer is unified (SYNC-110/T-372)?
- **Evidence:** live census (70th session, 2026-09-14): 6 objects total — `birth_certificate-1789339995946.png`, `birth_certificate-1789340019994.png`, `birth_certificate-1789340134747.png` (3× the SAME 3 029 615-byte PNG re-uploaded while the flow was broken), `id_photo-1789341401507.jpeg` (104 115 bytes — the SAME size as the SUCCESSFUL `birth_certificate-1789341527070.jpeg` row 2 minutes later). Each orphan corresponds to a file the owner EVENTUALLY re-uploaded successfully.
- **Why it matters:** auto-recovering them (kind parsed from the path prefix, file_name from the path tail) would mint DUPLICATE document rows for files that are already represented — the owner would see 4 extra documents. Deleting them loses nothing (the same files exist as successful rows) but destroys the forensic trail of the failed attempts. Leaving them documents the UPLOAD-104 era honestly but keeps 3 MB×3 of dead bytes.
- **Affected components:** `student-documents` bucket only; no client reads the orphans (every list is table-driven).
- **Blocked:** nothing hard — an owner decision (default: leave as forensic residue until the owner says otherwise).
- **Required to resolve:** owner choice between (a) recover as rows (accepting duplicates), (b) delete the 4 objects (service-key storage API — the `storage.buckets` SQL-delete guard doesn't apply to objects), (c) leave as residue.

---

## Resolved unknowns

- **UNKNOWN-005 (chat product scope)** — resolved 2026-08-31, 14th session: chat is a committed
  cross-platform feature (owner instruction). Decision recorded in ADR-008; backend migration
  0061 applied live (verify_t-098 15/15); desktop T-099/T-100 and website T-101 landed.
  Unblocked T-037; spawned T-102 (Android chat UI scope gap).

- **UNKNOWN-0XX (T-401, 2026-09-22): Gestion & Économie spécialités.** The
  Algerian 3AS Gestion & Économie filière has spécialité subdivisions in some
  classifications (sciences économiques / sciences de gestion — the BAC series
  naming). The school's actual practice is UNCONFIRMED; the 0107 catalog seeds
  only the well-established génie spécialités under Technique Mathématique. The
  catalog is data: the school adds the rows when confirmed (the desktop UI
  already renders any spécialité the catalog carries). Do not seed unconfirmed
  streams — AGENTS.md §15 rule 2 (never guess business rules).


## UNKNOWN-024 — Should a student-bound portal account see the FAMILY's financial surfaces? (T-413, 2026-09-26, 97th session)

The T-413 student-bound portal resolution deliberately scopes a student login to: their own student row (self-scoped childrenList) + the family row (the context header, via `parents_student_sees_own`). The FINANCIAL rows (installments/payments/ledger) remain parent-role-gated (0019) — a student sees honest empty financial tabs, while the parent's own portal owns the billing surfaces.

This is the safe default (the parents are the billing entity per plan §04), but the owner may want students to see the family's installments (e.g., teenage students checking their own tranche status). That would require extending the installments/payments/ledger SELECT policies with the student-self path (the is_own_parent_via_student pattern) — an owner decision, not an assumption. Registered during T-413; blocked on the owner's word.


## UNKNOWN-025 — The payroll-calendar convention: should INTERIOR disbursement gaps surface as missed payrolls? (T-412 second round / WORKFORCE-506, 2026-09-26, 98th session)

The T-412 overdue carry-over (financial-rules §16 / INV-17c) surfaces the TRAILING gap — months without `salary_payments` rows between the last PRE-current recorded period and the current period (the WORKFORCE-506 repair). INTERIOR gaps — months without rows BETWEEN two older recorded periods (e.g. rows exist for 2026-05 and 2026-09 but not 2026-06..08) — deliberately do NOT surface.

The conservative choice is intentional: distinguishing "no payroll was due that month" (e.g. a school that does not pay salaries in July/August) from "payroll was missed but never recorded" requires the school's payroll-calendar convention, which the repository does not document. Surfacing every interior gap by default could fabricate false funding requirements for legitimately payroll-free summer months.

**The owner should decide:** (a) payroll runs 12 months a year → interior gaps should surface as overdue (a one-line engine change + tests); (b) payroll runs on a school calendar (e.g. September–June) → the engine needs the no-payroll month set (a documented convention, potentially a `system_settings` key) before surfacing interior gaps; (c) leave conservative (the current state). Registered during the T-412 second round; blocked on the owner's word.

Related: UNKNOWN-020's sibling class (`on_leave` staff in the eligibility basis — financial-rules §16.1's standing note) is the OTHER payroll-basis owner decision pending since the 96th session.

## UNKNOWN-026 — The cold-cache backup boundary: should a Supabase-mode runBackup WAIT for the repository caches to seed? (T-415, 2026-09-26, 99th session)

The Supabase repositories' reactive caches seed asynchronously on first `observe()` (fire-and-forget). A backup taken on a cold app — before any screen subscribed — snapshots empty collections. The archive's metadata counts honestly expose that (the Settings list + inspectArchive show 0 — the detection surface, pinned by the metadata-fidelity tests), but the honest question for the owner: should runBackup (a) pre-warm and AWAIT the seeds (needs a `whenSeeded()` surface on the shared repositories — 8 classes), (b) snapshot a fresh server read instead of the caches (a bigger re-architecture of snapshotState), or (c) keep the current documented boundary (backups are of the app's current data view; take one after the app loaded)? Until decided, the boundary is documented in the SupabaseBackupRepository header + the T-415 registry entry.

## UNKNOWN-027 — The Supabase-mode restore semantics: restore rehydrates the OFFLINE operating layer (T-300's design) — should a full server rehydration path exist for Supabase mode? (T-415, 2026-09-26, 99th session)

Per T-300, `restore()` applies the snapshot into the offline operating mode (the mock layer) and arms staging — post-restore mutations flow to the server through the sync queue. In Supabase mode the app's screens read the Supabase repositories' caches, so a restored snapshot is not what the UI shows until the data flows back through sync. The full server-side rehydration path EXISTS as the Excel-import restore (t-364/t-366, IMPORT-106 — the atomic empty-DB restore). The owner decision: (a) keep the two paths separate (local/offline restore for disaster recovery + the Excel path for server rebuilds — the current state, documented), or (b) unify (a Supabase-mode restore re-imports the whole snapshot through the canonical RPCs — a significant new surface with idempotency requirements the Excel path already solved).

## UNKNOWN-028 — The unregistered live migration 0118 + the live-schema divergence: who owns reconciling the repo's migration chain with the live database? (T-415 live discoveries, 2026-09-26, 99th session)

The live `supabase_migrations.schema_migrations` carries **0118 / purge_student_parent_domain** with NO corresponding file in the repository (the §15.14 unregistered-patch class — applied by an off-repo actor), and **migration 0007's `receipts` table is ABSENT live** (only `pending_receipts` exists) — the live database was not built by replaying the file chain verbatim. Per §57c the live schema is the authority (introspect; read the live registry for the next free number — it is **0120** after this session's 0119). The owner decision: audit + document 0118's content and the receipts divergence (a backfill file? a live-schema census doc?), or accept the divergence permanently with the introspection rule as the guard.

## UNKNOWN-029 — The FI (frais d'inscription) semantics at re-enrollment: per-student-per-year or per-family-per-year? (T-439 / BUSINESS-110, 2026-09-29, 118th session)

The T-439 audit found the three billing paths DIVERGE on the registration fee: (1) the WORKBOOK charges FI per student (each student's TOTAL CREANCE includes it — the T-425 official model books FI as a per-student tranche-0 fee row on the import path); (2) the WIZARD (`register_family_batch`, unchanged since T-397) persists ONE flat `pricingConfig.registrationFee` LEDGER entry per family (`reg-<parentCode>-fee`); (3) the RE-ENROLLMENT path (T-437) reuses the batch shape — so the family-keyed `re-<year>-<parentCode>-fee` source id means re-enrolling a SECOND sibling through the per-student modal silently DROPS that child's FI (`ON CONFLICT DO NOTHING`), while the modal's devis (computeBilling) SHOWS a per-child, per-grade FI. At most one flat FI lands regardless of how many children are re-enrolled; the shown and persisted amounts disagree for every multi-child family.

**The owner should decide:** (a) FI is per-student-per-year (the workbook's apparent model — every enrolled child pays it) → the re-enrollment builder mints per-student-year FI source ids AND the devis shows per-child FI (consistent — but the wizard's legacy family-FI rows remain a historical divergence to document); or (b) FI is per-family-per-year (the wizard's model) → the modal's devis must show the family-level FI ONCE (a shown-vs-persisted repair on computeBilling's per-grade FI) and the sibling drop becomes correct behavior to disclose; or (c) the school uses both conventions in practice (a per-case toggle).

Until decided: BUSINESS-110 stays OPEN with the engineering fixes staged behind the ruling (the per-student-year ids OR the once-per-family devis; the FI account_id alignment to the batch convention [fn_re_enroll_student stamps every ledger row with the student id — the FI's null student_ref is ignored]; the existing-obligations guard against the wizard×re-enroll double-billing window; the batch path's year stamping). Registered during the T-439 audit (the 38-commit review of T-434..T-438).

## UNKNOWN-030 — The auto-Relevé (grades/homework/roll-call auto-ledger) cannot exist under the current canonical contract — who records a teacher's automatic activity entries? (T-477's audit / WORKFORCE-508, 2026-10-04)

The mock layer auto-appends Relevé entries when a teacher enters grades / pushes homework / submits roll call (`auto-releve.ts` — vault §09.06's "AUTOMATED operational activity ledger per teacher"). The canonical `releve_entries` contract makes that impossible as-written: RLS allows INSERT only for super_admin/financial_officer/support_staff/manager (0019), and the `prevent_self_releve_entry` trigger (0009) raises whenever `recorded_by == personnel.user_id` — a teacher's own auto-entry fires the trigger by construction, and there is no system/principal identity that holds the recorder role. The desktop Supabase-mode teacher ledger therefore shows admin-recorded entries only (the honest state after T-481's port); the mock's auto entries are mock-mode-only.

**The owner should decide:** (a) auto-tracking is wanted server-side → a canonical design is needed (a SECURITY DEFINER recorder path, an exempted auto entry kind, or a role-widened RLS with the trigger scoped to manual rows only) — an ADR + migration, not a client patch; (b) the §09.05 admin-recorded model stands → the auto-releve mock helpers should be retired entirely (and the ReleveTab copy must never claim automatic entries); or (c) defer. Registered during T-477's Personnel-page audit; T-481's port deliberately does NOT touch the server contract.
