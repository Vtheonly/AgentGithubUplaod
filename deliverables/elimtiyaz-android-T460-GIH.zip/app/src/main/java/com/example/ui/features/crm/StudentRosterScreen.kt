package com.example.ui.features.crm

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.Result
import com.example.core.Session
import com.example.domain.model.Student
import com.example.domain.repository.StudentRepository
import com.example.infrastructure.supabase.SupabaseClientProvider
import com.example.infrastructure.sync.PullSyncRepository
import com.example.ui.designsystem.components.card.ElCard
import com.example.ui.designsystem.components.card.ElCardSize
import com.example.ui.designsystem.components.display.ElAvatar
import com.example.ui.designsystem.components.display.ElAvatarSize
import com.example.ui.designsystem.components.display.ElTag
import com.example.ui.designsystem.components.display.ElTagTone
import com.example.ui.designsystem.components.feedback.ElEmptyState
import com.example.ui.designsystem.components.input.ElSearchBar
import com.example.ui.designsystem.theme.ElTheme
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * T-320 (55th session, UI-310) — CRM student roster, migrated to the
 * canonical design system with a School icon in the metric strip, a real
 * search bar, and the STATUS-AWARE tag kept (active → level tint, other
 * statuses → danger tint — the proposal's always-grade tag would hide
 * archived/inactive state). The ViewModel contract is unchanged.
 */
@HiltViewModel
class StudentRosterViewModel @Inject constructor(
    private val studentRepository: StudentRepository,
    private val pullSyncRepository: PullSyncRepository,
    private val supabaseProvider: SupabaseClientProvider,
) : ViewModel() {

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val students: StateFlow<List<Student>> = _query
        .flatMapLatest { q -> studentRepository.search(q) }
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _syncMessage = MutableStateFlow<String?>(null)
    val syncMessage: StateFlow<String?> = _syncMessage.asStateFlow()

    private val _isConfigured = MutableStateFlow(supabaseProvider.isConfigured())
    val isConfigured: StateFlow<Boolean> = _isConfigured.asStateFlow()

    fun setQuery(q: String) { _query.value = q }

    fun syncFromCloud() {
        if (_isSyncing.value) return
        _isSyncing.value = true
        _syncMessage.value = null
        viewModelScope.launch {
            try {
                val res = pullSyncRepository.pullAll()
                when (res) {
                    is Result.Ok -> {
                        _syncMessage.value = "${res.value} enregistrements synchronisés !"
                    }
                    is Result.Err -> {
                        _syncMessage.value = "Erreur : ${res.error.message}"
                    }
                }
            } catch (e: Exception) {
                _syncMessage.value = "Erreur de connexion : ${e.message}"
            } finally {
                _isSyncing.value = false
                _isConfigured.value = supabaseProvider.isConfigured()
            }
        }
    }

    fun clearMessage() { _syncMessage.value = null }
}

@Composable
fun StudentRosterScreen(
    session: Session,
    onStudentClick: (String) -> Unit,
    viewModel: StudentRosterViewModel = hiltViewModel(),
) {
    val c = ElTheme.colors
    val context = LocalContext.current
    val query by viewModel.query.collectAsState()
    val students by viewModel.students.collectAsState()
    val isSyncing by viewModel.isSyncing.collectAsState()
    val syncMessage by viewModel.syncMessage.collectAsState()
    val isConfigured by viewModel.isConfigured.collectAsState()

    LaunchedEffect(syncMessage) {
        syncMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.clearMessage()
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp),
            shape = RoundedCornerShape(12.dp),
            color = c.surfaceVariant.copy(alpha = 0.5f),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(
                                if (isConfigured) c.primary
                                else c.textMuted,
                            ),
                    )
                    Spacer(Modifier.width(8.dp))
                    Icon(
                        Icons.Default.School,
                        contentDescription = null,
                        tint = ElTheme.colors.primary,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = "${students.size} élève${if (students.size > 1) "s" else ""}",
                        style = ElTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isSyncing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = c.primary,
                        )
                    } else if (isConfigured) {
                        IconButton(
                            onClick = { viewModel.syncFromCloud() },
                            modifier = Modifier.size(36.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Actualiser",
                                tint = c.primary,
                            )
                        }
                    }
                }
            }
        }

        ElSearchBar(
            query = query,
            onQueryChange = viewModel::setQuery,
            placeholder = "Nom, prénom, matricule…",
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp),
        )

        if (students.isEmpty()) {
            ElEmptyState(
                icon = Icons.Default.Person,
                title = "Aucun élève trouvé",
                subtitle = if (query.isBlank()) "Aucun élève inscrit." else "Aucun élève ne correspond à « $query ».",
                modifier = Modifier.padding(top = 32.dp),
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 88.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(students, key = { it.id }) { student ->
                    ElCard(
                        modifier = Modifier.fillMaxWidth(),
                        size = ElCardSize.COMPACT,
                        onClick = { onStudentClick(student.id) },
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            ElAvatar(initials = student.fullName, size = ElAvatarSize.M)
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    student.fullName,
                                    style = ElTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold,
                                )
                                Text(
                                    "Matricule : ${student.code} • ${student.gradeLevel.uppercase()}",
                                    style = ElTheme.typography.bodySmall,
                                    color = ElTheme.colors.textSecondary,
                                )
                            }
                            // Status-aware tag: active shows the cycle, other
                            // statuses surface the raw status in danger tone.
                            if (student.status == "active") {
                                ElTag(text = student.level, tone = ElTagTone.INFO)
                            } else {
                                ElTag(text = student.status, tone = ElTagTone.DANGER)
                            }
                        }
                    }
                }
            }
        }
    }
}
