package com.example.domain.model

import kotlinx.serialization.Serializable

/**
 * T-340 (61st session, 2026-09-14 — STATS-400): the executive-statistics
 * snapshot — the repository → UI contract for the Executive Command Center.
 *
 * Every value is computed by `core/ExecutiveStatistics.kt` (the ADR-002
 * verbatim mirror of the desktop's executive-statistics.ts) at the
 * REPOSITORY level — the UI layer only renders. Honest defaults: no
 * fabricated meters, no hardcoded reference numbers (§15.16). This snapshot
 * REPLACES the removed vanity fields (amountBins / collectionHeatmap /
 * revenueTrend) on the DashboardKpi contract.
 */
@Serializable
data class ExecutiveStatsSnapshot(
    val waves: List<ExecWaveItem> = emptyList(),
    val erosion: ExecErosionItem = ExecErosionItem(),
    val triage: ExecTriageSnapshot = ExecTriageSnapshot(),
    val concentration: ExecConcentrationSnapshot = ExecConcentrationSnapshot(),
    val transport: ExecTransportSnapshot = ExecTransportSnapshot(),
    val services: List<ExecServiceItem> = emptyList(),
    val dynamics: ExecDynamicsSnapshot = ExecDynamicsSnapshot(),
    val riskSummary: ExecRiskSummaryItem = ExecRiskSummaryItem(),
    val riskRadar: List<ExecRiskProfileItem> = emptyList(),
    /**
     * T-454 (PARITY-007 / the desktop T-447 STATS-401 mirror): the canonical
     * POOLED all-categories T1/T2/T3 rows — the object BOTH the dashboard
     * wave hero (WaveVelocityCard) and the Finance strip (TrancheWaveCard)
     * render. Computed ONCE at the repository level by
     * `deriveExecPooledTrancheWaves` (the verbatim mirror of the desktop's
     * `derivePooledTrancheWaves`); the UI layers NEVER re-derive (the
     * one-derivation rule — one calculation, N presentations).
     */
    val pooledWaves: List<ExecPooledWaveItem> = emptyList(),
    /**
     * T-454: the non-wave rows (FI / unnumbered / out-of-range) grouped by
     * (kind × category) — the categories the wave model excludes BY DESIGN,
     * rendered in their own « Hors Tranches » section so the analysis
     * covers every revenue commitment with nothing silently dropped.
     */
    val nonWaveSummary: List<ExecNonWaveItem> = emptyList(),
)

@Serializable
data class ExecWaveItem(
    val key: String,                // "tuition#1" …
    val category: String,
    val categoryLabel: String,      // FR label
    val wave: Int,                  // 1 | 2 | 3
    val installmentCount: Int,
    val paidCount: Int,
    val familyCount: Int,
    val debtorFamilyCount: Int,
    /** T-451 (T-427 mirror): the wave's actually-late families (PAST-DUE only). */
    val overdueDebtorFamilyCount: Int = 0,
    val dueTotal: Long,             // centimes
    val paidTotal: Long,
    val remainingTotal: Long,
    val collectedPct: Int,
    val clearedPct: Int,
    val dueDate: String? = null,
    /** T-451 (T-435 mirror): the wave's due-date RANGE far bound (ISO). */
    val dueDateMax: String? = null,
    val phase: String = "in_window",// not_due | in_window | overdue
)

// ============================================================================
// T-454 (PARITY-007, 127th session — the desktop T-447 STATS-401 mirror):
// the POOLED wave + non-wave UI contract. The serializable repository→UI
// twins of core/ExecutiveStatistics.kt's ExecPooledTrancheWave /
// ExecWaveStatsRow / ExecNonWaveCategoryStat — the exact-dinar parity
// objects the desktop's WaveVelocityCard and Finance strip render (one
// derivation, two presentations; the UI NEVER re-computes).
// ============================================================================

/** The per-(category × wave) breakdown row inside a pooled wave (the TrancheWaveStats mirror). */
@Serializable
data class ExecWaveStatsItem(
    val category: String,
    val categoryLabel: String,      // FR label
    val wave: Int,                  // 1 | 2 | 3
    val installmentCount: Int,
    val settledCount: Int,
    val familyCount: Int,
    val debtorFamilyCount: Int,
    val overdueDebtorFamilyCount: Int,
    val dueTotal: Long,             // centimes
    val paidTotal: Long,
    val pendingTotal: Long,
    val remainingTotal: Long,
    val dueDateMin: String? = null, // ISO (null when no row carries a date)
    val dueDateMax: String? = null,
    val anyUnsettledOverdue: Boolean = false,
    val anyUnsettledFuture: Boolean = false,
)

/** The POOLED per-wave row (the PooledTrancheWave mirror) — the wave hero + the Finance strip's shared basis. */
@Serializable
data class ExecPooledWaveItem(
    val wave: Int,                  // 1 | 2 | 3
    val installmentCount: Int,
    val settledCount: Int,
    val familyCount: Int,           // SET UNION across categories
    val debtorFamilyCount: Int,     // SET UNION across categories
    val overdueDebtorFamilyCount: Int, // SET UNION across categories
    val dueTotal: Long,             // centimes
    val paidTotal: Long,
    val pendingTotal: Long,
    val remainingTotal: Long,
    /** Σ per-row max(0, paid + pending − due) — the parent credit ON the rows. */
    val overCoverageTotal: Long = 0L,
    /** round(paidTotal / dueTotal × 100) — PARITY-001, never clamped. */
    val collectedPct: Int = 0,
    val dueDateMin: String? = null, // ISO (null when no row carries a date)
    val dueDateMax: String? = null,
    val anyUnsettledOverdue: Boolean = false,
    val anyUnsettledFuture: Boolean = false,
    /** The wave's per-category breakdown (stable order: tuition → transport → others). */
    val perCategory: List<ExecWaveStatsItem> = emptyList(),
)

/** The non-wave row classes (the NonWaveKind mirror). */
@Serializable
enum class ExecNonWaveKindItem {
    FI, UNNUMBERED, OUT_OF_RANGE;
    val wire: String get() = name.lowercase()
}

/** The non-wave (kind × category) group (the NonWaveCategoryStats mirror) — the « Hors Tranches » section. */
@Serializable
data class ExecNonWaveItem(
    val kind: ExecNonWaveKindItem,
    val kindLabel: String,          // FR label ("fi" | "unnumbered" | "out_of_range")
    val category: String,
    val categoryLabel: String,      // FR label
    val installmentCount: Int,
    val settledCount: Int,
    val familyCount: Int,
    val debtorFamilyCount: Int,
    val overdueDebtorFamilyCount: Int,
    val dueTotal: Long,             // centimes
    val paidTotal: Long,
    val pendingTotal: Long,
    val remainingTotal: Long,
    val overCoverageTotal: Long = 0L,
    val dueDateMin: String? = null,
    val dueDateMax: String? = null,
    val anyUnsettledOverdue: Boolean = false,
)

@Serializable
data class ExecErosionItem(
    val remiseCount: Int = 0,
    val remiseTotal: Long = 0L,     // centimes
    val cancelCount: Int = 0,
    val cancelTotal: Long = 0L,
    val netRemiseTotal: Long = 0L,
    val grossCharges: Long = 0L,
    val stickerTotal: Long = 0L,
    val erosionPct: Int = 0,
    val averageRemise: Long = 0L,
    val maxRemise: Long = 0L,
    val minRemise: Long = 0L,
    val remiseFamilyCount: Int = 0,
)

@Serializable
data class ExecTriageBucketItem(
    val bucket: String,             // not_due | current | reminder | chronic
    val label: String,              // FR label
    val amount: Long,               // centimes
    val installmentCount: Int,
    val familyCount: Int,
    val share: Int,
)

@Serializable
data class ExecCallListEntryItem(
    val parentId: String,
    val parentName: String,
    val outstanding: Long,          // centimes
    val worstDaysOverdue: Long,
)

@Serializable
data class ExecTriageSnapshot(
    val buckets: List<ExecTriageBucketItem> = emptyList(),
    val totalOutstanding: Long = 0L,
    val callList: List<ExecCallListEntryItem> = emptyList(),
    /** T-457 (§15.1): the RED threshold actually applied by the derivation —
     *  the call-list header renders "beyond RED" from THIS value, never a
     *  hardcoded day count (the pre-T-457 stale "> 45 j" label bug). The
     *  default is the documented seed (migration 0125: red 60). */
    val redDays: Int = 60,
)

@Serializable
data class ExecTopFamilyItem(
    val parentId: String,
    val parentName: String,
    val outstanding: Long,          // centimes
    val childCount: Int,
    val shareOfTotalDebt: Int,
    val worstDaysOverdue: Long,
)

@Serializable
data class ExecConcentrationSnapshot(
    val totalOutstanding: Long = 0L,
    val debtorFamilyCount: Int = 0,
    val topFamilies: List<ExecTopFamilyItem> = emptyList(),
    val topTotal: Long = 0L,
    val topConcentrationPct: Int = 0,
)

@Serializable
data class ExecTransportRouteItem(
    val destination: String,        // canonical key
    val destinationLabel: String,   // FR label
    val riders: Int,
    val dueTotal: Long,             // centimes
    val paidTotal: Long,
    val remainingTotal: Long,
    val collectedPct: Int,
)

@Serializable
data class ExecTransportSnapshot(
    val riders: Int = 0,
    val nonRiders: Int = 0,
    val unresolvedRawValues: List<String> = emptyList(),
    val routes: List<ExecTransportRouteItem> = emptyList(),
    val dueTotal: Long = 0L,
    val paidTotal: Long = 0L,
    val remainingTotal: Long = 0L,
    val collectedPct: Int = 0,
)

@Serializable
data class ExecServiceItem(
    val category: String,
    val label: String,              // FR label
    val paymentCount: Int,
    val revenue: Long,              // centimes
    val studentCount: Int,
)

@Serializable
data class ExecFamilySizeItem(
    val label: String,              // "1 enfant" … "5+ enfants"
    val familyCount: Int,
    val studentCount: Int,
)

@Serializable
data class ExecSectionImbalanceItem(
    val gradeLabel: String,
    val sectionCount: Int,
    val sectionsLabel: String,      // "51 / 3" — the enrolled counts, desc
    val minEnrolled: Int,
    val maxEnrolled: Int,
    val averageEnrolled: Int,
    val spread: Int,
    val imbalanced: Boolean,
)

@Serializable
data class ExecDynamicsSnapshot(
    val totalStudents: Int = 0,
    val totalFamilies: Int = 0,
    val siblingIndex: Double? = null,
    val multiChildFamilyCount: Int = 0,
    val multiChildFamilyPct: Int = 0,
    val familySizes: List<ExecFamilySizeItem> = emptyList(),
    val imbalances: List<ExecSectionImbalanceItem> = emptyList(),
)

@Serializable
data class ExecRiskSummaryItem(
    val tripleCriticalCount: Int = 0,
    val academicAlertCount: Int = 0,
    val attendanceAlertCount: Int = 0,
    val financialTensionCount: Int = 0,
    val healthyCount: Int = 0,
    val tripleCriticalPct: Int = 0,
)

@Serializable
data class ExecRiskProfileItem(
    val studentId: String,
    val studentName: String,
    val className: String,
    val parentId: String,
    val parentName: String,
    val gpa: Double? = null,
    val attendanceRate: Double = 1.0,
    val unexcusedAbsences: Int = 0,
    val debtAmount: Long = 0L,      // centimes
    val riskCategory: String = "healthy",
)
