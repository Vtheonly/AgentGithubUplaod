package com.example.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant

/**
 * T-340 — the ExecutiveStatistics parity suite (STATS-400, 61st session).
 *
 * Every fixture + expected value below is the DESKTOP'S OWN
 * `src/tests/features/dashboard/executive-statistics.test.ts` corpus
 * (commit 256bfa4, T-338 / 61st session), mirrored VERBATIM. The fixtures
 * model the LIVE production shapes discovered during the session's DB
 * exploration (2026-09-14): installments carry tranche_number 1/2/3 with
 * tuition labels "INSCRIPTION (FI)" / "2EME TRANCHE (V2)" / "3ème TRANCHE
 * (2V)"; the remise markers are STRUCTURED metadata (field=REMISE +
 * reason=double_remise_cancel); transport_tier holds messy town spellings.
 *
 * Every test pins the EXACT expected integer values (no approximations)
 * so the Android mirror is held to the same corpus as the desktop. A
 * failure here means the two platforms would display DIFFERENT numbers
 * for the same data — the desktop ≡ android engine pin.
 */
class ExecutiveStatisticsTest {

    private val now = Instant.parse("2026-09-14T12:00:00Z").toEpochMilli()

    // ── Fixture builders (mirror the desktop make* builders) ──────────────

    private fun ins(
        id: String,
        parentId: String = "p-1",
        category: String = "tuition",
        trancheNumber: Int = 1,
        amountDue: Long = 100_000,
        amountPaid: Long = 0,
        amountPending: Long = 0,
        dueDate: String = "2025-09-15",
        status: String = "unpaid",
    ) = ExecInstallment(
        id = id, parentId = parentId, category = category, trancheNumber = trancheNumber,
        amountDue = amountDue, amountPaid = amountPaid, amountPending = amountPending,
        dueDate = dueDate, status = status,
    )

    private fun led(
        id: String,
        parentId: String = "p-1",
        category: String = "tuition",
        amount: Long = 0,
        type: String = "adjustment",
        description: String = "",
        metadata: Map<String, Any?> = emptyMap(),
    ) = ExecLedgerEntry(
        id = id, parentId = parentId, category = category, amount = amount,
        type = type, description = description, metadata = metadata,
    )

    private fun stu(
        id: String,
        parentId: String = "p-1",
        status: String = "active",
        transportTier: String? = null,
    ) = ExecStudent(id = id, parentId = parentId, status = status, transportTier = transportTier)

    private fun pay(
        id: String,
        amount: Long = 10_000,
        status: String = "paid",
        category: String = "therapy_psychology",
        studentId: String? = "stu-1",
    ) = ExecPayment(id = id, amount = amount, status = status, category = category, studentId = studentId)

    private fun cls(
        id: String,
        name: String,
        gradeCode: String,
        enrolledCount: Int,
        isActive: Boolean = true,
    ) = ExecClass(id = id, name = name, gradeCode = gradeCode, isActive = isActive, enrolledCount = enrolledCount)

    // ══════════════════════════════════════════════════════════════════════
    // Shared helpers
    // ══════════════════════════════════════════════════════════════════════

    @Test
    fun `daysBetweenFloor - a tranche due today is 0 days overdue, never 1`() {
        assertEquals(0L, execDaysBetweenFloor("2026-09-14", now))
    }

    @Test
    fun `daysBetweenFloor - floors partial days (due yesterday 13h vs now 12h = 0)`() {
        assertEquals(0L, execDaysBetweenFloor("2026-09-13T13:00:00Z", now))
    }

    @Test
    fun `daysBetweenFloor - 45 days late boundary is exact`() {
        assertEquals(45L, execDaysBetweenFloor("2026-07-31", now))
        assertEquals(46L, execDaysBetweenFloor("2026-07-30", now))
    }

    @Test
    fun `installmentRemaining - INV-4 uncleared pending funds count as covered-but-uncleared`() {
        assertEquals(30_000L, execInstallmentRemaining(100_000, 40_000, 30_000, "partial"))
    }

    @Test
    fun `installmentRemaining - paid installments are 0 even with rounding dust`() {
        assertEquals(0L, execInstallmentRemaining(100_000, 99_999, 5, "paid"))
    }

    @Test
    fun `installmentRemaining - clamps overpayment to 0`() {
        assertEquals(0L, execInstallmentRemaining(100_000, 120_000, 0, "unpaid"))
    }

    @Test
    fun `sharePct - round-half-up convention (PARITY-001, never integer division)`() {
        assertEquals(33, execSharePct(1, 3))
        assertEquals(67, execSharePct(2, 3))
        assertEquals(13, execSharePct(90_000, 700_000)) // the pinned corpus vector
        assertEquals(0, execSharePct(5, 0))
    }

    // ══════════════════════════════════════════════════════════════════════
    // 1. Tranche-wave collection velocity
    // ══════════════════════════════════════════════════════════════════════

    private val waveFixtures = listOf(
        // T1 tuition: 3 billed, 2 paid
        ins("t1-a", "p-1", trancheNumber = 1, amountDue = 100_000, amountPaid = 100_000, status = "paid", dueDate = "2025-09-15"),
        ins("t1-b", "p-2", trancheNumber = 1, amountDue = 110_000, amountPaid = 110_000, status = "paid", dueDate = "2025-09-15"),
        ins("t1-c", "p-3", trancheNumber = 1, amountDue = 120_000, amountPaid = 60_000, status = "partial", dueDate = "2025-09-15"),
        // T2 tuition: 3 billed, 1 paid
        ins("t2-a", "p-1", trancheNumber = 2, amountDue = 80_000, amountPaid = 80_000, status = "paid", dueDate = "2025-12-15"),
        ins("t2-b", "p-2", trancheNumber = 2, amountDue = 80_000, amountPaid = 0, status = "unpaid", dueDate = "2025-12-15"),
        ins("t2-c", "p-3", trancheNumber = 2, amountDue = 80_000, amountPaid = 0, status = "unpaid", dueDate = "2025-12-15"),
        // T3 tuition: 3 billed, 0 paid
        ins("t3-a", "p-1", trancheNumber = 3, amountDue = 80_000, amountPaid = 0, status = "unpaid", dueDate = "2026-03-15"),
        ins("t3-b", "p-2", trancheNumber = 3, amountDue = 80_000, amountPaid = 0, status = "unpaid", dueDate = "2026-03-15"),
        ins("t3-c", "p-3", trancheNumber = 3, amountDue = 80_000, amountPaid = 0, status = "unpaid", dueDate = "2026-03-15"),
        // Transport waves: 2 billed, both paid
        ins("tr-1", "p-1", category = "transport", trancheNumber = 1, amountDue = 20_000, amountPaid = 20_000, status = "paid", dueDate = "2025-09-15"),
        ins("tr-2", "p-2", category = "transport", trancheNumber = 2, amountDue = 10_000, amountPaid = 10_000, status = "paid", dueDate = "2025-12-15"),
    )

    @Test
    fun `waves - groups by category x tranche_number, never by label parsing`() {
        val waves = deriveExecTrancheWaves(waveFixtures, now)
        assertEquals(
            listOf("tuition#1", "tuition#2", "tuition#3", "transport#1", "transport#2"),
            waves.map { it.key },
        )
    }

    @Test
    fun `waves - T1 tuition exact billed collected remaining + value-based rate`() {
        val t1 = deriveExecTrancheWaves(waveFixtures, now)[0]
        assertEquals(3, t1.installmentCount)
        assertEquals(2, t1.paidCount)
        assertEquals(3, t1.familyCount)
        assertEquals(1, t1.debtorFamilyCount) // p-3 partial
        assertEquals(330_000L, t1.dueTotal)
        assertEquals(270_000L, t1.paidTotal)
        assertEquals(60_000L, t1.remainingTotal)
        assertEquals(82, t1.collectedPct) // round(270000/330000*100)
        assertEquals(67, t1.clearedPct)   // round(2/3*100)
        // The desktop toISOString convention — ALWAYS 3-digit millis.
        assertEquals("2025-09-15T00:00:00.000Z", t1.dueDate)
        assertEquals(WavePhase.OVERDUE, t1.phase) // unpaid remainder past due
    }

    @Test
    fun `waves - T2 T3 tuition exact staircase decay (the payroll-warning view)`() {
        val waves = deriveExecTrancheWaves(waveFixtures, now)
        assertEquals(33, waves[1].collectedPct)  // 80000/240000
        assertEquals(160_000L, waves[1].remainingTotal)
        assertEquals(0, waves[2].collectedPct)
        assertEquals(240_000L, waves[2].remainingTotal)
    }

    @Test
    fun `waves - fully-collected waves report 100 percent and phase in_window (complete)`() {
        val tr1 = deriveExecTrancheWaves(waveFixtures, now)[3]
        assertEquals(100, tr1.collectedPct)
        assertEquals(0L, tr1.remainingTotal)
        assertEquals(WavePhase.IN_WINDOW, tr1.phase)
    }

    @Test
    fun `waves - a wave whose unpaid remainders are all in the future is not_due`() {
        val future = deriveExecTrancheWaves(
            listOf(ins("f-1", "p-9", trancheNumber = 1, amountDue = 50_000, amountPaid = 0, status = "unpaid", dueDate = "2026-12-15")),
            now,
        )
        assertEquals(WavePhase.NOT_DUE, future[0].phase)
        assertEquals(50_000L, future[0].remainingTotal)
    }

    @Test
    fun `waves - T-451 the canonical settled predicate - a row whose INV-4 remaining is zero is settled even when status is not paid`() {
        // T-424 (DATA-042): isInstallmentSettled = status 'paid' OR
        // clampNonNegative(due - paid - pending) === 0 — the per-surface
        // status-only check rendered DIFFERENT verdicts for the same row.
        val waves = deriveExecTrancheWaves(
            listOf(
                ins("c-1", "p-9", trancheNumber = 1, amountDue = 100_000, amountPaid = 100_000, status = "unpaid", dueDate = "2025-09-15"),
                ins("c-2", "p-9", trancheNumber = 1, amountDue = 50_000, amountPaid = 50_000, status = "partial", dueDate = "2025-09-15"),
            ),
            now,
        )
        assertEquals(2, waves[0].paidCount)
        assertEquals(0L, waves[0].remainingTotal)
        assertEquals(0, waves[0].debtorFamilyCount)
        assertEquals(100, waves[0].clearedPct)
        assertEquals(WavePhase.IN_WINDOW, waves[0].phase)
        // The predicate is also exported for surface-level use.
        assertTrue(execIsInstallmentSettled("unpaid", 100_000, 100_000, 0))
        assertTrue(execIsInstallmentSettled("partial", 60_000, 50_000, 10_000)) // pending coverage counts
        assertFalse(execIsInstallmentSettled("partial", 60_000, 50_000, 0))
        assertTrue(execIsInstallmentSettled("paid", 60_000, 0, 0))
    }

    @Test
    fun `waves - T-451 non-wave rows (FI tranche 0 and legacy out-of-range) are EXCLUDED, never coerced into a wave`() {
        // T-425 (DATA-044, the official model): tranche 0 = the registration
        // fee (FI — a FEE, not a tranche); out-of-range legacy values (the
        // phantom T4) never form a wave. The live DB carries 1,137 FI rows at
        // tranche 0 — the old coerceIn(1,3) pooled them into wave 1.
        val waves = deriveExecTrancheWaves(
            listOf(
                ins("fi-1", "p-1", trancheNumber = 0, amountDue = 100_000, amountPaid = 100_000, status = "paid", dueDate = "2025-09-15"),
                ins("fi-2", "p-2", trancheNumber = 0, amountDue = 110_000, amountPaid = 110_000, status = "paid", dueDate = "2025-09-15"),
                ins("t4-1", "p-1", trancheNumber = 4, amountDue = 80_000, amountPaid = 0, status = "unpaid", dueDate = "2026-06-15"),
                ins("t1-1", "p-1", trancheNumber = 1, amountDue = 120_000, amountPaid = 60_000, status = "partial", dueDate = "2025-09-15"),
            ),
            now,
        )
        assertEquals(listOf("tuition#1"), waves.map { it.key })
        assertEquals(1, waves[0].installmentCount)
        assertEquals(120_000L, waves[0].dueTotal)
        // The FI rows' money NEVER reaches the waves.
        assertEquals(60_000L, waves[0].paidTotal)
    }

    @Test
    fun `waves - T-451 overdueDebtorFamilyCount separates owing families from actually-LATE families (T-427 DATA-048)`() {
        val waves = deriveExecTrancheWaves(
            listOf(
                // p-1 owes, PAST DUE (2025-09-15 < now) — actually late
                ins("o-1", "p-1", trancheNumber = 1, amountDue = 100_000, amountPaid = 0, status = "unpaid", dueDate = "2025-09-15"),
                // p-2 owes the SAME wave but the due date is FUTURE (2026-12-15) — owing, not late
                ins("o-2", "p-2", trancheNumber = 1, amountDue = 100_000, amountPaid = 0, status = "unpaid", dueDate = "2026-12-15"),
            ),
            now,
        )
        assertEquals(2, waves[0].debtorFamilyCount)
        assertEquals(1, waves[0].overdueDebtorFamilyCount)
    }

    @Test
    fun `waves - T-451 dueDateMax carries the wave due-date RANGE far bound (T-435 UI-317)`() {
        val waves = deriveExecTrancheWaves(
            listOf(
                ins("dr-1", "p-1", trancheNumber = 2, amountDue = 80_000, amountPaid = 0, status = "unpaid", dueDate = "2025-12-15"),
                ins("dr-2", "p-2", trancheNumber = 2, amountDue = 80_000, amountPaid = 0, status = "unpaid", dueDate = "2026-01-20"), // drifted off the official schedule
            ),
            now,
        )
        assertEquals("2025-12-15T00:00:00.000Z", waves[0].dueDate)
        assertEquals("2026-01-20T00:00:00.000Z", waves[0].dueDateMax)
    }

    @Test
    fun `waves - empty input to empty output (honest empty state)`() {
        assertTrue(deriveExecTrancheWaves(emptyList(), now).isEmpty())
    }

    // ══════════════════════════════════════════════════════════════════════
    // T-453 — the POOLED all-categories waves + the non-wave summary
    // (the T-447/STATS-401 mirrors — the exact-dinar parity object)
    // ══════════════════════════════════════════════════════════════════════

    @Test
    fun `pooled waves - set-union family counts across categories (never the sum of counts)`() {
        // p-1 owes BOTH tuition T1 AND transport T1 → ONE family in the pooled
        // wave-1 row (summing per-category counts would double-count them —
        // the §15.79 pooled-aggregate trap).
        val pooled = deriveExecPooledTrancheWaves(
            listOf(
                ins("pw-1", "p-1", trancheNumber = 1, amountDue = 100_000, amountPaid = 0, status = "unpaid", dueDate = "2025-09-15"),
                ins("pw-2", "p-1", category = "transport", trancheNumber = 1, amountDue = 20_000, amountPaid = 0, status = "unpaid", dueDate = "2025-09-15"),
                ins("pw-3", "p-2", trancheNumber = 1, amountDue = 80_000, amountPaid = 80_000, status = "paid", dueDate = "2025-09-15"),
            ),
            now,
        )
        assertEquals(1, pooled.size)
        val w1 = pooled[0]
        assertEquals(1, w1.wave)
        assertEquals(3, w1.installmentCount)
        assertEquals(1, w1.settledCount)
        assertEquals(2, w1.familyCount) // p-1 + p-2 — the SET union
        assertEquals(1, w1.debtorFamilyCount) // p-1 only
        assertEquals(1, w1.overdueDebtorFamilyCount) // p-1's rows are past due
        assertEquals(200_000L, w1.dueTotal)
        assertEquals(80_000L, w1.paidTotal)
        assertEquals(120_000L, w1.remainingTotal)
        assertEquals(40, w1.collectedPct) // round(80000/200000*100)
        assertEquals(2, w1.perCategory.size) // tuition first, transport second
        assertEquals("tuition", w1.perCategory[0].category)
        assertEquals("transport", w1.perCategory[1].category)
    }

    @Test
    fun `pooled waves - the reconciliation identity holds exactly, including the overCoverage leg`() {
        // The mandate's "Total Due = Paid + Pending + Remaining" identity:
        //   dueTotal + overCoverageTotal = paidTotal + pendingTotal + remainingTotal
        // The over-covered row (paid > due) exercises the overCoverage leg.
        val pooled = deriveExecPooledTrancheWaves(
            listOf(
                // over-covered: paid 250k of a 200k due → overCoverage 50k
                ins("oc-1", "p-1", category = "transport", trancheNumber = 2, amountDue = 200_000, amountPaid = 250_000, status = "paid", dueDate = "2025-12-15"),
                // normal row
                ins("oc-2", "p-2", trancheNumber = 2, amountDue = 100_000, amountPaid = 40_000, status = "partial", dueDate = "2025-12-15"),
                // pending coverage (uncleared cheque)
                ins("oc-3", "p-3", trancheNumber = 2, amountDue = 50_000, amountPaid = 0, amountPending = 50_000, status = "pending_clearance", dueDate = "2025-12-15"),
            ),
            now,
        )
        assertEquals(1, pooled.size)
        val w2 = pooled[0]
        assertEquals(50_000L, w2.overCoverageTotal)
        assertEquals(350_000L, w2.dueTotal)
        assertEquals(290_000L, w2.paidTotal)
        assertEquals(50_000L, w2.pendingTotal)
        assertEquals(60_000L, w2.remainingTotal) // the over-covered and pending rows contribute 0
        // settled: oc-1 (paid, and remaining clamps to 0) + oc-3 (pending coverage settles it)
        assertEquals(2, w2.settledCount)
        // THE identity — exact, per wave.
        assertEquals(w2.dueTotal + w2.overCoverageTotal, w2.paidTotal + w2.pendingTotal + w2.remainingTotal)
    }

    @Test
    fun `pooled waves - non-wave rows (FI) never reach the pool, and only waves with rows are returned`() {
        val pooled = deriveExecPooledTrancheWaves(
            listOf(
                ins("fi-x", "p-1", trancheNumber = 0, amountDue = 500_000, amountPaid = 500_000, status = "paid", dueDate = "2025-09-15"),
                ins("t3-x", "p-1", trancheNumber = 3, amountDue = 80_000, amountPaid = 0, status = "unpaid", dueDate = "2027-03-15"),
            ),
            now,
        )
        assertEquals(1, pooled.size) // wave 3 only — wave 1/2 have no rows, FI excluded
        assertEquals(3, pooled[0].wave)
        assertEquals(80_000L, pooled[0].dueTotal)
        assertTrue(pooled[0].anyUnsettledFuture) // the 2026-03-15 row is future-dated
        assertFalse(pooled[0].anyUnsettledOverdue)
    }

    @Test
    fun `non-wave summary - the FI (tranche 0) disclosure grouped by kind x category`() {
        val nw = deriveExecNonWaveSummary(
            listOf(
                ins("fi-1", "p-1", trancheNumber = 0, amountDue = 500_000, amountPaid = 500_000, status = "paid", dueDate = "2025-09-15"),
                ins("fi-2", "p-2", trancheNumber = 0, amountDue = 600_000, amountPaid = 300_000, status = "partial", dueDate = "2025-09-15"),
                // a legacy out-of-range row (the pre-T-425 phantom T4)
                ins("t4-x", "p-2", trancheNumber = 4, amountDue = 80_000, amountPaid = 0, status = "unpaid", dueDate = "2026-06-15"),
                // wave rows never reach the non-wave summary
                ins("w-x", "p-1", trancheNumber = 1, amountDue = 100_000, amountPaid = 0, status = "unpaid", dueDate = "2025-09-15"),
            ),
            now,
        )
        assertEquals(2, nw.size)
        // FI first (kind rank 0), then out_of_range
        assertEquals(ExecNonWaveKind.FI, nw[0].kind)
        assertEquals("tuition", nw[0].category)
        assertEquals(2, nw[0].installmentCount)
        assertEquals(1, nw[0].settledCount)
        assertEquals(2, nw[0].familyCount)
        assertEquals(1, nw[0].debtorFamilyCount)
        assertEquals(300_000L, nw[0].remainingTotal)
        assertEquals(ExecNonWaveKind.OUT_OF_RANGE, nw[1].kind)
        assertEquals(80_000L, nw[1].remainingTotal)
    }

    // ══════════════════════════════════════════════════════════════════════
    // 2. Discount erosion
    // ══════════════════════════════════════════════════════════════════════

    @Test
    fun `erosion - identifies remises via the STRUCTURED metadata marker (field REMISE)`() {
        val e = deriveExecDiscountErosion(
            listOf(
                led("c-1", type = "charge", amount = 100_000, description = "Devis annuel"),
                led(
                    "r-1", type = "adjustment", amount = -20_000,
                    description = "Remise sur devis (import Excel run run_msp3foah_c254f9)",
                    metadata = mapOf("field" to "REMISE", "importRunId" to "run_msp3foah_c254f9"),
                ),
            ),
        )
        assertEquals(1, e.remiseCount)
        assertEquals(20_000L, e.remiseTotal)
        assertEquals(0, e.cancelCount)
        assertEquals(100_000L, e.grossCharges)
        assertEquals(120_000L, e.stickerTotal)
        assertEquals(17, e.erosionPct) // round(20000/120000*100)
        assertEquals(20_000L, e.averageRemise)
        assertEquals(1, e.remiseFamilyCount)
    }

    @Test
    fun `erosion - description fallback catches legacy remise rows without metadata`() {
        val e = deriveExecDiscountErosion(
            listOf(led("r-legacy", type = "adjustment", amount = -5_000, description = "Remise sur devis (legacy import)")),
        )
        assertEquals(1, e.remiseCount)
        assertEquals(5_000L, e.remiseTotal)
    }

    @Test
    fun `erosion - double-remise-cancel debits counted separately and net to zero with the remise`() {
        val e = deriveExecDiscountErosion(
            listOf(
                led(
                    "r-1", type = "adjustment", amount = -25_500,
                    description = "Remise sur devis (import Excel run run_msp3foah_c254f9)",
                    metadata = mapOf("field" to "REMISE"),
                ),
                led(
                    "x-1", type = "adjustment", amount = 25_500,
                    description = "Annulation double-remise (réconciliation 0063) — le devis importé est déjà net de remise (formule Excel L = composantes − J)",
                    metadata = mapOf(
                        "reason" to "double_remise_cancel", "original_entry" to "r-1",
                        "reconciliation" to "0063", "original_amount" to -25500,
                    ),
                ),
            ),
        )
        assertEquals(1, e.remiseCount)
        assertEquals(25_500L, e.remiseTotal)
        assertEquals(1, e.cancelCount)
        assertEquals(25_500L, e.cancelTotal)
        assertEquals(0L, e.netRemiseTotal) // ledger-honest: the imported devis is already net
    }

    @Test
    fun `erosion - payments refunds other adjustments never pollute the erosion math`() {
        val e = deriveExecDiscountErosion(
            listOf(
                led("pay-1", type = "payment", amount = -50_000, description = "Encaissement", metadata = mapOf("field" to "REMISE")),
                led("ref-1", type = "refund", amount = -5_000, description = "Remise sur devis (looks like one)", metadata = mapOf("field" to "REMISE")),
                led("adj-1", type = "adjustment", amount = -15_000, description = "Crédit parent (excédent)"),
                led("neg-charge", type = "charge", amount = -3_000, description = "Correction"),
            ),
        )
        assertEquals(0, e.remiseCount)
        assertEquals(0L, e.remiseTotal)
        assertEquals(0L, e.grossCharges)
        assertEquals(0, e.erosionPct)
    }

    @Test
    fun `erosion - the live-shaped corpus remises 95k 85k 84k 80k against a 113 723 800 net base`() {
        val e = deriveExecDiscountErosion(
            listOf(led("c-1", type = "charge", amount = 113_723_800, description = "Devis (net)")) +
                listOf(95_000L, 85_000L, 84_000L, 80_000L).mapIndexed { i, amt ->
                    led(
                        "r-$i", type = "adjustment", amount = -amt,
                        description = "Remise sur devis (import Excel run run_msp3foah_c254f9)",
                        metadata = mapOf("field" to "REMISE", "importRunId" to "run_msp3foah_c254f9"),
                    )
                },
        )
        assertEquals(344_000L, e.remiseTotal)
        assertEquals(114_067_800L, e.stickerTotal)
        assertEquals(0, e.erosionPct) // round(344000/114067800*100) = 0.30 → 0
        assertEquals(95_000L, e.maxRemise)
        assertEquals(80_000L, e.minRemise)
        assertEquals(86_000L, e.averageRemise)
    }

    // ══════════════════════════════════════════════════════════════════════
    // 3. Debt triage
    // ══════════════════════════════════════════════════════════════════════

    private val triageFixtures = listOf(
        // p-1: T1 late 61 days (chronic), 40_000 remaining
        ins("d-1", "p-1", trancheNumber = 1, amountDue = 40_000, amountPaid = 0, status = "unpaid", dueDate = "2026-07-15"),
        // p-2: 20 days late (reminder), 30_000 remaining
        ins("d-2", "p-2", trancheNumber = 2, amountDue = 30_000, amountPaid = 0, status = "unpaid", dueDate = "2026-08-25"),
        // p-3: 5 days late (current), 10_000 remaining
        ins("d-3", "p-3", trancheNumber = 1, amountDue = 10_000, amountPaid = 0, status = "unpaid", dueDate = "2026-09-09"),
        // p-4: not due yet (the December wave), 50_000 remaining
        ins("d-4", "p-4", trancheNumber = 3, amountDue = 50_000, amountPaid = 0, status = "unpaid", dueDate = "2026-12-15"),
        // p-1 ALSO owes a second late tranche (44 days — still reminder bucket)
        ins("d-5", "p-1", trancheNumber = 2, amountDue = 20_000, amountPaid = 0, status = "unpaid", dueDate = "2026-08-01"),
    )

    @Test
    fun `triage - splits into the four action tiers with exact amounts and family counts`() {
        val t = deriveExecDebtTriage(triageFixtures, now)
        val byBucket = t.buckets.associateBy { it.bucket }
        assertEquals(50_000L, byBucket[ExecTriageBucket.NOT_DUE]!!.amount)
        assertEquals(1, byBucket[ExecTriageBucket.NOT_DUE]!!.familyCount)
        assertEquals(10_000L, byBucket[ExecTriageBucket.CURRENT]!!.amount)
        assertEquals(50_000L, byBucket[ExecTriageBucket.REMINDER]!!.amount) // p-2 (20j, 30k) + p-1's 2nd tranche (44j, 20k)
        assertEquals(40_000L, byBucket[ExecTriageBucket.CHRONIC]!!.amount) // p-1's 61-day tranche
        assertEquals(1, byBucket[ExecTriageBucket.CHRONIC]!!.familyCount)
        assertEquals(1, byBucket[ExecTriageBucket.CHRONIC]!!.installmentCount)
        assertEquals(2, byBucket[ExecTriageBucket.REMINDER]!!.installmentCount)
    }

    @Test
    fun `triage - total outstanding = sum of buckets, shares exact`() {
        val t = deriveExecDebtTriage(triageFixtures, now)
        assertEquals(150_000L, t.totalOutstanding)
        assertEquals(33, t.buckets[0].share) // 50000/150000
        assertEquals(27, t.buckets[3].share) // 40000/150000
    }

    @Test
    fun `triage - the call list = families with ANY installment over 45 days late, full exposure, ranked`() {
        val t = deriveExecDebtTriage(triageFixtures, now)
        assertEquals(1, t.callList.size)
        assertEquals("p-1", t.callList[0].parentId)
        assertEquals(60_000L, t.callList[0].outstanding) // full exposure incl. the 44d tranche
        assertEquals(61L, t.callList[0].worstDaysOverdue) // 2026-07-15 → 2026-09-14
    }

    @Test
    fun `triage - the call list = families with ANY installment over the RED threshold (60 days default), full exposure, ranked`() {
        val t = deriveExecDebtTriage(triageFixtures, now)
        assertEquals(1, t.callList.size)
        assertEquals("p-1", t.callList[0].parentId)
        assertEquals(60_000L, t.callList[0].outstanding) // full exposure incl. the 44d tranche
        assertEquals(61L, t.callList[0].worstDaysOverdue) // 2026-07-15 → 2026-09-14
    }

    @Test
    fun `triage - T-450 boundary pins - exactly 60 days is reminder, 61 is chronic (over redDays strict)`() {
        // T-450 (PARITY-006): the canonical edges are the CONFIGURABLE thresholds
        // (yellow 15 / red 60 — migration 0125's seed, the live system_settings
        // values), replacing the hardcoded 45. The boundary test intent carries
        // over from the pre-T-443 45-day pin.
        val at60 = deriveExecDebtTriage(
            listOf(ins("b-60", "p-9", amountDue = 10_000, amountPaid = 0, status = "unpaid", dueDate = "2026-07-16")), // exactly 60 days
            now,
        )
        assertEquals(10_000L, at60.buckets.first { it.bucket == ExecTriageBucket.REMINDER }.amount)
        assertEquals(0L, at60.buckets.first { it.bucket == ExecTriageBucket.CHRONIC }.amount)
        assertEquals(0, at60.callList.size)

        val at61 = deriveExecDebtTriage(
            listOf(ins("b-61", "p-9", amountDue = 10_000, amountPaid = 0, status = "unpaid", dueDate = "2026-07-15")), // exactly 61 days
            now,
        )
        assertEquals(10_000L, at61.buckets.first { it.bucket == ExecTriageBucket.CHRONIC }.amount)
        assertEquals(1, at61.callList.size)
        assertEquals(61L, at61.callList[0].worstDaysOverdue)
    }

    @Test
    fun `triage - T-450 boundary pins - exactly 15 days is current, 16 is reminder (over yellowDays strict)`() {
        val at15 = deriveExecDebtTriage(
            listOf(ins("b-15", "p-9", amountDue = 10_000, amountPaid = 0, status = "unpaid", dueDate = "2026-08-30")), // exactly 15 days
            now,
        )
        assertEquals(10_000L, at15.buckets.first { it.bucket == ExecTriageBucket.CURRENT }.amount)
        assertEquals(0L, at15.buckets.first { it.bucket == ExecTriageBucket.REMINDER }.amount)

        val at16 = deriveExecDebtTriage(
            listOf(ins("b-16", "p-9", amountDue = 10_000, amountPaid = 0, status = "unpaid", dueDate = "2026-08-29")), // exactly 16 days
            now,
        )
        assertEquals(10_000L, at16.buckets.first { it.bucket == ExecTriageBucket.REMINDER }.amount)
        assertEquals(0L, at16.buckets.first { it.bucket == ExecTriageBucket.CURRENT }.amount)
    }

    @Test
    fun `triage - T-450 configurable thresholds - a custom red edge re-buckets and re-labels`() {
        // The desktop's live tenant configuration drives the edges (the
        // system_settings category debt rows); the derivation must follow
        // the values it is handed — never a hardcoded edge.
        val custom = ExecDebtAgingThresholds(
            gracePeriodDays = 5, yellowDays = 10, redDays = 30, activePayerGraceDays = 15,
        )
        val t = deriveExecDebtTriage(
            listOf(ins("c-1", "p-9", amountDue = 10_000, amountPaid = 0, status = "unpaid", dueDate = "2026-08-01")), // 44 days late
            now,
            custom,
        )
        // 44 > custom red 30 → chronic, and the label carries the CONFIGURED numbers
        assertEquals(10_000L, t.buckets.first { it.bucket == ExecTriageBucket.CHRONIC }.amount)
        assertEquals("Retard > 30 j (intervention)", t.buckets.first { it.bucket == ExecTriageBucket.CHRONIC }.label)
        assertEquals("Retard 10–30 j (relance)", t.buckets.first { it.bucket == ExecTriageBucket.REMINDER }.label)
        assertEquals("Retard ≤ 10 j (à surveiller)", t.buckets.first { it.bucket == ExecTriageBucket.CURRENT }.label)
        assertEquals(1, t.callList.size)
    }

    @Test
    fun `triage - the default labels carry the canonical seed numbers (15 and 60)`() {
        val labels = execDebtTriageLabels(ExecDebtAgingThresholds.DEFAULT)
        assertEquals("Non échue", labels.getValue(ExecTriageBucket.NOT_DUE))
        assertEquals("Retard ≤ 15 j (à surveiller)", labels.getValue(ExecTriageBucket.CURRENT))
        assertEquals("Retard 15–60 j (relance)", labels.getValue(ExecTriageBucket.REMINDER))
        assertEquals("Retard > 60 j (intervention)", labels.getValue(ExecTriageBucket.CHRONIC))
    }

    @Test
    fun `triage - satisfied installments never enter any bucket`() {
        val t = deriveExecDebtTriage(
            listOf(ins("paid-1", amountDue = 10_000, amountPaid = 10_000, status = "paid", dueDate = "2025-09-15")),
            now,
        )
        assertEquals(0L, t.totalOutstanding)
        assertTrue(t.buckets.all { it.amount == 0L })
    }

    // ══════════════════════════════════════════════════════════════════════
    // 4. Family concentration
    // ══════════════════════════════════════════════════════════════════════

    private val concFixtures = listOf(
        ins("f-1", "p-big", trancheNumber = 1, amountDue = 150_000, amountPaid = 0, status = "unpaid", dueDate = "2025-09-15"),
        ins("f-2", "p-big2", trancheNumber = 1, amountDue = 120_000, amountPaid = 0, status = "unpaid", dueDate = "2025-09-15"),
        ins("f-3", "p-mid", trancheNumber = 1, amountDue = 60_000, amountPaid = 0, status = "unpaid", dueDate = "2025-09-15"),
        ins("f-4", "p-small", trancheNumber = 1, amountDue = 10_000, amountPaid = 0, status = "unpaid", dueDate = "2026-12-15"),
    )

    private val concStudents = listOf(
        stu("s-1", "p-big"), stu("s-2", "p-big"), stu("s-3", "p-big"),
        stu("s-4", "p-big2"), stu("s-5", "p-big2"),
        stu("s-6", "p-mid"), stu("s-7", "p-mid"),
        stu("s-8", "p-small"),
        stu("s-9", "p-zero-debt"),                       // family with NO debt
        stu("s-10", "p-zero-debt", status = "withdrawn"), // inactive child not counted
    )

    private val concParents = listOf(
        "p-big" to "BENZAOUI", "p-big2" to "KOUBAA", "p-mid" to "ALIOUAT",
        "p-small" to "ATTOUCHE", "p-zero-debt" to "CHARIF",
    )

    @Test
    fun `concentration - per-family outstanding ranked desc with child counts (the 80 20 view)`() {
        val c = deriveExecFamilyConcentration(concFixtures, concParents, concStudents, topN = 2, nowEpochMs = now)
        assertEquals(340_000L, c.totalOutstanding)
        assertEquals(4, c.debtorFamilyCount)
        assertEquals(listOf("p-big", "p-big2"), c.topFamilies.map { it.parentId })
        assertEquals(3, c.topFamilies[0].childCount)
        assertEquals("BENZAOUI", c.topFamilies[0].parentName)
        assertEquals(44, c.topFamilies[0].shareOfTotalDebt) // round(150000/340000*100)
    }

    @Test
    fun `concentration - top-N concentration = round(topTotal over total times 100)`() {
        val c = deriveExecFamilyConcentration(concFixtures, concParents, concStudents, topN = 2, nowEpochMs = now)
        assertEquals(270_000L, c.topTotal)
        assertEquals(79, c.topConcentrationPct) // round(270000/340000*100)
    }

    @Test
    fun `concentration - families with no debt never appear in the ranking`() {
        val c = deriveExecFamilyConcentration(concFixtures, concParents, concStudents, topN = 2, nowEpochMs = now)
        assertTrue(c.topFamilies.none { it.parentId == "p-zero-debt" })
    }

    @Test
    fun `concentration - worstDaysOverdue reflects the family's oldest unpaid tranche (deterministic now)`() {
        val c = deriveExecFamilyConcentration(concFixtures, concParents, concStudents, topN = 2, nowEpochMs = now)
        assertEquals(364L, c.topFamilies[0].worstDaysOverdue) // 2025-09-15 → 2026-09-14T12:00Z = 364.5 floored
    }

    // ══════════════════════════════════════════════════════════════════════
    // 5. Transport yield
    // ══════════════════════════════════════════════════════════════════════

    @Test
    fun `transport - normalizes messy live spellings through TOWN_ALIASES and reconciles route money`() {
        val students = listOf(
            stu("r-1", "p-1", transportTier = "BOUMERDES"),
            stu("r-2", "p-2", transportTier = "BOUMRDES"),     // typo → same town
            stu("r-3", "p-3", transportTier = "OULED MOUSSA"), // spaced → ouled_moussa
            stu("r-4", "p-4", transportTier = "KHEMISELKHCHNA"),
            stu("r-5", "p-5", transportTier = "ERBATACHE"),    // unknown → autres
            stu("r-6", "p-6", transportTier = null),           // no transport
            stu("r-7", "p-1", transportTier = "BOUMREDES"),    // same parent, 2nd child, same town
        )
        val installments = listOf(
            // p-1 (boumerdes): 2 transport installments, one paid
            ins("tr-1", "p-1", category = "transport", trancheNumber = 1, amountDue = 20_000, amountPaid = 20_000, status = "paid", dueDate = "2025-09-15"),
            ins("tr-2", "p-1", category = "transport", trancheNumber = 2, amountDue = 10_000, amountPaid = 0, status = "unpaid", dueDate = "2025-12-15"),
            // p-3 (ouled_moussa): unpaid
            ins("tr-3", "p-3", category = "transport", trancheNumber = 1, amountDue = 30_000, amountPaid = 0, status = "unpaid", dueDate = "2025-09-15"),
            // p-5 (autres): partially paid
            ins("tr-4", "p-5", category = "transport", trancheNumber = 1, amountDue = 30_000, amountPaid = 15_000, status = "partial", dueDate = "2025-09-15"),
            // A transport installment with NO rider student → bucketed under autres
            ins("tr-5", "p-9", category = "transport", trancheNumber = 3, amountDue = 10_000, amountPaid = 0, status = "unpaid", dueDate = "2026-03-15"),
        )

        val t = deriveExecTransportYield(students, installments)

        assertEquals(6, t.riders)
        assertEquals(1, t.nonRiders)
        assertEquals(listOf("ERBATACHE"), t.unresolvedRawValues)

        val boumerdes = t.routes.first { it.destination == "boumerdes" }
        assertEquals(2, boumerdes.riders) // two PARENTS (p-1, p-2)
        assertEquals(30_000L, boumerdes.dueTotal)
        assertEquals(20_000L, boumerdes.paidTotal)
        assertEquals(10_000L, boumerdes.remainingTotal)
        assertEquals(67, boumerdes.collectedPct)

        val ouledMoussa = t.routes.first { it.destination == "ouled_moussa" }
        assertEquals(1, ouledMoussa.riders)
        assertEquals(30_000L, ouledMoussa.remainingTotal)

        // Σ across routes reconciles the whole transport installment stream:
        // due 100_000, paid 35_000, remaining 65_000 → 35%.
        assertEquals(100_000L, t.dueTotal)
        assertEquals(35_000L, t.paidTotal)
        assertEquals(65_000L, t.remainingTotal)
        assertEquals(35, t.collectedPct)
    }

    @Test
    fun `transport - routes sort by riders desc, then remaining desc`() {
        val t = deriveExecTransportYield(
            listOf(
                stu("r-1", "p-1", transportTier = "CORSO"),
                stu("r-2", "p-2", transportTier = "SAHEL"),
                stu("r-3", "p-3", transportTier = "SAHEL"),
            ),
            emptyList(),
        )
        assertEquals(listOf("sahel", "corso"), t.routes.map { it.destination })
        assertEquals(0, t.collectedPct)
        assertEquals(0L, t.dueTotal)
    }

    // ══════════════════════════════════════════════════════════════════════
    // normalizeTransportTier (the canonical normalizer)
    // ══════════════════════════════════════════════════════════════════════

    @Test
    fun `normalizeTransportTier - null blank to null (no transport, NOT counted as a rider)`() {
        assertNull(normalizeTransportTier(null))
        assertNull(normalizeTransportTier("   "))
    }

    @Test
    fun `normalizeTransportTier - live spelling variants collapse to their real town`() {
        assertEquals("boumerdes", normalizeTransportTier("BOUMERDES"))
        assertEquals("boumerdes", normalizeTransportTier("BOUMRDES"))
        assertEquals("boumerdes", normalizeTransportTier("BOUMREDES"))
        assertEquals("boumerdes", normalizeTransportTier("BOUMERDES20000"))
        assertEquals("ouled_moussa", normalizeTransportTier("OULED MOUSSA"))
        assertEquals("khemis_el_khechna", normalizeTransportTier("KHEMISELKHCHNA"))
        assertEquals("zemmouri", normalizeTransportTier("ZEMOURI"))
        assertEquals("tidjelabine_sahel_figuier_corso", normalizeTransportTier("tidjelabine_sahel_figuier_corso"))
    }

    @Test
    fun `normalizeTransportTier - unknown non-empty to autres (a rider from an unrecognized locality)`() {
        assertEquals("autres", normalizeTransportTier("ERBATACHE"))
    }

    // ══════════════════════════════════════════════════════════════════════
    // 6. Service yield
    // ══════════════════════════════════════════════════════════════════════

    private val servicePayments = listOf(
        pay("sp-1", amount = 10_000, category = "therapy_psychology", studentId = "stu-1"),
        pay("sp-2", amount = 10_000, category = "therapy_psychology", studentId = "stu-2"),
        pay("sp-3", amount = 10_000, category = "therapy_psychology", studentId = "stu-1"),
        pay("sp-4", amount = 5_000, category = "therapy_speech", studentId = "stu-3"),
        pay("sp-5", amount = 1_659_500, category = "other", studentId = null),
        // Non-service categories are excluded:
        pay("sp-6", amount = 100_000, category = "tuition"),
        // Refunded therapy does not count as yield:
        pay("sp-7", amount = 5_000, category = "therapy_speech", status = "refunded"),
    )

    @Test
    fun `services - per-service revenue volume students from the PAID stream, sorted desc`() {
        val s = deriveExecServiceYield(servicePayments)
        assertEquals(
            listOf("other", "therapy_psychology", "therapy_speech"),
            s.map { it.category },
        )
        val psy = s.first { it.category == "therapy_psychology" }
        assertEquals(30_000L, psy.revenue)
        assertEquals(3, psy.paymentCount)
        assertEquals(2, psy.studentCount) // stu-1 paid twice, counted once
        assertEquals("Psychologie", psy.label)
    }

    @Test
    fun `services - empty service activity to empty output (honest empty state)`() {
        assertTrue(deriveExecServiceYield(emptyList()).isEmpty())
        assertTrue(deriveExecServiceYield(listOf(pay("only-tuition", amount = 10_000, category = "tuition"))).isEmpty())
    }

    // ══════════════════════════════════════════════════════════════════════
    // 7. Enrollment dynamics + section imbalance
    // ══════════════════════════════════════════════════════════════════════

    private fun buildDynamicsStudents(): List<ExecStudent> {
        // Live-shaped family mix: 5×1 + 2×2 + 1×3 + 1×5 = 17 students / 9 families.
        val out = ArrayList<ExecStudent>()
        repeat(5) { i -> out.add(stu("s1-$i", "p-$i")) }
        repeat(2) { i -> out.add(stu("s2-$i", "p-5")) }
        repeat(2) { i -> out.add(stu("s2b-$i", "p-6")) }
        repeat(3) { i -> out.add(stu("s3-$i", "p-7")) }
        repeat(5) { i -> out.add(stu("s5-$i", "p-8")) }
        out.add(stu("s-inactive", "p-8", status = "withdrawn")) // not counted
        return out
    }

    private val dynamicsClasses = listOf(
        // Live-shaped multi-section grade: CP 51 vs 1AP 3 (same gradeCode 1ap) + a balanced grade.
        cls("cp", "CP — Cours Préparatoire", "1ap", 51),
        cls("1ap", "1ère Année Primaire", "1ap", 3),
        cls("ce1", "CE1 — 2ème Année Primaire", "2ap", 35),
        cls("2ap", "2ème Année Primaire", "2ap", 35),
        cls("5ap", "5ème Année Primaire", "5ap", 41),                       // single section
        cls("gs-old", "Grande Section", "prescolaire_2", 22, isActive = false), // inactive
    )

    @Test
    fun `dynamics - sibling index = totalStudents over totalFamilies, 2 decimals, inactive excluded`() {
        val dyn = deriveExecEnrollmentDynamics(buildDynamicsStudents(), dynamicsClasses)
        assertEquals(17, dyn.totalStudents)
        assertEquals(9, dyn.totalFamilies)
        assertEquals(1.89, dyn.siblingIndex!!, 0.0001)
    }

    @Test
    fun `dynamics - family-size distribution merges 5+ and reports both counts`() {
        val dyn = deriveExecEnrollmentDynamics(buildDynamicsStudents(), dynamicsClasses)
        assertEquals(
            listOf("1 enfant", "2 enfants", "3 enfants", "5+ enfants"),
            dyn.familySizes.map { it.label },
        )
        assertEquals(5, dyn.familySizes.first { it.label == "1 enfant" }.familyCount)
        assertEquals(1, dyn.familySizes.first { it.label == "5+ enfants" }.familyCount)
        assertEquals(5, dyn.familySizes.first { it.label == "5+ enfants" }.studentCount)
    }

    @Test
    fun `dynamics - multi-child families count and share`() {
        val dyn = deriveExecEnrollmentDynamics(buildDynamicsStudents(), dynamicsClasses)
        assertEquals(4, dyn.multiChildFamilyCount)
        assertEquals(44, dyn.multiChildFamilyPct) // round(4/9*100)
    }

    @Test
    fun `dynamics - section imbalance spread plus the (spread at least 10 OR max at least 1point5 min) rule`() {
        val dyn = deriveExecEnrollmentDynamics(buildDynamicsStudents(), dynamicsClasses)
        assertEquals(
            listOf("CP — Cours Préparatoire (1AP)", "CE1 — 2ème Année Primaire (2AP)"),
            dyn.imbalances.map { it.gradeLabel },
        )
        val cp = dyn.imbalances[0]
        assertEquals(2, cp.sectionCount)
        assertEquals(51, cp.maxEnrolled)
        assertEquals(3, cp.minEnrolled)
        assertEquals(48, cp.spread)
        assertEquals(27, cp.averageEnrolled)
        assertTrue(cp.imbalanced)
        val ce1 = dyn.imbalances[1]
        assertEquals(0, ce1.spread)
        assertFalse(ce1.imbalanced)
    }

    @Test
    fun `dynamics - single-section grades and inactive classes never appear as imbalances`() {
        val dyn = deriveExecEnrollmentDynamics(buildDynamicsStudents(), dynamicsClasses)
        assertTrue(dyn.imbalances.none { i -> i.sections.any { it.classId == "5ap" } })
        assertTrue(dyn.imbalances.none { i -> i.sections.any { it.classId == "gs-old" } })
    }

    @Test
    fun `dynamics - max at least 1point5 x min flags even with a spread under 10 (the ratio rule)`() {
        val d = deriveExecEnrollmentDynamics(
            listOf(stu("x", "p-1")),
            listOf(
                cls("a", "1AM A", "1am", 15),
                cls("b", "1AM B", "1am", 9),
            ),
        )
        assertEquals(6, d.imbalances[0].spread)
        assertTrue(d.imbalances[0].imbalanced) // 15 ≥ 1.5 × 9 = 13.5
    }

    @Test
    fun `dynamics - empty school to null sibling index and empty structures`() {
        val d = deriveExecEnrollmentDynamics(emptyList(), emptyList())
        assertNull(d.siblingIndex)
        assertTrue(d.familySizes.isEmpty())
        assertTrue(d.imbalances.isEmpty())
    }

    // ══════════════════════════════════════════════════════════════════════
    // 8. Triple-risk radar
    // ══════════════════════════════════════════════════════════════════════

    @Test
    fun `risk - execRiskCategoryOf thresholds (GPA under 10 + absences at least 3 + debt at least 25k DZD)`() {
        // triple critical: all three vectors
        assertEquals(
            ExecRiskCategory.TRIPLE_CRITICAL,
            execRiskCategoryOf(gpa = 8.0, unexcusedAbsences = 4, attendanceRate = 0.9, debtAmountCentimes = 3_000_000),
        )
        // academic only
        assertEquals(
            ExecRiskCategory.ACADEMIC_ALERT,
            execRiskCategoryOf(gpa = 8.0, unexcusedAbsences = 0, attendanceRate = 1.0, debtAmountCentimes = 0),
        )
        // attendance via rate < 0.85
        assertEquals(
            ExecRiskCategory.ATTENDANCE_ALERT,
            execRiskCategoryOf(gpa = 14.0, unexcusedAbsences = 0, attendanceRate = 0.80, debtAmountCentimes = 0),
        )
        // financial tension at exactly 25 000 DZD (2 500 000 centimes)
        assertEquals(
            ExecRiskCategory.FINANCIAL_TENSION,
            execRiskCategoryOf(gpa = 14.0, unexcusedAbsences = 0, attendanceRate = 1.0, debtAmountCentimes = 2_500_000),
        )
        // null GPA = no academic data → NO academic alert even with debt
        assertEquals(
            ExecRiskCategory.HEALTHY,
            execRiskCategoryOf(gpa = null, unexcusedAbsences = 0, attendanceRate = 1.0, debtAmountCentimes = 2_400_000),
        )
    }

    @Test
    fun `risk - counts each category plus the triple-critical share`() {
        val s = deriveExecTripleRiskSummary(
            listOf(
                ExecRiskCategory.TRIPLE_CRITICAL,
                ExecRiskCategory.TRIPLE_CRITICAL,
                ExecRiskCategory.ACADEMIC_ALERT,
                ExecRiskCategory.ATTENDANCE_ALERT,
                ExecRiskCategory.FINANCIAL_TENSION,
                ExecRiskCategory.HEALTHY,
            ),
        )
        assertEquals(2, s.tripleCriticalCount)
        assertEquals(1, s.academicAlertCount)
        assertEquals(1, s.attendanceAlertCount)
        assertEquals(1, s.financialTensionCount)
        assertEquals(1, s.healthyCount)
        assertEquals(33, s.tripleCriticalPct) // round(2/6*100)
    }

    @Test
    fun `risk - zero profiles to all zeros (honest empty state)`() {
        val s = deriveExecTripleRiskSummary(emptyList())
        assertEquals(0, s.tripleCriticalCount)
        assertEquals(0, s.tripleCriticalPct)
    }

    // ════════════════════════════════════════════════════════════════════
    // T-454 (PARITY-007) — the Finance-strip view-model adapter + the strip
    // totals (the desktop installment-schedule-tab T-447 construction: the
    // fixed T1/T2/T3 slots mapped from the canonical POOLED rows — one
    // derivation, this surface's presentation only).
    // ════════════════════════════════════════════════════════════════════

    @Test
    fun `strip - the fixed T1 T2 T3 slots, the pooled basis, the canonical unclamped rate`() {
        // The corpus scenario shape (analytics_visuals_tranche_waves): the
        // label is IRRELEVANT (the "Tranche 10"-labeled row at column 1
        // joins wave 1), the non-wave rows (FI at 0 / out-of-range at 4)
        // are excluded from every wave, and the pooled rate is round(…)
        // NEVER clamped.
        val rows = listOf(
            ins("i1", "p-1", "tuition", 1, 4_000_000, 4_000_000, 0, "2025-09-15", "paid"),
            ins("i2", "p-2", "tuition", 1, 2_000_000, 1_000_000, 0, "2025-09-15", "partial"),
            // The row that WOULD be labeled "Tranche 10" — the engine has NO
            // label field at all: the canonical trancheNumber column is the
            // ONLY grouping key (the pre-T-454 regex feed silently dropped
            // such rows; the corpus scenario pins the same class).
            ins("i3", "p-6", "tuition", 1, 1_000_000, 1_000_000, 0, "2025-10-01", "paid"),
            ins("i4", "p-1", "tuition", 2, 3_000_000, 1_500_000, 500_000, "2025-12-15", "partial"),
            ins("i5", "p-3", "tuition", 2, 3_000_000, 0, 0, "2025-12-15", "unpaid"),
            ins("i6", "p-4", "tuition", 3, 3_000_000, 0, 0, "2026-03-15", "unpaid"),
            // The FI registration fee (tranche 0) — NEVER folded into T1.
            ins("i7", "p-8", "tuition", 0, 250_000, 0, 0, "2025-09-01", "unpaid"),
        )
        val strip = deriveExecTrancheWaveStrip(rows, now)
        assertEquals(3, strip.size) // the FIXED slots
        assertEquals("Tranche 1 (Septembre)", strip[0].label)
        assertEquals("échéance 15 sep", strip[0].hint)
        // Wave 1 pools ALL categories + the "Tranche 10"-labeled row:
        // due 4M + 2M + 1M = 7M, paid 4M + 1M + 1M = 6M.
        assertEquals(7_000_000L, strip[0].due)
        assertEquals(6_000_000L, strip[0].paid)
        assertEquals(86, strip[0].pct) // round(6/7×100) = 86 — the canonical rate
        // The wave-1 derived échéance RANGE (min 2025-09-15 → max 2025-10-01).
        assertEquals("2025-09-15T00:00:00.000Z", strip[0].dueDate)
        assertEquals("2025-10-01T00:00:00.000Z", strip[0].dueDateMax)
        // Wave 1 is the FIRST wave with a remaining balance (i2 owes 1M) → target.
        assertTrue(strip[0].isNextTarget)
        // The tuition-isolated rate: tuition paid 6M / tuition due 7M → 86.
        assertEquals(86, strip[0].tuitionPct)
        // Wave 2: due 6M, paid 1.5M, pending 0.5M → remaining 4M; rate 25.
        assertEquals(6_000_000L, strip[1].due)
        assertEquals(1_500_000L, strip[1].paid)
        assertEquals(500_000L, strip[1].pending)
        assertEquals(4_000_000L, strip[1].remaining)
        assertEquals(25, strip[1].pct)
        assertFalse(strip[1].isNextTarget)
        // Wave 3: due 3M, nothing paid → pct 0; future-dated (2026-03-15 <
        // now 2026-09-14 → past; the flag derives from the rows).
        assertEquals(3_000_000L, strip[2].due)
        assertEquals(0, strip[2].pct)
        assertFalse(strip[2].isNextTarget)
        // The FI row NEVER lands in a wave: its 250_000 is absent from every slot.
        assertTrue(strip.none { it.due >= 7_250_000L })
    }

    @Test
    fun `strip - the over-covered wave renders its honest above-100 rate`() {
        // The pre-T-454 feed CLAMPED this at 100 (Math.min) — the desktop's
        // T-447 fix renders the honest rate (an over-covered wave = parent
        // credit ON the rows).
        val rows = listOf(
            ins("o1", "p-1", "tuition", 1, 1_000_000, 1_200_000, 0, "2025-09-15", "paid"),
        )
        val strip = deriveExecTrancheWaveStrip(rows, now)
        assertEquals(120, strip[0].pct)
        // Over-covered → no remaining → NOT the next target.
        assertEquals(0L, strip[0].remaining)
        assertFalse(strip[0].isNextTarget)
    }

    @Test
    fun `strip - the empty selection renders the honest zero slots`() {
        val strip = deriveExecTrancheWaveStrip(emptyList(), now)
        assertEquals(3, strip.size)
        assertTrue(strip.all { it.due == 0L && it.paid == 0L && it.pct == 0 && it.dueDate == null && !it.isNextTarget })
        // The desktop's T-447 static hints (the fallback when no row carries
        // a parseable date — "échéance 15 sep", NOT the old "… — à l'inscription").
        assertEquals("échéance 15 sep", strip[0].hint)
        assertEquals("échéance 15 déc", strip[1].hint)
        assertEquals("échéance 15 mars", strip[2].hint)
    }

    @Test
    fun `strip totals - the canonical sums over the WHOLE selection, FI rows included`() {
        // The 4-cell totals row: Σdue / Σpaid / the INV-4 remaining / the
        // dynamic overdue count. The FI row is BILLED money — the wave sums
        // alone would silently drop it (the pre-T-454 card summed the waves).
        val rows = listOf(
            ins("t1", "p-1", "tuition", 1, 2_000_000, 1_000_000, 0, "2025-09-15", "partial"),
            ins("t2", "p-2", "tuition", 2, 3_000_000, 0, 0, "2025-12-15", "unpaid"),
            ins("t3", "p-3", "tuition", 0, 250_000, 0, 0, "2025-09-01", "unpaid"), // FI, past-due
            ins("t4", "p-1", "tuition", 3, 4_000_000, 0, 0, "2027-03-15", "unpaid"), // future
        )
        val totals = deriveExecTrancheStripTotals(rows, now)
        assertEquals(9_250_000L, totals.totalDue)   // 2M + 3M + 250k + 4M (FI + future included)
        assertEquals(1_000_000L, totals.totalPaid)
        assertEquals(8_250_000L, totals.totalRemaining) // 9.25M − 1M − 0
        // Overdue: t1 (partial, past-due, owing) + t3 (FI, unpaid, past-due) = 2.
        // t4 is FUTURE (à échoir, never late); t2 is unpaid but due 2025-12-15
        // < now → past-due + owing → ALSO overdue. Let me recount: t1 ✓, t2 ✓,
        // t3 ✓, t4 future ✗ → 3.
        assertEquals(3, totals.overdueCount)
    }

    @Test
    fun `overdue predicate - paid, future, settled-despite-status and sub-day rows`() {
        // The canonical dynamic predicate (the desktop isInstallmentOverdue):
        // only not-paid, STRICTLY-past-due, still-owing rows are "en retard".
        val paid = ins("a", "p-1", "tuition", 1, 100, 100, 0, "2025-09-15", "paid")
        assertFalse(isExecInstallmentOverdueRow(paid, now))
        val future = ins("b", "p-1", "tuition", 3, 100, 0, 0, "2027-03-15", "unpaid")
        assertFalse(isExecInstallmentOverdueRow(future, now))
        // An uncleared cheque covering the row settles it (INV-4 — never late).
        val coveredByPending = ins("c", "p-1", "tuition", 1, 100, 0, 100, "2025-09-15", "partial")
        assertFalse(isExecInstallmentOverdueRow(coveredByPending, now))
        val owing = ins("d", "p-1", "tuition", 1, 100, 40, 0, "2025-09-15", "partial")
        assertTrue(isExecInstallmentOverdueRow(owing, now))
        // dueDate == now → NOT strictly past.
        val dueNow = ins("e", "p-1", "tuition", 1, 100, 0, 0, "2026-09-14T12:00:00Z", "unpaid")
        assertFalse(isExecInstallmentOverdueRow(dueNow, now))
    }

    @Test
    fun `emptyExecPooledWave - the zero-row slot factory`() {
        val w = emptyExecPooledWave(2)
        assertEquals(2, w.wave)
        assertEquals(0, w.installmentCount)
        assertEquals(0L, w.dueTotal)
        assertEquals(0L, w.remainingTotal)
        assertNull(w.dueDateMin)
        assertNull(w.dueDateMax)
        assertFalse(w.anyUnsettledOverdue)
        assertTrue(w.perCategory.isEmpty())
    }
}
