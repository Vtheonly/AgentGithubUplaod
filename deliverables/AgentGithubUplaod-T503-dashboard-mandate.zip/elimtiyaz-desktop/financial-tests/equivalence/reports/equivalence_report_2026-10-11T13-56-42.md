# Cross-Platform Equivalence Report

**Generated:** 2026-10-11T13-56-42
**Strict mode:** false

## Executive Summary

| Metric | Value |
|---|---|
| Total scenarios | 820 |
| Matched on both sides | 820 |
| **Exact equivalence (zero discrepancies)** | **820** |
| Scenarios with discrepancies | 0 |
| Desktop-only (Android missing) | 0 |
| Android-only (Desktop missing) | 0 |
| Canonical expected verified | 319 / 319 |
| **Equivalence rate** | **100.00%** |

## Scenarios by Category

| Category | Total | Matched both | With discrepancies |
|---|---|---|---|
| academic | 15 | 15 | 0 |
| analytics_statistics | 3 | 3 | 0 |
| analytics_visuals | 3 | 3 | 0 |
| balance | 1 | 1 | 0 |
| boundary | 66 | 66 | 0 |
| complex_sequence | 1 | 1 | 0 |
| corpus | 259 | 259 | 0 |
| crm | 5 | 5 | 0 |
| discount_engine | 68 | 68 | 0 |
| executive_statistics | 3 | 3 | 0 |
| idempotency | 1 | 1 | 0 |
| lifo_reversal | 128 | 128 | 0 |
| overpayment | 64 | 64 | 0 |
| parent_summary | 1 | 1 | 0 |
| reconcile | 65 | 65 | 0 |
| subject_configuration | 7 | 7 | 0 |
| sync_round_trip | 1 | 1 | 0 |
| waterfall | 129 | 129 | 0 |

## Conclusion

For the tested domain of valid business operations and inputs (820 scenarios), the desktop and Android implementations produce **exactly equivalent financial and business results**.

Evidence:
- 820/820 scenarios produced bit-identical centime-level results
- 319/319 scenarios with canonical expectations verified
- Zero discrepancies detected
- Regression cases preserved for all known past discrepancies