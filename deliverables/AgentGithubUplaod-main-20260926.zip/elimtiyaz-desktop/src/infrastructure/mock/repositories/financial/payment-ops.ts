/**
 * Payment operations — plain-function helpers used by `MockPaymentRepository`.
 *
 * Extracted from `financial-repository.ts` in task 6-b. Behavior preserved
 * verbatim — only file location + import paths changed.
 *
 * UNIFIED ARCHITECTURE (this revision):
 *   - `collectPayment` now runs the waterfall allocation engine
 *     (`allocatePaymentAcrossInstallments`) and writes a `parent_credit`
 *     adjustment entry when there's an overpayment. This closes the loop
 *     on Invariant 2 (Waterfall Conservation) and Invariant 4 (Cleared
 *     Funds Only) — uncleared checks/transfers no longer mark tranches
 *     as `"paid"`.
 *   - `refundPayment` now calls `revertPaymentAllocation` (LIFO) to
 *     subtract the reversed amount from `installment.amountPaid` (or
 *     `amountPending`) and re-evaluate tranche statuses. This closes
 *     the loop on Invariant 5 (Reversal Balance).
 */
import type { Result } from "../../../../core/result";
import { Ok, Err } from "../../../../core/result";
import { Errors } from "../../../../core/app-error";
import { AuditActions } from "../../../../core/audit-actions";
import type {
  Payment,
  AccountAdjustment,
  Receipt,
  CollectPaymentInput,
  PaymentStatus,
  PaymentCategory,
} from "../../../../domain/model/payment";
import type { LedgerEntry } from "../../../../domain/model/ledger";
import { deriveAccountId } from "../../../../domain/calc/ledger";
import { allocatePaymentAcrossInstallments } from "./installment-ops";
import { revertPaymentAllocation } from "../../../../domain/calc/payment/lifo-reversal";
import { clearPendingAllocation } from "../../../../domain/calc/payment/clearance";
import type { FinancialOpsCtx } from "./types";
import {
  dispatchPaymentRecorded,
  dispatchPaymentClearedOrBounced,
} from "../workflow-event-bridge";

/**
 * Collect a payment and atomically:
 *   1. Insert the `payments` row.
 *   2. Append the canonical payment ledger entry (negative credit).
 *   3. Run the waterfall allocator against the parent's installments:
 *      - For cash (status="paid"): increment `amountPaid`, possibly mark
 *        tranches as `"paid"` / `"partial"`.
 *      - For check/transfer (status="pending"): increment `amountPending`
 *        only; status becomes `"pending_clearance"`. The tranche is NOT
 *        considered satisfied until the underlying payment clears.
 *   4. If there's an overpayment (`unallocatedAmount > 0`), append a
 *      `parent_credit` adjustment entry under category `"parent_credit"`
 *      so the credit can be auto-absorbed by future charges.
 */
export async function collectPayment(
  ctx: FinancialOpsCtx,
  input: CollectPaymentInput,
  collectedBy: string,
): Promise<Result<Payment>> {
  const { store, appendAudit, nowIso, delay, tenantId } = ctx;
  await delay(250);
  // TIER 4 FIX — canonical input validation (matches the Android collect()
  // guard AND the SQL collect_and_allocate_payment RPC / enforce_payment_proof
  // trigger). The desktop mock previously accepted zero/negative amounts and
  // proof-less check payments while both other implementations rejected them.
  if (input.amount <= 0) {
    return Err(Errors.validation("Payment amount must be > 0"));
  }
  // FIX (type error → runtime bug): the guard referenced `input.proofPath`,
  // which does NOT exist on `CollectPaymentInput` (the field is `proofUrl`).
  // Since `undefined` is always falsy, EVERY non-cash payment was rejected
  // with "Proof is required" even when a proof URL was supplied — checks and
  // transfers could never be collected in mock mode.
  if (input.method !== "cash" && !input.proofUrl) {
    return Err(Errors.validation(`Proof is required for ${input.method} payments`));
  }
  // VAULT §07.01 — method-specific structured fields. Mirrors the backend
  // `enforce_payment_proof` trigger (migration 0007): check → number + bank
  // name; transfer → transaction reference.
  if (input.method === "check" && (!input.checkNumber?.trim() || !input.checkBankName?.trim())) {
    return Err(Errors.validation("Le numéro de chèque et le nom de la banque sont obligatoires pour un paiement par chèque"));
  }
  if (input.method === "transfer" && !input.transferReference?.trim()) {
    return Err(Errors.validation("La référence de transaction est obligatoire pour un virement"));
  }
  const year = new Date().getFullYear();
  const seq = store.payments.length + 1;
  const status: PaymentStatus = input.method === "cash" ? "paid" : "pending";
  const payment: Payment = {
    // IDs must be GLOBALLY unique: the pure sequence (`pay-003`) collides
    // when earlier payments are removed (Excel rollback, test isolation),
    // which would wrongly trip the waterfall idempotency guard for a NEW
    // payment that happens to reuse the id. A random suffix keeps ids unique.
    id: `pay-${String(seq).padStart(3, "0")}-${Math.random().toString(36).slice(2, 8)}`,
    tenantId,
    receiptNumber: `REC-${year}-${String(seq).padStart(6, "0")}`,
    parentId: input.parentId,
    studentId: input.studentId,
    amount: input.amount,
    method: input.method,
    status,
    category: input.category,
    installmentId: input.installmentId,
    proofUrl: input.proofUrl ?? null,
    notes: input.notes ?? null,
    checkNumber: input.checkNumber?.trim() || null,
    checkBankName: input.checkBankName?.trim() || null,
    checkIssueDate: input.checkIssueDate || null,
    checkClearanceDate: input.checkClearanceDate || null,
    transferReference: input.transferReference?.trim() || null,
    transferSourceBank: input.transferSourceBank?.trim() || null,
    collectedBy,
    collectedAt: nowIso(),
    createdAt: nowIso(),
    updatedAt: nowIso(),
  };
  store.payments.unshift(payment);
  store.notifyPayments();

  // === 1. Append the canonical payment ledger entry ===
  // The ledger is the single source of truth; the payments table is a
  // denormalized view. accountId is student-scoped when studentId is
  // provided, parent-scoped otherwise.
  const ledgerEntry: LedgerEntry = {
    id: `led-${nowIso()}-${Math.random().toString(36).slice(2, 10)}`,
    tenantId,
    // ADR-023 (BUSINESS-106): null category → the synthetic cross-category
    // account `parent:{id}:category:all` (mirrors the SQL RPC's booking).
    accountId: deriveAccountId(input.parentId, input.category, input.studentId),
    parentId: input.parentId,
    studentId: input.studentId,
    category: input.category,
    amount: -input.amount, // payments are credits (negative)
    type: "payment",
    sourceType: "payment",
    sourceId: payment.id,
    method: input.method,
    receiptNumber: payment.receiptNumber,
    paymentStatus: status,
    reversesId: null,
    description: `Encaissement ${payment.receiptNumber} — ${input.method} (${input.category ?? "multi-services"})`,
    actorId: collectedBy,
    actorName: "Session courante",
    at: payment.collectedAt,
    metadata: Object.freeze({
      installmentId: input.installmentId ?? null,
      proofUrl: input.proofUrl ?? null,
      checkNumber: payment.checkNumber ?? null,
      checkBankName: payment.checkBankName ?? null,
      transferReference: payment.transferReference ?? null,
      transferSourceBank: payment.transferSourceBank ?? null,
    }),
  };
  store.ledger = [...store.ledger, ledgerEntry];
  store.notifyLedger();

  // === 2. Run the waterfall allocator ===
  // For cash (status="paid"): increments amountPaid, possibly marks tranches "paid".
  // For check/transfer (status="pending"): increments amountPending ONLY;
  // status becomes "pending_clearance". Tranche is NOT satisfied until clearance.
  const allocationResult = await allocatePaymentAcrossInstallments(
    ctx,
    input.parentId,
    input.amount,
    payment.id,
    input.category,
    collectedBy,
    "Session courante",
    status,
  );

  // === 3. Record overpayment as parent_credit (if any) ===
  if (allocationResult.ok) {
    const unallocated = allocationResult.value.unallocatedAmount;
    // CANONICAL (INV-7 + 0034 SQL): EVERY positive unallocated amount becomes
    // a parent_credit entry. The legacy > 0.5 DZD tolerance silently swallowed
    // sub-half-dinar credits, diverging from the backend RPC (> 0).
    if (unallocated > 0.005) {
      const creditEntry: LedgerEntry = {
        id: `led-${nowIso()}-${Math.random().toString(36).slice(2, 10)}`,
        tenantId,
        // Parent-level credit account: student-scoped-null.
        accountId: deriveAccountId(input.parentId, "parent_credit", null),
        parentId: input.parentId,
        studentId: null,
        category: "parent_credit",
        amount: -unallocated, // negative = credit (school owes parent)
        type: "adjustment",
        sourceType: "adjustment",
        sourceId: `credit-${payment.id}`,
        method: null,
        // CANONICAL (0034 SQL): the parent_credit entry carries NO receipt
        // number — the source payment is referenced via metadata.sourcePaymentId.
        receiptNumber: null,
        paymentStatus: null,
        reversesId: null,
        description: `Crédit parent (excédent de paiement reçu ${payment.receiptNumber})`,
        actorId: collectedBy,
        actorName: "Session courante",
        at: nowIso(),
        metadata: Object.freeze({
          sourcePaymentId: payment.id,
          unallocatedAmount: unallocated,
          category: "parent_credit",
        }),
      };
      store.ledger = [...store.ledger, creditEntry];
      store.notifyLedger();
      appendAudit({
        action: AuditActions.PaymentAdjust,
        entityType: "adjustment",
        entityId: creditEntry.id,
        actorId: collectedBy,
        actorName: "Session courante",
        diff: {
          before: null,
          after: {
            amount: -unallocated,
            category: "parent_credit",
            sourcePaymentId: payment.id,
          },
        },
        note: `Excédent de paiement ${payment.receiptNumber} stocké comme crédit parent`,
      });
    }
  }

  appendAudit({
    action: AuditActions.PaymentCreate,
    entityType: "payment",
    entityId: payment.id,
    actorId: collectedBy,
    actorName: "Session courante",
    diff: {
      before: null,
      after: {
        amount: payment.amount,
        method: payment.method,
        receipt: payment.receiptNumber,
        ledgerEntryId: ledgerEntry.id,
        status: payment.status,
        allocations: allocationResult.ok ? allocationResult.value.allocations.length : 0,
        unallocatedCredit: allocationResult.ok ? allocationResult.value.unallocatedAmount : 0,
      },
    },
    note: `Encaissement ${payment.receiptNumber} — ${payment.method} (${payment.category}) ${payment.amount.toLocaleString("fr-FR")} DZD [${payment.status}]`,
  });
  // T-314 (event bridge): fire the DEPLOYED `payment_recorded` workflows
  // with a REAL entity context (parent + ledger debt + students). Fail-
  // safe: workflow errors never break the collection.
  void dispatchPaymentRecorded(input.parentId, {
    id: payment.id,
    amount: payment.amount,
    method: payment.method,
    // ADR-023: the bridge's category is a display string — null becomes
    // the multi-service label.
    category: payment.category ?? "multi_services",
  }, collectedBy).catch(() => {
    /* the bridge audit-logs its own failures */
  });
  return Ok(payment);
}

/**
 * Refund / cancel a payment atomically:
 *   1. Update `payments.status` to `"refunded"`.
 *   2. Append a ledger reversal entry that negates the original payment entry.
 *   3. Call `revertPaymentAllocation` (LIFO) to subtract the reversed
 *      amount from the installments' `amountPaid` (or `amountPending`
 *      when the original payment was uncleared) and re-evaluate statuses.
 *   4. Write an audit entry per affected installment.
 *
 * This implements Invariant 5 (Reversal Balance) and ensures tranches
 * are correctly re-opened when a check bounces or a payment is canceled.
 *
 * T-014 (BUSINESS-003): the caller's REAL reason and actor identity are now
 * propagated into the ledger reversal entry + audit entries (previously
 * hardcoded "Remboursement manuel" / "usr-current" / "Session courante").
 * The reason is mandatory (≥3 chars) and a second refund of an
 * already-reverted payment is rejected — mirroring the canonical
 * `revert_payment_allocation` RPC guard (migration 0041:493-495).
 */
export async function refundPayment(
  ctx: FinancialOpsCtx,
  id: string,
  reason: string,
  actorId?: string,
  actorName?: string,
): Promise<Result<Payment>> {
  const { store, appendAudit, nowIso, delay, tenantId } = ctx;
  const trimmed = reason.trim();
  if (trimmed.length < 3) {
    return Err(Errors.validation(
      "Un motif d'au moins 3 caractères est obligatoire pour rembourser un paiement",
    ));
  }
  await delay(200);
  const idx = store.payments.findIndex((p) => p.id === id);
  if (idx < 0) return Err(Errors.notFound("Payment", id));
  const before = store.payments[idx];
  // CANONICAL (revert_payment_allocation): only 'paid' | 'pending' payments
  // can be reverted — a second refund attempt is rejected, not idempotent.
  if (before.status !== "paid" && before.status !== "pending") {
    return Err(Errors.validation(
      `Le paiement ${before.receiptNumber} ne peut pas être remboursé (statut actuel : ${before.status})`,
    ));
  }
  const effectiveActorId = actorId ?? "usr-current";
  const effectiveActorName = actorName ?? "Session courante";
  const after: Payment = { ...before, status: "refunded", updatedAt: nowIso() };
  store.payments[idx] = after;
  store.notifyPayments();

  // === 1. Append the ledger reversal entry ===
  const originalLedgerEntry = store.ledger.find(
    (e) => e.sourceType === "payment" && e.sourceId === id && e.type === "payment",
  );
  if (originalLedgerEntry) {
    const reversalEntry: LedgerEntry = {
      id: `led-${nowIso()}-${Math.random().toString(36).slice(2, 10)}`,
      tenantId,
      accountId: originalLedgerEntry.accountId,
      parentId: originalLedgerEntry.parentId,
      studentId: originalLedgerEntry.studentId,
      category: originalLedgerEntry.category,
      // Original payment entry stored a NEGATIVE amount (credit).
      // Reversal negates it → POSITIVE amount (debit; parent owes it back).
      amount: -originalLedgerEntry.amount,
      type: "reversal",
      sourceType: "payment",
      sourceId: id,
      // CANONICAL (0034 revert_payment_allocation): refund reversals carry
      // method=NULL and paymentStatus=NULL — the reversal itself is the
      // record; duplicating the original's method/status made the typed
      // totals disagree with the backend RPC.
      method: null,
      receiptNumber: originalLedgerEntry.receiptNumber,
      paymentStatus: null,
      reversesId: originalLedgerEntry.id,
      description: `Remboursement ${before.receiptNumber} — ${trimmed} — inversion de l'écriture de paiement`,
      actorId: effectiveActorId,
      actorName: effectiveActorName,
      at: nowIso(),
      metadata: Object.freeze({
        refundReason: trimmed,
        originalPaymentId: id,
      }),
    };
    store.ledger = [...store.ledger, reversalEntry];
    store.notifyLedger();

    // === 2. Reverse the waterfall allocation (LIFO) ===
    // Determine whether the original payment was cleared or pending.
    const originalWasPending = originalLedgerEntry.paymentStatus === "pending";
    const parentInstallments = store.installments.filter((i) => i.parentId === before.parentId);
    const revertResult = revertPaymentAllocation(
      parentInstallments,
      before.amount,
      before.category,
      originalWasPending,
      // CANONICAL: re-evaluate tranche statuses at the operation's clock,
      // not the wall clock — matches the SQL RPC (as-of = transaction time)
      // and keeps offline/backdated refunds deterministic.
      new Date(nowIso()),
    );

    // === 3. Persist each revert ===
    for (const rev of revertResult.reverts) {
      const insIdx = store.installments.findIndex((i) => i.id === rev.installmentId);
      if (insIdx < 0) continue;
      const insBefore = store.installments[insIdx];
      store.installments[insIdx] = {
        ...insBefore,
        amountPaid: rev.newAmountPaid,
        amountPending: rev.newAmountPending,
        status: rev.newStatus,
        // Clear paidDate if the tranche is no longer satisfied.
        paidDate: rev.newStatus === "paid" ? insBefore.paidDate : null,
      };
      appendAudit({
        action: "installment.revert_allocation",
        entityType: "installment",
        entityId: rev.installmentId,
        actorId: effectiveActorId,
        actorName: effectiveActorName,
        diff: {
          before: {
            amountPaid: insBefore.amountPaid,
            amountPending: insBefore.amountPending,
            status: insBefore.status,
          },
          after: {
            amountPaid: rev.newAmountPaid,
            amountPending: rev.newAmountPending,
            status: rev.newStatus,
            reverted: rev.revertedAmount,
          },
        },
        note: `Inversion LIFO — paiement ${id} remboursé. Reverted ${rev.revertedAmount} DZD.`,
      });
    }
    if (revertResult.reverts.length > 0) {
      store.notifyInstallments();
    }

    appendAudit({
      action: AuditActions.PaymentRefund,
      entityType: "payment",
      entityId: id,
      actorId: effectiveActorId,
      actorName: effectiveActorName,
      diff: {
        before: { status: before.status, ledgerEntryId: originalLedgerEntry.id },
        after: {
          status: "refunded",
          reversalEntryId: reversalEntry.id,
          revertsCount: revertResult.reverts.length,
          totalReverted: revertResult.totalReverted,
          unreverted: revertResult.unrevertedAmount,
        },
      },
      note: `Remboursement ${before.receiptNumber} — inversion LIFO de ${revertResult.totalReverted.toLocaleString("fr-FR")} DZD sur ${revertResult.reverts.length} tranche(s)`,
    });
  } else {
    // No original ledger entry found — log a warning but still record the refund.
    appendAudit({
      action: AuditActions.PaymentRefund,
      entityType: "payment",
      entityId: id,
      actorId: effectiveActorId,
      actorName: effectiveActorName,
      diff: { before: { status: before.status }, after: { status: "refunded" } },
      note: "ATTENTION: aucune écriture de ledger correspondante trouvée pour le remboursement",
    });
  }
  return Ok(after);
}

/**
 * PENDING → PAID transition (vault §07.02 — "bank clearance verified").
 *
 * Marks an uncleared check / bank transfer as cleared by the bank:
 *   1. `payments.status` moves "pending" → "paid".
 *   2. Uncleared installment funds (`amountPending`) move into `amountPaid`,
 *      oldest tranche first (waterfall order), statuses re-evaluated —
 *      Invariant 4 (Cleared Funds Only).
 *   3. Audit entry records actor + timestamp + before/after deltas.
 */
export async function markPaymentCleared(
  ctx: FinancialOpsCtx,
  id: string,
  actorId: string,
  actorName: string = "Session courante",
): Promise<Result<Payment>> {
  const { store, appendAudit, nowIso, delay, tenantId } = ctx;
  await delay(200);
  const idx = store.payments.findIndex((p) => p.id === id);
  if (idx < 0) return Err(Errors.notFound("Payment", id));
  const before = store.payments[idx];
  if (before.status !== "pending") {
    return Err(Errors.conflict(`Seuls les paiements en attente peuvent être confirmés par la banque (statut actuel : ${before.status})`));
  }

  const after: Payment = { ...before, status: "paid", updatedAt: nowIso() };
  store.payments[idx] = after;
  store.notifyPayments();

  // === Move uncleared funds into cleared funds (waterfall order) ===
  const parentInstallments = store.installments.filter((i) => i.parentId === before.parentId);
  const clearResult = clearPendingAllocation(
    parentInstallments,
    before.amount,
    before.category,
    // CANONICAL: status re-evaluation at the operation's clock (matches the
    // SQL mark_payment_cleared RPC's transaction-time semantics).
    new Date(nowIso()),
  );
  for (const clr of clearResult.clears) {
    const insIdx = store.installments.findIndex((i) => i.id === clr.installmentId);
    if (insIdx < 0) continue;
    const insBefore = store.installments[insIdx];
    store.installments[insIdx] = {
      ...insBefore,
      amountPaid: clr.newAmountPaid,
      amountPending: clr.newAmountPending,
      status: clr.newStatus,
      paidDate: clr.fullySatisfied ? (insBefore.paidDate ?? nowIso()) : insBefore.paidDate,
    };
    appendAudit({
      action: "installment.clear_funds",
      entityType: "installment",
      entityId: clr.installmentId,
      actorId,
      actorName,
      diff: {
        before: {
          amountPaid: insBefore.amountPaid,
          amountPending: insBefore.amountPending,
          status: insBefore.status,
        },
        after: {
          amountPaid: clr.newAmountPaid,
          amountPending: clr.newAmountPending,
          status: clr.newStatus,
          cleared: clr.clearedAmount,
        },
      },
      note: `Compensation bancaire — paiement ${id} confirmé. ${clr.clearedAmount.toLocaleString("fr-FR")} DZD clearés.`,
    });
  }
  if (clearResult.clears.length > 0) {
    store.notifyInstallments();
  }

  // BUSINESS-107 (T-411 / migration 0115 parity): cleared funds that could
  // NOT move (every tranche at capacity) become a parent_credit entry —
  // previously the excess silently vanished from every read surface.
  if (clearResult.overflowCredit > 0.005) {
    const overflowEntry: LedgerEntry = {
      id: `led-${nowIso()}-${Math.random().toString(36).slice(2, 10)}`,
      tenantId,
      accountId: `parent:${before.parentId}:category:parent_credit`,
      parentId: before.parentId,
      studentId: null,
      category: "parent_credit",
      amount: -clearResult.overflowCredit,
      type: "adjustment",
      sourceType: "adjustment",
      sourceId: `credit-${before.id}`,
      method: null,
      receiptNumber: null,
      paymentStatus: null,
      reversesId: null,
      description: `Crédit parent (excédent de compensation — paiement ${before.receiptNumber})`,
      actorId,
      actorName,
      at: nowIso(),
      metadata: Object.freeze({
        sourcePaymentId: before.id,
        overflowCredit: clearResult.overflowCredit,
      }),
    };
    store.ledger = [...store.ledger, overflowEntry];
    store.notifyLedger();
  }

  appendAudit({
    action: "payment.mark_cleared",
    entityType: "payment",
    entityId: id,
    actorId,
    actorName,
    diff: {
      before: { status: "pending", amount: before.amount },
      after: {
        status: "paid",
        clearedInstallments: clearResult.clears.length,
        totalCleared: clearResult.totalCleared,
        overflowCredit: clearResult.overflowCredit,
      },
    },
    note: `Compensation bancaire confirmée pour ${before.receiptNumber} — ${before.method} de ${before.amount.toLocaleString("fr-FR")} DZD`,
  });
  // T-314 (event bridge): fire the DEPLOYED `payment_cleared_or_bounced`
  // workflows (cleared outcome). Fail-safe by contract.
  void dispatchPaymentClearedOrBounced(before.parentId, {
    id: before.id,
    amount: before.amount,
    method: before.method,
    outcome: "cleared",
  }, actorId).catch(() => {
    /* the bridge audit-logs its own failures */
  });
  return Ok(after);
}

/**
 * PENDING → UNPAID transition (vault §07.02 — "check bounces / transfer fails").
 *
 * Marks an uncleared non-cash payment as failed:
 *   1. `payments.status` moves "pending" → "unpaid".
 *   2. The uncleared allocation is reversed LIFO (`amountPending`
 *      decremented, statuses re-evaluated — tranches reopen).
 *   3. A reversal ledger entry exactly negates the original payment entry
 *      (Invariant 5).
 *   4. The mandatory reason is audit-logged with actor + timestamp.
 */
export async function markPaymentBounced(
  ctx: FinancialOpsCtx,
  id: string,
  reason: string,
  actorId: string,
  actorName: string = "Session courante",
): Promise<Result<Payment>> {
  const { store, appendAudit, nowIso, delay, tenantId } = ctx;
  await delay(200);
  const trimmedReason = reason.trim();
  if (!trimmedReason) {
    return Err(Errors.validation("Un motif est obligatoire pour marquer un paiement comme échoué (chèque sans provision / virement rejeté)"));
  }
  const idx = store.payments.findIndex((p) => p.id === id);
  if (idx < 0) return Err(Errors.notFound("Payment", id));
  const before = store.payments[idx];
  if (before.status !== "pending") {
    return Err(Errors.conflict(`Seuls les paiements en attente peuvent être marqués échoués (statut actuel : ${before.status})`));
  }

  const after: Payment = { ...before, status: "unpaid", notes: trimmedReason, updatedAt: nowIso() };
  store.payments[idx] = after;
  store.notifyPayments();

  // === 1. Append the ledger reversal entry (exactly negates the original) ===
  const originalLedgerEntry = store.ledger.find(
    (e) => e.sourceType === "payment" && e.sourceId === id && e.type === "payment",
  );
  if (originalLedgerEntry) {
    const reversalEntry: LedgerEntry = {
      id: `led-${nowIso()}-${Math.random().toString(36).slice(2, 10)}`,
      tenantId,
      accountId: originalLedgerEntry.accountId,
      parentId: originalLedgerEntry.parentId,
      studentId: originalLedgerEntry.studentId,
      category: originalLedgerEntry.category,
      amount: -originalLedgerEntry.amount,
      type: "reversal",
      sourceType: "payment",
      sourceId: id,
      method: originalLedgerEntry.method,
      receiptNumber: originalLedgerEntry.receiptNumber,
      paymentStatus: "unpaid",
      reversesId: originalLedgerEntry.id,
      description: `Échec d'encaissement ${before.receiptNumber} — chèque/virement rejeté`,
      actorId,
      actorName,
      at: nowIso(),
      metadata: Object.freeze({
        bounceReason: trimmedReason,
        originalPaymentId: id,
      }),
    };
    store.ledger = [...store.ledger, reversalEntry];
    store.notifyLedger();

    // === 2. Reverse the uncleared allocation (LIFO) — tranches reopen ===
    const parentInstallments = store.installments.filter((i) => i.parentId === before.parentId);
    const revertResult = revertPaymentAllocation(
      parentInstallments,
      before.amount,
      before.category,
      true, // original was pending — decrement amountPending
      // CANONICAL: re-evaluate at the operation's clock (SQL parity).
      new Date(nowIso()),
    );
    for (const rev of revertResult.reverts) {
      const insIdx = store.installments.findIndex((i) => i.id === rev.installmentId);
      if (insIdx < 0) continue;
      const insBefore = store.installments[insIdx];
      store.installments[insIdx] = {
        ...insBefore,
        amountPaid: rev.newAmountPaid,
        amountPending: rev.newAmountPending,
        status: rev.newStatus,
        paidDate: rev.newStatus === "paid" ? insBefore.paidDate : null,
      };
      appendAudit({
        action: "installment.revert_allocation",
        entityType: "installment",
        entityId: rev.installmentId,
        actorId,
        actorName,
        diff: {
          before: {
            amountPaid: insBefore.amountPaid,
            amountPending: insBefore.amountPending,
            status: insBefore.status,
          },
          after: {
            amountPaid: rev.newAmountPaid,
            amountPending: rev.newAmountPending,
            status: rev.newStatus,
            reverted: rev.revertedAmount,
          },
        },
        note: `Rejet bancaire — paiement ${id} échoué. Reverted ${rev.revertedAmount} DZD (fonds non clearés).`,
      });
    }
    if (revertResult.reverts.length > 0) {
      store.notifyInstallments();
    }

    appendAudit({
      action: "payment.mark_bounced",
      entityType: "payment",
      entityId: id,
      actorId,
      actorName,
      diff: {
        before: { status: "pending", amount: before.amount },
        after: {
          status: "unpaid",
          reason: trimmedReason,
          reversalEntryId: reversalEntry.id,
          revertsCount: revertResult.reverts.length,
          totalReverted: revertResult.totalReverted,
        },
      },
      note: `Rejet bancaire ${before.receiptNumber} (${before.method}) — motif : ${trimmedReason}`,
    });
  } else {
    appendAudit({
      action: "payment.mark_bounced",
      entityType: "payment",
      entityId: id,
      actorId,
      actorName,
      diff: { before: { status: "pending" }, after: { status: "unpaid", reason: trimmedReason } },
      note: `Rejet bancaire ${before.receiptNumber} — motif : ${trimmedReason} (aucune écriture de ledger correspondante)`,
    });
  }
  // T-314 (event bridge): fire the DEPLOYED `payment_cleared_or_bounced`
  // workflows (bounced outcome). Fail-safe by contract.
  void dispatchPaymentClearedOrBounced(before.parentId, {
    id: before.id,
    amount: before.amount,
    method: before.method,
    outcome: "bounced",
    reason: trimmedReason,
  }, actorId).catch(() => {
    /* the bridge audit-logs its own failures */
  });
  return Ok(after);
}

/** Adjust a parent's account (manual entry — appends an adjustment ledger entry). */
export async function adjustAccount(
  ctx: FinancialOpsCtx,
  parentId: string,
  amount: number,
  reason: string,
  approvedBy: string,
  options?: {
    category?: PaymentCategory;
    studentId?: string | null;
  },
): Promise<Result<AccountAdjustment>> {
  const { store, appendAudit, nowIso, delay, tenantId } = ctx;
  await delay(200);
  const adj: AccountAdjustment = {
    id: `adj-${Date.now()}`,
    parentId,
    amount,
    reason,
    approvedBy,
    approvedAt: nowIso(),
    receiptRef: null,
  };

  // CANONICAL RULES (Tier 3 R1.5 + studentId bug fix):
  //   - Credit (amount < 0): always written to the parent_credit account
  //     with studentId = null. This preserves INV-3.
  //   - Debit (amount > 0): written to the caller-specified category
  //     (default "tuition") and studentId (default null). When studentId
  //     is provided, the accountId is student-scoped.
  //
  // Before Tier 3, the mock always used category="other" + studentId=null
  // — divergent from the Supabase implementation which used parent_credit
  // for credits + tuition for debits. This unifies both modes.
  const isCredit = amount < 0;
  const category: PaymentCategory = isCredit
    ? "parent_credit"
    : (options?.category ?? "tuition");
  const studentId: string | null = isCredit ? null : (options?.studentId ?? null);
  const accountId = deriveAccountId(parentId, category, studentId);

  // VAULT §07.04 — full before/after JSON delta. The "before" snapshot is the
  // parent's outstanding balance BEFORE the adjustment; "after" is the balance
  // once the signed adjustment lands (debit ↑ debt, credit ↓ debt).
  const parentEntriesBefore = store.ledger.filter((e) => e.parentId === parentId);
  const balanceBefore = parentEntriesBefore.reduce((acc, e) => acc + e.amount, 0);
  const balanceAfter = balanceBefore + amount;

  const adjustmentEntry: LedgerEntry = {
    id: `led-${nowIso()}-${Math.random().toString(36).slice(2, 10)}`,
    tenantId,
    accountId,
    parentId,
    studentId,
    category,
    amount, // signed: + for debit (majoration — CALC-001: no penalties), - for credit (waiver)
    type: "adjustment",
    sourceType: "adjustment",
    sourceId: adj.id,
    method: null,
    receiptNumber: null,
    paymentStatus: null,
    reversesId: null,
    description: reason,
    actorId: approvedBy,
    actorName: "Session courante",
    at: nowIso(),
    metadata: Object.freeze({ reason, adjustmentId: adj.id, category, studentId }),
  };
  store.ledger = [...store.ledger, adjustmentEntry];
  store.notifyLedger();

  appendAudit({
    action: AuditActions.PaymentAdjust,
    entityType: "adjustment",
    entityId: adj.id,
    actorId: approvedBy,
    actorName: "Session courante",
    diff: {
      before: {
        parentOutstandingBalance: Math.round(balanceBefore * 100) / 100,
      },
      after: {
        parentOutstandingBalance: Math.round(balanceAfter * 100) / 100,
        amount,
        reason,
        ledgerEntryId: adjustmentEntry.id,
        category,
        studentId,
        kind: amount < 0 ? "credit" : "debit",
      },
    },
    note: `Ajustement manuel — ${amount > 0 ? "débit" : "crédit"} de ${Math.abs(amount).toLocaleString("fr-FR")} DZD (${reason})`,
  });
  return Ok(adj);
}

/** Generate a (mock) receipt PDF for an existing payment. */
export async function generateReceiptForPayment(
  ctx: FinancialOpsCtx,
  paymentId: string,
  generatedBy: string,
): Promise<Result<Receipt>> {
  const { store, appendAudit, nowIso, delay } = ctx;
  await delay(180);
  const p = store.payments.find((x) => x.id === paymentId);
  if (!p) return Err(Errors.notFound("Payment", paymentId));
  const receipt: Receipt = {
    id: `rcp-${Date.now()}`,
    paymentId,
    receiptNumber: p.receiptNumber,
    pdfUrl: `mock://receipts/${p.receiptNumber}.pdf`,
    generatedAt: nowIso(),
    generatedBy,
  };
  appendAudit({
    action: AuditActions.ReceiptGenerate,
    entityType: "receipt",
    entityId: receipt.id,
    actorId: generatedBy,
    actorName: "Session courante",
    diff: { before: null, after: { receiptNumber: p.receiptNumber, paymentId, pdfUrl: receipt.pdfUrl } },
    note: `Reçu généré pour le paiement ${p.receiptNumber} (${p.amount.toLocaleString("fr-FR")} DZD)`,
  });
  return Ok(receipt);
}
