/**
 * Repository interfaces — pure abstract contracts that any data layer
 * implementation (mock, Supabase, SQLite) must satisfy.
 *
 * Methods return Promises of Result<T> so failure modes are explicit in the
 * type system. Methods that return live data expose an Observable<T> via a
 * subscribe callback so React can re-render on backend changes.
 */
import type { Result } from "../../core/result";
import type { GradeEntryInput } from "./academic-repository";
import type { Session } from "../../core/rbac/session";
import type { Role } from "../../core/rbac/roles";
import type {
  Parent,
  CreateParentInput,
  UpdateParentInput,
} from "../model/parent";
import type { Student, CreateStudentInput, UpdateStudentInput, BatchRegistrationInput, BatchRegistrationResult, StudentDocument, StudentDocumentDraft } from "../model/student";
import type {
  AcademicClass,
  Subject,
  ClassSubject,
  Assessment,
  AttendanceRecord,
  AttendanceSession,
  AttendanceStatus,
  Homework,
  AcademicTerm,
  SubjectConfiguration,
} from "../model/academic";
import type {
  Payment,
  Installment,
  AccountAdjustment,
  ParentFinancialProfile,
  DebtSummary,
  Receipt,
  CollectPaymentInput,
  UpdateInstallmentDueDateInput,
  AcademicCycle,
  PaymentCategory,
  PaymentPlan,
  PaymentAllocation,
} from "../model/payment";
import type { AllocationResult } from "../calc/payment/waterfall-allocator";
// T-405 (financial-rules §15) — the debt-aging record type.
import type { DebtAgingAnalysis, DebtAgingThresholds } from "../calc/ledger/debt-aging";
import type {
  AppNotification,
  DashboardKpi,
  RevenuePoint,
  DebtByAgingBucket,
  DemographicSlice,
  CreateAlertInput,
} from "../model/operations";
import type {
  CalendarEvent,
  CreateCalendarEventInput,
} from "../model/calendar";
import type { Expense, SubmitExpenseInput } from "../model/expense";
import type {
  Personnel,
  ReleveEntry,
  ReleveActivity,
  SalaryAdjustment,
  SalaryAdjustmentType,
  SalaryPaymentRecord,
  PayrollMethod,
} from "../model/personnel";
import type { AttributedActivityEvent, AttributedActivityStream, AuditEntry, AuditLogFilter, AuditLogQueryResult } from "../model/audit";
import type { PricingConfig, PricingConfigSummary, PricingEntry, PricingCategory, DiscountType, DiscountCode } from "../model/pricing";
import type { LedgerEntry, ParentLedgerSummary } from "../model/ledger";
import type { GradeLevel } from "../model/student";
import type { TransportDestination } from "../model/parent";
import type { Workflow, WorkflowRun, WorkflowServerDryRun, WorkflowTriggerType, WorkflowNodeSubtype } from "../model/workflow";
import type { ArchiveInspection, BackupArchive, BackupRestoreResult } from "../model/backup";
import type { AIProviderConfig, AIProvider, AIRequest, AIResponse } from "../model/ai";
import type { PromotionRepository } from "./academic-repository";

/** Minimal Observable<T> contract — glues mock/supabase reactive reads to React. */
export type Subscriber<T> = (value: T) => void;
export interface Observable<T> {
  subscribe(fn: Subscriber<T>): () => void;
  get(): T;
}

export interface AuthRepository {
  signIn(email: string, password: string): Promise<Result<Session>>;
  signOut(): Promise<Result<void>>;
  refreshSession(): Promise<Result<Session | null>>;
  /**
   * Change the signed-in user's password. Contract (SEC-103, task T-003):
   * the implementation MUST re-authenticate with the current password,
   * persist the new one via the backend (Supabase: auth.updateUser) and
   * revoke the user's sessions. Returning Ok means the password REALLY
   * changed — callers may write an audit entry on that basis.
   */
  changePassword(currentPassword: string, newPassword: string): Promise<Result<void>>;
}

/** Input for an admin provisioning a login account for another user (T-079). */
export interface CreateAccountInput {
  /** Login email — must be unique across existing accounts. */
  email: string;
  /** Display name shown in the UI (stored as user_profiles.display_name). */
  fullName?: string;
  /** Optional contact phone. */
  phone?: string;
  /** Role assigned at creation — one of the 11 wire codes. */
  role: Role;
  /**
   * Initial password. When omitted/empty, the IMPLEMENTATION generates a
   * policy-compliant one (plan §12.04). The admin conveys it to the user
   * out-of-band; the user changes it at first sign-in (SEC-103 fixed the
   * changePassword path, so this loop is closed).
   */
  initialPassword?: string;
  /**
   * T-371 (WORKFORCE-501) — the employee record this account belongs to.
   * When set, the backend binds personnel.user_id to the new profile IN
   * the creation transaction (one atomic RPC), so the employee's own
   * profile / tasks / responsibilities resolve from the very first
   * sign-in. The selected employee must be active, in-tenant and not
   * already bound to another account (the EF/RPC guard; this contract
   * surfaces the rejection as an Err).
   */
  personnelId?: string;
}

/** Result of a successful account creation. */
export interface CreatedAccount {
  email: string;
  role: Role;
  /**
   * The initial password — returned EXACTLY ONCE so the admin can hand it
   * over. It is never persisted client-side and never written to the audit
   * log (SEC-100 lesson).
   */
  initialPassword: string;
  /**
   * T-371 — the bound employee, echoed once so the admin's confirmation
   * panel can show the association that was just created. Absent/null for
   * unlinked accounts (parents, students, …).
   */
  personnelCode?: string | null;
  /** T-371 — "Prénom Nom" of the bound employee, for display only. */
  personnelName?: string | null;
}

/** One row of the admin's accounts overview (T-371). */
export interface AccountOverviewEntry {
  /** user_profiles.id — the id tasks/assignee_ids key on. */
  profileId: string;
  email: string;
  displayName: string | null;
  status: string;
  /** Primary role code (first active assignment), when resolvable. */
  role: Role | null;
  /** The bound employee id (personnel.user_id match), when any. */
  personnelId: string | null;
  personnelCode: string | null;
  personnelName: string | null;
}

/**
 * Admin-side account administration (T-079). Kept SEPARATE from
 * AuthRepository: AuthRepository is the *self* authentication surface
 * (sign in/out, own password); this interface is the *admin* surface
 * (provisioning accounts for OTHER users). Supabase implementation goes
 * through the create-user-account Edge Function (super_admin only);
 * mock implementation mints into seedAccounts so created users can sign
 * in during dev/demo without a backend.
 */
export interface UserAccountRepository {
  createAccount(input: CreateAccountInput): Promise<Result<CreatedAccount>>;
  /**
   * T-371 — the accounts overview for the admin's verification surface:
   * every login account in the tenant with its role and its bound employee
   * (the association state the redesigned workflow creates). Read-only;
   * SuperAdmin-visible under RLS in Supabase mode.
   */
  listAccounts(): Promise<Result<AccountOverviewEntry[]>>;
  /**
   * T-381 — permanently remove a login account. The Supabase
   * implementation goes through the delete-user-account Edge Function
   * (super_admin only): profile + role assignments + auth identity are
   * removed, linked employees/parents are unbound. The owner-pinned admin
   * (admin@elimtiyaz.dz) and the caller's own account are refused by the
   * EF's guard rails.
   */
  deleteAccount(profileId: string): Promise<Result<void>>;
}

export interface ParentRepository {
  observe(): Observable<Parent[]>;
  observeById(id: string): Observable<Parent | null>;
  search(query: string): Promise<Result<Parent[]>>;
  createParent(input: CreateParentInput): Promise<Result<Parent>>;
  updateParent(id: string, input: UpdateParentInput): Promise<Result<Parent>>;
  deleteParent(id: string): Promise<Result<void>>;
  /**
   * T-421 (IMPORT-119): createParent with the UPSERT OUTCOME surfaced.
   *
   * The Supabase layer's createParent delegates to the idempotent
   * `upsert_parent_from_import` RPC, which RETURNS `out_was_inserted` —
   * information the plain Result<Parent> mapping drops. The Excel import's
   * compensating rollback must only delete parents the run actually
   * CREATED (an upsert that matched an existing parent must NOT push that
   * parent into the compensation log), and the run stats must count an
   * upsert-match as an UPDATE, not an INSERT.
   *
   * Optional: repositories without upsert semantics (the mock) may omit
   * it — callers must fall back to createParent and assume wasInserted.
   */
  createParentTracked?(input: CreateParentInput): Promise<Result<{ parent: Parent; wasInserted: boolean }>>;
}

export interface StudentRepository {
  observe(): Observable<Student[]>;
  observeByParent(parentId: string): Observable<Student[]>;
  observeByClass(classId: string): Observable<Student[]>;
  observeById(id: string): Observable<Student | null>;
  search(query: string): Promise<Result<Student[]>>;
  createStudent(parentId: string, input: CreateStudentInput): Promise<Result<Student>>;
  /**
   * T-421 (IMPORT-119): createStudent with the UPSERT OUTCOME surfaced.
   *
   * Same contract as createParentTracked: the Supabase layer's
   * `upsert_student_from_import` RPC returns `out_was_inserted`, and the
   * import's rollback + stats need it (only truly-created students join
   * createdStudentIds; an upsert-matched existing student counts as an
   * update). Optional — callers fall back to createStudent.
   */
  createStudentTracked?(parentId: string, input: CreateStudentInput): Promise<Result<{ student: Student; wasInserted: boolean }>>;
  updateStudent(id: string, updates: UpdateStudentInput): Promise<Result<Student>>;
  deleteStudent(id: string): Promise<Result<void>>;
  batchRegister(input: BatchRegistrationInput): Promise<Result<BatchRegistrationResult>>;
  promote(studentIds: string[], academicYear: string): Promise<Result<Student[]>>;
  /**
   * SYNC-110/T-372 — attach ONE document to a student against the CANONICAL
   * `student_documents` table (the store the web portal also reads/writes,
   * so the document becomes visible on BOTH platforms). The caller uploads
   * the binary to the media vault FIRST and passes the returned storage
   * path in `input.storagePath`. Replaces the removed full-array
   * `updateStudent({ documents })` clobber.
   */
  addStudentDocument(studentId: string, input: StudentDocumentDraft): Promise<Result<StudentDocument>>;
  /**
   * SYNC-110/T-372 — remove ONE document row (staff-only surface; the portal
   * deliberately offers no deletion). Honest zero-match semantics: deleting
   * an id that no longer exists returns a notFound Result, never a silent
   * success (AGENTS.md §15.30b).
   */
  removeStudentDocument(studentId: string, documentId: string): Promise<Result<void>>;
}

export interface ClassRepository {
  observe(): Observable<AcademicClass[]>;
  observeByLevel(level: string): Observable<AcademicClass[]>;
  observeById(id: string): Observable<AcademicClass | null>;
  createClass(input: Omit<AcademicClass, "id" | "tenantId" | "enrolledCount">): Promise<Result<AcademicClass>>;
  updateClass(id: string, updates: Partial<AcademicClass>): Promise<Result<AcademicClass>>;
  deleteClass(id: string): Promise<Result<void>>;
}

export interface SubjectRepository {
  observe(): Observable<Subject[]>;
  observeByLevel(level: string): Observable<Subject[]>;
  observeByClass(classId: string): Observable<ClassSubject[]>;
  /**
   * T-345 (MATIERE-500/ADR-018): the context-specific subject
   * configurations (subject × year × level × direction) — the single
   * source every surface resolves coefficients/recipes through.
   */
  observeConfigurations(): Observable<SubjectConfiguration[]>;
  /** Create/update ONE configuration row (non-retroactive: snapshots hold). */
  upsertSubjectConfiguration(
    input: Omit<SubjectConfiguration, "id" | "tenantId"> & { id?: string },
  ): Promise<Result<SubjectConfiguration>>;
  assignSubjectToClass(input: Omit<ClassSubject, "id">): Promise<Result<ClassSubject>>;
  removeSubjectFromClass(id: string): Promise<Result<void>>;
  /**
   * Iteration 3-E (plan §05): Subject CRUD for admin management.
   * Coefficient change should trigger GPA recompute for affected students
   * (handled at the repository implementation level).
   */
  createSubject(input: Omit<Subject, "id" | "tenantId">): Promise<Result<Subject>>;
  updateSubject(id: string, updates: Partial<Omit<Subject, "id" | "tenantId">>): Promise<Result<Subject>>;
  archiveSubject(id: string): Promise<Result<void>>;
}

export interface GradeRepository {
  observeForStudent(studentId: string): Observable<Assessment[]>;
  observeForClass(classId: string, academicYear?: string, term?: string): Observable<Assessment[]>;
  /**
   * T-352 (DASH-402): school-wide assessment stream (tenant-scoped).
   * The Analytics tab's risk engine needs EVERY student's marks; the
   * previous wiring queried `observeForClass("")` — a literal empty-UUID
   * filter matching ZERO rows (the whole Diagnostic Actif surface showed
   * GPA "—" while marks existed). Semantics: `academicYear`/`term` are
   * optional filters exactly as on observeForClass; no filters = the
   * entire tenant catalogue.
   */
  observeAll(academicYear?: string, term?: string): Observable<Assessment[]>;
  enterGrade(input: GradeEntryInput): Promise<Result<Assessment>>;
  enterGradesBatch(inputs: ReadonlyArray<GradeEntryInput>): Promise<Result<Assessment[]>>;
}

export interface AttendanceRepository {
  observeByClass(classId: string, date: string): Observable<AttendanceRecord[]>;
  /**
   * Observe attendance for a class over a date range [from, to] (inclusive).
   * FIX: the class attendance tab claimed "7 derniers jours" but only ever
   * queried a single day.
   */
  observeByClassRange(classId: string, from: string, to: string): Observable<AttendanceRecord[]>;
  observeByStudent(studentId: string, from: string, to: string): Observable<AttendanceRecord[]>;
  /**
   * T-352 (DASH-402): school-wide attendance stream over [from, to]
   * (tenant-scoped). The Analytics tab's risk engine previously called
   * `observeByStudent("", …)` — an empty-UUID filter matching ZERO rows,
   * so `calculateAttendanceRate([])` defaulted every student to 100%
   * (§WEAK-019 family inversion: missing data rendered as PERFECT
   * attendance).
   */
  observeAll(from: string, to: string): Observable<AttendanceRecord[]>;
  recordRollCall(input: {
    classId: string;
    date: string;
    session: AttendanceSession;
    statuses: ReadonlyMap<string, AttendanceStatus>;
    /**
     * VAULT §09.01 — arrival times (HH:MM) for students marked LATE.
     * Keyed by studentId; ignored for other statuses.
     */
    arrivalTimes?: ReadonlyMap<string, string>;
    recordedBy: string;
  }): Promise<Result<AttendanceRecord[]>>;
  /**
   * VAULT §09.04 — automated absence alerts. The implementation MUST:
   *   1. Count each student's absences for the CURRENT TERM (not a rolling
   *      window).
   *   2. Only act on students whose count reaches the threshold of 3 —
   *      "never send the alert before the threshold is hit".
   *   3. Flag the student (audit) and dispatch a parent notification.
   *
   * The input is the set of students that JUST became non-present in the
   * submitted roll call; the repository re-checks the threshold before
   * alerting.
   */
  alertAbsences(studentIds: string[]): Promise<Result<void>>;
  /**
   * T-040 (ATT-101): observe records whose justification is in the given
   * workflow state (default 'submitted' — the staff review queue).
   */
  observeJustifications(status?: "submitted" | "accepted" | "rejected"): Observable<AttendanceRecord[]>;
  /**
   * T-040 (ATT-101): staff decision on a submitted justification — writes
   * justification_status + reviewer + timestamp. 'none' records cannot be
   * reviewed; a previous decision may be overturned.
   */
  reviewJustification(input: {
    recordId: string;
    decision: "accepted" | "rejected";
    reviewedBy: string;
  }): Promise<Result<AttendanceRecord>>;
}

export interface HomeworkRepository {
  observeForClass(classId: string): Observable<Homework[]>;
  observeByTeacher(teacherId: string): Observable<Homework[]>;
  push(input: {
    classId: string;
    subjectId: string;
    teacherId: string;
    teacherName: string;
    title: string;
    description: string;
    dueDate: string;
    attachments: string[];
  }): Promise<Result<Homework>>;
}

export interface PaymentRepository {
  observe(): Observable<Payment[]>;
  observeByParent(parentId: string): Observable<Payment[]>;
  observeByStudent(studentId: string): Observable<Payment[]>;
  observeById(id: string): Observable<Payment | null>;
  /**
   * T-423 (CACHE-103, GitHub issue #23): force a re-read past the cache
   * TTL and await it — the Finances page's "Réessayer" hook for the
   * honest-degradation state. Optional: mock/test repositories never
   * degrade, so they need not implement it.
   */
  refresh?(): Promise<void>;
  /**
   * T-330 (58th session, 2026-09-13): the CANONICAL per-payment coverage
   * read — the `payment_allocations` rows written server-side by
   * collect_and_allocate_payment (the waterfall RPC, migration 0033).
   *
   * The Payment Breakdown UI consumes this as its PRIMARY source; the
   * ledger-derived receipt-number join (the previous only source) remains
   * the FALLBACK for legacy payments predating the table. The website
   * portal applies the IDENTICAL precedence
   * (src/lib/canonical/payment-coverage.ts) so the same payment produces
   * the same coverage lines on both platforms — the owner's cross-platform
   * consistency mandate.
   *
   * Optional so existing implementations (Android mirrors, test fakes)
   * keep compiling; the Supabase + Mock repositories both implement it.
   * RLS: payment_allocations_staff_write (0041) allows the staff SELECT.
   */
  allocationsForPayment?(paymentId: string): Promise<Result<readonly PaymentAllocation[]>>;
  /**
   * T-411 (DATA-029): the page-level stream of EVERY payment allocation —
   * the canonical per-service attribution source the Diagnostic tab's
   * CrossServiceMatrix consumes (where the waterfall actually put the
   * money, not the payment row's category). Optional like
   * `allocationsForPayment`; the Supabase implementation paginates at
   * 1000/page (§15.29c), the mock derives from its ledger stream.
   */
  observeAllocations?(): Observable<readonly PaymentAllocation[]>;
  collect(input: CollectPaymentInput, collectedBy: string): Promise<Result<Payment>>;
  /**
   * BULK IMPORT FIX: Batch-collect many payments in a SINGLE Supabase
   * INSERT call instead of one RPC per payment. ~100x faster for the
   * Excel importer.
   *
   * Falls back to looping `collect()` when the repository doesn't support
   * bulk collect.
   */
  bulkCollect?(inputs: ReadonlyArray<{ input: CollectPaymentInput; collectedBy: string }>): Promise<Result<readonly Payment[]>>;
  /**
   * T-421 (IMPORT-116/118): bulkCollect with per-chunk LANDED-ROW progress.
   *
   * `onProgress(landedRows)` fires after each successfully committed chunk
   * with the cumulative number of rows actually inserted so far — the honest
   * count the import's failure message reports when a LATER chunk fails
   * (chunks before the failure are already committed; the old message
   * falsely claimed "aucune écriture partielle"). Optional parameter —
   * existing callers are unaffected.
   */
  bulkCollectWithProgress?(inputs: ReadonlyArray<{ input: CollectPaymentInput; collectedBy: string }>, onProgress?: (landedRows: number) => void): Promise<Result<readonly Payment[]>>;
  /**
   * T-421 (IMPORT-116 — re-import idempotency): the payment_numbers of
   * every IMPORTED payment currently in the database (`IMP-…`). The Excel
   * import's flush preflights its pending batch against this set so a
   * re-import of an already-imported workbook writes NOTHING instead of
   * dying on the first all-conflicting chunk (live-proven: PostgREST's
   * `ignoreDuplicates` only arbitrates the PRIMARY KEY — cross-run
   * conflicts on (tenant_id, payment_number) raise 23505). Optional;
   * callers without it fall back to writing (first-import semantics).
   */
  listImportPaymentNumbers?(): Promise<Set<string>>;
  /**
   * Refund a payment (T-014 / BUSINESS-003 — canonical §7.2 contract).
   *
   * `reason` is MANDATORY (≥3 chars, user-provided — mirrored from the
   * refund-payment Edge Function contract) and `actorId`/`actorName` carry
   * the signed-in user's real identity so the audit trail attributes the
   * refund correctly. Implementations delegate to the canonical
   * `revert_payment_allocation` RPC (Supabase) or its TS mirror (mock) and
   * MUST reject a second refund of an already-refunded payment.
   */
  refund(id: string, reason: string, actorId: string, actorName?: string): Promise<Result<Payment>>;
  /**
   * PENDING → PAID transition (vault §07.02 — "bank clearance verified").
   *
   * Marks an uncleared check / bank transfer as cleared by the bank:
   *   1. `payments.status` moves `"pending"` → `"paid"`.
   *   2. Every installment holding uncleared funds from this payment has
   *      `amountPending` moved into `amountPaid` (oldest tranche first,
   *      mirroring the waterfall order), and its status is re-evaluated
   *      (Invariant 4: Cleared Funds Only — a tranche becomes `"paid"`
   *      only once cleared funds cover it).
   *   3. An audit entry records the transition (actor + timestamp).
   *
   * Cash payments are already `"paid"` — calling this on them returns a
   * conflict error.
   */
  markCleared(id: string, actorId: string, actorName?: string): Promise<Result<Payment>>;
  /**
   * PENDING → UNPAID transition (vault §07.02 — "check bounces / transfer
   * fails").
   *
   * Marks an uncleared non-cash payment as failed:
   *   1. `payments.status` moves `"pending"` → `"unpaid"`.
   *   2. The uncleared allocation is reversed LIFO (`amountPending`
   *      decremented, statuses re-evaluated — tranches reopen).
   *   3. A reversal ledger entry exactly negates the original payment entry
   *      (Invariant 5).
   *   4. The mandatory `reason` is audit-logged with the actor + timestamp.
   */
  markBounced(id: string, reason: string, actorId: string, actorName?: string): Promise<Result<Payment>>;
  /**
   * Apply a signed adjustment (debit or credit) to a parent's ledger.
   *
   * CANONICAL RULES (Tier 3 unification, R1.5):
   *   - If `amount < 0` (credit): the adjustment is written to the
   *     `parent_credit` account with `studentId = null` (parent-scoped).
   *     This preserves INV-3 ("negative balance on non-parent_credit
   *     account is a reconciler violation").
   *   - If `amount > 0` (debit, e.g. a majoration / remise cancellation —
   *     CALC-001: penalties do not exist): the adjustment
   *     is written to the caller-specified `category` (default `tuition`)
   *     and `studentId` (default `null`). When `studentId` is provided,
   *     the accountId is student-scoped; otherwise it is parent-scoped.
   *
   * The optional `category` and `studentId` parameters let callers apply
   * a positive adjustment to a non-tuition category (e.g. a canteen
   * surcharge) or to a specific student's account. When omitted, the
   * canonical defaults apply.
   *
   * @returns the created AccountAdjustment record (with `id` for audit trail)
   */
  adjust(
    parentId: string,
    amount: number,
    reason: string,
    approvedBy: string,
    options?: {
      category?: PaymentCategory;
      studentId?: string | null;
    },
  ): Promise<Result<AccountAdjustment>>;
  generateReceipt(paymentId: string, generatedBy: string): Promise<Result<Receipt>>;
  /**
   * Append an à-la-carte charge for an additional service (canteen, uniform,
   * books, 2nd apron). Used by the UnifiedPaymentModal `single_item` mode and
   * the parent drawer's "Sell service" action.
   *
   * UNIFIED ARCHITECTURE (Epic 4.3): ensures every billable service — not
   * just tuition + transport — writes a `charge` entry to `ledger_entries`.
   */
  appendManualCharge(input: {
    parentId: string;
    studentId: string;
    /** CALC-001: the REAL school services (PSY/ORTH/E-PLANT/Ratrapage/AUTISTE). */
    serviceQualifier:
      | "psy1"
      | "psy2"
      | "orth1"
      | "orth2"
      | "e_plant"
      | "ratrapage"
      | "autiste";
    description?: string;
  }, actorId: string): Promise<Result<LedgerEntry>>;
}

export interface InstallmentRepository {
  /**
   * All installments (tenant-wide). Used by the backup snapshot
   * (vault §13.01) and analytics surfaces.
   */
  observe(): Observable<Installment[]>;
  observeByParent(parentId: string): Observable<Installment[]>;
  observeByStudent(studentId: string): Observable<Installment[]>;
  observeById(id: string): Observable<Installment | null>;
  /**
   * T-423 (CACHE-103, GitHub issue #23): force a re-read past the cache
   * TTL and await it — the Finances page's "Réessayer" hook. Optional
   * (the mock never degrades).
   */
  refresh?(): Promise<void>;
  markPaid(id: string, paymentId: string): Promise<Result<Installment>>;
  /**
   * Waterfall Allocation Engine — distribute a payment across all
   * eligible unpaid/partial installments for a parent (oldest first).
   *
   * Returns the per-installment breakdown plus any leftover amount
   * (overpayment / parent credit). Guarantees Ledger ↔ Installment
   * mathematical consistency.
   *
   * @param parentId        Parent whose installments should be satisfied.
   * @param paymentAmount   Total amount being paid.
   * @param paymentId       The Payment ID (for audit trail linkage).
   * @param categoryFilter  Optional — restrict allocation to a single
   *                        category (e.g. "tuition" or "transport").
   * @param actorId         Audit actor ID.
   * @param actorName       Audit actor display name.
   */
  allocatePayment(
    parentId: string,
    paymentAmount: number,
    paymentId: string,
    categoryFilter?: PaymentCategory,
    actorId?: string,
    actorName?: string,
  ): Promise<Result<AllocationResult>>;
  /**
   * Iteration 9 — flexible installment schedules (plan §07.03 expansion).
   *
   * Override an installment's due date per parent to accommodate custom
   * payment agreements. The installment is marked `customSchedule: true`
   * and the optional note is recorded for audit visibility.
   */
  updateDueDate(input: UpdateInstallmentDueDateInput): Promise<Result<Installment>>;
  /**
   * Iteration 9 — cycle-based installment customization.
   *
   * Regenerate installments for a parent based on the given cycle's
   * default tranche template. Existing paid installments are preserved;
   * only pending / partial installments are re-templated.
   */
  regenerateForCycle(parentId: string, cycle: AcademicCycle, actorId: string, actorName: string): Promise<Result<readonly Installment[]>>;
  /** Find installments whose due date has passed but are not fully paid. Used by the automated overdue alert generator. */
  findOverdue(now?: Date): Promise<Result<readonly Installment[]>>;
  /**
   * Bulk-import an installment row idempotently.
   *
   * Used by the Excel importer to create one installment per tuition tranche
   * (Sept 15 / Dec 15 / Mar 15) and per transport tranche, marking them
   * paid/partial/unpaid according to the imported amounts. Re-importing the
   * same Excel row updates the same installment in place rather than
   * creating duplicates — identity is `(tenant, parentId, studentId, category, trancheNumber)`.
   *
   * Implementations:
   *   - Mock: appends to `store.installments` with the deterministic id
   *     `imp-${parentId}-${studentId}-${category}-${trancheNumber}`.
   *   - Supabase: calls the `upsert_installment_from_import` RPC.
   *
   * Implementations that don't support bulk import (none in this codebase,
   * but kept as a safety net) should return `Err(server("not implemented"))`.
   */
  importInstallment(input: ImportInstallmentInput): Promise<Result<Installment>>;
  /**
   * BULK IMPORT FIX: Batch-import many installments in a SINGLE Supabase
   * upsert call instead of one per installment. ~100x faster for the
   * Excel importer.
   *
   * Falls back to looping `importInstallment()` when the repository doesn't
   * support bulk import.
   */
  bulkImportInstallments?(inputs: readonly ImportInstallmentInput[]): Promise<Result<readonly Installment[]>>;
  /**
   * T-421 (IMPORT-116/118): bulkImportInstallments with per-chunk
   * LANDED-ROW progress — same contract as bulkCollectWithProgress.
   * Optional parameter; existing callers unaffected.
   */
  bulkImportInstallmentsWithProgress?(inputs: readonly ImportInstallmentInput[], onProgress?: (landedRows: number) => void): Promise<Result<readonly Installment[]>>;
  /**
   * T-421 (IMPORT-116 — re-import idempotency): the canonical tranche
   * identities of every IMPORTED installment currently in the database,
   * as `parentId|studentId|category|trancheNumber|academicYearId` keys
   * (the 0129 `installments_bulk_import_identity_idx` contract — YEAR-
   * SCOPED since T-439/DATA-055: the 6th key is the COALESCE year
   * component, `""` for NULL-year rows). The import's flush preflights
   * its pending batch against this set — a re-import of already-present
   * data writes NOTHING, while a NEXT-YEAR workbook's tranches for a
   * continuing student (a DIFFERENT obligation under the 0129 identity)
   * are NOT dropped as duplicates (the year-blind key silently ate
   * every new-year tranche — the client-side DATA-054). Optional;
   * callers without it fall back to writing.
   */
  listImportInstallmentIdentities?(): Promise<Set<string>>;
  /**
   * T-439 (DATA-055): resolve a due date to the tenant's academic-year
   * id — the SAME INV-14 window resolver the write path stamps with
   * (the Supabase twin's `resolveAcademicYearIdForDueDate`; the mock
   * twin's store windows). The import adapter uses it to build the
   * year-scoped preflight key for each pending row. Optional; when
   * absent the adapter falls back to the LEGACY year-blind key.
   */
  resolveImportAcademicYearId?(dueDate: string): Promise<string | null>;
  /**
   * T-466 (DEBT-102, the owner's manual-debt mandate): create a
   * PRE-EXISTING debt as a CANONICAL installment obligation — the explicit
   * "this person owes X DZD for THIS reason" write path.
   *
   * CANONICAL ARCHITECTURE (the owner's unified-financial-data mandate): the
   * created row is an installments row (source_type='manual_entry',
   * tranche_number NULL = the T-424/DATA-042 NON-WAVE row class, the
   * academic year stamped at write time per ADR-030) + the matching ledger
   * CHARGE entry, so the new obligation flows into EVERY debt surface by
   * construction — the Créances summary, the aging statuses, Year Tracking,
   * the Dashboard statistics, the CRM échéancier — and allocates through the
   * canonical payment waterfall exactly like a tranche. There is deliberately
   * NO second debt store and NO per-surface wiring (§15.53a).
   *
   * Supabase: the `create_manual_debt` RPC (migration 0137). Mock: the
   * deterministic `mdt-` id + the same ledger charge entry + the audit row.
   *
   * @returns the created installment row (the canonical debt record).
   *
   * OPTIONAL (the `bulkImportInstallments?` convention): the mock and the
   * Supabase repositories implement it; older fakes (test stubs, mirrors)
   * degrade honestly — callers MUST surface the unavailability instead of
   * fabricating a row (§15.15).
   */
  createManualDebt?(input: CreateManualDebtInput): Promise<Result<Installment>>;
}

/**
 * Input for `InstallmentRepository.importInstallment` — the bulk-import
 * path that creates or updates an installment row idempotently.
 *
 * The `trancheNumber` (0–3) plus `category`, `parentId`, `studentId`
 * form the identity key. Re-importing the same Excel row produces the same
 * identity key → the existing installment is updated rather than duplicated.
 * T-425 (the owner's confirmed official model): tuition is the
 * Registration + 3-Tranche structure — 0 = the REGISTRATION FEE (FI — a
 * fee, NOT a tranche; a non-wave row), 1..3 = Tranches 1/2/3 (V1/2V/v3 —
 * due Sept 15 / Dec 15 / Mar 15). There is NO 4th tranche (the old
 * "4ème TRANCHE" was the deleted BON receipt template's error); transport
 * stays 1..3 (1T/T2/t3).
 */
export interface ImportInstallmentInput {
  readonly parentId: string;
  readonly studentId: string;
  readonly category: PaymentCategory;
  readonly trancheNumber: 0 | 1 | 2 | 3;
  readonly label: string;
  readonly amountDue: number;
  readonly amountPaid: number;
  readonly dueDate: string;
  readonly paidDate: string | null;
  readonly status: "unpaid" | "partial" | "paid" | "overdue" | "pending_clearance";
  readonly academicCycle?: AcademicCycle;
  readonly paymentPlan?: PaymentPlan;
  readonly sourceType?: string;
  readonly sourceId?: string;
  readonly actorId?: string;
  readonly actorName?: string;
}

/**
 * Input for `InstallmentRepository.createManualDebt` — T-466 (DEBT-102):
 * the manual creation of a PRE-EXISTING debt obligation.
 *
 * Every field the owner's issue lists maps onto the canonical installment
 * record: person/family (parentId) · student (studentId — REQUIRED, the
 * installments table's own NOT NULL) · amount (amountDue) · reason/description
 * (label — the debt's own line item text; note joins the ledger description
 * + metadata) · associated service/fee/purchase/charge (category) · date
 * (dueDate) · academic year (academicYear — explicit code, else the INV-14
 * window resolver stamps it) · payment status/amount paid/remaining derive
 * canonically from the row (status starts 'unpaid', amountPaid/amountPending
 * 0, the INV-4 remaining = amountDue) · reference/source (reference — the
 * ledger metadata; the row's source_type='manual_entry' + source_id link
 * the installment to its ledger charge).
 */
export interface CreateManualDebtInput {
  readonly parentId: string;
  /** REQUIRED: the installments table's student_id is NOT NULL — the debt is
   *  anchored to one of the family's students (the family remains the debtor:
   *  parent_id is what every debt surface groups by). */
  readonly studentId: string;
  /** The associated service/fee/purchase/charge (the category CHECK list). */
  readonly category: PaymentCategory;
  /** The reason — what the debt represents (REQUIRED, >= 3 chars, e.g.
   *  "Achat uniforme" / "Frais de cantine impayés"). */
  readonly label: string;
  /** The amount owed (REQUIRED, > 0, DZD). */
  readonly amountDue: number;
  /** The debt date (REQUIRED, ISO yyyy-mm-dd). */
  readonly dueDate: string;
  /** Explicit academic-year code (e.g. "2026-2027"); null = the INV-14
   *  window resolver stamps it from the due date. */
  readonly academicYear?: string | null;
  /** Free detail note (ledger description + metadata). */
  readonly note?: string | null;
  /** External reference/source (ledger metadata). */
  readonly reference?: string | null;
  readonly actorId?: string;
  readonly actorName?: string;
}

export interface DebtRepository {
  observeSummary(): Observable<DebtSummary[]>;
  /**
   * T-423 (CACHE-103, GitHub issue #23): force the summary re-read past
   * the cache TTL and await it — the Finances page's "Réessayer" hook
   * (the refreshAging sibling for the Créances surface). Optional (the
   * mock never degrades).
   */
  refreshSummary?(): Promise<void>;
  observeParentProfile(parentId: string): Observable<ParentFinancialProfile | null>;
  /**
   * T-405 — cross-year debt aging & payment-behavior tracking
   * (financial-rules §15). One row per debtor family (installment
   * outstanding > 0.001 DZD): origin academic year, original due date,
   * debt age (never reset by partial payments), last payment, inactivity,
   * subsequent-year payment activity, and the canonical INV-16 status with
   * its explanation. The outstanding amount is the SAME canonical number
   * `observeSummary()` shows — never a second calculation.
   *
   * Supabase mode: the `compute_debt_aging_summary` RPC (migration 0111 —
   * the server-side canonical contract). Mock mode: `computeDebtAgingAnalysis`
   * (the TS reference engine) over the mock store.
   */
  observeAging(): Observable<DebtAgingAnalysis[]>;
  /**
   * T-443 (DEBT-101, financial-rules §15.1 INV-16f) — the tenant's ACTIVE
   * debt-aging thresholds (the `system_settings` category `debt`), the SAME
   * values `compute_debt_aging_summary` applies to its status/reason columns
   * and the SAME values every client-side derivation (the explanation
   * rendering, the Statistics triage edges, the Finances legend) must use.
   *
   * Supabase mode: the `read_debt_aging_thresholds` RPC (migration 0133 —
   * staff-gated like the aging surface itself, because `system_settings`
   * SELECT is RLS-restricted to super_admin/support_staff while the aging
   * audience includes financial_officer), kept in sync with the aging
   * seed's `applied_thresholds`. Mock mode: the documented DEFAULTS
   * (`DEFAULT_DEBT_AGING_THRESHOLDS` — mock mode has no settings backend
   * by design; INV-16f's configuration home is the server).
   */
  observeThresholds(): Observable<DebtAgingThresholds>;
  /**
   * Re-run the aging analysis after underlying financial facts changed
   * (payments, allocations, due dates). The Supabase path re-queries the
   * canonical RPC; the mock recomputes reactively (no-op).
   */
  refreshAging(): Promise<void>;
  sendReminder(parentId: string): Promise<Result<void>>;
  /**
   * VAULT §07.06 (Debt Dashboard — Actions) + §10.07 — "Broadcast Overdue
   * Payment Reminders": sends a reminder (notification + audit entry) to
   * EVERY debtor above `minDaysOverdue` (default 0 = all overdue debtors).
   * One-click admin bulk trigger — must be confirmation-gated in the UI.
   *
   * @returns the number of reminders dispatched.
   */
  broadcastReminders(minDaysOverdue?: number, actorId?: string): Promise<Result<number>>;
  /**
   * VAULT §07.06 (Actions) + §10.07 — "Lock Delinquent Accounts": applies
   * `FINANCIALLY_RESTRICTED` to every debtor overdue by more than
   * `minDaysOverdue` days (vault default: > 90 days). Each restriction is
   * audit-logged; already-restricted parents are skipped.
   *
   * @returns the number of accounts newly restricted.
   */
  lockDelinquentAccounts(minDaysOverdue?: number, actorId?: string): Promise<Result<number>>;
}

export interface ExpenseRepository {
  observe(): Observable<Expense[]>;
  observeByStatus(status: string): Observable<Expense[]>;
  observeById(id: string): Observable<Expense | null>;
  submit(input: SubmitExpenseInput, submittedBy: string): Promise<Result<Expense>>;
  approve(id: string, approver: string, note?: string): Promise<Result<Expense>>;
  reject(id: string, approver: string, note: string): Promise<Result<Expense>>;
  disburse(id: string, disbursedBy: string): Promise<Result<Expense>>;
  /**
   * VAULT §08.05 (Tier 3) — settle with the receipt proof AND the actual
   * final spent amount entered by staff. The financial officer verifies
   * the receipt against the disbursed amount before the ticket closes.
   */
  settleProof(id: string, proofUrl: string, uploadedBy: string, finalSpentAmount?: number): Promise<Result<Expense>>;
}

export interface PersonnelRepository {
  observe(): Observable<Personnel[]>;
  observeByCategory(category: string): Observable<Personnel[]>;
  observeById(id: string): Observable<Personnel | null>;
  /** Iteration 9: lookup by auth userId (replaces the displayName bridge hack). */
  observeByUserId(userId: string): Observable<Personnel | null>;
  createPersonnel(input: Omit<Personnel, "id" | "tenantId" | "weeklyHoursLogged">): Promise<Result<Personnel>>;
  updatePersonnel(id: string, updates: Partial<Personnel>): Promise<Result<Personnel>>;
  deletePersonnel(id: string): Promise<Result<void>>;
  /**
   * T-369 (74d3ebb commit / migration 0095) — the payroll surface.
   *
   * Salary adjustments are AUDITED, IMMUTABLE events: every raise/cut/
   * bonus/deduction carries a mandatory reason (min 5 chars, mirroring the
   * DB CHECK) and produces a permanent salary_adjustments row. raise/cut move
   * the base salary; bonus/deduction are one-offs that leave it unchanged.
   * In Supabase mode this goes through the canonical atomic RPC
   * `adjust_personnel_salary` (role-guarded, tenant-guarded, audit-logged
   * server-side); the mock mirrors the same semantics in memory.
   */
  adjustSalary(input: {
    personnelId: string;
    type: SalaryAdjustmentType;
    amount: number;
    reason: string;
    effectiveDate?: string;
    actorId: string;
    actorName: string;
  }): Promise<Result<SalaryAdjustment>>;
  /**
   * T-369 — records (or idempotently re-records) a monthly payroll payout.
   * Supabase mode: the canonical `record_salary_disbursement` RPC (unique per
   * tenant+personnel+period; the period's bonuses/deductions derived from
   * salary_adjustments server-side). Mock: the same semantics in memory.
   */
  recordSalaryPayment(input: {
    personnelId: string;
    period: string;
    method: PayrollMethod;
    referenceNumber?: string | null;
    notes?: string | null;
    actorId: string;
    actorName: string;
  }): Promise<Result<SalaryPaymentRecord>>;
  /** T-369 — the payroll disbursement ledger (drives the Payroll tab's paid/
   * unpaid statuses per period; RLS restricts reads to the finance roles +
   * own records server-side). */
  observeSalaryPayments(): Observable<SalaryPaymentRecord[]>;
}

export interface ReleveRepository {
  observeByPersonnel(personnelId: string, from: string, to: string): Observable<ReleveEntry[]>;
  logEntry(input: {
    personnelId: string;
    personnelName: string;
    date: string;
    hoursIn: number;
    hoursOut: number | null;
    activity: ReleveActivity;
    classId: string | null;
    subjectId: string | null;
  }): Promise<Result<ReleveEntry>>;
}

export interface AuditRepository {
  query(filter: AuditLogFilter): Promise<Result<AuditLogQueryResult>>;
  byEntity(entityType: string, entityId: string): Promise<Result<AuditEntry[]>>;
  recent(limit?: number): Promise<Result<AuditEntry[]>>;
  /**
   * T-299 (OFFLINE-400): the realtime attributed-activity stream — one
   * event per audit_logs INSERT (Actor name + role + account id, action,
   * target entity), broadcast cross-platform. The mock implementation
   * emits on `log()`; the Supabase implementation subscribes to the
   * audit_logs postgres-changes channel (migration 0085 adds the table to
   * the realtime publication — RLS still gates which rows each subscriber
   * receives).
   */
  observeActivity(): AttributedActivityStream;
  log(input: {
    action: string;
    entityType: string;
    entityId: string;
    actorId: string;
    actorName: string;
    /**
     * T-296 (OFFLINE-400): the actor's role at the time of the action — part
     * of the contextual audit schema (VAULT §12.02, migration 0014's
     * actor_role column). Optional for backward compatibility with existing
     * call sites; the UI renders it in the diff drawer's attribution block.
     */
    actorRole?: string | null;
    /** T-053: null = resolve the working tenant (throws for a global admin with no tenant picked). */
    tenantId: string | null;
    diff?: { before?: unknown; after?: unknown } | null;
    note?: string | null;
  }): Promise<Result<AuditEntry>>;
}

export interface NotificationRepository {
  observe(): Observable<AppNotification[]>;
  /** Reactive stream filtered to alerts visible to the given session (broadcast + user/role targeted). */
  observeForSession(session: { userId: string; role: import("../../core/rbac/roles").Role }): Observable<AppNotification[]>;
  markRead(id: string): Promise<Result<void>>;
  markAllRead(): Promise<Result<void>>;
  clear(): Promise<Result<void>>;
  /** Dismiss / delete a single alert by id. */
  dismiss(id: string): Promise<Result<void>>;
  /**
   * Iteration 9 — manually create a custom alert.
   *
   * Used by the Alert Creator modal (accessible from the main Alerts tab
   * AND from the Personnel workspace so non-admin staff can also create
   * alerts). The new alert is appended to the reactive stream.
   */
  create(input: CreateAlertInput): Promise<Result<AppNotification>>;
  /** Update an existing alert (e.g. reschedule a reminder, change priority). */
  update(id: string, updates: Partial<Omit<AppNotification, "id" | "createdAt">>): Promise<Result<AppNotification>>;
}

export interface DashboardRepository {
  kpis(): Promise<Result<DashboardKpi>>;
  revenueLast12Months(): Promise<Result<RevenuePoint[]>>;
  debtByAging(): Promise<Result<DebtByAgingBucket[]>>;
  /**
   * Demographic visualizations (plan §15.03).
   *
   * Returns 3 slices:
   *   - `grade`: student count per academic level (Primaire / CEM / Lycée)
   *   - `gender`: student count per gender
   *   - `age`: student count per age bucket (< 6, 6-8, 9-11, 12-14, 15-17, 18+)
   *
   * T-339 (61st session, STATS-400): the `capacity` fill-rate slice was
   * REMOVED — a class carries no artificial maximum (owner directive), so
   * fill-rate denominators were operationally false. The replacement is
   * the SECTION IMBALANCE derivation (executive-statistics.ts).
   */
  demographics(): Promise<Result<{ grade: DemographicSlice[]; gender: DemographicSlice[]; age: DemographicSlice[] }>>;
  /**
   * Iteration 9 — academic year + date range filtering.
   *
   * All KPI / chart calls can be scoped to a specific academic year and
   * (optionally) a finer-grained month/quarter/custom range. The default
   * call (no args) returns the current academic year's data.
   */
  kpisForRange(academicYear: string, range?: DateRange): Promise<Result<DashboardKpi>>;
  revenueForRange(academicYear: string, range?: DateRange): Promise<Result<RevenuePoint[]>>;
  debtByAgingForRange(academicYear: string, range?: DateRange): Promise<Result<DebtByAgingBucket[]>>;
}

/** Date range filter — used by the dashboard academic-year selector. */
export interface DateRange {
  readonly from: string; // ISO date
  readonly to: string;   // ISO date
}

/** Predefined range kinds surfaced in the dashboard selector UI. */
export type DateRangePreset = "ytd" | "month" | "quarter" | "custom";

/** Available academic years — populated by the mock from payment history. */
export interface AcademicYearInfo {
  readonly code: string; // "2025-2026"
  readonly startMonth: number; // 9 (September)
  readonly endMonth: number;   // 6 (June of following year)
}

export interface PricingRepository {
  observe(): Observable<PricingConfig>;

  updateRegistration(amount: number, updatedBy: string): Promise<Result<PricingConfig>>;
  updateMonthly(level: import("../model/student").AcademicLevel, amount: number, updatedBy: string): Promise<Result<PricingConfig>>;
  // CALC-001 (2026-09-13): updateLatePenalty REMOVED — penalties do not exist.
  addDiscount(input: { label: string; amount: number; discountType: DiscountType; discountCode?: DiscountCode }, updatedBy: string): Promise<Result<PricingConfig>>;
  removeDiscount(id: string, updatedBy: string): Promise<Result<PricingConfig>>;
  addAdditionalService(input: { label: string; amount: number }, updatedBy: string): Promise<Result<PricingConfig>>;
  removeAdditionalService(id: string, updatedBy: string): Promise<Result<PricingConfig>>;

  // ---- Iteration 6: granular pricing methods ----
  /** Update tuition for a specific grade level (annual + 3 installments). */
  updateTuitionForGradeLevel(
    gradeLevel: GradeLevel,
    annualAmount: number,
    installments: readonly [number, number, number],
    updatedBy: string,
  ): Promise<Result<PricingConfig>>;

  /** Update transport for a specific destination (annual + 3 installments). */
  updateTransportForDestination(
    destination: TransportDestination,
    annualAmount: number,
    installments: readonly [number, number, number],
    updatedBy: string,
  ): Promise<Result<PricingConfig>>;

  /** Update the 2nd apron surcharge. */
  updateSecondApronFee(amount: number, updatedBy: string): Promise<Result<PricingConfig>>;

  /** Add a complementary service (psychology, speech therapy, etc.) with semester & annual pricing. */
  addComplementaryService(input: {
    label: string;
    qualifier: string;
    semesterAmount: number;
    annualAmount: number;
  }, updatedBy: string): Promise<Result<PricingConfig>>;

  /** Remove a complementary service. */
  removeComplementaryService(id: string, updatedBy: string): Promise<Result<PricingConfig>>;

  // ---- T-414 (PRICING-500 / ADR-025, 2026-09-26): per-year configuration ----
  // Each academic year carries its own INDEPENDENT, COMPLETE price
  // configuration; exactly ONE config per tenant is ACTIVE and is the
  // single source of truth for new payments / invoices / charges /
  // calculations (`observe()` returns it). Inactive configs are historical
  // and read-only — financial records keep the prices applicable at their
  // time (balances replay stored ledger amounts; ADR-017 §4 / INV-1).

  /** List every pricing configuration (one per academic year) for the tenant. */
  listConfigs(): Promise<Result<readonly PricingConfigSummary[]>>;

  /**
   * Read a SPECIFIC year's configuration payload (read-only surface for
   * viewing/auditing historical or prepared configs). Falls back to the
   * seed grid per missing key — same shape as `observe()`'s payload.
   */
  readForYear(academicYearId: string): Promise<Result<PricingConfig>>;

  /**
   * Create a new configuration for an academic year (the 0006
   * unique (tenant_id, academic_year_id) keeps one config per year).
   * `cloneFromActive` copies the ACTIVE config's grids as the starting
   * point (year-over-year prices are usually a delta). The new config is
   * INACTIVE until `activateConfig` is called (ADR-025 §3: create → edit →
   * activate).
   */
  createConfigForYear(input: {
    academicYearId: string;
    label?: string;
    cloneFromActive: boolean;
  }, updatedBy: string): Promise<Result<PricingConfigSummary>>;

  /**
   * Atomically switch the tenant's ACTIVE configuration (the source of
   * truth for all NEW financial calculations). The previously active
   * config is preserved unchanged except `is_active = false` — historical
   * data is never re-priced.
   */
  activateConfig(configId: string, updatedBy: string): Promise<Result<void>>;
}

/**
 * Ledger repository — iteration 5.
 *
 * Single source of truth for all financial transactions. Every charge,
 * payment, adjustment, refund, and reversal is recorded here as an
 * immutable `LedgerEntry`. Balances are NEVER stored — they are always
 * computed by replaying the ledger via `computeParentSummary()`.
 */
export interface LedgerRepository {
  observe(): Observable<LedgerEntry[]>;
  observeByParent(parentId: string): Observable<LedgerEntry[]>;
  observeByAccount(accountId: string): Observable<LedgerEntry[]>;
  /**
   * T-423 (CACHE-103, GitHub issue #23): force a re-read past the cache
   * TTL and await it — the Finances page's "Réessayer" hook. Optional
   * (the mock never degrades).
   */
  refresh?(): Promise<void>;
  append(entry: LedgerEntry): Promise<Result<LedgerEntry>>;
  appendMany(entries: readonly LedgerEntry[]): Promise<Result<readonly LedgerEntry[]>>;
  /**
   * BULK IMPORT FIX: Batch-insert many ledger entries in a SINGLE Supabase
   * INSERT call instead of one RPC per entry. This is ~100x faster for the
   * Excel importer (390 rows × ~22 entries = ~8,580 entries → 1 INSERT
   * instead of 8,580 RPCs).
   *
   * Falls back to `appendMany` (loop) when the repository doesn't support
   * bulk insert (e.g. mock repository).
   */
  bulkAppend?(entries: readonly LedgerEntry[]): Promise<Result<readonly LedgerEntry[]>>;
  /**
   * T-421 (IMPORT-116/118): bulkAppend with per-chunk LANDED-ROW progress —
   * same contract as the payments'/installments' WithProgress variants.
   * Optional parameter; existing callers unaffected.
   */
  bulkAppendWithProgress?(entries: readonly LedgerEntry[], onProgress?: (landedRows: number) => void): Promise<Result<readonly LedgerEntry[]>>;
  /**
   * T-421 (IMPORT-116 — re-import idempotency): the `sourceType|sourceId`
   * identity keys of every bulk-import ledger entry currently in the
   * DATABASE (not a cache — live rows, read back paginated). The import's
   * flush preflights its pending batch against this set: re-imported
   * entries (whose `${studentId}:${field}` sourceIds already exist) are
   * skipped client-side, because the DB-level "guard" does NOT exist on
   * the wire — PostgREST's `ignoreDuplicates` only arbitrates the primary
   * key, so cross-run conflicts on the (partial) `ledger_entries_source_uidx`
   * raise 23505 (live-proven; on_conflict can't express the partial-index
   * predicate either — 42P10). Optional; callers without it fall back to
   * the observe()-cache keys (the legacy IMPORT-107 behavior).
   */
  listImportLedgerSourceKeys?(): Promise<Set<string>>;
  /** Reverse a prior entry by ID. Returns the new reversal entry. */
  reverse(originalId: string, reason: string, actorId: string, actorName: string): Promise<Result<LedgerEntry>>;
  /** Compute the full parent ledger summary (computed via replay — never stored). */
  summary(parentId: string): Promise<Result<ParentLedgerSummary>>;
  /** Run reconciliation against the entire ledger. */
  reconcile(): Promise<Result<import("../calc/reconcile").ReconciliationReport>>;
}

/* ------------------------------------------------------------------ */
/*  Iteration 7 — Workflow automation (plan §10)                       */
/* ------------------------------------------------------------------ */

/**
 * Workflow repository — plan §10.
 *
 * Visual DAG editor + execution monitor. Workflows are versioned: deploy
 * snapshots the current nodes/edges and marks the workflow as `deployed`.
 * Execute is manual-trigger only on desktop (plan §10.02).
 */
export interface WorkflowRepository {
  observe(): Observable<Workflow[]>;
  observeById(id: string): Observable<Workflow | null>;
  createWorkflow(input: {
    name: string;
    description: string;
    triggerType: WorkflowTriggerType;
    createdBy: string;
  }): Promise<Result<Workflow>>;
  updateWorkflow(
    id: string,
    updates: Partial<Pick<Workflow, "name" | "description" | "nodes" | "edges" | "triggerType" | "status">>,
    updatedBy: string,
  ): Promise<Result<Workflow>>;
  deleteWorkflow(id: string): Promise<Result<void>>;
  deploy(id: string, deployedBy: string): Promise<Result<Workflow>>;
  /**
   * Execute a workflow manually (plan §10.06 — manual triggers). Returns
   * the run record.
   *
   * T-314: executions now produce REAL side effects (tasks, notifications,
   * parent restriction, audit). The optional `options` carry the Test
   * Studio's real-entity context / target parent / event trigger subtype —
   * the legacy 3-argument call keeps working (default context).
   */
  execute(
    id: string,
    actorId: string,
    actorName: string,
    options?: {
      /** Execution context (Test Studio real-entity run; default when absent). */
      context?: Record<string, unknown>;
      /** The parent the run targets (restrict_account / recipients). */
      targetParentId?: string | null;
      /** Which trigger fired (event bridge; recorded in the audit trail). */
      triggerSubtype?: WorkflowNodeSubtype;
    },
  ): Promise<Result<WorkflowRun>>;
  /**
   * T-314 (event bridge): fire every DEPLOYED workflow whose trigger nodes
   * include `triggerSubtype`, with a real-entity context and REAL side
   * effects. Called by the school-domain repositories (roll call, payment
   * collection, enrollment). Optional — implementations without event
   * bridging (tests) may omit it; callers must feature-detect.
   */
  dispatchTrigger?(input: {
    triggerSubtype: WorkflowNodeSubtype;
    context: Record<string, unknown>;
    actorId: string;
    actorName: string;
    targetParentId?: string | null;
  }): Promise<Result<readonly WorkflowRun[]>>;
  /**
   * T-230: server dry-run (the EF's dry_run mode — real entity context,
   * simulated actions, zero side effects, no run row). Mock: the local
   * dry-run engine; Supabase: the canonical EF call.
   */
  dryRun(
    id: string,
    entity?: { parentId?: string; studentId?: string },
  ): Promise<Result<WorkflowServerDryRun>>;
}

/**
 * Workflow run repository — plan §10.04.
 *
 * Append-only log of workflow executions. Each run tracks per-node results
 * so the Exécutions tab can render a timeline.
 */
export interface WorkflowRunRepository {
  observe(): Observable<WorkflowRun[]>;
  observeByWorkflow(workflowId: string): Observable<WorkflowRun[]>;
  observeById(id: string): Observable<WorkflowRun | null>;
  retryRun(id: string, actorId: string, actorName: string): Promise<Result<WorkflowRun>>;
}

/* ------------------------------------------------------------------ */
/*  Iteration 7 — Backup & recovery (plan §13)                         */
/* ------------------------------------------------------------------ */

/**
 * Backup repository — iteration 7 (plan §13).
 *
 * AES-256-GCM encrypted archives written to a local IndexedDB vault with
 * 365-day rolling retention. The repository exposes metadata-only reads via
 * `observe()` — the ciphertext itself lives in the IndexedDB vault and is
 * fetched on demand by the service layer during restore.
 *
 * The repository also owns the encryption key derivation: a passphrase is
 * stored in `localStorage["el-imtiyaz:backup-passphrase"]` for the mock
 * implementation. Production (per plan §13.02) will swap this for a separate
 * secrets manager (HSM or Supabase secrets) — the `getEncryptionKey` contract
 * stays identical.
 */
export interface BackupRepository {
  /** Reactive metadata list (ciphertext is NOT exposed here — fetch by id on demand). */
  observe(): Observable<BackupArchive[]>;
  observeById(id: string): Observable<BackupArchive | null>;
  /** Run a new backup: serialize → gzip → AES-256-GCM → store → audit log. */
  runBackup(actorId: string, actorName: string): Promise<Result<BackupArchive>>;
  /** Restore an archive by id: fetch → decrypt → verify checksum → audit log. */
  restore(archiveId: string, actorId: string, actorName: string): Promise<Result<BackupRestoreResult>>;
  /**
   * T-300 (OFFLINE-400): inspect an archive OFFLINE — decrypt + verify +
   * parse WITHOUT restoring (the point-in-time selector's read path).
   * Corrupted archives return integrity: "corrupted" (no thrown error).
   */
  inspectArchive(archiveId: string): Promise<Result<ArchiveInspection>>;
  /** Delete a single archive (manual). Writes an audit entry. */
  deleteArchive(archiveId: string, actorId: string, actorName: string): Promise<Result<void>>;
  /** Purge all archives whose retentionExpiresAt has passed. Returns the purged archives. */
  purgeExpired(actorId: string, actorName: string): Promise<Result<BackupArchive[]>>;
  /** Derive the AES-256-GCM CryptoKey from the configured passphrase via PBKDF2. */
  getEncryptionKey(): Promise<Result<CryptoKey>>;
}

/* ------------------------------------------------------------------ */
/*  Iteration 7 — AI integration (plan §11)                            */
/* ------------------------------------------------------------------ */

/**
 * AI configuration repository — iteration 7 (plan §11).
 *
 * Owns the BYOK (Bring Your Own Key) provider config: Groq primary + OpenRouter
 * fallback. API keys are AES-256-GCM encrypted at rest in localStorage
 * (see `ai-config-storage.ts`) — the repository never exposes plaintext keys
 * via `observe()`; UI components display only a "Configuré / Non configuré"
 * badge based on whether the key is non-null.
 */
export interface AIConfigRepository {
  /** Reactive config stream — always emits the latest persisted config. */
  observe(): Observable<AIProviderConfig>;
  /** Update the persisted config. Writes an audit entry. */
  updateConfig(
    input: Partial<Omit<AIProviderConfig, "updatedAt" | "updatedBy">>,
    updatedBy: string,
  ): Promise<Result<AIProviderConfig>>;
  /** Ping the configured endpoint. Mock returns ok=true after 500ms. */
  testProvider(provider: AIProvider): Promise<Result<{ ok: boolean; latencyMs: number; error?: string }>>;
}

export interface LLMAdapter {
  generate(request: AIRequest): Promise<Result<AIResponse>>;
}

/* ------------------------------------------------------------------ */
/*  Iteration 9 — Calendar (plan §15 expansion)                        */
/* ------------------------------------------------------------------ */

/**
 * Calendar repository — iteration 9.
 *
 * Provides the daily activity log used by the Dashboard calendar:
 * payments received, audit log entries, expense events, plus any
 * manually scheduled follow-up calls / reminders / meetings / custom
 * events. Auto-generated events are derived from existing repositories;
 * manually scheduled events are persisted.
 */
export interface CalendarRepository {
  /** Reactive stream of all events for a date (YYYY-MM-DD). */
  observeForDate(date: string): Observable<CalendarEvent[]>;
  /** Reactive stream of all events in a month (YYYY-MM). */
  observeForMonth(yearMonth: string): Observable<CalendarEvent[]>;
  /** Manually schedule a new event. */
  create(input: CreateCalendarEventInput): Promise<Result<CalendarEvent>>;
  /** Update a manually scheduled event. */
  update(id: string, updates: Partial<CreateCalendarEventInput>): Promise<Result<CalendarEvent>>;
  /** Delete a manually scheduled event. Only manual events can be deleted. */
  delete(id: string): Promise<Result<void>>;
}

/* ------------------------------------------------------------------ */
/*  Iteration 9 — Automated overdue alert generator (plan §07.05)      */
/* ------------------------------------------------------------------ */

/**
 * Overdue alert generator — iteration 9.
 *
 * Scans installments whose due date has passed without payment
 * confirmation and produces `payment_overdue` alerts of priority
 * `high` or `urgent` (depending on days overdue). Idempotent: re-running
 * the generator for the same installment does NOT create duplicate
 * alerts — the generator keys dedup on `entityType=installment` +
 * `entityId=<installmentId>`.
 */
export interface OverdueAlertGenerator {
  /**
   * Scan installments and emit overdue alerts. Returns the list of newly
   * created alerts (empty if all overdue installments already had alerts).
   */
  run(now?: Date): Promise<Result<readonly AppNotification[]>>;
}

