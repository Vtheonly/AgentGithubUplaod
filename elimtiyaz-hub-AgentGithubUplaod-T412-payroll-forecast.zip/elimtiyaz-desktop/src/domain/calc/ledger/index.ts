/**
 * Ledger calculation module — public barrel.
 *
 * Re-exports all ledger calc submodules so callers can import everything
 * from `@domain/calc/ledger`.
 *
 * Submodules:
 *   - `account-id` — deriveAccountId
 *   - `balance`    — computeAccountBalance, computeParentSummary,
 *                    replayParentLedger, balanceForAccount,
 *                    totalOutstandingAcrossAccounts
 *   - `overdue`    — maxDaysOverdueFromLedger, buildOverdueDueDateMap
 *   - `debt-aging` — computeDebtAgingAnalysis, computeDebtAgingStatus,
 *                    resolveAcademicYearForDate (T-405, §15)
 *   - `entries`    — createChargeEntry, createPaymentEntry, createAdjustmentEntry,
 *                    createRefundEntry, createReversalEntry
 *   - `charges`    — buildTuitionChargeEntries, buildTransportChargeEntry,
 *                    buildTransportChargeEntriesForDestination
 */
export * from "./account-id";
export * from "./balance";
export * from "./overdue";
export * from "./debt-aging";
export * from "./entries";
export * from "./charges";
