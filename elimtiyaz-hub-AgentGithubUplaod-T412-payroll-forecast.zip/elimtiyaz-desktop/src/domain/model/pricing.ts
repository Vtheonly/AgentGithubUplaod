/**
 * Pricing Configuration domain — plan §"Administration".
 *
 * Hard rule: "All pricing must be configurable by administrators.
 *             Never hardcode payment values."
 *
 * The billing system reads amounts from this config — never from constants.
 * Adding or changing a price MUST NOT require modifying source code.
 *
 * Pricing is structured by category and qualifier:
 *   - Tuition: by granular grade level (prescolaire_1 ... 3eme_annee)
 *   - Transport: by named destination (ville_boumerdes / tidjelabine_sahel_figuier_corso /
 *                boudouaou_thenia_zemmouri / autres) — each with its own 3-tranche schedule
 *   - Registration: flat per academic year
 *   - Complementary services: psychology / speech therapy with semester & annual options
 *   - Additional services: free-form name → price (canteen, uniform, books, 2nd apron, clubs)
 *   - Discounts: named discount codes with percentage or fixed amount
 *   - (CALC-001, owner mandate 2026-09-13: NO penalties — the per-day late
 *     payment penalty concept was REMOVED from the engine entirely; never re-add)
 *
 * Iteration 6 changes:
 *   - Tuition is now keyed by `GradeLevel` (14 grades) instead of `AcademicLevel` (3 levels).
 *   - Each grade level has its own 3-tranche installment schedule.
 *   - Transport is now keyed by `TransportDestination` (4 named zones) with per-destination
 *     3-tranche schedules — replacing the abstract T1/T2/T3 tiers.
 *   - 5 canonical discount codes per the official 2026-2027 schedule:
 *       * passage_palier — fixed −10,000 DA (grade-level transition)
 *       * seniority_5y   — 5% (more than 5 years seniority)
 *       * full_annual    — 10% (full annual payment before June 30)
 *       * highest_average — 10% (student with highest average in grade level)
 *       * sibling_fixed  — fixed −5,000 DA per additional student
 *   - Complementary services (psychology, speech therapy) with semester/annual options.
 *   - 2nd apron surcharge (2,000 DA).
 *
 * Backward-compatibility helpers (`tuitionForLevel`, `transportForTier`) are kept
 * but delegate to the new structure with sensible defaults.
 */
import type { AcademicLevel } from "./student";
import type { GradeLevel } from "./student";
import { GRADE_LEVELS } from "./student";
import type { TransportDestination } from "./parent";
import { TRANSPORT_DESTINATIONS } from "./parent";

export type PricingCategory =
  | "tuition"
  | "transport"
  | "registration"
  | "monthly"
  | "discount"
  | "additional"
  | "complementary"; // CALC-001: "penalty" removed — penalties do not exist

export type DiscountType = "percentage" | "fixed_amount";

/**
 * Canonical discount codes recognized by the billing engine.
 * Adding a new code here automatically makes it selectable in the
 * Account Adjustment modal — no UI changes required.
 *
 * CALC-001 (2026-09-12): `passage_palier`, `highest_average` and
 * `seniority_5y` are FICTIONAL rules (never existed at the school — see
 * discount-rules.ts). The codes stay in the union for DB compatibility
 * (the `discounts` table CHECK constraint allows them) but they are marked
 * legacy and the engine never fires them.
 */
export type DiscountCode =
  | "passage_palier"
  | "seniority_5y"
  | "full_annual"
  | "highest_average"
  | "sibling_fixed"
  | "sibling_10"
  | "sibling_15"
  | "early_bird"
  | "negotiated_remise"
  | "custom";

export const DISCOUNT_CODE_LABELS_FR: Record<DiscountCode, string> = {
  passage_palier: "Passage de palier [RÈGLE FICTIVE — ne pas utiliser]",
  seniority_5y: "Ancienneté > 5 ans [RÈGLE FICTIVE — ne pas utiliser]",
  full_annual: "Paiement annuel avant le 30 juin (−5% scolarité)",
  highest_average: "Meilleure moyenne du palier [RÈGLE FICTIVE — ne pas utiliser]",
  sibling_fixed: "Fratrie — par enfant supplémentaire (−5 000 DA)",
  sibling_10: "Fratrie — 2ème enfant (−10%) [legacy]",
  sibling_15: "Fratrie — 3ème enfant et + (−15%) [legacy]",
  early_bird: "Paiement anticipé annuel (−5%) [legacy]",
  negotiated_remise: "Remise négociée (montant libre)",
  custom: "Remise personnalisée",
};

/** Single pricing entry. The `qualifier` disambiguates within a category. */
export interface PricingEntry {
  readonly id: string;
  readonly tenantId: string;
  readonly category: PricingCategory;
  /** Sub-key within the category: level for tuition, tier for transport, name for additional. */
  readonly qualifier: string;
  readonly label: string;
  /** Positive number for charges (tuition, transport, etc.) and penalties.
   *  For discounts: percentage (0-100) when type=percentage, or DZD amount when type=fixed_amount (negative). */
  readonly amount: number;
  readonly discountType?: DiscountType;
  /** For discounts, the canonical code (drives UI grouping + ledger metadata). */
  readonly discountCode?: DiscountCode;
  readonly isActive: boolean;
  readonly updatedAt: string;
  readonly updatedBy: string;
}

/**
 * Per-grade-level tuition configuration.
 *
 * The annual amount AND the 3-tranche installment schedule are both stored,
 * so each grade can have its own non-equal tranche split (per the official
 * 2026-2027 fee schedule where T1 ≠ T2 ≠ T3 for most grades).
 */
export interface TuitionPricing {
  readonly annualAmount: number;
  /** Exactly 3 tranches — `installments[0]` is due at registration, etc. */
  readonly installments: readonly [number, number, number];
  /**
   * T-334 (59th session): the per-tranche DUE MONTHS (1–12) as stored on
   * grade_level_tuition.tranche_*_month — the live grid carries THREE
   * variants (9/1/5, 9/12/3, 9/12/4). Optional: when absent the canonical
   * Prices.md template [9, 12, 3] (Sept 15 / Dec 15 / Mar 15) applies — the
   * same fallback the due-date templates use. Consumed by the exhaustive
   * per-service pricing profile (calc/payment/service-pricing-profile.ts).
   */
  readonly installmentMonths?: readonly [number, number, number];
}

/**
 * Per-destination transport configuration.
 *
 * Each destination has its own 3-tranche schedule:
 *   - Tranche 1: due at registration
 *   - Tranche 2: due Dec 01 – Dec 15
 *   - Tranche 3: due Mar 01 – Mar 15
 */
export interface TransportPricing {
  readonly annualAmount: number;
  readonly installments: readonly [number, number, number];
  /** T-334: per-tranche due months (transport_destinations.tranche_*_month). */
  readonly installmentMonths?: readonly [number, number, number];
}

/** Complementary service with semester & annual pricing options. */
export interface ComplementaryServicePricing {
  readonly semesterAmount: number;
  readonly annualAmount: number;
}

export interface PricingConfig {
  /** Per-grade-level tuition (14 entries — one per `GradeLevel`). */
  readonly tuitionByGradeLevel: Record<GradeLevel, TuitionPricing>;
  /** Per-destination transport (all towns + legacy zones). */
  readonly transportByDestination: Record<TransportDestination, TransportPricing>;
  /**
   * LEGACY flat family FI (deprecated — CALC-001). Kept because the
   * `pricing_configs.registration_fee` column and older UIs still read it.
   * New registrations charge `registrationFeeByGrade` PER STUDENT.
   */
  readonly registrationFee: number;
  /**
   * FI (frais d'inscription) per grade level — charged PER STUDENT.
   * Evidence: ETAT column R is per-student; the Devis sheet lists an F I
   * column per student line (HEBBAZ: 33000 + 33000 + 18000 for 3 children).
   */
  readonly registrationFeeByGrade: Record<GradeLevel, number>;
  readonly monthlyByLevel: Partial<Record<AcademicLevel, number>>;
  // CALC-001 (owner mandate 2026-09-13): `latePenaltyPerDay` REMOVED from the
  // model — no daily penalty exists at the school. Never re-add.
  readonly discounts: readonly PricingEntry[];
  readonly additionalServices: readonly PricingEntry[];
  /** Complementary services — psychology sessions, speech therapy sessions. */
  readonly complementaryServices: readonly (PricingEntry & ComplementaryServicePricing)[];
  /** 2nd apron surcharge — legacy fictional item (CALC-001); kept for compat. */
  readonly secondApronFee: number;
}

// ---------------------------------------------------------------------------
// Lookups & helpers — REFACTORED (iteration 1)
//
// The implementations now live in `@/domain/calc/pricing/`. The exports
// below are thin re-exports so existing imports from `@/domain/model/pricing`
// keep working. Once all call sites migrate to `@/domain/calc`, these
// re-exports can be removed.
// ---------------------------------------------------------------------------

export {
  tuitionForGradeLevel,
  tuitionForLevel,
  tuitionTranchesForGrade,
  tuitionTranches,
} from "../calc/pricing/tuition";

export {
  transportForDestination,
  transportForTier,
  transportTranchesForDestination,
} from "../calc/pricing/transport";

export {
  applyDiscount,
  findDiscountByCode,
  computeSiblingDiscount,
} from "../calc/pricing/discount-rules";

export const PRICING_CATEGORY_LABELS_FR: Record<PricingCategory, string> = {
  tuition: "Scolarité",
  transport: "Transport",
  registration: "Inscription",
  monthly: "Mensualité",
  discount: "Remise",
  additional: "Service additionnel",
  complementary: "Service complémentaire",
};

export const DISCOUNT_TYPE_LABELS_FR: Record<DiscountType, string> = {
  percentage: "Pourcentage",
  fixed_amount: "Montant fixe",
};

// Re-export transport destinations for convenience.
export { TRANSPORT_DESTINATIONS, GRADE_LEVELS };
