#!/bin/bash
# T-195 / MIG-TOKENS pattern (AGENTS.md §15 rule 10): apply migration 0079 live
# with its schema_migrations registration in ONE atomic transaction.
# Usage: SUPABASE_ACCESS_TOKEN=... bash apply_0079_live.sh
set -euo pipefail

SUPABASE_ACCESS_TOKEN="${SUPABASE_ACCESS_TOKEN:?Set SUPABASE_ACCESS_TOKEN in your environment before running}"
SUPABASE_SERVICE_ROLE_KEY="${SUPABASE_SERVICE_ROLE_KEY:?Set SUPABASE_SERVICE_ROLE_KEY (server-only key) to remove the storage bucket}"
PROJECT_REF="hkvkefubghbbotgnteir"
MIGRATION_FILE="$(dirname "$0")/../supabase/migrations/0079_drop_orphaned_receipts.sql"

# KNOWN QUIRK (AGENTS.md §11.1): the Management API SQL endpoint silently DROPS
# `COMMENT ON` statements — the catalog comments land only on fresh CLI
# deployments. The DDL + registration below persist normally.

PAYLOAD=$(mktemp /tmp/apply_0079.XXXXXX.sql)
{
  echo "BEGIN;"
  cat "$MIGRATION_FILE"
  echo "COMMIT;"
} > "$PAYLOAD"

echo "Applying 0079 to ${PROJECT_REF} (atomic)…"
HTTP_CODE=$(curl -s -o /tmp/apply_0079_response.json -w "%{http_code}" \
  -X POST "https://api.supabase.com/v1/projects/${PROJECT_REF}/database/query" \
  -H "Authorization: Bearer ${SUPABASE_ACCESS_TOKEN}" \
  -H "Content-Type: application/json" \
  --data "$(python3 -c "import json; print(json.dumps({'query': open('$PAYLOAD').read()}))")")

echo "HTTP ${HTTP_CODE}"
head -c 600 /tmp/apply_0079_response.json 2>/dev/null || true
echo ""
rm -f "$PAYLOAD"


# The storage BUCKET cannot be dropped via SQL (storage.protect_delete) —
# remove it through the Storage API (service key). Idempotent: 404 when gone.
echo "Deleting the empty 'receipts' storage bucket via the Storage API…"
HTTP_BUCKET=$(curl -s -o /tmp/bucket_del.json -w "%{http_code}" \
  -X DELETE "https://${PROJECT_REF}.supabase.co/storage/v1/bucket/receipts" \
  -H "apikey: ${SUPABASE_SERVICE_ROLE_KEY:-}" \
  -H "Authorization: Bearer ${SUPABASE_SERVICE_ROLE_KEY:-}")
echo "bucket delete HTTP ${HTTP_BUCKET}"; head -c 200 /tmp/bucket_del.json 2>/dev/null; echo ""

echo "Post-check:"
curl -s -X POST "https://api.supabase.com/v1/projects/${PROJECT_REF}/database/query" \
  -H "Authorization: Bearer ${SUPABASE_ACCESS_TOKEN}" \
  -H "Content-Type: application/json" \
  --data '{"query": "SELECT count(*) AS n, max(version) AS max_v FROM supabase_migrations.schema_migrations;"}'
echo ""
